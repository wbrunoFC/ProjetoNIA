package br.com.bb.gearq.c4coleta.manager;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.SecaoConversaBotBuilder.umSecaoConversaBot;
import static br.com.bb.databuilder.SecaoConversaBotParametrosEntradaBuilder.umSecaoConversaBotParametrosEntrada;

import br.com.bb.gearq.c4coleta.dao.LogNiaInfraDao;
import br.com.bb.gearq.c4coleta.dao.SecaoConversaBotDao;
import br.com.bb.gearq.c4coleta.model.SecaoConversaBot;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.SecaoConversaBotParametrosEntrada;



public class SecaoConversaBotManagerTest {
    @InjectMocks
    private SecaoConversaBotManager secaoConversaBotManager;
    
    @Mock
    private SecaoConversaBotDao secaoConversaBotDao;
    
    @Mock
    private LogNiaInfraDao logNiaInfraDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testProcessarSecaoConversaBot() {
        //Cenário
        Date dataConsulta = new Date();
        
        List<SecaoConversaBot> listaConversasBots = Arrays.asList(umSecaoConversaBot().build());
        
        SecaoConversaBot secaoConversaBot = listaConversasBots.get(0);
        
        //Mock
        when(secaoConversaBotDao.listarSecaoConversaBot(dataConsulta,logNiaInfraDao)).thenReturn(listaConversasBots);
        when(secaoConversaBotDao.persist(secaoConversaBot)).thenReturn(secaoConversaBot);
        
        //Ação
        secaoConversaBotManager.processarSecaoConversaBot(dataConsulta);
        
        //Verificação
        verify(secaoConversaBotDao, times(1)).listarSecaoConversaBot(dataConsulta, logNiaInfraDao);
        verify(secaoConversaBotDao, times(1)).persist(secaoConversaBot);
        
    }

    @Test
    public void testProcessarLegadoSecaoConversaBot() {
        //Cenário
        Calendar dataConsulta = Calendar.getInstance();
        Date dataConsulta2 = dataConsulta.getTime();
         
        List<SecaoConversaBot> listaConversasBots = Arrays.asList(umSecaoConversaBot().comId(1).build());
        
        SecaoConversaBot secaoConversaBot = listaConversasBots.get(0);
        
        //Mock
        when(secaoConversaBotDao.listarSecaoConversaBot(dataConsulta2,logNiaInfraDao)).thenReturn(listaConversasBots);
        
        //Ação
        secaoConversaBotManager.processarLegadoSecaoConversaBot(dataConsulta);
        
        //Verificação
    }
    
    
    @Test
    public void testGetListaConversasBots() {
        //Ação
        secaoConversaBotManager.getListaConversasBots();
    }

    @Test
    public void testSetListaConversasBots() {
        //Cenário
        List<SecaoConversaBot> listaConversasBots = Arrays.asList(umSecaoConversaBot().build());
        listaConversasBots.get(0).getId();
        listaConversasBots.get(0).getSiglaNuvem();
        listaConversasBots.get(0).getQuantidadeInteracao();
        listaConversasBots.get(0).getIdConversa();
        listaConversasBots.get(0).getChaveUsuario();
        listaConversasBots.get(0).getCodigoCanal();
        listaConversasBots.get(0).getDataInicio();
        listaConversasBots.get(0).getDataFim();
        listaConversasBots.get(0).getOrigem();
        listaConversasBots.get(0).hashCode();
        Object obj = new Object();
        listaConversasBots.get(0).equals(obj);
        listaConversasBots.get(0).toString();
        
        //Ação
        secaoConversaBotManager.setListaConversasBots(listaConversasBots);
    }
    
    @Test
    public void testSetListaConversasBots_ComObjNull() {
        //Cenário
        List<SecaoConversaBot> listaConversasBots = Arrays.asList(umSecaoConversaBot().build());
        listaConversasBots.get(0).getId();
        listaConversasBots.get(0).getSiglaNuvem();
        listaConversasBots.get(0).getQuantidadeInteracao();
        listaConversasBots.get(0).getIdConversa();
        listaConversasBots.get(0).getChaveUsuario();
        listaConversasBots.get(0).getCodigoCanal();
        listaConversasBots.get(0).getDataInicio();
        listaConversasBots.get(0).getDataFim();
        listaConversasBots.get(0).getOrigem();
        listaConversasBots.get(0).hashCode();
        Object obj = null;
        listaConversasBots.get(0).equals(obj);
        
        //Ação
        secaoConversaBotManager.setListaConversasBots(listaConversasBots);
    }

    @Test
    public void testListaSecaoConversaBotParametros() {
        //Cenário
        Date dtInicial = FormatarData.formatarStringParaData("20/01/2020");
        Date dtFinal = FormatarData.formatarStringParaData("30/01/2020");
        SecaoConversaBotParametrosEntrada entrada = umSecaoConversaBotParametrosEntrada().comDataInicial(dtInicial).comDataFinal(dtFinal).build();
        Paginacao<SecaoConversaBot> paginacao = new Paginacao<>();
        
        //Mock
        when(secaoConversaBotDao.listaSecaoConversaBotParametros(entrada,paginacao)).thenReturn(paginacao);
        
        //Ação
        secaoConversaBotManager.listaSecaoConversaBotParametros(entrada, paginacao);
        
        //Verificação
        verify(secaoConversaBotDao, times(1)).listaSecaoConversaBotParametros(entrada, paginacao);
    }
    
    @Test
    public void testListaSecaoConversaBotParametrosPeriodoPersonalizado() {
        //Cenário
        Date dtInicial = FormatarData.formatarStringParaData("20/01/2020");
        Date dtFinal = FormatarData.formatarStringParaData("30/01/2020");
        SecaoConversaBotParametrosEntrada entrada = umSecaoConversaBotParametrosEntrada().comIdPeriodo("PERSONALIZADO").comDataInicial(dtInicial).comDataFinal(dtFinal).build();
        Paginacao<SecaoConversaBot> paginacao = new Paginacao<>();
        
        //Mock
        when(secaoConversaBotDao.listaSecaoConversaBotParametros(entrada,paginacao)).thenReturn(paginacao);
        
        //Ação
        secaoConversaBotManager.listaSecaoConversaBotParametros(entrada, paginacao);
        
        //Verificação
        verify(secaoConversaBotDao, times(1)).listaSecaoConversaBotParametros(entrada, paginacao);
    }
    
}
