package br.com.bb.gearq.c4coleta.manager;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.InteracaoBotVOBuilder.umInteracaoBotVO;
import static br.com.bb.databuilder.PeriodoVOBuilder.umPeriodoVO;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;

import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao.PeriodoVO;
import br.com.bb.gearq.c4coleta.dao.RelatorioLogDao;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.RelatorioLog;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.gearq.c4coleta.vo.InteracaoBotVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class RelatorioLogManagerTest {
    @InjectMocks
    RelatorioLogManager relatorioLogManager;
    
    @Mock 
    private RelatorioLogDao relatorioLogDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testListarPorBotComValorPeriodoNUlo() {
        //Cenário
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo(null).build();
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
    }
    
    @Test
    public void testListarPorBotHoje() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("HOJE").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);
    }
    

    @Test
    public void testListarPorBotOntem() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("ONTEM").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);

    }
    
    @Test
    public void testListarPorBotUltimos7Dias() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("ULTIMOS_7_DIAS").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);

    }
    
    @Test
    public void testListarPorBotSemanaAtual() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("SEMANA_ATUAL").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);

    }
    
    @Test
    public void testListarPorBotSemanaPassada() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("SEMANA_PASSADA").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);

    }
    
    @Test
    public void testListarPorBotMesAtual() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("MES_ATUAL").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);

    }
    
    @Test
    public void testListarPorBotMesPassado() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("MES_PASSADO").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        verify(relatorioLogDao, times(1)).buscarPorListaIdInteracaoBot(interacaoBotVO);

    }
    
    @Test
    public void testListarPorBotOutro() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        
        Date dtInicio = FormatarData.formatarStringParaData("02/01/2020");
        Date dtFim = FormatarData.formatarStringParaData("01/01/2020");
        
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comDataInicial(dtInicio).comDataFinal(dtFim).comValorPeriodo("OUTRO").comListaListaBot(nuvem).build();
        
        //Ação
        assertThatThrownBy(() -> {
            relatorioLogManager.listarPorBot(interacaoBotVO);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("A data inícial deve ser anterior a data final");
        
    }
    
    @Test
    public void testListarPorBotOutroComDataNull() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().build();
        
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comValorPeriodo("OUTRO").comListaListaBot(nuvem).build();
        
        Paginacao<RelatorioLog> relatorio = new Paginacao<>();
        
        RelatorioLog relatorioLog = new RelatorioLog();
        relatorioLog.getNomeDiretoria();
        
        //Mock
        when(relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO)).thenReturn(relatorio);
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
    }
    
    @Test
    public void testListarPorBotOutroComListaNuvemNull() {
        //Cenário
        InteracaoBotVO interacaoBotVO = umInteracaoBotVO().comDataInicial(null).comDataFinal(null).comValorPeriodo("OUTRO").build();
        
        //Ação
        relatorioLogManager.listarPorBot(interacaoBotVO);
        
        //Verificação
        assertNull(relatorioLogManager.listarPorBot(interacaoBotVO));
        
    }

}
