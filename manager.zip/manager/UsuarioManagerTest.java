package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.UsuarioBuilder.umUsuario;
import static br.com.bb.databuilder.UsuarioVOBuilder.umUsuarioVO;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.model.Usuario;

public class UsuarioManagerTest {
    /**
     * @author c1312334
     */
    
    @InjectMocks
    private UsuarioManager usuarioManager;
    
    @Mock
    private UsuarioDao usuarioDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

//  === Cenario 1 === if (funci != null)
    @Test
    public void testObterUsuarioLogado() {
        // Cenario
        String chave = "Chave";
        
        Usuario usuario = null;
        
        UsuarioVO funci = umUsuarioVO().comChave(chave).build();
        
        // Mock
        when(usuarioDao.findByChave(chave)).thenReturn(usuario);
        
        // Açao 
        usuarioManager.obterUsuarioLogado(funci);
        
        // Verificaçao
        verify(usuarioDao, times(1)).findByChave(chave);
    }
    
//    === Cenario 2 === if (funci = null)
    @Test
    public void testFunciNull() {
        // Cenario
        String chave = "Chave";
        
        Usuario usuario = null;
        
        UsuarioVO funci = null;
        
        // Mock
        when(usuarioDao.findByChave(chave)).thenReturn(usuario);
        
        // Açao 
        usuarioManager.obterUsuarioLogado(funci);
        
        // Verificaçao
        verify(usuarioDao, times(0)).findByChave(chave);
    }

    @Test
    public void testObterIdUsuarioLogado() {
        // Cenario
        String chave = "Chave";
        
        UsuarioVO funci = umUsuarioVO().comId("10").comChave(chave).build();
        
        Usuario usuarioLogado = umUsuario().comId(10).build();
        usuarioLogado.getId();
        usuarioLogado.getEmail();
        usuarioLogado.getNome();
        usuarioLogado.getTipousuarioferramenta();
        usuarioLogado.getChaveNome();
        
        // Açao
        usuarioManager.obterIdUsuarioLogado(funci);
       
        // Mock
        when(usuarioDao.findByChave(chave)).thenReturn(usuarioLogado);
        
        // Verificação
        verify(usuarioDao, times(1)).findByChave(chave);
    }
    
    @Test
    public void testusuarioLogadoNull() {
        // Cenario
        String chave = "Chave";
        
        UsuarioVO funci = null;
        
        Usuario usuarioLogado = null;
        
        // Mock
        when(usuarioDao.findByChave(chave)).thenReturn(usuarioLogado);
        
        // Açao
        usuarioManager.obterIdUsuarioLogado(funci);
        
        // Verificaçao
        verify(usuarioDao, times(0)).findByChave(chave);
    }
}
