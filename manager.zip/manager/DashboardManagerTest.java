package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.DashboardBuilder.umDashboard;
import static br.com.bb.databuilder.PeriodoVOBuilder.umPeriodoVO;
import static br.com.bb.databuilder.QualidadeCorpusBuilder.umQualidadeCorpus;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import br.com.bb.gearq.c4coleta.audit.dto.QualidadeCorpus;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DashboardGeralDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao.PeriodoVO;
import br.com.bb.gearq.c4coleta.dao.UsuarioDashboardDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Dashboard;

public class DashboardManagerTest {
    /**
     * @author c1312334
     */
    
    @InjectMocks
    private DashboardManager dashboardManager;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private DashboardGeralDao dashboardGeralDao;
    
    @Mock
    private UsuarioDashboardDao usuarioDashboardDao;
    
    @Mock
    private RelatoriosGeralManager relatoriosGeralManager;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }
    
    @Test
    public void testComValorPeriodo_HOJE() {
        // Cenario
        String valorPeriodo = "HOJE";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
    @Test
    public void testComValorPeriodo_ONTEM() {
        // Cenario
        String valorPeriodo = "ONTEM";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
    @Test
    public void testComValorPeriodo_ULTIMOS_7_DIAS() {
        // Cenario
        String valorPeriodo = "ULTIMOS_7_DIAS";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
    @Test
    public void testComValorPeriodo_SEMANA_ATUAL() {
        // Cenario
        String valorPeriodo = "SEMANA_ATUAL";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
    @Test
    public void testComValorPeriodo_SEMANA_PASSADA() {
        // Cenario
        String valorPeriodo = "SEMANA_PASSADA";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
    @Test
    public void testComValorPeriodo_MES_ATUAL() {
        // Cenario
        String valorPeriodo = "MES_ATUAL";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
    @Test
    public void testComValorPeriodo_MES_PASSADO() {
        // Cenario
        String valorPeriodo = "MES_PASSADO";
        String dataInicial = "31/12/1969";
        String dataFinal = "07/02/2020";
        
        PeriodoVO periodo = umPeriodoVO()
                            .comInicio(new Date(06/02/2020))
                            .comFim(new Date(07/02/2020))
                            .build();
        
        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
                                                            .comDataCriacao(new Date(06/02/2020))
                                                            .comDataFinalizacao(new Date(07/02/2020))
                                                            .build());
        
        List<Dashboard> dashboards = Arrays.asList(umDashboard()
                                            .comDataConsulta(new Date(13/10/2020))
                                            .build()); 
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(dashboards);
        
        // Açao
        String retorno = valorPeriodo;
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
         assertEquals(valorPeriodo, retorno);
    }
    
//    @Test
//    public void testSemPeriodo() {
//        // Cenario
//        String valorPeriodo = "Sem Periodo";
//        String dataInicial = "31/12/1969";
//        String dataFinal = "07/02/2020";
//        String retorno = valorPeriodo;
//        
////        PeriodoVO periodo = umPeriodoVO()
////                            .comInicio(new Date(06/02/2020))
////                            .comFim(new Date(07/02/2020))
////                            .build();
//        
//        List<Classificador> listaClassificadores = Arrays.asList(umClassificador()
//                                                            .comDataCriacao(new Date(06/02/2020))
//                                                            .comDataFinalizacao(new Date(07/02/2020))
//                                                            .build());
//        
//        List<Dashboard> dashboards = Arrays.asList(umDashboard()
//                .comQtTotalPerguntas(2)
//                .comQtTotalSecao(2)
//                .comQtFeedbackPosit(2)
//                .comQtFeedbackNegat(2)
//                .comQtPerguntasCuradasRegua(2)
//                .comQtTotalPerguntasEnvGestor(2)
//                .comQtPerguntasNaocuradas(2)
//                .comQtPerguntasCuradasCurador(2)
//                .build());
//        
//        // Mock
//        when(dashboardGeralDao.findIdDashboard(listaClassificadores, Mockito.any(Date.class), Mockito.any(Date.class))).thenReturn(dashboards);
//        
//        // Açao
//        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
//        
//        // Verificaao
//         verify(dashboardGeralDao, times(0)).findIdDashboard(listaClassificadores, dataInicial, dataFinal);
//         assertEquals(retorno, valorPeriodo);
//    }
    
    @Test
    public void testComValorPeriodoNull() {
        // Cenario
        String valorPeriodo = null;
        String dataInicial = null;
        String dataFinal = null;
        
        List<Classificador> listaClassificadores = null;
        
        List<Dashboard> listaDashboards = null;
        
        PeriodoVO periodo = new PeriodoVO();
        periodo.setInicio(null);
        periodo.setFim(null);
        
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(listaDashboards);
        
        // Açao
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
        assertNull(valorPeriodo);
        assertNull(dataInicial);
        assertNull(dataFinal);
        assertNull(listaClassificadores);
        assertNull(listaDashboards);
        assertNotNull(periodo);
    }
    
    @Test
    public void testComListaEPeriodoNull() {
        // Cenario
        String valorPeriodo = "Invalido";
        String dataInicial = null;
        String dataFinal = null;
        
        List<Classificador> listaClassificadores = null;
        List<Dashboard> listaDashboards = Arrays.asList(umDashboard().build(),
                                                        umDashboard().build());
        listaDashboards.get(0).getId();
        listaDashboards.get(0).getQtTotalSecao();
        listaDashboards.get(0).getQtTotalPerguntasEnvGestor();
        listaDashboards.get(0).getQtTotalIntencoes();
        listaDashboards.get(0).getQtPerguntasCuradasCurador();
        int qtPerguntasCuradasCurador = 10;
        listaDashboards.get(0).setQtPerguntasCuradasCurador(qtPerguntasCuradasCurador);
        listaDashboards.get(0).getQtPerguntasCuradasRegua();
        listaDashboards.get(0).getMediaGrauConhecimento();
        listaDashboards.get(0).getQtdPerguntasCuradasExcluida();
        
        
        PeriodoVO periodo = umPeriodoVO().comFim(null).build();
        
        // Mock
        when(dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim())).thenReturn(listaDashboards);
        
        // Açao
        dashboardManager.recuperarDadosDashBoard(listaClassificadores, valorPeriodo, dataInicial, dataFinal);
        
        // Verificaao
        verify(dashboardGeralDao, times(0)).findIdDashboard(listaClassificadores, dataInicial, dataFinal);
    }

    @Test
    public void testRecuperarQualidadeCorpus() {
        // Cenario
        List<Classificador> classificadores = Arrays.asList(umClassificador().build());
        
        QualidadeCorpus qualidade = umQualidadeCorpus().build();
        // Mock
        when(dashboardGeralDao.findQtdPerguntasPorIntencao(classificadores)).thenReturn(qualidade);
        
        // Açao
        dashboardManager.recuperarQualidadeCorpus(classificadores);
        
        // Verificaçao
    }
    
    @Test
    public void testQualidadeNull() {
        // Cenario
        List<Classificador> classificadores = Arrays.asList(umClassificador().build());
        
        QualidadeCorpus qualidade = null;
        // Mock
        when(dashboardGeralDao.findQtdPerguntasPorIntencao(classificadores)).thenReturn(qualidade);
        
        // Açao
        dashboardManager.recuperarQualidadeCorpus(classificadores);
        
        // Verificaçao
        verify(dashboardGeralDao, times(1)).findQtdPerguntasPorIntencao(classificadores);
    }

}
