package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static br.com.bb.databuilder.VariavelContextoBuilder.umVariavelContexto;

import br.com.bb.gearq.c4coleta.dao.VariavelContextoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.VariavelContexto;
import br.com.bb.gearq.c4coleta.versionamento.v1.VariavelContextoVersaoV1;


public class VariavelContextoManagerTest {
    
    @InjectMocks
    private VariavelContextoManager variavelContextoManager;

    @Mock
    private VariavelContextoDao variavelContextoDao;

    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    
    @Test
    public void testListarVersao() {
        //Cenário
        int idClassificador = 1;
        
        List<VariavelContextoVersaoV1> variaveisVersao = new ArrayList<>();
        
        List<VariavelContexto> listaVariaveis = Arrays.asList(
                umVariavelContexto().build()
                );
        
        VariavelContexto variavel = listaVariaveis.get(0);
        
        variaveisVersao.add(new VariavelContextoVersaoV1(variavel));
        
        //Mock
        when(variavelContextoDao.findByIdClassificador(idClassificador)).thenReturn(listaVariaveis);
        
        //Ação
        variavelContextoManager.listarVersao(idClassificador);
        
        //Verificação
        verify(variavelContextoDao, times(1)).findByIdClassificador(idClassificador);
    }

    
    @Test
    public void testSalvar() {
        //Cenário
        int idClassificador = 1;
        VariavelContexto entity = umVariavelContexto().comId(2).build();
        
        entity.setIdClassificador(idClassificador);
        
        //Mock
        variavelContextoDao.persist(entity);
        
        //Ação
        variavelContextoManager.salvar(idClassificador, entity);
        
        //Verificação
        verify(variavelContextoDao, times(2)).persist(entity);
    }
    
    @Test
    public void testLimparPorClassificador() {
        //Cenário
        int idClassificador = 1;

        List<VariavelContexto> lista = Arrays.asList(
                umVariavelContexto().comId(1).build()
                );
        
        VariavelContexto vc = lista.get(0);
        vc.getVariavelContexto();
        vc.getClassificador();
        Classificador classificador = new Classificador();
        vc.setClassificador(classificador);
        vc.getIdClassificador();
        
        //Mock
        when(variavelContextoDao.findByIdClassificador(idClassificador)).thenReturn(lista);
        VariavelContexto vc2 = variavelContextoDao.findById(vc.getId());
        
        variavelContextoDao.remove(vc2);
        
        //Ação
        variavelContextoManager.limparPorClassificador(idClassificador);
        
        //Verificação
        verify(variavelContextoDao, times(1)).findByIdClassificador(idClassificador);
        verify(variavelContextoDao, times(2)).findById(vc.getId());
    }
    
    @Test
    public void testLimparPorClassificador_ComClassificadorNull() {
        //Cenário
        int idClassificador = 1;

        List<VariavelContexto> lista = Arrays.asList(
                umVariavelContexto().comId(1).build()
                );
        lista.get(0).getVariavelContexto();
        
        VariavelContexto vc = lista.get(0);
        vc.getVariavelContexto();
        vc.getClassificador();
        Classificador classificador = null;
        vc.setClassificador(classificador);
        vc.getIdClassificador();
        
        //Mock
        when(variavelContextoDao.findByIdClassificador(idClassificador)).thenReturn(lista);
        VariavelContexto vc2 = variavelContextoDao.findById(vc.getId());
        
        variavelContextoDao.remove(vc2);
        
        //Ação
        variavelContextoManager.limparPorClassificador(idClassificador);
        
        //Verificação
        verify(variavelContextoDao, times(1)).findByIdClassificador(idClassificador);
        verify(variavelContextoDao, times(2)).findById(vc.getId());
    }
    
}
