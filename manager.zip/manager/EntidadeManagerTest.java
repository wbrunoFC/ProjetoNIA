package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AgruparEntidadeSinonimosBuilder.umAgruparEntidadeSinonimos;
import static br.com.bb.databuilder.BuscaAvancadaEntidadeVOBuilder.umBuscaAvancadaEntidadeVO;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.EntidadeBuilder.umEntidade;
import static br.com.bb.databuilder.FluxoBuilder.umFluxo;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.MigrarEntidadeVOBuilder.umMigrarEntidadeVO;
import static br.com.bb.databuilder.SinonimoBuilder.umSinonimo;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jsoup.select.Evaluator.IsEmpty;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AgrupadorSinonimosDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeVODao;
import br.com.bb.gearq.c4coleta.dao.SinonimoDao;
import br.com.bb.gearq.c4coleta.model.AgruparEntidadeSinonimos;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Sinonimo;
import br.com.bb.gearq.c4coleta.model.TipoAgrupador;
import br.com.bb.gearq.c4coleta.vo.BuscaAvancadaEntidadeVO;
import br.com.bb.gearq.c4coleta.vo.EntidadeVO;
import br.com.bb.gearq.c4coleta.vo.MigrarEntidadeVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class EntidadeManagerTest {
    /**
     * @author c1312334
     */

    @InjectMocks
    private EntidadeManager entidadeManager;
    
    @Mock
    private EntidadeDao entidadeDao;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private AgrupadorSinonimosDao agrupadorSinonimosDao;
    
    @Mock
    private SinonimoDao sinonimoDao;
    
    @Mock
    private FluxoManager fluxoManager;
    
    @Mock
    private EntidadeVODao entidadeVODao;
    
    @Mock
    private CacheProgresso cacheProgresso;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }
    
    @Test
    public void testFindByClassificadorFluxo() {
        // Cenario
        int idClassificador = 1;
        String nome = "";

        // Acao
        entidadeManager.findByClassificadorFluxo(idClassificador, nome);
        
        // Verificacao
        Assert.assertTrue(nome.length() < 2);
        Assert.assertTrue(nome.trim().isEmpty());
        verify(entidadeDao, times(0)).findByClassificadorFluxo(idClassificador, nome);
        
    }   
    
    
    @Test
    public void testListarEntidadesIntStringPaginacaoOfEntidadeIntBooleanBoolean() {
        // Cenario
        int idClassificador = 1;
        String entidade = "Entidade";
        int colunaOrdenacao = 2; 
        boolean asc = true;
        boolean showsys = true;

        AgruparEntidadeSinonimos agruparEntidades = umAgruparEntidadeSinonimos().build();
        
        Paginacao<Entidade> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umEntidade()
                .comIdClassificador(idClassificador)
                .comListaAgrupadores(agruparEntidades)
                .build()));
        
        // Mock
        when(entidadeDao.findEntidade(paginacao, idClassificador, entidade, colunaOrdenacao, asc, showsys)).thenReturn(paginacao);
        
        // Açao
        entidadeManager.listarEntidades(idClassificador, entidade, paginacao, colunaOrdenacao, asc, showsys);
        
        // Verificaçao
        verify(entidadeDao,times(1)).findEntidade(paginacao, idClassificador, entidade, colunaOrdenacao, asc, showsys);
    }

    @Test
    public void testListarEntidadesVO() {
        // Cenario
        int idClassificador = 2;
        String entidade = new String("Entidade");
        int colunaOrdenacao = 1;
        boolean asc = true;
        boolean showsys = true;
        
        Paginacao<EntidadeVO> paginacao = new Paginacao<>();
        
        // Mock
        when(entidadeVODao.findEntidadeVO(paginacao, idClassificador, entidade, colunaOrdenacao, asc, showsys)).thenReturn(paginacao);
        
        // Açao
        entidadeManager.listarEntidadesVO(idClassificador, entidade, paginacao, colunaOrdenacao, asc, showsys);
    }

    @Test
    public void testListarEntidadesIntStringPaginacaoOfEntidadeIntBoolean() {
        // Cenario
        int idClassificador = 2;
        String entidade = new String("Entidade");
        int colunaOrdenacao = 1;
        boolean asc = true;
        
        Paginacao<Entidade> paginacao = new Paginacao<>();
        
        // Mock
        when(entidadeDao.findEntidade(paginacao, idClassificador, entidade, colunaOrdenacao, asc, false)).thenReturn(paginacao);
        
        // Açao
        entidadeManager.listarEntidades(idClassificador, entidade, paginacao, colunaOrdenacao, asc);
    }

    @Test
    public void testListarEntidadesClassiFluxo() {
        // Cenario
        int idClassificador = 2; 
        String entidade = "Entidade";
        
        List<Classificador> Classificador = Arrays.asList(umClassificador().comId(idClassificador).build());
        
        List<Entidade> listEntidade = Arrays.asList(umEntidade().comClassificador(Classificador.get(0)).comNome(entidade).build());
        
        // Mock
        when(entidadeDao.findByClassificadorFluxo(idClassificador, entidade)).thenReturn(listEntidade);
        
        // Açao
        entidadeManager.listarEntidadesClassiFluxo(idClassificador, entidade);
        
        // Verificaçao
        verify(entidadeDao, times(1)).findByClassificadorFluxo(idClassificador, entidade);
    }

    @Test
    public void testListarEntidadesSistema() {
        // Cenario
        int idClassificador = 2;
        
        List<Entidade> entidades = new ArrayList<Entidade>();
        
        List<Entidade> entidades2 = entidades;
        
        // Açao
        entidadeManager.listarEntidadesSistema(idClassificador);
        
        // Verificaçao
        assertEquals(entidades, entidades2);
    }

    @Test
    public void testBuscarEntidadePorNomeExato() {
        // Cenario
        String nome = new String("Nome");
        int idClassificador = 1;
        
        List<Entidade> entidade = new ArrayList<>();
        
        // Açao
        when(entidadeDao.findByNomeExato(idClassificador, nome)).thenReturn(entidade);
        entidadeManager.buscarEntidadePorNomeExato(nome, idClassificador);
     
        // VerificaçaoS
        verify(entidadeDao, times(1)).findByNomeExato(idClassificador, nome);
    }

    @Test
    public void testSalvar() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("Nome")
                                                                        .comId(4) 
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("Nome Diferente")
                                                        .comTipo(TipoAgrupador.SINONIMOS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Nome Diferente")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Nome")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0)); 
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Entidade Nome já existe!");
        
    }
    
    @Test
    public void testSalvarComNomeEntidadeFormularioDiferenteDeEntidadeConsulta() {
     // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome Igual")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Nome Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Integer idSinonimo = new Integer(15);
        Sinonimo sinonimo = umSinonimo()
                .comNome("Nome Diferente")
                .comId(14)
                .build();
        when(sinonimoDao.persist(sinonimo)).thenReturn(sinonimo);
        
        Sinonimo sinonimoConsulta = umSinonimo()
                .comNome("Nome sinonimoConsulta")
                .comId(idSinonimo)
                .build();
        when(sinonimoDao.findIdSinonimo(sinonimo.getId())).thenReturn(sinonimoConsulta);
        
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("Nome")
                                                                        .comId(4)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("Nome Diferente")
                                                        .comTipo(TipoAgrupador.SINONIMOS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        when(agrupadorSinonimosDao.findByIdAgrupador(listaAgrupadores.get(0).getId())).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.persist(listaAgrupadores.get(0))).thenReturn(agrupadorConsulta);
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Nome Diferente")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Nome")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .comId(listaAgrupadores.get(0).getId())
                                                    .build());
        when(entidadeDao.findById(Mockito.eq(4))).thenReturn(listaEntidade.get(0));
        
        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
        
        // Verificaçao
        verify(sinonimoDao, times(1)).persist(sinonimo);
        verify(sinonimoDao, times(1)).findIdSinonimo(sinonimo.getId());
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(listaAgrupadores.get(0).getId());
        verify(agrupadorSinonimosDao, times(1)).persist(listaAgrupadores.get(0));
        verify(entidadeDao, times(1)).findById(Mockito.eq(4));
        verify(entidadeDao, times(1)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(2)).persist(entidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
    }
    
    @Test
    public void testSalvarSinonimoConsultaComNomeIgualAoDoSinonimo() {
     // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome Igual")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Nome Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Integer idSinonimo = new Integer(15);
        Sinonimo sinonimo = umSinonimo()
                .comNome("Nome Sinonimo Igual")
                .comId(14)
                .build();
        when(sinonimoDao.persist(sinonimo)).thenReturn(sinonimo);
        
        Sinonimo sinonimoConsulta = umSinonimo()
                .comNome("Nome Sinonimo Igual")
                .comId(idSinonimo)
                .build();
        when(sinonimoDao.findIdSinonimo(sinonimo.getId())).thenReturn(sinonimoConsulta);
        
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("Nome")
                                                                        .comId(4)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("Nome Diferente")
                                                        .comTipo(TipoAgrupador.SINONIMOS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        when(agrupadorSinonimosDao.findByIdAgrupador(listaAgrupadores.get(0).getId())).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.persist(listaAgrupadores.get(0))).thenReturn(agrupadorConsulta);
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Nome Diferente")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Nome")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .comId(listaAgrupadores.get(0).getId())
                                                    .build());
        when(entidadeDao.findById(Mockito.eq(4))).thenReturn(listaEntidade.get(0));
        
        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
        
        // Verificaçao
        verify(sinonimoDao, times(0)).persist(sinonimo);
        verify(sinonimoDao, times(1)).findIdSinonimo(sinonimo.getId());
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(listaAgrupadores.get(0).getId());
        verify(agrupadorSinonimosDao, times(1)).persist(listaAgrupadores.get(0));
        verify(entidadeDao, times(1)).findById(Mockito.eq(4));
        verify(entidadeDao, times(1)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(2)).persist(entidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
    }
    
    @Test
    public void testSalvarComCenarioDeTesteOIdDoSinonimoIgualAZero() {
     // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome Igual")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Nome Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Integer idSinonimo = new Integer(15);
        Sinonimo sinonimo = umSinonimo()
                .comNome("Nome Diferente")
                .comId(0)
                .build();
        when(sinonimoDao.persist(sinonimo)).thenReturn(sinonimo);
        
        Sinonimo sinonimoConsulta = umSinonimo()
                .comNome("Nome sinonimoConsulta")
                .comId(idSinonimo)
                .build();
        when(sinonimoDao.findIdSinonimo(sinonimo.getId())).thenReturn(sinonimoConsulta);
        
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("Nome")
                                                                        .comId(4)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("Nome Diferente")
                                                        .comTipo(TipoAgrupador.SINONIMOS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        when(agrupadorSinonimosDao.findByIdAgrupador(listaAgrupadores.get(0).getId())).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.persist(listaAgrupadores.get(0))).thenReturn(agrupadorConsulta);
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Nome Diferente")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Nome")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .comId(listaAgrupadores.get(0).getId())
                                                    .build());
        when(entidadeDao.findById(Mockito.eq(4))).thenReturn(listaEntidade.get(0));
        
        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
        
        // Verificaçao
        verify(sinonimoDao).persist(sinonimo);
        verify(sinonimoDao, times(0)).findIdSinonimo(sinonimo.getId());
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(listaAgrupadores.get(0).getId());
        verify(agrupadorSinonimosDao, times(1)).persist(listaAgrupadores.get(0));
        verify(entidadeDao, times(1)).findById(Mockito.eq(4));
        verify(entidadeDao, times(1)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(2)).persist(entidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
    }
    
    @Test
    public void testSalvarComCenarioContrarioParaAgruparEntidadeSinonimosEEntidade() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("")
                                                                        .comId(0) 
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("")
                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Diferente")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);

        // Verificaçoa
        verify(entidadeDao, times(1)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId());
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
        
    }
    
    @Test
    public void testSalvarComListaEntidadeSemListaAgrupadoresS() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("")
                                                                        .comId(0) 
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("")
                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Diferente")
                                                    .comIdClassificador(22)
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);

        // Verificaçoa
        verify(entidadeDao, times(1)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId());
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
        
    }
    
    @Test
    public void testSalvarComAgrupadoresVazio() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos().build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = new AgruparEntidadeSinonimos();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Diferente")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores()
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);

        // Verificaçoa
        verify(entidadeDao, times(1)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId());
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
        
    }
    
    @Test
    public void testSalvarComFuzzyMatchDeEntidadeConsultaFalse() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("")
                                                                        .comId(0)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("")
                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Diferente")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);

        // Verificaçoa
        verify(entidadeDao, times(0)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId());
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
        
    }
    
    @Test
    public void testSalvarComFuzzyMatchFalse() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("")
                                                                        .comId(0)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("")
                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Diferente")
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);

        // Verificaçoa
        verify(entidadeDao, times(0)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId());
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
        
    }
    
    @Test
    public void testSalvarComAgrupadoresEComEntidadeCadastrada() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("Nome Agrupador")
                                                                        .comId(null)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("Nome Agrupador")
                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Nome Agrupador")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Nome")
                                                    .comId(10)
                                                    .comIdClassificador(22)
                                                    .comListaAgrupadores(listaAgrupadores.get(0))
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Entidade Nome já existe!");
    }
    
    @Test
    public void testSalvarComAgrupadorCadastrado() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo buscarSinonimo = umSinonimo().comId(10).build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(buscarSinonimo);
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("agrupador")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                .comAgruparSinonimo(agrupadorA)
                .comAgruparSinonimo(agrupadorB)
                .comNome(agrupadorA.getNome())
                .comId(0)
                .comNome("Sinonimo")
                .build());
        
        Integer idEntidade = 0;
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("agrupador")
                                                                                    .comNome(agrupadorA.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("agrupador já existe!");
    }
    
    @Test
    public void testSalvarComIdDoAgrupador() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo buscarSinonimo = umSinonimo().comId(10).build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(buscarSinonimo);
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("agrupador")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                .comAgruparSinonimo(agrupadorA)
                .comAgruparSinonimo(agrupadorB)
                .comNome(agrupadorA.getNome())
                .comId(0)
                .comNome("Sinonimo")
                .build());
        
        Integer idEntidade = 0;
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("agrupador")
                                                                                    .comNome(agrupadorA.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("agrupador já existe!");
    }
    
    @Test
    public void testSalvarComAgrupadoresNull() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        Integer idAgruparEntidadeSinonimos = new Integer(2);
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(false)
                .build();
        
        Sinonimo sinonimo = umSinonimo().comNome("Nome Diferente").build();
        List<AgruparEntidadeSinonimos> listaAgrupadores = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                        .comNome("")
                                                                        .comId(0)
                                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                                        .comListaSinonimos(sinonimo)
                                                                        .build());
        
        AgruparEntidadeSinonimos agrupadorConsulta = umAgruparEntidadeSinonimos()
                                                        .comNome("")
                                                        .comTipo(TipoAgrupador.PATTERNS)
                                                        .comId(3)
                                                        .comListaSinonimos(sinonimo)
                                                        .build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("")
                                                                                    .build());
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comNome("Entidade Diferente")
                                                    .comIdClassificador(22)
                                                    .build());

        //Mock
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(listaEntidade.get(0));
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(listaAgrupadores.get(0)); 
        when(agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos)).thenReturn(agrupadorConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId())).thenReturn(listaAgrupadores);
        when(agrupadorSinonimosDao.persist(agrupadorConsulta)).thenReturn(listaAgrupadores.get(0));
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)))).thenReturn(listaAgruparEntidadeSinonimos);
        
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);

        // Verificaçoa
        verify(entidadeDao, times(0)).findIdEntidade(entidade.getId());
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
        verify(entidadeDao, times(0)).findIdEntidade(idEntidade);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(agrupadorSinonimosDao, times(0)).findByIdAgrupador(idAgruparEntidadeSinonimos);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorConsulta.getId());
        verify(agrupadorSinonimosDao, times(0)).persist(agrupadorConsulta);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(Mockito.eq(0), Mockito.eq(new Integer(2)));
        
        
    }
    
    @Test
    public void testSalvarGetFuzzyMatchIguais() {
        // Cenario
        int idClassificador = 1;
        int idEntidade = 2;
        
        Entidade entidade = umEntidade()
                .comId(1)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();
        
        Entidade entidadeConsulta = umEntidade()
                .comId(1)
                .comNome("Entidade Nome")
                .comIdClassificador(idClassificador)
                .comFuzzyMatch(true)
                .build();

        List<Entidade> listaEntidade = null;
        
        //Mock
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.findIdEntidade(entidade.getId())).thenReturn(entidadeConsulta);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidadeConsulta);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
    }
    
    @Test
    public void testSalvarComSinonimoExistente() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 10; 
        
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .comNome(sinonimo.getNome())
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimo.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(sinonimo.getId())).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Sinonimo já existe na Entidade");
    }
    
    @Test
    public void testandoIdDoAgrupadorAMenorQueZero() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 10; 
        
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .comNome(sinonimo.getNome())
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimo.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(sinonimo.getId())).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(-1)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Sinonimo já existe na Entidade");
    }
    
    @Test
    public void testandoIdDoAgrupadorAMenorMaiorQueAZero() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 10; 
        
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .comNome(sinonimo.getNome())
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimo.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(sinonimo.getId())).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(122)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .comTipo(TipoAgrupador.PATTERNS)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .comTipo(TipoAgrupador.SINONIMOS)
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Sinonimo já existe na Entidade");
    }
    
    @Test
    public void testComSinonimoVazio() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 10; // Caso de teste com o numero zero
        
        Sinonimo sinonimo = new Sinonimo();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .comNome(sinonimo.getNome())
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimo.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(122)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .comTipo(TipoAgrupador.PATTERNS)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .comTipo(TipoAgrupador.SINONIMOS)
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
            entidadeManager.salvar(idClassificador, entidade);
            
         // verificaçao
        verify(sinonimoDao, times(0)).findIdSinonimo(idSinonimo);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorA.getId());
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(agrupadorA.getId());
        verify(agrupadorSinonimosDao, times(1)).persist(agrupadorA);
        verify(sinonimoDao, times(0)).findIdSinonimo(idSinonimo);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(entidadeDao, times(2)).persist(entidade);
        verify(entidadeDao, times(1)).findById(entidade.getId());
    }
    
    @Test
    public void testComSinonimoNaoCadastrado() {
     // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 10; // Caso de teste com o numero zero
        
        Sinonimo sinonimo = umSinonimo() 
                                .comId(0)
                                .comNome("Sinonimo Diferente")
                                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo Consulta")
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo Lista")
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(sinonimo.getId())).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(122)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .comTipo(TipoAgrupador.PATTERNS)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .comTipo(TipoAgrupador.SINONIMOS)
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
        
        // verificaçao
        verify(sinonimoDao, times(0)).findIdSinonimo(idSinonimo);
        verify(sinonimoDao, times(1)).findEntidadeId(sinonimo.getId());
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(idEntidade, agrupadorA.getId());
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(agrupadorA.getId());
        verify(agrupadorSinonimosDao, times(1)).persist(agrupadorA);
        verify(sinonimoDao, times(0)).findIdSinonimo(idSinonimo);
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
        verify(entidadeDao, times(2)).persist(entidade);
        verify(entidadeDao, times(1)).findById(entidade.getId());
    }
    
    @Test
    public void testComTipoAgrupadorIgualParaAgrupadorA_e_B() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 10; 
        
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .comNome(sinonimo.getNome())
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimo.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(sinonimo.getId())).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(122)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .comTipo(TipoAgrupador.PATTERNS)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .comTipo(TipoAgrupador.PATTERNS)
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Sinonimo já existe na Entidade");
    }
    
    @Test
    public void testSalvarComidEntidadeIgualAZero() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 0;
        
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimo.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Sinonimo já existe na Entidade");
    }
    
    @Test
    public void testSalvarComSinonimoNull() {
        // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Integer idEntidade = 0;
        
        Sinonimo sinonimo = new Sinonimo();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .build();
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(agrupadorA.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("AGRUPADOR NOME já existe!");
    }
    
    @Test
    public void testSalvarComNomeDoSinonimoDiferente() {
        // Cenario
        int idClassificador = 100;
        int idSinonimo = 99;
        Integer idEntidade = 98;
        
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo Diferente")
                .comId(idSinonimo)
                .build();
        
        Sinonimo sinonimoConsulta = umSinonimo()
                                    .comId(13)
                                    .comNome("Sinonimo")
                                    .build();
        
        List<Sinonimo> sinonimoComNomeIgual = Arrays.asList(umSinonimo()
                                                    .comNome("SinonimoList")
                                                    .comId(122)
                                                    .build()); 
        when(sinonimoDao.findIdSinonimo(sinonimoConsulta.getId())).thenReturn(sinonimo);
        
        List<Sinonimo> sinoList = Arrays.asList(umSinonimo()
                                            .comNome("Sinonimo")
                                            .comNome(sinonimoConsulta.getNome())
                                            .comId(12)
                                            .build());
        when(sinonimoDao.findEntidadeId(sinoList.get(0).getId())).thenReturn(sinonimoComNomeIgual);
        when(sinonimoDao.findEntidadeId(Mockito.eq(0))).thenReturn(sinoList);
        
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(10)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimoConsulta)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(11)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .comListaSinonimos(sinoList.get(0))
                .build();
        
        Sinonimo sinonimo2 = umSinonimo()
                .comNome("Sinonimo2")
                .comAgruparSinonimo(agrupadorA)
                .build();
        when(sinonimoDao.findIdSinonimo(sinoList.get(0).getId())).thenReturn(sinonimo2);
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(32)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.salvar(idClassificador, entidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Sinonimo já existe na Entidade");
    }
    
    
    
    @Test
    public void testSinonimoConsulta() {
     // Cenario
        int idClassificador = 0;
        int idSinonimo = 0;
        Sinonimo sinonimoConsulta = umSinonimo().comId(2).build();

        List<Sinonimo> sinoList = new ArrayList<>();
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR NOME")
                .comListaSinonimos(sinonimoConsulta)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(0)
                .comNome("AGRUPADOR COM NOME DIFERENTE")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade()
                .comId(0)
                .comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        Integer idEntidade = 1;
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimoConsulta);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
    }
    
    @Test
    public void testSalvarEntidadeComIdNull() {
     // Cenario
        int idClassificador = 0;
        int idSinonimo = 2;
        Sinonimo sinonimo = umSinonimo()
                .comNome("Sinonimo")
                .comId(idSinonimo)
                .build();

        List<Sinonimo> sinoList = Arrays.asList(umSinonimo().comNome(sinonimo.getNome()).build());
        
        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos()
                .comId(2)
                .comNome("")
                .comListaSinonimos(sinonimo)
                .build();
        AgruparEntidadeSinonimos agrupadorB = umAgruparEntidadeSinonimos()
                .comId(2)
                .comNome("")
                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                                    .comId(0)
                                                    .comNome("Entidade")
                                                    .build());
        
        
        Entidade entidade = umEntidade().comId(0).comNome("Entidade Diferente")
                .comListaAgrupadores(agrupadorB)
                .comListaAgrupadores(agrupadorA)
                .comIdClassificador(idClassificador).build();
        
        Integer idEntidade = 1;
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                                    .comNome("Entidade Diferente")
                                                                                    .comNome(entidade.getNome())
                                                                                    .comId(2)
                                                                                    .comId(entidade.getId())
                                                                                    .comEntidade(entidade)
                                                                                    .build());
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agrupadorA.getId())).thenReturn(listaAgruparEntidadeSinonimos);
        when(sinonimoDao.findEntidadeId(idEntidade)).thenReturn(sinoList);
        when(sinonimoDao.findIdSinonimo(idSinonimo)).thenReturn(sinonimo);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupadorA.getId())).thenReturn(agrupadorB);
        when(agrupadorSinonimosDao.persist(agrupadorA)).thenReturn(agrupadorA);
        when(entidadeDao.findById(entidade.getId())).thenReturn(entidade);
        
        // Açao
        entidadeManager.salvar(idClassificador, entidade);
        
        // Verificaçao
    }

    @Test
    public void testBuscarEntidade() {
        // Cenario
        int idEntidade = 2;
        
        Entidade entidade = umEntidade().comId(idEntidade).build();
        
        // Mock
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        
        // Açao
        entidadeManager.buscarEntidade(idEntidade);
        
        // Verificaçao
        verify(entidadeDao, times(1)).findIdEntidade(idEntidade);
    }

    @Test
    public void testListarAgrupador() {
        // Cenario
        Entidade entidade = umEntidade().comId(2).build();
        
        List<AgruparEntidadeSinonimos> agrupador = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                 .comEntidade(entidade)
                                                                 .build());
                
        // Mock
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(entidade.getId(), null)).thenReturn(agrupador);
       
        // Açao
        entidadeManager.listarAgrupador(entidade);
        
        // Verificaçao
      verify(agrupadorSinonimosDao, times(1)).findAgrupadorIdEntidade(entidade.getId(), null);
    }

    @Test
    public void testSalvarEditarAgrupador() {
        // Cenario
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos().build();
        
        // Mock
        when(agrupadorSinonimosDao.persist(agrupador)).thenReturn(agrupador);
        
        // Açao
        entidadeManager.salvarEditarAgrupador(agrupador);

        // Verificaçao
        verify(agrupadorSinonimosDao, times(1)).persist(agrupador);
        
    }

    @Test
    public void testSalvarEditarSinonimo() {
        // Cenario
        Sinonimo sinonimo = umSinonimo().build();
        
        // Mock
        when(sinonimoDao.persist(sinonimo)).thenReturn(sinonimo);
        
        // Açao
        entidadeManager.salvarEditarSinonimo(sinonimo);
        
        // Verificaçao
        verify(sinonimoDao, times(1)).persist(sinonimo);
    }
    
    @Test
    public void testSalvarEditarSinonimoNull() {
        // Cenario
        Sinonimo sinonimo = null;
        
        // Mock
        when(sinonimoDao.persist(sinonimo)).thenReturn(sinonimo);
        
        // Açao
        entidadeManager.salvarEditarSinonimo(sinonimo);
        
        // Verificaçao
        verify(sinonimoDao, times(0)).persist(sinonimo);
    }

    @Test
    public void testListarSinonimos() {
        // Cenario
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos().comId(2).build();
        
        List<Sinonimo> sinonimo = Arrays.asList(umSinonimo().comAgruparSinonimo(agrupador).build());
        
        // Mock
        when(sinonimoDao.findAgrupadorId(agrupador.getId())).thenReturn(sinonimo);
        
        // Açao
        entidadeManager.listarSinonimos(agrupador);
        
        // Verificaçao
        verify(sinonimoDao, times(1)).findAgrupadorId(agrupador.getId());
    }

    @Test 
    public void testRemoverSinonimo() {
        // Cenario
        Entidade entidade = umEntidade().comId(2).build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos().comEntidade(entidade).build();
        
        Sinonimo sinonimo = umSinonimo()
                            .comId(42)
                            .comAgruparSinonimo(agrupador)
                            .build();
        
        // Mock
        when(sinonimoDao.findIdSinonimo(sinonimo.getId())).thenReturn(sinonimo);
        when(entidadeDao.findById(agrupador.getEntidade().getId())).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        
        // Açao
        entidadeManager.removerSinonimo(sinonimo);
        
        // Verificaçao
        verify(sinonimoDao, times(1)).findIdSinonimo(sinonimo.getId());
    }
    
    @Test 
    public void testRemoverSinonimoRetornandoNull() {
        // Cenario
        Entidade entidade = umEntidade().comId(2).build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos().comEntidade(entidade).build();
        
        Sinonimo sinonimo = umSinonimo()
                            .comId(42)
                            .comAgruparSinonimo(agrupador)
                            .build();
        
        // Mock
        when(sinonimoDao.findIdSinonimo(sinonimo.getId())).thenReturn(null);
        when(entidadeDao.findById(agrupador.getEntidade().getId())).thenReturn(entidade);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        
        // Açao
        entidadeManager.removerSinonimo(sinonimo);
        
        // Verificaçao
        verify(sinonimoDao, times(1)).findIdSinonimo(sinonimo.getId());
    }
    

    @Test
    public void testRemoverAgrupador() {
        // Cenario
        int idEntidade = 1;
        Entidade entidade = umEntidade().comId(idEntidade).build();
        
        Sinonimo sinonimo = umSinonimo().build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comListaSinonimos(sinonimo)
                                            .comEntidade(entidade)
                                            .comId(2)
                                            .build();
        
        // Mock
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupador.getId())).thenReturn(agrupador);
        when(entidadeDao.findById(idEntidade)).thenReturn(entidade);
        entidadeDao.persist(entidade);
        
        // Açao
        entidadeManager.removerAgrupador(agrupador);
        
        // Verificaçao
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(agrupador.getId());
        verify(entidadeDao, times(1)).findById(idEntidade);
        verify(entidadeDao, times(2)).persist(entidade);
    }
    
    @Test
    public void testRemoverComSinonimoNull() {
        // Cenario
        int idEntidade = 1;
        Entidade entidade = umEntidade().comId(idEntidade).build();
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidade)
                                            .comId(2)
                                            .build();
        
        // Mock
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupador.getId())).thenReturn(agrupador);
        when(entidadeDao.findById(idEntidade)).thenReturn(entidade);
        entidadeDao.persist(entidade);
        
        // Açao
        entidadeManager.removerAgrupador(agrupador);
        
        // Verificaçao
        verify(agrupadorSinonimosDao, times(1)).findByIdAgrupador(agrupador.getId());
        verify(entidadeDao, times(1)).findById(idEntidade);
        verify(entidadeDao, times(2)).persist(entidade);
    }
    
    @Test
    public void testRemoverAgrupadorIdZERO() {
        // Cenario
        int idEntidade = 1;
        Entidade entidade = umEntidade().comId(idEntidade).build();
        
        Sinonimo sinonimo = null;
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comListaSinonimos(sinonimo)
                                            .comEntidade(entidade)
                                            .comId(0)
                                            .build();
        
        // Mock
        when(agrupadorSinonimosDao.findByIdAgrupador(agrupador.getId())).thenReturn(agrupador);
        when(entidadeDao.findById(idEntidade)).thenReturn(entidade);
        entidadeDao.persist(entidade);
        
        // Açao
        entidadeManager.removerAgrupador(agrupador);
        
        // Verificaçao
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(agrupador.getId());
        verify(entidadeDao, times(0)).findById(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
    }
    
    @Test
    public void testAgrupadorComIdNull() {
     // Cenario
        int idEntidade = 1;
        Entidade entidade = umEntidade().comId(idEntidade).build();
        
        Sinonimo sinonimo = null;
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comId(null)
                                            .comListaSinonimos(sinonimo)
                                            .comEntidade(entidade)
                                            .build();
        
        // Mock
        when(entidadeDao.findById(idEntidade)).thenReturn(entidade);
        entidadeDao.persist(entidade);
        
        // Açao
        entidadeManager.removerAgrupador(agrupador);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findById(idEntidade);
        verify(entidadeDao, times(1)).persist(entidade);
    }

    @Test
    public void testExcluirInteger() {
        // Cenario
        Integer idEntidade = new Integer(2);
        Sinonimo sinonimo = umSinonimo().build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comListaSinonimos(sinonimo)
                                            .comId(1)
                                            .build();
        
        List<AgruparEntidadeSinonimos> agrupadores = Arrays.asList(umAgruparEntidadeSinonimos().build());
        
        Entidade entidade = umEntidade()
                            .comNome("Não é permitida a exclusão da entidade")
                            .comId(idEntidade)
                            .comListaAgrupadores(agrupadores.get(0))
                            .comListaAgrupadores(agrupador)
                            .build();

        Intencao intencao = umIntencao().comNome("Nome").build();
        
        Fluxo fluxoPai = umFluxo().comIntencao(intencao).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                        .comFluxoPai(fluxoPai)
                                        .comIntencao(intencao)
                                        .comEntidade(entidade)
                                        .comAgrupador(agrupador)
                                        .build());
        
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.excluir(idEntidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitida a exclusão da entidade Não é permitida a exclusão da entidade, pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
    }
    
    @Test
    public void testExcluirComFluxoNull() {
        // Cenario
        Integer idEntidade = new Integer(2);
        Sinonimo sinonimo = umSinonimo().build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comListaSinonimos(sinonimo)
                                            .comId(1)
                                            .build();
        
        List<AgruparEntidadeSinonimos> agrupadores = Arrays.asList(umAgruparEntidadeSinonimos().build());
        
        Entidade entidade = umEntidade()
                            .comNome("Não é permitida a exclusão da entidade")
                            .comId(idEntidade)
                            .comListaAgrupadores(agrupadores.get(0))
                            .comListaAgrupadores(agrupador)
                            .build();

        Intencao intencao = umIntencao().comNome("Nome").build();
        
        Fluxo fluxoPai = umFluxo().comIntencao(null).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                        .comFluxoPai(fluxoPai)
                                        .comIntencao(intencao)
                                        .comEntidade(entidade)
                                        .comAgrupador(agrupador)
                                        .build());
        
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.excluir(idEntidade);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitida a exclusão da entidade Não é permitida a exclusão da entidade, pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
    }
    
    @Test
    public void testComListaFluxoVazia() {
        // Cenario
        Integer idEntidade = new Integer(2);
        Sinonimo sinonimo = umSinonimo().build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comListaSinonimos(sinonimo)
                                            .comId(1)
                                            .build();
        
        List<AgruparEntidadeSinonimos> agrupadores = Arrays.asList(umAgruparEntidadeSinonimos().build());
        
        Entidade entidade = umEntidade()
                            .comNome("Não é permitida a exclusão da entidade")
                            .comId(idEntidade)
                            .comListaAgrupadores(agrupadores.get(0))
                            .comListaAgrupadores(agrupador)
                            .build();

        List<Fluxo> listaFluxo = new ArrayList<>();
        
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        when(entidadeDao.findIdEntidade(idEntidade)).thenReturn(entidade);
        
        // Açao
        entidadeManager.excluir(idEntidade);
        
        // Verificaçao
        verify(fluxoManager, times(1)).listarPorAgrupador(Mockito.anyInt());
        verify(entidadeDao, times(1)).findIdEntidade(idEntidade);
    }

//    @Test
//    public void testExcluirEntidade() {
//        fail("Not yet implemented");
//    }

    @Test
    public void testAgrupadorEntidadeFluxo() {// Verificar Metodo Salvar
        // Cenario
        int idClassificador = 1;
        String cpNome = new String("Nome");
        
        Paginacao<AgruparEntidadeSinonimos> paginacao= new Paginacao<>();
        
        // Mock
        when(agrupadorSinonimosDao.findByAgrupadorEntidade(paginacao, idClassificador, cpNome)).thenReturn(paginacao);
        
        // Açao
        entidadeManager.agrupadorEntidadeFluxo(paginacao, idClassificador, cpNome);
        
        // Verificaçao
        verify(agrupadorSinonimosDao, times(1)).findByAgrupadorEntidade(paginacao, idClassificador, cpNome);
    }

    @Test
    public void testMigrarComClassificadorPreenchido() {
        // Cenário
        Classificador classificador = umClassificador().comId(2).build();
        List<Entidade> listaEntidadeClassificador = Arrays.asList(umEntidade()
                                                          .comClassificador(classificador)
                                                          .comId(classificador.getId())
                                                          .comNome("Erro")
                                                          .build());

        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                .comClassificador(classificador)
                .comListaListaEntidade(listaEntidadeClassificador)
                .build();
        
        AgruparEntidadeSinonimos agruparEntidadeSinonimos = umAgruparEntidadeSinonimos()
                                                                .comId(3)
                                                                .build();
        
        Fluxo fluxoPai = umFluxo().build();
        Intencao intencao = umIntencao().comNome("Intençao").build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comAgrupador(agruparEntidadeSinonimos)
                                                .comFluxoPai(fluxoPai)
                                                .comIntencao(intencao)
                                                .comId(agruparEntidadeSinonimos.getId())
                                                .build());
        
        List<AgruparEntidadeSinonimos> agrupador = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                    .comId(agruparEntidadeSinonimos.getId())
                                                                    .comEntidade(listaEntidadeClassificador.get(0))
                                                                    .comNome("Erro Diferente")
                                                                    .build());
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.any())).thenReturn(listaFluxo);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(listaEntidadeClassificador.get(0).getId(), null)).thenReturn(agrupador);
        when(entidadeDao.findByClassificador(migrar.getClassificador().getId())).thenReturn(listaEntidadeClassificador);
        entidadeDao.persist(listaEntidadeClassificador.get(0));
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.migrar(migrar);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitido migrar a(s) entidade(s) listada(s) abaixo, pois a(s) mesma(s) já existe(m) no corpus selecionado:");
    }
    
    @Test
    public void testMigrarComNomesDiferentesDaListaEntidade() {
        // Cenário
        Classificador classificador = umClassificador().comId(2).build();
        List<Entidade> listaEntidadeClassificador = Arrays.asList(umEntidade()
                                                          .comClassificador(classificador)
                                                          .comId(classificador.getId())
                                                          .comNome("Erro")
                                                          .build());
        
        List<Fluxo> listaFluxoVazia = new ArrayList<>();
        List<Entidade> listaEntidadeClassificador2 = Arrays.asList(umEntidade()
                                                                .comClassificador(classificador)
                                                                .comId(classificador.getId())
                                                                .comNome("Erro Nome Diferente")
                                                                .build());

        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                .comClassificador(classificador)
                .comListaListaEntidade(listaEntidadeClassificador)
                .build();
        
        AgruparEntidadeSinonimos agruparEntidadeSinonimos = umAgruparEntidadeSinonimos()
                                                                .comId(3)
                                                                .build();

        List<AgruparEntidadeSinonimos> agrupador = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                    .comId(agruparEntidadeSinonimos.getId())
                                                                    .comEntidade(listaEntidadeClassificador.get(0))
                                                                    .comNome("Erro Diferente")
                                                                    .build());
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.any())).thenReturn(listaFluxoVazia);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(listaEntidadeClassificador.get(0).getId(), null)).thenReturn(agrupador);
        when(entidadeDao.findByClassificador(migrar.getClassificador().getId())).thenReturn(listaEntidadeClassificador2);
        entidadeDao.persist(listaEntidadeClassificador.get(0));
        
        // Açao
        entidadeManager.migrar(migrar);
        
        // Verificaçao
        verify(fluxoManager, times(1)).listarPorAgrupador(Mockito.any());
        verify(agrupadorSinonimosDao, times(1)).findAgrupadorIdEntidade(listaEntidadeClassificador.get(0).getId(), null);
        verify(entidadeDao,  times(1)).findByClassificador(migrar.getClassificador().getId());
        
    }
    
    @Test
    public void testMigrarListaEntidadeComErroVazia() {
        // Cenário
        Classificador classificador = umClassificador().comId(2).build();
        List<Entidade> listaEntidadeClassificador = Arrays.asList(umEntidade()
                                                          .comClassificador(classificador)
                                                          .comId(classificador.getId())
                                                          .comNome("Erro")
                                                          .build());
        
        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                .comClassificador(classificador)
                .comListaListaEntidade(listaEntidadeClassificador)
                .build();
        
        AgruparEntidadeSinonimos agruparEntidadeSinonimos = umAgruparEntidadeSinonimos()
                                                                .comId(3)
                                                                .build();
        
        Intencao intencao = umIntencao().comNome("Intençao").build();
        Fluxo fluxoPai = umFluxo().comIntencao(intencao).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comAgrupador(agruparEntidadeSinonimos)
                                                .comFluxoPai(fluxoPai)
                                                .comIntencao(intencao)
                                                .comId(agruparEntidadeSinonimos.getId())
                                                .build());
        
        List<AgruparEntidadeSinonimos> agrupador = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                    .comId(agruparEntidadeSinonimos.getId())
                                                                    .comEntidade(listaEntidadeClassificador.get(0))
                                                                    .comNome("Erro Diferente")
                                                                    .build());
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.any())).thenReturn(listaFluxo);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(listaEntidadeClassificador.get(0).getId(), null)).thenReturn(agrupador);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.migrar(migrar);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitida a migração da(s) entidade(s):");
        
    }
    
    @Test
    public void testMigrarComFluxoPaiNull() {
        // Cenário
        Classificador classificador = umClassificador().comId(2).build();
        List<Entidade> listaEntidadeClassificador = Arrays.asList(umEntidade()
                                                          .comClassificador(classificador)
                                                          .comId(classificador.getId())
                                                          .comNome("Erro")
                                                          .build());
        
        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                .comClassificador(classificador)
                .comListaListaEntidade(listaEntidadeClassificador)
                .build();
        
        AgruparEntidadeSinonimos agruparEntidadeSinonimos = umAgruparEntidadeSinonimos()
                                                                .comId(3)
                                                                .build();
        
        Fluxo fluxoPai = null;
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comAgrupador(agruparEntidadeSinonimos)
                                                .comFluxoPai(fluxoPai)
                                                .comId(agruparEntidadeSinonimos.getId())
                                                .build());
        
        List<AgruparEntidadeSinonimos> agrupador = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                    .comId(agruparEntidadeSinonimos.getId())
                                                                    .comEntidade(listaEntidadeClassificador.get(0))
                                                                    .comNome("Erro Diferente")
                                                                    .build());
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.any())).thenReturn(listaFluxo);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(listaEntidadeClassificador.get(0).getId(), null)).thenReturn(agrupador);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.migrar(migrar);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitida a migração da(s) entidade(s):");
        
    }
    
    @Test
    public void testMigrarComGetIntençaoNull() {
        // Cenário
        Classificador classificador = umClassificador().comId(2).build();
        List<Entidade> listaEntidadeClassificador = Arrays.asList(umEntidade()
                                                          .comClassificador(classificador)
                                                          .comId(classificador.getId())
                                                          .comNome("Erro")
                                                          .build());
        
        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                .comClassificador(classificador)
                .comListaListaEntidade(listaEntidadeClassificador)
                .build();
        
        AgruparEntidadeSinonimos agruparEntidadeSinonimos = umAgruparEntidadeSinonimos()
                                                                .comId(3)
                                                                .build();
        Intencao intencao = null;
        Fluxo fluxoPai = umFluxo().comIntencao(intencao).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comAgrupador(agruparEntidadeSinonimos)
                                                .comFluxoPai(fluxoPai)
                                                .comId(agruparEntidadeSinonimos.getId())
                                                .build());
        
        List<AgruparEntidadeSinonimos> agrupador = Arrays.asList(umAgruparEntidadeSinonimos()
                                                                    .comId(agruparEntidadeSinonimos.getId())
                                                                    .comEntidade(listaEntidadeClassificador.get(0))
                                                                    .comNome("Erro Diferente")
                                                                    .build());
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.any())).thenReturn(listaFluxo);
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(listaEntidadeClassificador.get(0).getId(), null)).thenReturn(agrupador);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.migrar(migrar);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitida a migração da(s) entidade(s):");
        
    }
    
    @Test
    public void testMigrarComListaEntidadeVazia() {
        // Cenário
        Classificador classificador = umClassificador().comId(2).build();
        List<Entidade> listaEntidadeClassificador = new ArrayList<>();

        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                .comClassificador(classificador)
                .comListaListaEntidade(listaEntidadeClassificador)
                .build();
        
        AgruparEntidadeSinonimos agruparEntidadeSinonimos = umAgruparEntidadeSinonimos()
                                                                .comId(3)
                                                                .build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comAgrupador(agruparEntidadeSinonimos)
                                                .comId(agruparEntidadeSinonimos.getId())
                                                .build());
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.migrar(migrar);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Selecione uma ou mais entidades.");
        
    }
    
    @Test
    public void testMigrarComClassificadorNull() {
        // Cenário
        List<Entidade> listaEntidadeClassificador = new ArrayList<>();

        MigrarEntidadeVO migrar = umMigrarEntidadeVO()
                                .comListaListaEntidade(listaEntidadeClassificador)
                                .comClassificador(null)
                                .build();
        
        List<Fluxo> listaFluxo = new ArrayList<>();

       
        // Mock
        when(fluxoManager.listarPorAgrupador(Mockito.any())).thenReturn(listaFluxo);
        
        // Açao
        assertThatThrownBy(() -> {
            entidadeManager.migrar(migrar);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Selecione um Classificador.");
        
    }

    @Test
    public void testSalvarEntidadeCondicao() { 
        // Cenario
        int idClassificador = 2;
        String textoConsulta = new String("cartao:credito");
        String operador = new String(":");
        
        Classificador classificador = umClassificador()
                                        .comId(idClassificador)
                                        .comId(12)
                                        .build();
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                                .comNome(textoConsulta)
                                                .comId(13)
                                                .build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                            .comListaAgrupadores(agrupador)
                                            .comId(2)
                                            .comClassificador(classificador)
                                            .comNome(textoConsulta)
                                            .comIdClassificador(idClassificador)
                                            .build());
        
        List<Entidade> entidadeAux =  Arrays.asList(umEntidade()
                                            .comId(2)
                                            .comListaAgrupadores(agrupador)
                                            .comIdClassificador(idClassificador)
                                            .comNome("cartao")
                                            .comUuid("Uuid")
                                            .build());
        
        Entidade entidade = umEntidade()
                .comId(10)
                .comListaAgrupadores(agrupador)
                .comUuid("Uuid")
                .build();
        when(entidadeDao.findByClassificador(Mockito.eq(2))).thenReturn(listaEntidade);
        
        // Mock
        when(entidadeDao.findByNomeIgual(textoConsulta,idClassificador)).thenReturn(listaEntidade);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(entidadeDao.findByClassificador(listaEntidade.get(0).getId())).thenReturn(entidadeAux);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(entidadeAux);
        when(entidadeDao.persist(entidade)).thenReturn(entidade);
        
        // Açao
        assertThatThrownBy(() -> {
        entidadeManager.salvarEntidadeCondicao(idClassificador, textoConsulta, operador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Entidade: cartao já existe!");
    }
    
    
    @Test
    public void testListaEntidadeVazia() {
        // Cenario
        int idClassificador = 2;
        String textoConsulta = new String("");
        String operador = new String(":");
        
        Classificador classificador = umClassificador().comId(idClassificador).build();
        classificador.getNomeTipoServicoInfra();
        classificador.getAtivo();
        classificador.getDataCriacao();
        classificador.getDataFinalizacao();
        classificador.getDataVerificacao();
        classificador.getDescricao();
        classificador.getLinguagem();
        classificador.getUsuario();
        classificador.getStatusClassificador();
        classificador.getTipoCorpus();
        classificador.getFeedbackColeta();
        classificador.getSituacao();
        classificador.isPossuiStatusColeta();
        classificador.isPossuiStatusCuradoria();
        classificador.isPossuiStatusTerminado();
        classificador.isPossuiStatusColetaCuradoria();
        classificador.getPorcentagemCuradoria();
        classificador.getPorcentagemIntencao();
        classificador.getReducaoCuradoria();
        classificador.getTipoRespostas();
        classificador.getBoasVindas();
        classificador.getNaoAtendida();
        classificador.getTaxaConfianca();
        classificador.getRespostaConfianca();
        classificador.getRespostaCancelarTransferencia();
        classificador.getCondicaoCancelarTransferencia();
        classificador.getNivelAcesso();
        classificador.getAcessoChat();
        classificador.getCanais();
        classificador.getClasses();
        classificador.getTipoCuradoriaSentimento();
        classificador.getRespostaNia();
        classificador.getEstadoClassificador();
        classificador.getTransbordoNia();
        classificador.setTransbordoNia(null);
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos().comNome(textoConsulta).build();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                                            .comListaAgrupadores(agrupador)
                                            .comId(0)
                                            .comClassificador(classificador)
                                            .comNome(textoConsulta)
                                            .comIdClassificador(idClassificador)
                                            .build());
        
        List<Entidade> entidadeAux =  Arrays.asList(umEntidade()
                                            .comId(2)
                                            .comNome(textoConsulta)
                                            .build());
        
        // Mock
        when(entidadeDao.findByNomeIgual(textoConsulta,idClassificador)).thenReturn(listaEntidade);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(entidadeAux);
        
        // Açao
        assertThatThrownBy(() -> {
        entidadeManager.salvarEntidadeCondicao(idClassificador, textoConsulta, operador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Entidade:  já existe!");
    }
    
    @Test
    public void testComOperadorNull() {
        // Cenario
        int idClassificador = 2;
        String textoConsulta = new String("");
        String operador = null;
        
        Classificador classificador = umClassificador().comId(idClassificador).build();
        
        List<Entidade> listaEntidade = new ArrayList<>();
        
        List<Entidade> entidadeAux =  Arrays.asList(umEntidade()
                                            .comId(2)
                                            .comNome(textoConsulta)
                                            .build());
        
        // Mock
        when(entidadeDao.findByNomeIgual(textoConsulta,idClassificador)).thenReturn(listaEntidade);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(entidadeAux);
        
        // Açao
        assertThatThrownBy(() -> {
        entidadeManager.salvarEntidadeCondicao(idClassificador, textoConsulta, operador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Entidade:  já existe!");
    }
    
    @Test
    public void testFindBuscaAvancada() {
        // cenario
        List<Integer> listaIdsEntidade = new ArrayList<Integer>();
        List<Integer> idsEntidadeConsultaLikeAgrupador = new ArrayList<>();
        List<Integer> listaIdsEntidadeConsultaLikeSinonimo = new ArrayList<>();
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                .comId(121)
                .build()); 
        
        BuscaAvancadaEntidadeVO buscaAvancadaEntidade = umBuscaAvancadaEntidadeVO()
                .comCheckValores(false)
                .comCheckSinonimos(false)
                .comIdClassificador(122)
                .build();
        
        Sinonimo sinonimo = umSinonimo().build();
        Entidade entidade = umEntidade()
                            .comId(123)
                            .build();
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                .comId(124)
                .comIdEntidade(entidade.getId())
                .comEntidade(listaEntidade.get(0))
                .comNome("Nome Agrupador")
                .comListaSinonimos(sinonimo)
                .comTipo(TipoAgrupador.PATTERNS)
                .build());
        
        Paginacao<Entidade> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umEntidade().build()));
        
        // Mock
        when(entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador())).thenReturn(listaEntidade);
        
        when(agrupadorSinonimosDao.findIdListaEntidadeLikeNomeAgrupador
                                                      (Mockito.any(), Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador())).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.listaIdsAgrupadoresByListaEntidade(listaIdsEntidade)).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(entidadeDao.findBuscaAvancada
                (buscaAvancadaEntidade,paginacao,idsEntidadeConsultaLikeAgrupador,listaIdsEntidadeConsultaLikeSinonimo))
        .thenReturn(paginacao);
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.anyInt(), Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        // Açao
        entidadeManager.findBuscaAvancada(buscaAvancadaEntidade, paginacao);
        
        // verificaçao
        verify(entidadeDao, times(0)).findByClassificador(buscaAvancadaEntidade.getIdClassificador());
        verify(agrupadorSinonimosDao, times(0)).findIdListaEntidadeLikeNomeAgrupador(Mockito.any(), Mockito.any());
        verify(entidadeDao, times(0)).findByClassificador(buscaAvancadaEntidade.getIdClassificador());
        verify(agrupadorSinonimosDao, times(0)).listaIdsAgrupadoresByListaEntidade(listaIdsEntidade);
        verify(entidadeDao, times(1)).findBuscaAvancada
        (buscaAvancadaEntidade,paginacao,idsEntidadeConsultaLikeAgrupador,listaIdsEntidadeConsultaLikeSinonimo);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(entidade.getId(), null);
    }
    
    @Test
    public void testCheckvaloresComParametrosFalse_e_SinonimosComParametroTrue() {
        // cenario
        List<Integer> idsEntidadeConsultaLikeAgrupador = new ArrayList<>();
        List<Integer> listaIdsEntidadeConsultaLikeSinonimo = new ArrayList<>();
        List<Entidade> listaEntidade = Arrays.asList(umEntidade().comId(121).build()); 
        
        BuscaAvancadaEntidadeVO buscaAvancadaEntidade = umBuscaAvancadaEntidadeVO()
                .comCheckValores(false)
                .comCheckSinonimos(true)
                .comIdClassificador(122)
                .build();
        
        Entidade entidade = umEntidade()
                .comId(123)
                .build();
        AgruparEntidadeSinonimos agruSinonimo = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comIdEntidade(entidade.getId())
                .build();
        List<Sinonimo> sinonimo = Arrays.asList(umSinonimo()
                .comAgruparSinonimo(agruSinonimo)
                .build());
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                .comId(entidade.getId())
                .comIdEntidade(entidade.getId())
                .comEntidade(entidade)
                .comNome("Nome Agrupador")
                .comListaSinonimos(sinonimo.get(0))
                .comTipo(TipoAgrupador.PATTERNS)
                .build());
        
        Paginacao<Entidade> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umEntidade().build()));
        
        // Mock
        when(entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador())).thenReturn(listaEntidade);
        
        when(agrupadorSinonimosDao.findIdListaEntidadeLikeNomeAgrupador
                                                      (Mockito.any(), Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador())).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.listaIdsAgrupadoresByListaEntidade(Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(entidadeDao.findBuscaAvancada
                (Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(paginacao);
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.anyInt(), Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(sinonimoDao.findByListaIdsAgrupadoresLikeNome
                (Mockito.any(),Mockito.any()))
        .thenReturn(sinonimo);
        
        // Açao
        entidadeManager.findBuscaAvancada(buscaAvancadaEntidade, paginacao);
        
        // verificaçao
        verify(entidadeDao, times(1)).findByClassificador(buscaAvancadaEntidade.getIdClassificador());
        verify(agrupadorSinonimosDao, times(0)).findIdListaEntidadeLikeNomeAgrupador(Mockito.any(), Mockito.any());
        verify(entidadeDao, times(1)).findByClassificador(buscaAvancadaEntidade.getIdClassificador());
        verify(entidadeDao, times(0)).findBuscaAvancada
        (buscaAvancadaEntidade,paginacao,idsEntidadeConsultaLikeAgrupador,listaIdsEntidadeConsultaLikeSinonimo);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(entidade.getId(), null);
    }
    
    @Test
    public void testCheckvaloresComParametrosTrue_e_SinonimosComParametroFalse() {
        // cenario
        List<Integer> idsEntidadeConsultaLikeAgrupador = new ArrayList<>();
        List<Integer> listaIdsEntidadeConsultaLikeSinonimo = new ArrayList<>();
        List<Entidade> listaEntidade = Arrays.asList(umEntidade().comId(121).build());
        
        BuscaAvancadaEntidadeVO buscaAvancadaEntidade = umBuscaAvancadaEntidadeVO()
                .comCheckValores(true)
                .comCheckSinonimos(false)
                .comIdClassificador(122)
                .build();
        
        Entidade entidade = umEntidade()
                .comId(123)
                .build();
        AgruparEntidadeSinonimos agruSinonimo = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comIdEntidade(entidade.getId())
                .build();
        List<Sinonimo> sinonimo = Arrays.asList(umSinonimo()
                .comAgruparSinonimo(agruSinonimo)
                .build()); 
        List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = Arrays.asList(umAgruparEntidadeSinonimos()
                .comId(124)
                .comIdEntidade(entidade.getId())
                .comEntidade(entidade) 
                .comNome("Nome Agrupador")
                .comListaSinonimos(sinonimo.get(0))
                .comTipo(TipoAgrupador.PATTERNS)
                .build());
        
        Paginacao<Entidade> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umEntidade().build()));
        
        // Mock
        when(entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador())).thenReturn(listaEntidade);
        
        when(agrupadorSinonimosDao.findIdListaEntidadeLikeNomeAgrupador
                                                      (Mockito.any(), Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador())).thenReturn(listaEntidade);
        when(agrupadorSinonimosDao.listaIdsAgrupadoresByListaEntidade(Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(entidadeDao.findBuscaAvancada
                (Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()))
        .thenReturn(paginacao);
        
        when(agrupadorSinonimosDao.findAgrupadorIdEntidade(Mockito.anyInt(), Mockito.any())).thenReturn(listaAgruparEntidadeSinonimos);
        
        when(sinonimoDao.findByListaIdsAgrupadoresLikeNome
                (Mockito.any(),Mockito.any()))
        .thenReturn(sinonimo);
        
        // Açao
        entidadeManager.findBuscaAvancada(buscaAvancadaEntidade, paginacao);
        
        // verificaçao
        verify(entidadeDao, times(1)).findByClassificador(buscaAvancadaEntidade.getIdClassificador());
        verify(agrupadorSinonimosDao, times(1)).findIdListaEntidadeLikeNomeAgrupador(Mockito.any(), Mockito.any());
        verify(entidadeDao, times(1)).findByClassificador(buscaAvancadaEntidade.getIdClassificador());
        verify(entidadeDao, times(0)).findBuscaAvancada
        (buscaAvancadaEntidade,paginacao,idsEntidadeConsultaLikeAgrupador,listaIdsEntidadeConsultaLikeSinonimo);
        verify(agrupadorSinonimosDao, times(0)).findAgrupadorIdEntidade(entidade.getId(), null);
    }

    @Test
    public void testListarEntidadeIdClassificador() {
        // Cenario
        int idClassificador = 2;
        
        List<Entidade> entidade = new ArrayList<>();
        
        // Mock
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(entidade);
        
        // Açao
        entidadeManager.listarEntidadeIdClassificador(idClassificador);
        
        
        // Verificaçao
        verify(entidadeDao, times(1)).findByClassificador(idClassificador);
    }

    @Test
    public void testListarVersao() {
        // Cenario
        Integer idClassificador = 2;
        
        List<Entidade> entidade = new ArrayList<>();
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        
        // Açao
        entidadeManager.listarVersao(idClassificador);
        
        // Verificaçao
        verify(entidadeDao, times(1)).listarVersao(idClassificador);
    }

    @Test
    public void testLimparPorClassificador() {
        // Cenario
        Integer idClassificador = 2;
        
        List<Entidade> entidade = new ArrayList<>();
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        
        // Açao
        entidadeManager.limparPorClassificador(idClassificador);
        
        // Verificaçao
        verify(entidadeDao, times(1)).listarVersao(idClassificador);
    }
    
    @Test
    public void testFalharAoLimparPorClassificador() {
        // Cenario
        Integer idClassificador = 2;
        Entidade entidades = umEntidade()
                                .comId(10)
                                .build();
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidades)
                                            .comId(1)
                                            .build();
        
        Intencao intencao = umIntencao().build();
        Fluxo fluxoPai = umFluxo().comIntencao(intencao).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comId(agrupador.getId())
                                                .comFluxoPai(fluxoPai)
                                                .build());
        
        List<Entidade> entidade = Arrays.asList(umEntidade()
                                                .comListaAgrupadores(agrupador)
                                                .build());
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        when(fluxoManager.listarPorAgrupador(agrupador.getId())).thenReturn(listaFluxo);
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        
        // Açao/Verificacao
        assertThatThrownBy(() -> {
            entidadeManager.limparPorClassificador(idClassificador);
        }).isInstanceOf(NegocioException.class);
    }
    
    @Test
    public void testEntidadeRemovida() {
        // Cenario
        Integer idClassificador = 2;
        Entidade entidades = umEntidade()
                                .comId(10)
                                .build();
        
        Sinonimo sinonimoDoAgrupador = umSinonimo().build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidades)
                                            .comListaSinonimos(sinonimoDoAgrupador)
                                            .comId(1)
                                            .build();
        Sinonimo sinonimoFor = umSinonimo()
                .comAgruparSinonimo(agrupador)
                .build();
        
        List<Entidade> entidade = Arrays.asList(umEntidade()
                                                .comListaAgrupadores(agrupador)
                                                .build());
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        sinonimoDao.remove(sinonimoFor);
        
        // Açao/Verificacao
        entidadeManager.limparPorClassificador(idClassificador);

        // Verificaçao
        verify(entidadeDao, times(1)).listarVersao(idClassificador);
        verify(sinonimoDao, times(1)).remove(sinonimoFor);
            
    }
    
    @Test
    public void testLimparPorClassificadorComIntençaoNull() {
        // Cenario
        Integer idClassificador = 2;
        Entidade entidades = umEntidade()
                                .comId(10)
                                .build();
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidades)
                                            .comId(1)
                                            .build();
        
        Intencao intencao = null;
        Fluxo fluxoPai = umFluxo().comIntencao(intencao).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comId(agrupador.getId())
                                                .comFluxoPai(fluxoPai)
                                                .build());
        
        List<Entidade> entidade = Arrays.asList(umEntidade()
                                                .comListaAgrupadores(agrupador)
                                                .build());
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        when(fluxoManager.listarPorAgrupador(agrupador.getId())).thenReturn(listaFluxo);
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        
        // Açao/Verificacao
        assertThatThrownBy(() -> {
            entidadeManager.limparPorClassificador(idClassificador);
        }).isInstanceOf(NegocioException.class);
    }
    
    @Test
    public void testLimparPorClassificadorComFluxoPaiNull() {
        // Cenario
        Integer idClassificador = 2;
        Entidade entidades = umEntidade()
                                .comId(10)
                                .build();
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidades)
                                            .comId(1)
                                            .build();
        
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comId(agrupador.getId())
                                                .comFluxoPai(null)
                                                .build());
        
        List<Entidade> entidade = Arrays.asList(umEntidade()
                                                .comListaAgrupadores(agrupador)
                                                .build());
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        when(fluxoManager.listarPorAgrupador(agrupador.getId())).thenReturn(listaFluxo);
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        
        // Açao/Verificacao
        assertThatThrownBy(() -> {
            entidadeManager.limparPorClassificador(idClassificador);
        }).isInstanceOf(NegocioException.class);
    }
    
    @Test
    public void testLimparPorClassificadorComFluxoPaiPreenchido() {
        // Cenario
        Integer idClassificador = 2;
        Entidade entidades = umEntidade()
                                .comId(10)
                                .build();
        
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidades)
                                            .comId(1)
                                            .build();
        
        Intencao intencao = umIntencao().build();
        Fluxo fluxoPai = umFluxo().comIntencao(intencao).build();
        List<Fluxo> listaFluxo = Arrays.asList(umFluxo()
                                                .comId(agrupador.getId())
                                                .comFluxoPai(fluxoPai)
                                                .build());
        
        List<Entidade> entidade = Arrays.asList(umEntidade()
                                                .comListaAgrupadores(agrupador)
                                                .build());
        
        // Mock
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidade);
        when(fluxoManager.listarPorAgrupador(agrupador.getId())).thenReturn(listaFluxo);
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        
        // Açao/Verificacao
        assertThatThrownBy(() -> {
            entidadeManager.limparPorClassificador(idClassificador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitida a exclusão da entidade , pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
    }
    
    @Test
    public void testLimparPorClassificadorComListafluxoVazia() {
        // Cenario
        Integer idClassificador = 2;
        
        Entidade entidades = umEntidade()
                                .comId(10)
                                .build();
        
        Sinonimo sinonimo = umSinonimo().build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                                            .comEntidade(entidades)
                                            .comListaSinonimos(sinonimo)
                                            .comId(1)
                                            .build();
        
        List<Fluxo> listaFluxo = new ArrayList<>();
        
         //Mock
        when(fluxoManager.listarPorAgrupador(agrupador.getId())).thenReturn(listaFluxo);
        when(fluxoManager.listarPorAgrupador(Mockito.anyInt())).thenReturn(listaFluxo);
        sinonimoDao.remove(sinonimo);
        
        // Açao/Verificacao
            entidadeManager.limparPorClassificador(idClassificador);
    }
    
//    public static void main(String[] args) {
//        new BuilderMaster().gerarCodigoClasse(BuscaAvancadaEntidadeVO.class);
//        
//    }
}
