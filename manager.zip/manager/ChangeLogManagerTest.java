package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ChangeLogEntidadeBuilder.umChangeLogEntidade;
import static br.com.bb.databuilder.ChangeLogExemploBuilder.umChangeLogExemplo;
import static br.com.bb.databuilder.ChangeLogIntencaoBuilder.umChangeLogIntencao;
import static br.com.bb.databuilder.ChangeLogParametrosEntradaVOBuilder.umChangeLogParametrosEntradaVO;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Time;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.ChangeLogAgrupadorDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogDialogoDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogDialogoTagDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogEntidadeDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogExemploDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogPerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogRespostaDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogSinonimoDao;
import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDialogoAUDDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotAUDDao;
import br.com.bb.gearq.c4coleta.dao.SlotsAUDDao;
import br.com.bb.gearq.c4coleta.dao.SlotsTagsAUDDao;
import br.com.bb.gearq.c4coleta.model.ChangeLogAgrupador;
import br.com.bb.gearq.c4coleta.model.ChangeLogDialogo;
import br.com.bb.gearq.c4coleta.model.ChangeLogDialogoTag;
import br.com.bb.gearq.c4coleta.model.ChangeLogResposta;
import br.com.bb.gearq.c4coleta.model.ChangeLogSinonimo;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativaDialogoAUD;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlotAUD;
import br.com.bb.gearq.c4coleta.model.SlotsAUD;
import br.com.bb.gearq.c4coleta.model.SlotsTagsAUD;
import br.com.bb.gearq.c4coleta.vo.ChangeLogEntidade;
import br.com.bb.gearq.c4coleta.vo.ChangeLogExemplo;
import br.com.bb.gearq.c4coleta.vo.ChangeLogIntencao;
import br.com.bb.gearq.c4coleta.vo.ChangeLogParametrosEntradaVO;
import br.com.bb.gearq.c4coleta.vo.ChangeLogPerguntaRevisao;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class ChangeLogManagerTest {
    /**
     * @author c1312334 (Wallison Bruno)
     * @date 26/12/19
     */

    @InjectMocks
    private ChangeLogManager changeLogManager;

    @Mock
    private ChangeLogIntencaoDao changeLogIntencaoDao;
    
    @Mock
    private ChangeLogExemploDao changeLogExemploDao;
    
    @Mock
    private ChangeLogPerguntaRevisaoDao changeLogPerguntaRevisaoDao;
    
    @Mock
    private ChangeLogEntidadeDao changeLogEntidadeDao;
    
    @Mock
    private ChangeLogSinonimoDao changeLogSinonimoDao;
    
    @Mock
    private ChangeLogAgrupadorDao changeLogAgrupadorDao;
    
    @Mock
    private ChangeLogRespostaDao changeLogRespostaDao;
    
    @Mock
    private ChangeLogDialogoDao changeLogDialogoDao;
    
    @Mock
    private ChangeLogDialogoTagDao changeLogDialogoTagDao;
    
    @Mock
    private InstrucaoNormativaDialogoAUDDao instrucaoNormativaDialogoAUDDao;
    
    @Mock
    private SlotsAUDDao slotsAUDDao;
    
    @Mock
    private SlotsTagsAUDDao slotsTagsAUDDao;
    
    @Mock
    private RespostaDialogoSlotAUDDao respostaDialogoSlotAUDDao;
    
    
    @Before
  public void setUp() {
      MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testListarChangeLogRespostaSlots() {
        
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<RespostaDialogoSlotAUD> paginacao = new Paginacao<>();
        
        // Mock
        when(respostaDialogoSlotAUDDao.listarChangeLogRespostaSlots(entradaParametrosChangeLog, paginacao)).thenReturn(paginacao);
        
        // Acao
        changeLogManager.listarChangeLogRespostaSlots(entradaParametrosChangeLog, paginacao);
        
        // verificacao
        verify(respostaDialogoSlotAUDDao, times(1)).listarChangeLogRespostaSlots(entradaParametrosChangeLog, paginacao);
    }
    
    @Test
    public void testListarChangeLogSlotsTags() {
        
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<SlotsTagsAUD> paginacao = new Paginacao<>();
        
        // Mock
        when(slotsTagsAUDDao.listarChangeLogSlotsTags(entradaParametrosChangeLog, paginacao)).thenReturn(paginacao);
        
        // Acao
        changeLogManager.listarChangeLogSlotsTags(entradaParametrosChangeLog, paginacao);
        
        // verificacao
        verify(slotsTagsAUDDao, times(1)).listarChangeLogSlotsTags(entradaParametrosChangeLog, paginacao);
    }
    
    @Test
    public void testListarChangeLogSlots() {
        
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<SlotsAUD> paginacao = new Paginacao<>();
        
        // Mock
        when(slotsAUDDao.listarChangeLogSlots(entradaParametrosChangeLog, paginacao)).thenReturn(paginacao);
        
        // Acao
        changeLogManager.listarChangeLogSlots(entradaParametrosChangeLog, paginacao);
        
        // verificacao
        verify(slotsAUDDao, times(1)).listarChangeLogSlots(entradaParametrosChangeLog, paginacao);
    }
    
    @Test
    public void testListarChangeLogIns() {
        
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<InstrucaoNormativaDialogoAUD> paginacao = new Paginacao<>();
        
        // Mock
        when(instrucaoNormativaDialogoAUDDao.listarChangeLogIns(entradaParametrosChangeLog, paginacao)).thenReturn(paginacao);
        
        // Acao
        changeLogManager.listarChangeLogIns(entradaParametrosChangeLog, paginacao);
        
        // verificacao
        verify(instrucaoNormativaDialogoAUDDao, times(1)).listarChangeLogIns(entradaParametrosChangeLog, paginacao);
    }
    
    @Test
    public void testListarChangeLogTagNos() {
        
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogDialogoTag> paginacao = new Paginacao<>();
        
        // Mock
        when(changeLogDialogoTagDao.listarChangeLogTagNos(entradaParametrosChangeLog, paginacao)).thenReturn(paginacao);
        
        // Acao
        changeLogManager.listarChangeLogTagNos(entradaParametrosChangeLog, paginacao);
        
        // verificacao
        verify(changeLogDialogoTagDao, times(1)).listarChangeLogTagNos(entradaParametrosChangeLog, paginacao);
    }
    
    @Test
    public void testListarChangeLogIntencao() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                        .comDataInicial(new Date(11/11/2012))
                                                        .comDataFinal(new Date(10/11/2012))
                                                        .build();
        
        Paginacao<ChangeLogIntencao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(
                                            umChangeLogIntencao()
                                            .comDataRevisao(entradaChangeLog.getDataInicial())
                                            .comDataRevisao(entradaChangeLog.getDataFinal())
                                            .build()
                                            ));
        // Mock
        when(changeLogIntencaoDao.listarChangeLogIntencao(entradaChangeLog, paginacao)).thenReturn(paginacao);
        
        // Acao
        changeLogManager.listarChangeLogIntencao(entradaChangeLog, paginacao);

        // verificacao
        verify(changeLogIntencaoDao).listarChangeLogIntencao(entradaChangeLog, paginacao);
        
    }

    @Test
    public void testListarChangeLogExemplo() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO()
                                                                  .comDataInicial(new Date(11/11/2012))
                                                                  .comDataFinal(new Date(10/11/2012))
                                                                  .build();
        
        Paginacao<ChangeLogExemplo> paginacao = new Paginacao<>();
        
                
        
        // Mock
        changeLogExemploDao.listarChangeLogExemplo(entradaParametrosChangeLog, paginacao);
        
        // Acao
        changeLogManager.listarChangeLogExemplo(entradaParametrosChangeLog, paginacao);
        
        // Verificacao
        verify(changeLogExemploDao, times(2)).listarChangeLogExemplo(entradaParametrosChangeLog, paginacao);
        
    }

    @Test
    public void testListarChangeLogPerguntaRevisao() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogPerguntaRevisao> paginacao = new Paginacao<>();
        
        // Mock
        changeLogPerguntaRevisaoDao.listarChangeLogPerguntaRevisao(entradaParametrosChangeLog, paginacao);
        
        // Acao
        changeLogManager.listarChangeLogPerguntaRevisao(entradaParametrosChangeLog, paginacao);
        
        // verificacao
        verify(changeLogPerguntaRevisaoDao, times(2)).listarChangeLogPerguntaRevisao(entradaParametrosChangeLog, paginacao);
    }

    @Test
    public void testListarChangeLogEntidade() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogEntidade> paginacao = new Paginacao<>();        
        
        // Mock
        changeLogEntidadeDao.listarChangeLogEntidade(entradaParametrosChangeLog, paginacao);
       
        // Acao
        changeLogManager.listarChangeLogEntidade(entradaParametrosChangeLog, paginacao);
        
        // Verificacao
        verify(changeLogEntidadeDao,times(2)).listarChangeLogEntidade(entradaParametrosChangeLog, paginacao);
    
    }

    @Test
    public void testListarChangeLogSinonimo() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogSinonimo> paginacao = new Paginacao<>();
        // Mock
        changeLogSinonimoDao.listarChangeLogSinonimo(entradaParametrosChangeLog, paginacao);
        
        // Acao
        changeLogManager.listarChangeLogSinonimo(entradaParametrosChangeLog, paginacao);

        // Verificacao
        verify(changeLogSinonimoDao, times(2)).listarChangeLogSinonimo(entradaParametrosChangeLog, paginacao);
    
    }

    @Test
    public void testListarChangeLogAgrupador() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogAgrupador> paginacao = new Paginacao<>();

        // Mock
        changeLogAgrupadorDao.listarChangeLogAgrupador(entradaParametrosChangeLog, paginacao);
        
        // Acao
        changeLogManager.listarChangeLogAgrupador(entradaParametrosChangeLog, paginacao);
        
        // verificao
        verify(changeLogAgrupadorDao, times(2)).listarChangeLogAgrupador(entradaParametrosChangeLog, paginacao);
        
    }

    @Test
    public void testListarChangeLogResposta() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogResposta> paginacao =  new Paginacao<>();
        
        // Mock
        changeLogRespostaDao.listarChangeLogResposta(entradaParametrosChangeLog, paginacao);
        
        // Acao
        changeLogManager.listarChangeLogResposta(entradaParametrosChangeLog, paginacao);
        
        // Verificao
        verify(changeLogRespostaDao, times(2)).listarChangeLogResposta(entradaParametrosChangeLog, paginacao);
    
    }

    @Test
    public void testListarChangeLogNos() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO().build();
        
        Paginacao<ChangeLogDialogo> paginacao = new Paginacao<>();
        
        // Mock
        changeLogDialogoDao.listarChangeLogNos(entradaParametrosChangeLog, paginacao);
        
        // Acao
        changeLogManager.listarChangeLogNos(entradaParametrosChangeLog, paginacao);
        
        //Verificacao
        verify(changeLogDialogoDao, times(2)).listarChangeLogNos(entradaParametrosChangeLog, paginacao);
        
    }

    @Test
    public void testlistarChangeLogIntencao() {
        // Cenario
        int idClassificador = 10;
        
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO()
                                                                  .comIdClassificador(idClassificador)
                                                                  .build();
        
        List<ChangeLogIntencao> listaChangeLogIntencao = Arrays.asList(umChangeLogIntencao()
                                                               .comIdClassificador(entradaParametrosChangeLog.getIdClassificador())
                                                               .build()
                                                                );
        
        // Mock
        when(changeLogIntencaoDao.listarChangeLogIntencao(entradaParametrosChangeLog, idClassificador))
                                                                .thenReturn(listaChangeLogIntencao);
        
        // Acao
        changeLogManager.listarChangeLogIntencao(entradaParametrosChangeLog, idClassificador);
        
        // Verificao
        verify(changeLogIntencaoDao, times(1)).listarChangeLogIntencao(entradaParametrosChangeLog, idClassificador);
    }

    @Test
    public void testlistarChangeLogExemplo() {
        // Cenario
        int idClassificador = 10;
        
        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO()
                                                                  .comIdClassificador(idClassificador)
                                                                  .build();
        
        List<ChangeLogExemplo> listaChangeLogExemplo = Arrays.asList(umChangeLogExemplo()
                                                             .comIdClassificador(entradaParametrosChangeLog.getIdClassificador())
                                                             .build()
                                                             );
        // Mock
        when(changeLogExemploDao.listarChangeLogExemplo(entradaParametrosChangeLog, idClassificador))
                                                        .thenReturn(listaChangeLogExemplo);
        
        // Acao
        changeLogManager.listarChangeLogExemplo(entradaParametrosChangeLog, idClassificador);
        
        // Verificacao
        verify(changeLogExemploDao, times(1)).listarChangeLogExemplo(entradaParametrosChangeLog, idClassificador);
    
    }

    @Test
    public void testlistarChangeLogEntidade() {
        // Cenario
        Integer idClassificador = 10;

        ChangeLogParametrosEntradaVO entradaParametrosChangeLog = umChangeLogParametrosEntradaVO()
                                                                    .comIdClassificador(idClassificador)
                                                                    .build();
        
        List<ChangeLogEntidade> listaChangeLogEntidade = Arrays.asList(umChangeLogEntidade()
                                                               .comIdClassificador(entradaParametrosChangeLog.getIdClassificador())
                                                               .build()
                                                               );

        // Mock
        when(changeLogEntidadeDao.listarChangeLogEntidade(entradaParametrosChangeLog, idClassificador))
                                                                .thenReturn(listaChangeLogEntidade);
        
        // Acao
        changeLogManager.listarChangeLogEntidade(entradaParametrosChangeLog, idClassificador);
        
        // Verificacao
        verify(changeLogEntidadeDao, times(1)).listarChangeLogEntidade(entradaParametrosChangeLog, idClassificador);
    }

//    ===== Cenario 1 ===== (entradaChangeLog.getDataInicial() = null && entradaChangeLog.getDataFinal() == null) >> linha 144 <<<
    @Test
    public void testValidarDatalNULL() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                        .comDataInicial(null)
                                                        .comDataFinal(null)
                                                        .build();

        // Acao
        changeLogManager.validarDatas(entradaChangeLog);
        
        // Verificacao
        assertNotNull(entradaChangeLog.getDataInicial());
        assertNotNull(entradaChangeLog.getDataFinal());
        
    }
    
//    ===== Cenario 2 ===== (entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() !== null) >> linha 144 <<<
    @Test
    public void testValidarDatasDiferenteDeNULL() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                        .comDataInicial(new Date(10/11/2012))
                                                        .comDataFinal(new Date(12/11/2012))
                                                        .build();

        // Acao
        changeLogManager.validarDatas(entradaChangeLog);
        
        
        // Verificacao
        assertNotNull(entradaChangeLog.getDataInicial());
        assertNotNull(entradaChangeLog.getDataFinal());

    }
    
//  ===== Cenario 3 ===== (entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() == null) >> linha 150 <<<   
    @Test
    public void testDataFinallNULL () {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                        .comDataInicial(new Date(10/11/2012))
                                                        .comDataFinal(null)
                                                        .build();

        // Acao
        changeLogManager.validarDatas(entradaChangeLog);
        
        
        // Verificacao
        assertNotNull(entradaChangeLog.getDataInicial());
        assertNotNull(entradaChangeLog.getDataFinal());
    }
    
//  ===== Cenario 4 ===== (entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() == null) >> linha 150 <<<   
    @Test
    public void testDataFinalDiferentelNULL() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                        .comDataInicial(new Date(10/11/2012))
                                                        .comDataFinal(new Date(30/11/2012))
                                                        .build();

        // Acao
        changeLogManager.validarDatas(entradaChangeLog);
        
        
        // Verificacao
        assertNotNull(entradaChangeLog.getDataInicial());
        assertNotNull(entradaChangeLog.getDataFinal());
    }
    
//  ===== Cenario 5 ===== (entradaChangeLog.getDataInicial() = null && entradaChangeLog.getDataFinal() !== null) >> linha 156 <<<
    @Test
    public void testDataInicialNULL() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                        .comDataInicial(null)
                                                        .comDataFinal(new Date(10/11/2012))
                                                        .build();

        // Acao
        changeLogManager.validarDatas(entradaChangeLog);
        
        
        // Verificacao
        assertNotNull(entradaChangeLog.getDataInicial());
        assertNotNull(entradaChangeLog.getDataFinal());
        
    }
    
//  ===== Cenario 6 ===== (entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() !== null) >> linha 156 <<<
    @Test
    public void testDataInicialDiferenteDeNULL() {
        // Cenario
//        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
//                                                        .comDataInicial(new Date(11/11/2012))
//                                                        .comDataFinal(new Date(10/11/2012))
//                                                        .build();

        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                .comDataInicial(new Date(10/11/2012))
                .comDataFinal(null)
                .build();
//        .comDataFinal(new Date(10/11/2012))
        // Acao
        changeLogManager.validarDatas(entradaChangeLog);
        
        
        // Verificacao
        assertNotNull(entradaChangeLog.getDataInicial());
        assertNotNull(entradaChangeLog.getDataFinal());
        
    }
    
//  ===== Cenario 7 ===== (entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() !== null) >> linha 161 <<<
    @Test
    public void testDataInicialMaiorQueDateFinal() {
        // Cenario
        ChangeLogParametrosEntradaVO entradaChangeLog = umChangeLogParametrosEntradaVO()
                                                    .comDataInicial(new Date(01/12/2012))
                                                    .comDataFinal(new Date(01/11/2012))
                                                    .comDataInicial(new Time(10))
                                                    .comDataFinal(new Time(0))
                                                    .build();

        // Acao
        assertThatThrownBy(() -> {
            changeLogManager.validarDatas(entradaChangeLog);
      }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Data inicial maior que a data final");
    }
}
