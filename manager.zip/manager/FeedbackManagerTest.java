package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static br.com.bb.databuilder.PerguntaBuilder.umPergunta;
import static br.com.bb.databuilder.PerguntaRevisaoBuilder.umPerguntaRevisao;
import static br.com.bb.databuilder.PerguntaRevisaoIntencaoBuilder.umPerguntaRevisaoIntencao;
import static br.com.bb.databuilder.PerguntaRevisaoUsuarioBuilder.umPerguntaRevisaoUsuario;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoEntidadeDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoIntencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.util.JSONUtils;


public class FeedbackManagerTest {
    
    @InjectMocks
    private FeedbackManager feedbackManager;
    
    @Mock
    private ClassificadorManager classificadorManager;
    
    @Mock
    JSONUtils jSONUtils;
    
    @Mock
    JSONObject jSONObject;
    
    @Mock
    private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Mock
    private PerguntaRevisaoDao perguntaRevisaoDao;
    
    @Mock 
    private PerguntaDao perguntaDao;
    
    @Mock
    private PerguntaRevisaoEntidadeDao perguntaRevisaoEntidadeDao;
    
    @Mock
    private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testRegistrarFeedbackComInputVazio() {
        //Cenário
        String siglaTipoServico = "Sigla";
        Boolean feedback = true;
        Boolean email = true;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"conversation_id\": \"81287577-41aa-4d10-a431-5367f0a9d8d1\",    "
                + "\"system\": {      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      "
                + "\"dialog_turn_counter\": 1.0,      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        "
                + "\"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [          0.0,          0.0,          3.0,          1.0,          2.0        ]      }    }  },  "
                + "\"entities\": [],  \"intents\": [],  \"output\": {    \"log_messages\": [],    \"text\": [      \"Oi, em que posso te ajudar?\"    ],    "
                + "\"nodes_visited\": [      \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\"    ]  },  \"input\": {    \"text\": \"\"  }}";
        
        Classificador classificador = umClassificador().comId(1).build();
        List<NuvemWatson> nuvens = Arrays.asList(umNuvemWatson().comClassificador(classificador).build());
        
        //Mock
        when(nuvemWatsonDao.findBySigla(siglaTipoServico)).thenReturn(nuvens);
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testRegistrarFeedbackComInputNull() {
        //Cenário
        String siglaTipoServico = "Sigla";
        Boolean feedback = true;
        Boolean email = true;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"conversation_id\": \"81287577-41aa-4d10-a431-5367f0a9d8d1\",    "
                + "\"system\": {      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      "
                + "\"dialog_turn_counter\": 1.0,      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        "
                + "\"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [          0.0,          0.0,          3.0,          1.0,          2.0        ]      }    }  },  "
                + "\"entities\": [],  \"intents\": [],  \"output\": {    \"log_messages\": [],    \"text\": [      \"Oi, em que posso te ajudar?\"    ],    "
                + "\"nodes_visited\": [      \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\"    ]  },  \"input\": null}";
        
        Classificador classificador = umClassificador().comId(1).build();
        List<NuvemWatson> nuvens = Arrays.asList(umNuvemWatson().comClassificador(classificador).build());
        
        //Mock
        when(nuvemWatsonDao.findBySigla(siglaTipoServico)).thenReturn(nuvens);
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testRegistrarFeedbackComClassificadorNull() {
        //Cenário
        String siglaTipoServico = "Sigla";
        Boolean feedback = true;
        Boolean email = true;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"conversation_id\": \"81287577-41aa-4d10-a431-5367f0a9d8d1\",    "
                + "\"system\": {      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      "
                + "\"dialog_turn_counter\": 1.0,      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        "
                + "\"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [          0.0,          0.0,          3.0,          1.0,          2.0        ]      }    }  },  "
                + "\"entities\": [],  \"intents\": [],  \"output\": {    \"log_messages\": [],    \"text\": [      \"Oi, em que posso te ajudar?\"    ],    "
                + "\"nodes_visited\": [      \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\"    ]  },  \"input\": {    \"text\": \"\"  }}";
        
        List<NuvemWatson> nuvens = new ArrayList<NuvemWatson>();
        
        //Mock
        when(nuvemWatsonDao.findBySigla(siglaTipoServico)).thenReturn(nuvens);
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testRegistrarFeedback() {
        //Cenário
        /*entrada*/
        String siglaTipoServico = "Sigla";
        Boolean feedback = null;
        Boolean email = true;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"canal\": \"BBNorminha\",    \"conversation_id\": \"009e9861-611b-472c-9892-32f9ced17f82\",    \"system\": {      "
                + "\"initialized\": true,      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      \"dialog_turn_counter\": 1.0,"
                + "      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        \"node_conversation_start0\": [          0.0        ]      },      "
                + "\"branch_exited\": true,      \"branch_exited_reason\": \"completed\"    }  },  \"entities\": [],  \"intents\": [    {      \"confidence\": "
                + "0.11202660182677705,      \"intent\": \"LCPR_-_METODOLOGIA_ASPECTOS_GERAIS_CMP_AMBIGUA\"    },    {      \"confidence\": 0.10811645787218184,      "
                + "\"intent\": \"LCPR_-_16_CONTROLE_LIMITE_CREDITO\"    },    {      \"confidence\": 0.10806644057738525,      \"intent\": \"LCPR_-_ANALISE_AUTOMATICA_INDIVIDUAL\"    },"
                + "    {      \"confidence\": 0.10702922410158423,      \"intent\": \"LCPR_-_METODOLOGIA_ASPECTOS_GERAIS_CMP\"    },    {      \"confidence\": 0.10531515478480814,"
                + "      \"intent\": \"LCPR_-_ESTABELECIMENTO_DEMAIS_GR_CARTAO_CHEQUE\"    },    {      \"confidence\": 0.10442672325514125,      \"intent\": \"LCPR_-_COMPETENCIA_DOCUMENTOS_DEL\""
                + "    },    {      \"confidence\": 0.1038241982020054,      \"intent\": \"LCPR_-_RESPOSTA_FORA_DE_NORMA\"    },    {      \"confidence\": 0.10340942982951518,      "
                + "\"intent\": \"LCPR_-_16_ASPECTOS_GERAIS_RISCO\"    },    {      \"confidence\": 0.10334677437951356,      \"intent\": \"LCPR_-_16_IMPACTO_ANC_RURAL_CUSTEIO_ALONG\"    },    "
                + "{      \"confidence\": 0.10309670798025651,      \"intent\": \"LCPR_-_PARECER_ASSESSOR_AGRO_AMBIGUA\"    }  ],  \"output\": {    \"text\": [      "
                + "\"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\"    ],    \"output_watson\": {"
                + "      \"tx_falado\": \"Oi em que posso te ajudar?\",      \"tx_twitter\": \"Oi em que posso te ajudar?\",      \"tx_facebook\": \"Oi em que posso te ajudar?\",      "
                + "\"log_messages\": [],      \"tx_atendimento_a_funcionarios\": \"Oi em que posso te ajudar?\",      \"tx_exclusivo_ditec\": \"Oi em que posso te ajudar?\",      "
                + "\"text\": [        \"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\"      ],"
                + "      \"tx_padrao\": \"Oi em que posso te ajudar?\",      \"tx_loja_de_aplicativos\": \"Oi em que posso te ajudar?\",      \"generic\": [        {          "
                + "\"response_type\": \"text\",          \"text\": \"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\" "
                + "       }      ],      \"nodes_visited\": [        \"node_conversation_start0\"      ]    }  },  \"input\": {    \"text\": \"oi\"  }}";
        
        /*registrarFeedback > getClassificadorPorServico ok*/ 
        Classificador classificador = umClassificador().comId(1).comReducaoCuradoria(true).build();
        List<NuvemWatson> nuvens = Arrays.asList(umNuvemWatson().comClassificador(classificador).build());
        when(nuvemWatsonDao.findBySigla(siglaTipoServico)).thenReturn(nuvens);
        
        /*registrarFeedback > getPerguntaCorpus ok*/
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(1).comPergunta("oi").build());
        when(perguntaDao.findIgual(classificador.getId(), "oi")).thenReturn(perguntas);
        Pergunta exemplo = perguntas.get(0);
        
        /*registrarFeedback > coletar > recuperarPerguntaRevisao*/
        PerguntaRevisaoStatus status = PerguntaRevisaoStatus.REVISAO;
        if( exemplo != null ){ status = PerguntaRevisaoStatus.AUTOMATICO; }
        List<PerguntaRevisao> listaPerguntas = Arrays.asList(umPerguntaRevisao().comId(1).comStatus(PerguntaRevisaoStatus.REVISAO).build(),
                                                             umPerguntaRevisao().comId(1).comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA).build());
        when(perguntaRevisaoDao.findPergunta("oi", classificador.getId(), status)).thenReturn(listaPerguntas);
        PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comPergunta("oi").comClassificador(classificador).comDataCriacao(new Date()).comQuantidade(0).comVinculada(false).comQtdNegativo(0).comQtdPositivo(0).comStatus(PerguntaRevisaoStatus.REVISAO).build();
        
        /*registrarFeedback > coletar > persistePerguntaRevisao*/
        perguntaRevisaoDao.persist(perguntaRevisao);
        String conversationId = "009e9861-611b-472c-9892-32f9ced17f82";
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().build());
        when(perguntaRevisaoUsuarioDao.findPergunta(usuario, conversationId, perguntaRevisao.getId())).thenReturn(usuarios);
        //PerguntaRevisaoEntidade entidade = umPerguntaRevisaoEntidade().comAgrupador("Agrupador").comEntidade("Entidade").comId(1).build();
        PerguntaRevisaoUsuario pru = umPerguntaRevisaoUsuario().build();
        perguntaRevisaoUsuarioDao.persist(pru);
        
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testRegistrarFeedback2() {
        //Cenário
        /*entrada*/
        String siglaTipoServico = "Sigla";
        Boolean feedback = null;
        Boolean email = true;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"canal\": \"BBNorminha\",    \"conversation_id\": \"009e9861-611b-472c-9892-32f9ced17f82\",    \"system\": {      "
                + "\"initialized\": true,      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      \"dialog_turn_counter\": 1.0,"
                + "      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        \"node_conversation_start0\": [          0.0        ]      },      "
                + "\"branch_exited\": true,      \"branch_exited_reason\": \"completed\"    }  },  \"entities\": [],  \"intents\": [    {      \"confidence\": "
                + "0.11202660182677705,      \"intent\": \"LCPR_-_METODOLOGIA_ASPECTOS_GERAIS_CMP_AMBIGUA\"    },    {      \"confidence\": 0.10811645787218184,      "
                + "\"intent\": \"LCPR_-_16_CONTROLE_LIMITE_CREDITO\"    },    {      \"confidence\": 0.10806644057738525,      \"intent\": \"LCPR_-_ANALISE_AUTOMATICA_INDIVIDUAL\"    },"
                + "    {      \"confidence\": 0.10702922410158423,      \"intent\": \"LCPR_-_METODOLOGIA_ASPECTOS_GERAIS_CMP\"    },    {      \"confidence\": 0.10531515478480814,"
                + "      \"intent\": \"LCPR_-_ESTABELECIMENTO_DEMAIS_GR_CARTAO_CHEQUE\"    },    {      \"confidence\": 0.10442672325514125,      \"intent\": \"LCPR_-_COMPETENCIA_DOCUMENTOS_DEL\""
                + "    },    {      \"confidence\": 0.1038241982020054,      \"intent\": \"LCPR_-_RESPOSTA_FORA_DE_NORMA\"    },    {      \"confidence\": 0.10340942982951518,      "
                + "\"intent\": \"LCPR_-_16_ASPECTOS_GERAIS_RISCO\"    },    {      \"confidence\": 0.10334677437951356,      \"intent\": \"LCPR_-_16_IMPACTO_ANC_RURAL_CUSTEIO_ALONG\"    },    "
                + "{      \"confidence\": 0.10309670798025651,      \"intent\": \"LCPR_-_PARECER_ASSESSOR_AGRO_AMBIGUA\"    }  ],  \"output\": {    \"text\": [      "
                + "\"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\"    ],    \"output_watson\": {"
                + "      \"tx_falado\": \"Oi em que posso te ajudar?\",      \"tx_twitter\": \"Oi em que posso te ajudar?\",      \"tx_facebook\": \"Oi em que posso te ajudar?\",      "
                + "\"log_messages\": [],      \"tx_atendimento_a_funcionarios\": \"Oi em que posso te ajudar?\",      \"tx_exclusivo_ditec\": \"Oi em que posso te ajudar?\",      "
                + "\"text\": [        \"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\"      ],"
                + "      \"tx_padrao\": \"Oi em que posso te ajudar?\",      \"tx_loja_de_aplicativos\": \"Oi em que posso te ajudar?\",      \"generic\": [        {          "
                + "\"response_type\": \"text\",          \"text\": \"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\" "
                + "       }      ],      \"nodes_visited\": [        \"node_conversation_start0\"      ]    }  },  \"input\": {    \"text\": \"oi\"  }}";
        
        /*registrarFeedback > getClassificadorPorServico ok*/ 
        Classificador classificador = umClassificador().comId(1).comReducaoCuradoria(true).build();
        List<NuvemWatson> nuvens = Arrays.asList(umNuvemWatson().comClassificador(classificador).build());
        when(nuvemWatsonDao.findBySigla(siglaTipoServico)).thenReturn(nuvens);
        
        /*registrarFeedback > getPerguntaCorpus ok*/
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(1).comPergunta("oi").build());
        when(perguntaDao.findIgual(classificador.getId(), "oi")).thenReturn(perguntas);
        Pergunta exemplo = perguntas.get(0);
        
        /*registrarFeedback > coletar > recuperarPerguntaRevisao*/
        PerguntaRevisaoStatus status = PerguntaRevisaoStatus.REVISAO;
        if( exemplo != null ){ status = PerguntaRevisaoStatus.AUTOMATICO; }
        List<PerguntaRevisao> listaPerguntas = Arrays.asList(umPerguntaRevisao().comId(1).comStatus(PerguntaRevisaoStatus.REVISAO).build(),
                                                             umPerguntaRevisao().comId(1).comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA).build());
        when(perguntaRevisaoDao.findPergunta("oi", classificador.getId(), status)).thenReturn(listaPerguntas);
        PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comPergunta("oi").comClassificador(classificador).comDataCriacao(new Date()).comQuantidade(0).comVinculada(false).comQtdNegativo(0).comQtdPositivo(0).comStatus(PerguntaRevisaoStatus.REVISAO).build();
        
        /*registrarFeedback > coletar > persistePerguntaRevisao*/
        perguntaRevisaoDao.persist(perguntaRevisao);
        String conversationId = "009e9861-611b-472c-9892-32f9ced17f82";
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().build());
        when(perguntaRevisaoUsuarioDao.findPergunta(usuario, conversationId, perguntaRevisao.getId())).thenReturn(usuarios);
        //PerguntaRevisaoEntidade entidade = umPerguntaRevisaoEntidade().comAgrupador("Agrupador").comEntidade("Entidade").comId(1).build();
        PerguntaRevisaoUsuario pru = umPerguntaRevisaoUsuario().build();
        perguntaRevisaoUsuarioDao.persist(pru);
        
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testRegistrarFeedbackComFeedbackTrue() {
        //Cenário
        String siglaTipoServico = "Sigla";
        Boolean feedback = true;
        Boolean email = true;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"conversation_id\": \"81287577-41aa-4d10-a431-5367f0a9d8d1\",    "
                + "\"system\": {      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      "
                + "\"dialog_turn_counter\": 1.0,      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        "
                + "\"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [          0.0,          0.0,          3.0,          1.0,          2.0        ]      }    }  },  "
                + "\"entities\": [],  \"intents\": [],  \"output\": {    \"log_messages\": [],    \"text\": [      \"Oi, em que posso te ajudar?\"    ],    "
                + "\"nodes_visited\": [      \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\"    ]  },  \"input\": {    \"text\": \"oi\"  }}";
        
        Classificador classificador = umClassificador().comId(1).build();
        List<NuvemWatson> nuvens = Arrays.asList(umNuvemWatson().comClassificador(classificador).build());
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(1).comDataCriacao(new Date()).comPergunta("oi").build());
        List<PerguntaRevisao> perguntaRevisao = Arrays.asList(umPerguntaRevisao().comId(2).comStatus(PerguntaRevisaoStatus.AUTOMATICO).build());
        
        //Mock
        when(nuvemWatsonDao.findBySigla(siglaTipoServico)).thenReturn(nuvens);
        when(perguntaDao.findIgual(nuvens.get(0).getClassificador().getId(), "oi")).thenReturn(perguntas);
        when(perguntaRevisaoDao.findPergunta("oi", nuvens.get(0).getClassificador().getId(), PerguntaRevisaoStatus.AUTOMATICO)).thenReturn(perguntaRevisao);
        perguntaRevisaoDao.persist(perguntaRevisao.get(0));
        PerguntaRevisaoUsuario pru = umPerguntaRevisaoUsuario().build();
        perguntaRevisaoUsuarioDao.persist(pru);
        perguntaRevisaoDao.flush();
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testRegistrarFeedbackComFeedbackFalse() {
        //Cenário
        String siglaTipoServico = "Sigla";
        Boolean feedback = false;
        Boolean email = false;
        String usuario = "F12345678";
        String json = "{  \"context\": {    \"canal\": \"BBNorminha\",    \"conversation_id\": \"009e9861-611b-472c-9892-32f9ced17f82\",    \"system\": {      "
                + "\"initialized\": true,      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      \"dialog_turn_counter\": 1.0,"
                + "      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        \"node_conversation_start0\": [          0.0        ]      },      "
                + "\"branch_exited\": true,      \"branch_exited_reason\": \"completed\"    }  },  \"entities\": [],  \"intents\": [    {      \"confidence\": "
                + "0.11202660182677705,      \"intent\": \"LCPR_-_METODOLOGIA_ASPECTOS_GERAIS_CMP_AMBIGUA\"    },    {      \"confidence\": 0.10811645787218184,      "
                + "\"intent\": \"LCPR_-_16_CONTROLE_LIMITE_CREDITO\"    },    {      \"confidence\": 0.10806644057738525,      \"intent\": \"LCPR_-_ANALISE_AUTOMATICA_INDIVIDUAL\"    },"
                + "    {      \"confidence\": 0.10702922410158423,      \"intent\": \"LCPR_-_METODOLOGIA_ASPECTOS_GERAIS_CMP\"    },    {      \"confidence\": 0.10531515478480814,"
                + "      \"intent\": \"LCPR_-_ESTABELECIMENTO_DEMAIS_GR_CARTAO_CHEQUE\"    },    {      \"confidence\": 0.10442672325514125,      \"intent\": \"LCPR_-_COMPETENCIA_DOCUMENTOS_DEL\""
                + "    },    {      \"confidence\": 0.1038241982020054,      \"intent\": \"LCPR_-_RESPOSTA_FORA_DE_NORMA\"    },    {      \"confidence\": 0.10340942982951518,      "
                + "\"intent\": \"LCPR_-_16_ASPECTOS_GERAIS_RISCO\"    },    {      \"confidence\": 0.10334677437951356,      \"intent\": \"LCPR_-_16_IMPACTO_ANC_RURAL_CUSTEIO_ALONG\"    },    "
                + "{      \"confidence\": 0.10309670798025651,      \"intent\": \"LCPR_-_PARECER_ASSESSOR_AGRO_AMBIGUA\"    }  ],  \"output\": {    \"text\": [      "
                + "\"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\"    ],    \"output_watson\": {"
                + "      \"tx_falado\": \"Oi em que posso te ajudar?\",      \"tx_twitter\": \"Oi em que posso te ajudar?\",      \"tx_facebook\": \"Oi em que posso te ajudar?\",      "
                + "\"log_messages\": [],      \"tx_atendimento_a_funcionarios\": \"Oi em que posso te ajudar?\",      \"tx_exclusivo_ditec\": \"Oi em que posso te ajudar?\",      "
                + "\"text\": [        \"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\"      ],"
                + "      \"tx_padrao\": \"Oi em que posso te ajudar?\",      \"tx_loja_de_aplicativos\": \"Oi em que posso te ajudar?\",      \"generic\": [        {          "
                + "\"response_type\": \"text\",          \"text\": \"No momento estou treinada para responder suas perguntas sobre cálculo e estabelecimento de limite de crédito para produtores rurais.\" "
                + "       }      ],      \"nodes_visited\": [        \"node_conversation_start0\"      ]    }  },  \"input\": {    \"text\": \"oi\"  }}";
        
        Classificador classificador = umClassificador().comId(1).build();
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(1).comDataCriacao(new Date()).comPergunta("oi").build());
        List<PerguntaRevisao> perguntaRevisao = Arrays.asList(umPerguntaRevisao().comId(2).comStatus(PerguntaRevisaoStatus.REVISAO).comQtdNegativo(null).build());
        
        //Mock
        when(classificadorManager.getClassificadorPorServico(siglaTipoServico)).thenReturn(classificador);
        when(perguntaDao.findIgual(classificador.getId(), "oi")).thenReturn(perguntas);
        when(perguntaRevisaoDao.findPergunta("oi", classificador.getId(), PerguntaRevisaoStatus.REVISAO)).thenReturn(perguntaRevisao);
        perguntaRevisaoDao.persist(perguntaRevisao.get(0));
        PerguntaRevisaoUsuario pru = umPerguntaRevisaoUsuario().build();
        perguntaRevisaoUsuarioDao.persist(pru);
        perguntaRevisaoDao.flush();
        
        //Ação
        feedbackManager.registrarFeedback(siglaTipoServico, feedback, email, usuario, json);
        
        //Verificação
    }
    
    @Test
    public void testColetarCorpusNull() {
        //Cenário
        String input = "Input";
        Classificador corpus = null;
        String usuario = "F12345678";
        Boolean email = true;
        String json = "Json";
        Integer quantidade = 3;
        Boolean temExemplo = false;
        Date data = new Date();
        
        //Ação
        feedbackManager.coletar(input, corpus, usuario, email, json, quantidade, temExemplo, data);;
    }
    
    @Test
    public void testColetarComPerguntasVazio() {
        //Cenário
        String input = "Input";
        Classificador corpus = umClassificador().build();
        String usuario = "F12345678";
        Boolean email = true;
        String json = "{  \"context\": {    \"conversation_id\": \"81287577-41aa-4d10-a431-5367f0a9d8d1\",    "
                + "\"system\": {      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      "
                + "\"dialog_turn_counter\": 1.0,      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        "
                + "\"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [          0.0,          0.0,          3.0,          1.0,          2.0        ]      }    }  },  "
                + "\"entities\": [],  \"intents\": [],  \"output\": {    \"log_messages\": [],    \"text\": [      \"Oi, em que posso te ajudar?\"    ],    "
                + "\"nodes_visited\": [      \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\"    ]  },  \"input\": {    \"text\": \"\"  }}";
        
        Integer quantidade = 3;
        Boolean temExemplo = true;
        Date data = new Date();
        
        PerguntaRevisaoStatus status = PerguntaRevisaoStatus.AUTOMATICO;
        
        List<PerguntaRevisao> perguntas = new ArrayList<PerguntaRevisao>();
        
        //Mock
        /*recuperarPerguntaRevisao*/
        when(perguntaRevisaoDao.findPergunta(input, corpus.getId(), status)).thenReturn(perguntas);
        
        //Ação
        feedbackManager.coletar(input, corpus, usuario, email, json, quantidade, temExemplo, data);;
        
        //Verificação
    }
    
    
    
    @Test
    public void testColetar() {
        //Cenário
        String input = "Input";
        Classificador corpus = umClassificador().build();
        String usuario = "F12345678";
        Boolean email = true;
        String json = "{  \"context\": {    \"conversation_id\": \"81287577-41aa-4d10-a431-5367f0a9d8d1\",    "
                + "\"system\": {      \"dialog_stack\": [        {          \"dialog_node\": \"root\"        }      ],      "
                + "\"dialog_turn_counter\": 1.0,      \"dialog_request_counter\": 1.0,      \"_node_output_map\": {        "
                + "\"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [          0.0,          0.0,          3.0,          1.0,          2.0        ]      }    }  },  "
                + "\"entities\": [],  \"intents\": [],  \"output\": {    \"log_messages\": [],    \"text\": [      \"Oi, em que posso te ajudar?\"    ],    "
                + "\"nodes_visited\": [      \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\"    ]  },  \"input\": {    \"text\": \"\"  }}";
        Integer quantidade = 3;
        Boolean temExemplo = true;
        Date data = new Date();
        
        PerguntaRevisaoStatus status = PerguntaRevisaoStatus.AUTOMATICO;
        
        List<PerguntaRevisao> perguntas = Arrays.asList(umPerguntaRevisao().comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA).build(),
                                                        umPerguntaRevisao().comStatus(PerguntaRevisaoStatus.REVISAO).build());
        
        //Mock
        /*recuperarPerguntaRevisao*/
        when(perguntaRevisaoDao.findPergunta(input, corpus.getId(), status)).thenReturn(perguntas);
        
        //Ação
        feedbackManager.coletar(input, corpus, usuario, email, json, quantidade, temExemplo, data);;
        
        //Verificação
    }
    
    @Test
    public void testGetIntencaoMaiorRelevancia() {
        //Cenário
        PerguntaRevisao pergunta = umPerguntaRevisao().build();
        List<PerguntaRevisaoIntencao> intencoes = Arrays.asList(umPerguntaRevisaoIntencao().build());
        
        //Ação
        feedbackManager.getIntencaoMaiorRelevancia(pergunta, intencoes);
    }
    
    @Test
    public void testGetIntencaoMaiorRelevanciaComIntencoesVazio() {
        //Cenário
        PerguntaRevisao pergunta = umPerguntaRevisao().build();
        List<PerguntaRevisaoIntencao> intencoes = new ArrayList<PerguntaRevisaoIntencao>();
        
        //Ação
        feedbackManager.getIntencaoMaiorRelevancia(pergunta, intencoes);
    }
    
    @Test
    public void testGetIntencaoMaiorRelevanciaComIntencoesNull1() {
        //Cenário
        PerguntaRevisao pergunta = umPerguntaRevisao().build();
        List<PerguntaRevisaoIntencao> intencoes = null;
        
        List<PerguntaRevisaoIntencao> retornoIntencoes = Arrays.asList(umPerguntaRevisaoIntencao().build());
        
        //Mock
        when(perguntaRevisaoIntencaoDao.findByPerguntaRevisaoIntencoes(pergunta.getId())).thenReturn(retornoIntencoes);
        
        //Ação
        feedbackManager.getIntencaoMaiorRelevancia(pergunta, intencoes);
        
        //Verificação
        
    }
    
    @Test
    public void testGetIntencaoMaiorRelevanciaComIntencoesNull2() {
        //Cenário
        PerguntaRevisao pergunta = umPerguntaRevisao().build();
        List<PerguntaRevisaoIntencao> intencoes = null;
        
        //Mock
        when(perguntaRevisaoIntencaoDao.findByPerguntaRevisaoIntencoes(pergunta.getId())).thenReturn(intencoes);
        
        //Ação
        feedbackManager.getIntencaoMaiorRelevancia(pergunta, intencoes);
        
        //Verificação
        
    }
    

}
