package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.DialogoVersaoV1Builder.umDialogoVersaoV1;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static br.com.bb.databuilder.RespostaBuilder.umResposta;
import static br.com.bb.databuilder.RespostaVersaoHistoricoBuilder.umRespostaVersaoHistorico;
import static br.com.bb.databuilder.VersaoCorpusBuilder.umVersaoCorpus;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import br.com.bb.databuilder.CorpusVersaoVoV1Builder;
import br.com.bb.databuilder.DialogoVersaoV1Builder;
import br.com.bb.databuilder.RespostaDialogoVersaoV1Builder;
import br.com.bb.gearq.c4coleta.dao.RespostaDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaVersaoHistoricoDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.Resposta;
import br.com.bb.gearq.c4coleta.model.RespostaVersaoHistorico;
import br.com.bb.gearq.c4coleta.model.StatusDialogo;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.util.JSONUtils;
import br.com.bb.gearq.c4coleta.versionamento.v1.CorpusVersaoVoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.RespostaDialogoSlotVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.RespostaDialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.SlotVersaoV1;

public class RespostaManagerTest {
    @InjectMocks
    private RespostaManager respostaManager;

    @InjectMocks
    private RespostaDialogoManager respostaDialogoManager;

    @Spy
    private VersaoCorpusManager versaoCorpusManager;

    @Mock
    private RespostaDao respostaDao;

    @Mock
    private RespostaDialogoDao respostaDialogoDao;

    @Mock
    private RespostaVersaoHistoricoDao respostaVersaoHistoricoDao;

    @Mock
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAtualizarRespostasNuvemSemJsonNIA() {

        // Cenário
        Classificador classificador = umClassificador().comId(1).build();

        String sigla = "SIGLA_BOT";
        NuvemWatson nuvem = umNuvemWatson().comSiglaNuvem(sigla).comClassificador(classificador).build();

        VersaoCorpus versaoCorpus = umVersaoCorpus().comId(1).build();
        versaoCorpus.getVersao();
        versaoCorpus.getDescricao();
        versaoCorpus.getIdClassificador();
        versaoCorpus.getClassificador();
        versaoCorpus.getDataCriacao();
        versaoCorpus.getJsonWatson();
        versaoCorpus.getIdUsuario();
        versaoCorpus.getUsuario();

        RespostaVersaoHistorico respostaHist1 = umRespostaVersaoHistorico().comHash("Hash-1").comJson("Json-1").build();
        respostaHist1.getId();
        respostaHist1.getClassificador();
        respostaHist1.getVersaoCorpusResposta();
        
        RespostaVersaoHistorico respostaHist2 = umRespostaVersaoHistorico().comHash("Hash-2").comJson("Json-2").build();
        List<RespostaVersaoHistorico> respostas = Arrays.asList(respostaHist1, respostaHist2);

        Resposta respostaEsperada1 = umResposta().comClassificador(nuvem.getClassificador())
                .comHash(respostaHist1.getHash()).comJson(respostaHist1.getJson()).comNuvemWatson(nuvem)
                .comSgNuvem(sigla).build();

        Resposta respostaEsperada2 = umResposta().comClassificador(nuvem.getClassificador())
                .comHash(respostaHist2.getHash()).comJson(respostaHist2.getJson()).comNuvemWatson(nuvem)
                .comSgNuvem(sigla).build();

        // Mock
        when(respostaDao.persist(respostaEsperada1)).thenReturn(respostaEsperada1);
        when(respostaDao.persist(respostaEsperada2)).thenReturn(respostaEsperada2);

        // Quando buscar respostas do historico
        when(respostaVersaoHistoricoDao.buscarPorVersaoClassificador(classificador.getId(), versaoCorpus.getId()))
                .thenReturn(respostas);

        // Ação
        respostaManager.atualizaRespostaAmbiente(nuvem, versaoCorpus);

        ArgumentCaptor<Resposta> respostaCapturada = ArgumentCaptor.forClass(Resposta.class);

        // Verifica se o persist foi chamado duas vezes
        verify(respostaDao, times(2)).persist(respostaCapturada.capture());
    }

    @Test
    public void testAtualizarRespostasNuvemComJsonNIA() {
        // Cenário
        Classificador classificador = umClassificador().comId(1).build();

        NuvemWatson nuvem = umNuvemWatson().comSiglaNuvem("SIGLA_BOT").comClassificador(classificador).build();

        CorpusVersaoVoV1 corpusVersao = buildCorpusVersao("uuid-no", "resposta-no", "uuid-slot", "resposta-slot");
        String jsonNia = JSONUtils.parseToJson(corpusVersao);

        VersaoCorpus versaoCorpus = umVersaoCorpus().comId(1).comJsonNia(jsonNia).build();

        Resposta respostaEsperada = umResposta().comClassificador(classificador).comHash("uuid-no")
                .comJson("[\"textoResposta\":\"resposta-no\"]").comNuvemWatson(nuvem).comSgNuvem(nuvem.getSiglaNuvem())
                .build();
        respostaEsperada.getId();
        respostaEsperada.getHash();
        respostaEsperada.getJson();
        respostaEsperada.getClassificador();
        respostaEsperada.getNuvemWatson();
        respostaEsperada.getSgNuvem();

        when(respostaDao.persist(respostaEsperada)).thenReturn(respostaEsperada);

//        // Mock
//        when(respostaDao.persist(respostaEsperada)).thenReturn(umResposta().comClassificador(nuvem.getClassificador()).comHash(respostas.get(0).getHash()).comJson(respostas.get(0).getJson()).comNuvemWatson(nuvem).comSgNuvem(nuvem.getSiglaNuvem();

        // Ação
        respostaManager.atualizaRespostaAmbiente(nuvem, versaoCorpus);
        ArgumentCaptor<Resposta> respostaCapturada = ArgumentCaptor.forClass(Resposta.class);

        // Verificação
        verify(respostaDao, times(4)).persist(respostaCapturada.capture());
    }

    private CorpusVersaoVoV1 buildCorpusVersao(String uuidNo, String textoNode, String uuidSlot, String textoSlot) {
        RespostaDialogoSlotVersaoV1 respostaVersaoSlot = new RespostaDialogoSlotVersaoV1();
        respostaVersaoSlot.setTextoResposta(textoSlot);
        SlotVersaoV1 slot = new SlotVersaoV1();
        slot.setUuid(uuidSlot);
        slot.getRespostas().add(respostaVersaoSlot);

        RespostaDialogoVersaoV1 respostaNo = RespostaDialogoVersaoV1Builder
                .umRespostaDialogoVersaoV1()
                .comTextoResposta(textoNode)
                .build();

        DialogoVersaoV1 dialogoVersaoV1 = umDialogoVersaoV1()
                .comListaRespostas(respostaNo)
                .comUuid(uuidNo)
                .build();

        dialogoVersaoV1.getSlots().add(slot);

        DialogoVersaoV1 dialogoVersaoInativo = umDialogoVersaoV1()
                .comStatus(StatusDialogo.INATIVO)
                .build();

        CorpusVersaoVoV1 corpusVersaoVoV1 = CorpusVersaoVoV1Builder.umCorpusVersaoVoV1()
                .comListaDialogos(dialogoVersaoV1, dialogoVersaoInativo).build();

        return corpusVersaoVoV1;
    }
}
