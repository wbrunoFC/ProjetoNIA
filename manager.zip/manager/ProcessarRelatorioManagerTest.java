package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import static br.com.bb.databuilder.AcionamentoIntencaoDiaBuilder.umAcionamentoIntencaoDia;

import br.com.bb.gearq.c4coleta.dao.AcionamentoIntencaoDiaDao;
import br.com.bb.gearq.c4coleta.model.AcionamentoIntencaoDia;

public class ProcessarRelatorioManagerTest {
    @InjectMocks
    private ProcessarRelatorioManager processarRelatorioManager;

    @Mock
    private AcionamentoIntencaoDiaDao acionamentoIntencaoDiaDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testprocessarQtd() {
        //Cenário
        List<AcionamentoIntencaoDia> lista = Arrays.asList(umAcionamentoIntencaoDia().build());
        
        //Mock
        when(acionamentoIntencaoDiaDao.findByDadosDia()).thenReturn(lista);
        
        //Ação
        processarRelatorioManager.processarQtd();
        
        //Verificação
        verify(acionamentoIntencaoDiaDao, times(1)).findByDadosDia();
        
    }

}
