package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.RespostaDialogoSlotBuilder.umRespostaDialogoSlot;
import static br.com.bb.databuilder.RespostaDialogoSlotPKBuilder.umRespostaDialogoSlotPK;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlot;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlotPK;

public class RespostaDialogoSlotManagerTest {
    @InjectMocks
    private RespostaDialogoSlotManager respostaDialogoSlotManager;

    @Mock
    private RespostaDialogoSlotDao respostaDialogoSlotDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testSalvar() {
        //Cenário
        Integer idSlot = 1;
        
        RespostaDialogoSlotPK respostaDialogoSlotPK = umRespostaDialogoSlotPK().build();
        Object obj =  new Object();
        respostaDialogoSlotPK.equals(obj);
        
        RespostaDialogoSlot resposta = umRespostaDialogoSlot().comId(respostaDialogoSlotPK).build();
        
        
        //Mock
        when(respostaDialogoSlotDao.persist(resposta)).thenReturn(resposta);
        
        //Ação
        respostaDialogoSlotManager.salvar(resposta, idSlot);
        
        //Verificação
        verify(respostaDialogoSlotDao, times(1)).persist(resposta);
        
    }
    
    @Test
    public void testSalvar_ComObjNull() {
        //Cenário
        Integer idSlot = 1;
        
        RespostaDialogoSlotPK respostaDialogoSlotPK = umRespostaDialogoSlotPK().build();
        Object obj = null;
        respostaDialogoSlotPK.equals(obj);
        
        RespostaDialogoSlot resposta = umRespostaDialogoSlot().comId(respostaDialogoSlotPK).build();
        
        
        //Mock
        when(respostaDialogoSlotDao.persist(resposta)).thenReturn(resposta);
        
        //Ação
        respostaDialogoSlotManager.salvar(resposta, idSlot);
        
        //Verificação
        verify(respostaDialogoSlotDao, times(1)).persist(resposta);
        
    }
}
