package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.ServicoNlcBuilder.umServicoNlc;
import static br.com.bb.databuilder.TipoRespostaBuilder.umTipoResposta;
import static br.com.bb.databuilder.TipoRespostaIntencaoBuilder.umTipoRespostaIntencao;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.ServicoNlcDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class RelatoriosGeralManagerTest {
    /**
     * @author c1312334
     */
    @InjectMocks
    private RelatoriosGeralManager relatoriosGeralManager;

    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private ServicoNlcDao servicoNlcDao;
    
    @Mock
    private IntencaoDao intencaoDao;
    
    @Mock
    private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
    
    @Mock
    private TipoRespostaDao tipoRespostaDao;
        
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }
    
    @Test
    public void testPaginaçaoTest() {
        // Cenario
        Paginacao<ServicoNlc> p = new Paginacao<>();
        
        // Mock
        when(servicoNlcDao.findByUsuarioAuthenticado(p, null)).thenReturn(p);
        // Açao
        relatoriosGeralManager.teste(p);
        
        // Verificaçao
        verify(servicoNlcDao, times(1)).findByUsuarioAuthenticado(p, null);
    }
    @Test
    public void testListaClassificadores() {
        // Cenário
        ServicoNlc servico = umServicoNlc().comId(1).build();
        servico.getTotalCorpus();
        servico.setTotalCorpus(1);
        servico.getAtivo();
        servico.getDataVerificacao();
        servico.getDescricao();
        servico.getNome();
        servico.getAcessos();
        servico.getClassificadores();
        
        List<Classificador> listaRetornoClassf = Arrays.asList(umClassificador()
                                                        .comServicoNlc(servico)
                                                        .build());
        
        Paginacao<ServicoNlc> p =  new Paginacao<ServicoNlc>();
        p.setListaPaginada(Arrays.asList(umServicoNlc()
                .comListaClassificadores(listaRetornoClassf.get(0))
                .build()));
        
        // Mock
        when(servicoNlcDao.findByUsuarioAuthenticado(Mockito.any(Paginacao.class), Mockito.any())).thenReturn(p);
        
        // Açao
        relatoriosGeralManager.listaClassificadores();
        
        // Verificaçao
        verify(servicoNlcDao, times(1)).findByUsuarioAuthenticado(Mockito.any(Paginacao.class), Mockito.any());
    }

    @Test
    public void testMediaTamanhoRespostas() {
        // Cenario
        int idClassificador = 1;
        
        List<Intencao> intencao = Arrays.asList(umIntencao().comId(42).comIdClassificador(idClassificador).build());
        
        Intencao p = umIntencao()
                .comId(2)
                .comIdClassificador(intencao.get(0)
                .getIdClassificador())
                .build();
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON("TX_PADRAO").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTextoResposta("1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                        "+ \"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950\"\r\n" + 
                        "+ \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "\"+ \\\"333435363738394041424344454647484950")
                .comTipoResposta(tipoResposta)
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(intencao.get(0).getId(), null)).thenReturn(respostas);
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(intencao);
        
        // Açao
        relatoriosGeralManager.mediaTamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaIntencaoDao, times(0)).findAll(p.getId(), null);
        verify(intencaoDao, times(1)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testComMenosDe199Palavras() {
        // Cenario
        int idClassificador = 1;
        
        List<Intencao> intencao = Arrays.asList(umIntencao().comId(42).comIdClassificador(idClassificador).build());
        
        Intencao p = umIntencao()
                .comId(2)
                .comIdClassificador(intencao.get(0)
                .getIdClassificador())
                .build();
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON("TX_PADRAO").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTextoResposta("1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "              \" + \\\"333435363738394041424344454647484950\"\r\n" + 
                        "              + \"1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                        "              \" + \\\"3334353637383940414243444546474849")
                .comTipoResposta(tipoResposta)
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(intencao.get(0).getId(), null)).thenReturn(respostas);
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(intencao);
        
        // Açao
        relatoriosGeralManager.mediaTamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaIntencaoDao, times(0)).findAll(p.getId(), null);
        verify(intencaoDao, times(1)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testComMenosDe100Palavras() {
        // Cenario
        int idClassificador = 1;
        
        List<Intencao> intencao = Arrays.asList(umIntencao().comId(42).comIdClassificador(idClassificador).build());
        
        Intencao p = umIntencao()
                .comId(2)
                .comIdClassificador(intencao.get(0)
                .getIdClassificador())
                .build();
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON("TX_PADRAO").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTextoResposta("1234567891011121314151617181920212223242526272829303132\\\"\\r\\n\" + \r\n" + 
                                  "\"+ \\\"333435363738394041424344454647484950")
                .comTipoResposta(tipoResposta)
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(intencao.get(0).getId(), null)).thenReturn(respostas);
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(intencao);
        
        // Açao
        relatoriosGeralManager.mediaTamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaIntencaoDao, times(0)).findAll(p.getId(), null);
        verify(intencaoDao, times(1)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testComPalavrasDaListaNull() {
        // Cenario
        int idClassificador = 1;
        
        List<Intencao> intencao = Arrays.asList(umIntencao().comId(42).comIdClassificador(idClassificador).build());
        
        Intencao p = umIntencao()
                .comId(2)
                .comIdClassificador(intencao.get(0)
                .getIdClassificador())
                .build();
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON("TX_PADRAO").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTextoResposta(null)
                .comTipoResposta(tipoResposta)
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(intencao.get(0).getId(), null)).thenReturn(respostas);
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(intencao);
        
        // Açao
        relatoriosGeralManager.mediaTamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaIntencaoDao, times(0)).findAll(p.getId(), null);
        verify(intencaoDao, times(1)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testTipoRespostaIntencaoNull() {
        // Cenario
        int idClassificador = 1;
        List<Intencao> intencao = Arrays.asList(umIntencao().comId(42).comIdClassificador(idClassificador).build());
        List<TipoRespostaIntencao> respostas = null;
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(intencao.get(0).getId(), null)).thenReturn(respostas);
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(intencao);
        
        // Açao
        relatoriosGeralManager.mediaTamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaIntencaoDao, times(1)).findAll(intencao.get(0).getId(), null);
        verify(intencaoDao, times(1)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testComTipoRespostaDiferente() {
        // Cenario
        int idClassificador = 1;
        List<Intencao> intencao = Arrays.asList(umIntencao().comId(42).comIdClassificador(idClassificador).build());
        
        TipoResposta tipoResposta = umTipoResposta().comNome("TX_DIFERENTE").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                                                     .comTextoResposta("")
                                                     .comTipoResposta(tipoResposta)
                                                     .build());
        
        Intencao p = umIntencao().comId(null).comIdClassificador(null).build();
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(intencao.get(0).getId(), null)).thenReturn(respostas);
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(intencao);
        
        // Açao
        relatoriosGeralManager.mediaTamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaIntencaoDao, times(0)).findAll(p.getId(), null);
        verify(intencaoDao, times(1)).findByClassificador(idClassificador);
    }

    @Test
    public void testTamanhoRespostas() {
        // Cenario
        int idClassificador = 2;
        String palavrasMaisDe200 = new String("1234567891011121314151617181920212223242526272829303132"
                + "333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950"
                + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "  + \"333435363738394041424344454647484950");
        
        String palavrasAte199 = new String("1234567891011121314151617181920212223242526272829303132\"\r\n" + 
              "+ \"333435363738394041424344454647484950"
              + "1234567891011121314151617181920212223242526272829303132\"\r\n" + 
              "+ \"3334353637383940414243444546474849");
        
        String palavrasComMenosDe100 = new String("1234567891011121314151617181920212223242526272829303132\"\r\n" + 
                "                                  + \"333435363738394041424344454647484950");
        
        List<String> respostas = new ArrayList<>();
        respostas.add(palavrasMaisDe200);
        respostas.add(palavrasAte199);
        respostas.add(palavrasComMenosDe100);
        
        
        // Mock
        when(tipoRespostaDao.findRespostasClassificador(idClassificador)).thenReturn(respostas);
        
        // Açao
        relatoriosGeralManager.tamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaDao, times(1)).findRespostasClassificador(idClassificador);
    }
    
    @Test
    public void testComRespostasNull() {
        // Cenario
        int idClassificador = 2;
        List<String> respostas = null;
        
        // Mock
        when(tipoRespostaDao.findRespostasClassificador(idClassificador)).thenReturn(respostas);
        
        // Açao
        relatoriosGeralManager.tamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaDao, times(1)).findRespostasClassificador(idClassificador);
    }
    
    @Test
    public void testComPalavrasNull() {
        // Cenario
        int idClassificador = 2;
        String palavras = new String();
        
        List<String> respostas = new ArrayList<>();
        respostas.contains(null);
        respostas.add(palavras);
        
        // Mock
        when(tipoRespostaDao.findRespostasClassificador(idClassificador)).thenReturn(respostas);
        
        // Açao
        relatoriosGeralManager.tamanhoRespostas(idClassificador);
        
        // Verificaçao
        verify(tipoRespostaDao, times(1)).findRespostasClassificador(idClassificador);
    }

}
