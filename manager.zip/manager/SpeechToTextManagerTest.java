package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.SpeechToTextBuilder.umSpeechToText;

import br.com.bb.gearq.c4coleta.dao.SpeechToTextDao;
import br.com.bb.gearq.c4coleta.model.SpeechToText;

public class SpeechToTextManagerTest {
    @InjectMocks
    private SpeechToTextManager speechToTextManager;

    @Mock
    private SpeechToTextDao speechToTextDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testsalvarArquivoGed() {
        //Cenário
        SpeechToText speechToText = umSpeechToText().build(); 
        speechToText.getId();
        speechToText.getNomeAudio();
        speechToText.getFormato();
        speechToText.getTelefone();
        speechToText.getAssertividade();
        speechToText.getTranscricao();
        speechToText.getTempoEnvioAudio();
        speechToText.getNrDocAudioCli();
        speechToText.getCodigoCliEnvioAudio();
        speechToText.getCodigoTipoLclRcbt();
        
        //Mock
        when(speechToTextDao.persist(speechToText)).thenReturn(speechToText);
        
        //Ação
        speechToTextManager.salvarArquivoGed(speechToText);
        
        //Verificação
        verify(speechToTextDao, times(1)).persist(speechToText);
    }
    

}
