package br.com.bb.gearq.c4coleta.manager;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.CenarioEsperadoBuilder.umCenarioEsperado;

import br.com.bb.gearq.c4coleta.dao.CenarioEsperadoDao;
import br.com.bb.gearq.c4coleta.model.CenarioEsperado;
import net.sf.saxon.functions.Parse;

public class CenarioEsperadoManagerTest {
    @InjectMocks
    private CenarioEsperadoManager cenarioEsperadoManager;
    
    @Mock
    private CenarioEsperadoDao cenarioEsperadoDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testSalvar() {
        //Cenário
        CenarioEsperado cenario = umCenarioEsperado().comId(1).build();
        
        //Mock
        cenarioEsperadoDao.persist(cenario);
        
        //Ação
        cenarioEsperadoManager.salvar(cenario);
        ArgumentCaptor<CenarioEsperado> cenarioCapturado = ArgumentCaptor.forClass(CenarioEsperado.class);
        
        //Verificação
        verify(cenarioEsperadoDao, times(2)).persist(cenarioCapturado.capture()); 
    }
    
    
    @Test
    public void testCriar() {
        //Cenário
        int idSecao = 1;
        
        CenarioEsperado cenario = umCenarioEsperado().comIdSecaoCasoDeTeste(idSecao).comIdTipoElemento(1).comIdTipoCondicao(1).comTextoElemento("").build();
        cenario.getIdSecaoCasoDeTeste();
        cenario.getSecao();
        cenario.getIdTipoElemento();
        cenario.getTipoElemento();
        cenario.getIdTipoCondicao();
        cenario.getTipoCondicao();
        cenario.getTextoElemento();
        cenario.getTextoElementoValor();
        
        //Mock
        cenarioEsperadoDao.persist(cenario);
        ArgumentCaptor<CenarioEsperado> cenarioCapturado = ArgumentCaptor.forClass(CenarioEsperado.class);
        
        //Ação
        cenarioEsperadoManager.criar(idSecao);
        
        //Verificação
        verify(cenarioEsperadoDao, times(2)).persist(cenarioCapturado.capture());    
    }
    
    
    @Test
    public void testFindBySecaoCasoDeTeste() {
        //Cenário
        int idSecao = 1;
        
        List<CenarioEsperado> cenario = Arrays.asList(
                umCenarioEsperado().build(),
                umCenarioEsperado().build()
                );
        
        //Mock
        when(cenarioEsperadoDao.findBySecaoCasoDeTeste(idSecao)).thenReturn(cenario);
        
        //Ação
        cenarioEsperadoManager.findBySecaoCasoDeTeste(idSecao);
        
        //Verificação 
        verify(cenarioEsperadoDao, times(1)).findBySecaoCasoDeTeste(idSecao);
    }
    
    
    @Test
    public void testExlcuirCenario() {
        //Cenário
        CenarioEsperado cenario = umCenarioEsperado().comId(1).build();
        
        //Mock
        when(cenarioEsperadoDao.findById(cenario.getId())).thenReturn(cenario);
        cenarioEsperadoDao.remove(cenario);
        
        //Ação
        cenarioEsperadoManager.excluir(cenario);
        
        //Verificação
        verify(cenarioEsperadoDao, times(1)).findById(cenario.getId());
        verify(cenarioEsperadoDao, times(2)).remove(cenario);
    }
    
    @Test
    public void testExlcuir() {
        //Cenário
        Integer idCenario = 1;
        CenarioEsperado cenario = new CenarioEsperado();
        
        //Mock
        when(cenarioEsperadoDao.findById(idCenario)).thenReturn(cenario);
        cenarioEsperadoDao.remove(cenario);
        
        //Ação
        cenarioEsperadoManager.excluir(idCenario);
        
        //Verificação
        verify(cenarioEsperadoDao, times(1)).findById(idCenario);
        verify(cenarioEsperadoDao, times(2)).remove(cenario);
        
    }
    
    @Test
    public void testFindById() {
        //Cenário
        int idCenario = 1;
        Integer idCenario2 = idCenario;
        
   
        CenarioEsperado cenario = umCenarioEsperado().comId(1).build();
        
        //Mock
        when(cenarioEsperadoDao.findById(idCenario)).thenReturn(cenario);
        
        //Ação
        cenarioEsperadoManager.findById(idCenario);
        
        //Verificação
        assertEquals(cenario.getId(), idCenario2);
    }
    

}
