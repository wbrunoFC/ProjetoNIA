package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.TagBuilder.umTag;

import java.util.Arrays;
import java.util.List;

import br.com.bb.gearq.c4coleta.dao.TagDao;
import br.com.bb.gearq.c4coleta.model.Tag;

public class TagManagerTest {
    
    @InjectMocks
    private TagManager tagmanager;
    
    @Mock
    private TagDao tagDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testListarToMap() {
        //Cenário
        List<Tag> listaTag = Arrays.asList(umTag().comTag("CANCELAR").build());
        
        //Mock
        when(tagDao.findAll()).thenReturn(listaTag);
        
        //Ação
        tagmanager.listarToMap();
        
        //Verificação
        verify(tagDao, times(1)).findAll();
    }

}
