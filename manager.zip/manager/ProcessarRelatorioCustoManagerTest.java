package br.com.bb.gearq.c4coleta.manager;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static br.com.bb.databuilder.RelatorioLogBuilder.umRelatorioLog;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.RelatorioCustoDao;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.RelatorioLog;
import br.com.bb.gearq.c4coleta.model.Resposta;

public class ProcessarRelatorioCustoManagerTest {
    
    @InjectMocks
    private ProcessarRelatorioCustoManager processarRelatorioCustoManager;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Mock
    private RelatorioCustoDao relatorioCustoDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
     }
    
    @Test
    public void testprocessarCusto() {
        
        //Cenário 

        List<NuvemWatson> listaNuvem = Arrays.asList(
                umNuvemWatson().build(),
                umNuvemWatson().comSiglaNuvem("SIGLA_OBJECT_NULL").build()
                );
        
        List<RelatorioLog> relatorioLog = Arrays.asList(umRelatorioLog().build());
        relatorioLog.get(0).getId();
        relatorioLog.get(0).getIdServico();
        relatorioLog.get(0).getIdClassificador();
        relatorioLog.get(0).getNomeClassificador();
        relatorioLog.get(0).getIdNuvemWatson();
        relatorioLog.get(0).getSiglaNuvem();
        relatorioLog.get(0).getIdServicoCognitivo();
        relatorioLog.get(0).getNomeServicoCognitivo();
        relatorioLog.get(0).getQuantidadeAcionamentos();
        relatorioLog.get(0).getTempoResposta();
        relatorioLog.get(0).getDataCalc();
        relatorioLog.get(0).getClassificador();
        relatorioLog.get(0).getNuvemWatson();
        relatorioLog.get(0).getListaRelatorioLog();
        relatorioLog.get(0).getDataCalcFormatada();
        relatorioLog.get(0).getNomeNuvem();
        relatorioLog.get(0).getServicoNlc();
        relatorioLog.get(0).getServicosCognitivos();
                
        Date data = new Date();
        
        //Mock
        when(nuvemWatsonDao.findAll()).thenReturn(listaNuvem);
        when(relatorioCustoDao.consultaDiaria(data, data, listaNuvem.get(0).getSiglaNuvem())).thenReturn(umRelatorioLog().build());
        when(relatorioCustoDao.consultaDiaria(data, data, "SIGLA_OBJECT_NULL")).thenReturn(null);
        
        //Ação
        processarRelatorioCustoManager.processarCusto(data);
        ArgumentCaptor<RelatorioLog> relatorioProcessado = ArgumentCaptor.forClass(RelatorioLog.class);
       
        
        //Verificação
        verify(relatorioCustoDao, times(1)).persist(relatorioProcessado.capture());
        
    }

}
