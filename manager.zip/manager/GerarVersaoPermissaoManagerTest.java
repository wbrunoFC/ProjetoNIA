package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.ServicoNlcBuilder.umServicoNlc;
import static br.com.bb.databuilder.PermissaoUsuarioVOBuilder.umPermissaoUsuarioVO;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoServicoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.util.PermissaoUsuario;
import br.com.bb.gearq.c4coleta.vo.PermissaoUsuarioVO;

public class GerarVersaoPermissaoManagerTest {
    @InjectMocks
    private GerarVersaoPermissaoManager gerarVersaoPermissaoManager;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private PermissaoUsuario permissaoUsuario;
    
    @Mock
    private PermissaoUsuarioManager permissaoUsuarioManager;

    @Mock
    private NivelAcessoClassificadorDao nivelAcessoClassificadorDao;

    @Mock
    private NivelAcessoServicoDao nivelAcessoServicoDao;
        
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    
    @Test
    public void testNivelPermissaoGerarVersaoAuditor() {
        //Cenário
        Integer idClassificador = 1;
        
        ServicoNlc servico = umServicoNlc().comId(10).build();
        Classificador classificador = umClassificador().comServicoNlc(servico).build();
        
        
        //Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        
        //Ação
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);
        
        //Verificação
        verify(classificadorDao, times(1)).findById(idClassificador);
        assertTrue(gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador));
    }
    
    @Test
    public void testNivelPermissaoGerarVersaoMaster() {
        //Cenário
        Integer idClassificador = 1;
        
        ServicoNlc servico = umServicoNlc().comId(10).build();
        Classificador classificador = umClassificador().comServicoNlc(servico).build();
        
        
        //Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        
        //Ação
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);
        
        //Verificação
        verify(classificadorDao, times(1)).findById(idClassificador);
        assertTrue(gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador));
    }
    
    @Test
    public void testNivelPermissaoGerarVersaoComPermissaoCuradorMaster() {
        //Cenário
        Integer idClassificador = 140;
        
        ServicoNlc servico = umServicoNlc().comId(12).build();
        Classificador classificador = umClassificador().comServicoNlc(servico).comId(idClassificador).build();
        
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        //Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        
        //Ação
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);
        
        //Verificação
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testNivelPermissaoGerarVersaoSemPermissaoCuradorMaster() {
        //Cenário
        Integer idClassificador = 140;
        
        ServicoNlc servico = umServicoNlc().comId(12).build();
        Classificador classificador = umClassificador().comServicoNlc(servico).comId(idClassificador).build();
        
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        
        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        
        //Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        
        //Ação
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);
        
        //Verificação
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testNivelPermissaoGerarVersaoComPermissaoCuradorMasterNoServico() {
        //Cenário
        Integer idClassificador = 140;
        
        ServicoNlc servico = umServicoNlc().comId(12).build();
        Classificador classificador = umClassificador().comServicoNlc(servico).comId(idClassificador).build();
        
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        
        //Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        
        //Ação
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);
        
        //Verificação
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testNivelPermissaoGerarVersaoComPermissaoCuradorMasterNoClassificador() {
        //Cenário
        Integer idClassificador = 140;
        
        ServicoNlc servico = umServicoNlc().comId(12).build();
        Classificador classificador = umClassificador().comServicoNlc(servico).comId(idClassificador).build();
        
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        
        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        //Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        
        //Ação
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);
        
        //Verificação
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
   
    @Test
    public void testNivelPermissaoGerarVersao() {
        // Cenario
        String nome = new String("Nome");
        String serviçoInfra = new String("Infra");
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador()
                                        .comNomeTipoServicoInfra(serviçoInfra)
                                        .comNome(nome)
                                        .comServicoNlc(nlc)
                                        .build();

        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        // Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testPermissaoClassificadorTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        
        // Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testPermissaoFalse() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(false).build();
        
        // Mock
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testPermissaoTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        // Mock
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(classificador.getServicoNlc().getId(), false);
        verify(permissaoUsuarioManager, times(1)).recuperarPermissao(idClassificador, true);
    }
    
    @Test
    public void testNivelPermissaoParaUsuárioTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoUsuarioVO = umPermissaoUsuarioVO().comAuditor(false).build();
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoUsuarioVO);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoUsuarioVO);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testNivelPermissaoFalse() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoUsuarioVO = umPermissaoUsuarioVO().comAuditor(false).build();
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        when(permissaoUsuario.isMaster()).thenReturn(false);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoUsuarioVO);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoUsuarioVO);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testAuditorTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();
        classificador.getIndDialogo();

        PermissaoUsuarioVO permissaoUsuarioVO = umPermissaoUsuarioVO().comAuditor(false).build();
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        when(permissaoUsuario.isMaster()).thenReturn(false);
        
        
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoUsuarioVO);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoUsuarioVO);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testMasterTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoUsuarioVO = umPermissaoUsuarioVO().comAuditor(false).build();
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoUsuarioVO);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoUsuarioVO);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testPermissaoUsuarioVOTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().comCuradorMaster(true).build();
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testPermissaoUsuarioVOFalse() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoServico = new PermissaoUsuarioVO();
        permissaoServico.setMaster(false);
        
        PermissaoUsuarioVO permissaoClassificador = new PermissaoUsuarioVO();
        permissaoClassificador.setMaster(false);
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testpermissaoClassificadorTrue() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoServico = new PermissaoUsuarioVO();
        permissaoServico.setMaster(false);
        
        PermissaoUsuarioVO permissaoClassificador = new PermissaoUsuarioVO();
        permissaoClassificador.setMaster(true);
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }
    
    @Test
    public void testpermissaoClassificadorFalse() {
        // Cenario
        Integer idClassificador = new Integer(1);
        ServicoNlc nlc = umServicoNlc().comId(2).build();
        
        Classificador classificador = umClassificador().comServicoNlc(nlc).build();

        PermissaoUsuarioVO permissaoServico = umPermissaoUsuarioVO().build();
        
        PermissaoUsuarioVO permissaoClassificador = umPermissaoUsuarioVO().build();
        
        // Mock
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        when(permissaoUsuario.isMaster()).thenReturn(true);
        
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(permissaoUsuarioManager.recuperarPermissao(classificador.getServicoNlc().getId(), false)).thenReturn(permissaoServico);
        when(permissaoUsuarioManager.recuperarPermissao(idClassificador, true)).thenReturn(permissaoClassificador);

        // Açao
        gerarVersaoPermissaoManager.nivelPermissaoGerarVersao(idClassificador);

        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
    }

}
