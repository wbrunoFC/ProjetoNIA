package br.com.bb.gearq.c4coleta.manager;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.databuilder.AudioClienteBuilder;
import br.com.bb.gearq.c4coleta.dao.AudioClienteDao;
import br.com.bb.gearq.c4coleta.model.AudioCliente;

public class AudioClienteManagerTest {
    
    @InjectMocks
    AudioClienteManager audioClienteManager;
    
    @Mock
    AudioClienteDao audioclienteDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

    }
    
    @Test
    public void salvarArquivoAudioCliente() {
        //cenário
        AudioCliente audioCliente = AudioClienteBuilder.umAudioCliente().comNomeAudio("Nome_do_audio").build();
        audioCliente.getId();
        audioCliente.getFormato();
        audioCliente.getTelefone();
        audioCliente.getAssertividade();
        audioCliente.getTranscricao();
        audioCliente.getTempoEnvioAudio();
        audioCliente.getNrDocAudioCli();
        audioCliente.getCodigoCliEnvioAudio();
        audioCliente.getCodigoTipoLclRcbt();
        
        //ação        
        when(audioclienteDao.persist(audioCliente)).thenReturn(audioCliente);
        AudioCliente salvarArquivoGed = audioClienteManager.salvarArquivoGed(audioCliente);
        
        //verificação
        assertThat(salvarArquivoGed.getNomeAudio()).isEqualTo("Nome_do_audio");
  }
}
