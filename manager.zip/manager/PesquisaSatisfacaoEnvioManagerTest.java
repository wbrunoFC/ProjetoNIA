package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.PesquisaSatisfacaoEnvioBuilder.umPesquisaSatisfacaoEnvio;

import br.com.bb.gearq.c4coleta.dao.PesquisaSatisfacaoEnvioDao;
import br.com.bb.gearq.c4coleta.model.PesquisaSatisfacaoEnvio;

public class PesquisaSatisfacaoEnvioManagerTest {
    @InjectMocks
    private PesquisaSatisfacaoEnvioManager pesquisaSatisfacaoEnvioManager;

    @Mock
    private PesquisaSatisfacaoEnvioDao pesquisaSatisfacaoEnvioDao;

   
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void testSalvar() {
        //Cenário
        PesquisaSatisfacaoEnvio pesquisaSatisfacaoEnvio = umPesquisaSatisfacaoEnvio().comId(1).build();
        pesquisaSatisfacaoEnvio.getId();
        pesquisaSatisfacaoEnvio.getPesquisaSatisfacao();
        pesquisaSatisfacaoEnvio.getDataHoraEnvio();
        pesquisaSatisfacaoEnvio.getOrigem();
        pesquisaSatisfacaoEnvio.getServico();
        pesquisaSatisfacaoEnvio.getAvaliacaoFormulario();
        
        //Mock
        when(pesquisaSatisfacaoEnvioDao.persist(pesquisaSatisfacaoEnvio)).thenReturn(pesquisaSatisfacaoEnvio);
        ArgumentCaptor<PesquisaSatisfacaoEnvio> pesquisaCapturada = ArgumentCaptor.forClass(PesquisaSatisfacaoEnvio.class);
        
        //Ação
        pesquisaSatisfacaoEnvioManager.salvar(pesquisaSatisfacaoEnvio);
        
        //Verificação
        verify(pesquisaSatisfacaoEnvioDao, times(1)).persist(pesquisaCapturada.capture());
        
    }
    
    @Test
    public void testGetPesquisaSatisfacaoEnvioDao() {
        //Cenário
        
        //Mock
        
        //Ação
        pesquisaSatisfacaoEnvioManager.getPesquisaSatisfacaoEnvioDao();
        
        //Verificação
        
    }
    

}
