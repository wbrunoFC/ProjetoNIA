package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.RespostaDialogoBuilder.umRespostaDialogo;
import static br.com.bb.databuilder.RespostaDialogoPKBuilder.umRespostaDialogoPK;
import static br.com.bb.databuilder.TipoComponenteVisualBuilder.umTipoComponenteVisual;
import static br.com.bb.databuilder.TipoRespostaBuilder.umTipoResposta;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.model.RespostaDialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoPK;
import br.com.bb.gearq.c4coleta.model.TipoComponenteVisual;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.vo.DialogoRespostaVo;


public class RespostaDialogoManagerTest {
    @InjectMocks
    private RespostaDialogoManager respostaDialogoManager;

    @Mock
    private RespostaDialogoDao respostaDialogoDao;

    @Mock
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testSalvar() {
        RespostaDialogo resposta = new RespostaDialogo();
        respostaDialogoManager.salvar(resposta);
    }
    
    @Test
    public void testLimparClassificador() {
        Integer idClassificador = 2;
        List<RespostaDialogo> respostaList = new ArrayList<RespostaDialogo>();
        RespostaDialogo resposta = new RespostaDialogo();
        
        when(respostaDialogoDao.listarVersao(idClassificador)).thenReturn(respostaList);
        
        respostaDialogoManager.limparPorClassificador(idClassificador);
    }

    @Test
    public void testeObterRespostasPadrao() {
        //Cenário
        int idDialogo = 25500;

        TipoResposta tipoResposta = umTipoResposta().comId(1).build();
        tipoResposta.getNome();
        tipoResposta.getTipoFormatacao();
        tipoResposta.isCampoObrigatorio();
        tipoResposta.getTamanhoCampo();
        tipoResposta.isCondicaoTamanho();
        
        RespostaDialogoPK idResposta1 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(1).comSequenciaItem(1).build();
        RespostaDialogoPK idResposta2 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(1).comSequenciaItem(2).build();
        RespostaDialogoPK idResposta3 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(2).comSequenciaItem(1).build();
        RespostaDialogoPK idResposta4 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(2).comSequenciaItem(2).build();
        idResposta4.getIdDialogo();
        idResposta4.hashCode();
        Object obj = new Object();
        idResposta4.equals(obj);

        List<RespostaDialogo> respostas = Arrays.asList(
            umRespostaDialogo()
                .comId(idResposta1)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 1, sequência 1")
                .comIdTipoComponente(null)
                .comTempoResposta(0F)
                .build(),
                
            umRespostaDialogo()
                .comId(idResposta2)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 1, sequência 2")
                .comIdTipoComponente(1)
                .comTempoResposta(0F)
                .build(),

            umRespostaDialogo()
                .comId(idResposta3)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 2, sequência 1")
                .comIdTipoComponente(1)
                .comTempoResposta(0F)
                .build(),

            umRespostaDialogo()
                .comId(idResposta4)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 2, sequência 2")
                .comIdTipoComponente(1)
                .comTempoResposta(0F)
                .build()
        );

        TipoComponenteVisual tipoComponente = umTipoComponenteVisual().build();

        //Mock
        when(tipoComponenteVisualDao.findById(respostas.get(0).getIdTipoComponenteVisual())).thenReturn(tipoComponente);
        
        when(respostaDialogoDao.findByDialogoETipoResposta(idDialogo, 1)).thenReturn(respostas);

        //Ação
        List<DialogoRespostaVo> obterRespostasPadrao = respostaDialogoManager.obterRespostasPadrao(idDialogo);

        //Verificação
        assertThat(obterRespostasPadrao.get(0).getBlocos()).hasSize(2);
//        assertThat(obterRespostasPadrao.get(0).getBlocos()).isEqualTo(respostaVO);
    }
    
    @Test
    public void testeObterRespostasPadrao_ComObjNull() {
        //Cenário
        int idDialogo = 25500;

        TipoResposta tipoResposta = umTipoResposta().comId(1).build();
        tipoResposta.getNome();
        tipoResposta.getTipoFormatacao();
        tipoResposta.isCampoObrigatorio();
        tipoResposta.getTamanhoCampo();
        tipoResposta.isCondicaoTamanho();
        
        RespostaDialogoPK idResposta1 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(1).comSequenciaItem(1).build();
        RespostaDialogoPK idResposta2 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(1).comSequenciaItem(2).build();
        RespostaDialogoPK idResposta3 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(2).comSequenciaItem(1).build();
        RespostaDialogoPK idResposta4 = umRespostaDialogoPK().comIdDialogo(idDialogo).comSequenciaBloco(2).comSequenciaItem(2).build();
        idResposta4.getIdDialogo();
        idResposta4.hashCode();
        Object obj = null;
        idResposta4.equals(obj);

        List<RespostaDialogo> respostas = Arrays.asList(
            umRespostaDialogo()
                .comId(idResposta1)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 1, sequência 1")
                .comIdTipoComponente(null)
                .comTempoResposta(0F)
                .build(),
                
            umRespostaDialogo()
                .comId(idResposta2)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 1, sequência 2")
                .comIdTipoComponente(1)
                .comTempoResposta(0F)
                .build(),

            umRespostaDialogo()
                .comId(idResposta3)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 2, sequência 1")
                .comIdTipoComponente(1)
                .comTempoResposta(0F)
                .build(),

            umRespostaDialogo()
                .comId(idResposta4)
                .comTipoResposta(tipoResposta)
                .comTextoResposta("Resposta do bloco 2, sequência 2")
                .comIdTipoComponente(1)
                .comTempoResposta(0F)
                .build()
        );

        TipoComponenteVisual tipoComponente = umTipoComponenteVisual().build();

        //Mock
        when(tipoComponenteVisualDao.findById(respostas.get(0).getIdTipoComponenteVisual())).thenReturn(tipoComponente);
        
        when(respostaDialogoDao.findByDialogoETipoResposta(idDialogo, 1)).thenReturn(respostas);

        //Ação
        List<DialogoRespostaVo> obterRespostasPadrao = respostaDialogoManager.obterRespostasPadrao(idDialogo);

        //Verificação
        assertThat(obterRespostasPadrao.get(0).getBlocos()).hasSize(2);
//        assertThat(obterRespostasPadrao.get(0).getBlocos()).isEqualTo(respostaVO);
    }

}





