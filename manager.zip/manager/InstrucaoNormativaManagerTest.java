package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.InstrucaoNormativaBuilder.umInstrucaoNormativa;
import static br.com.bb.databuilder.InstrucaoNormativaVOBuilder.umInstrucaoNormativaVO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDao;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativa;
import br.com.bb.gearq.c4coleta.vo.InstrucaoNormativaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class InstrucaoNormativaManagerTest {
    /**
     * @author c1312334
     * @date 23/12/19
     */
    @InjectMocks
    private InstrucaoNormativaManager instrucaoNormativaManager;
    
    @Mock
    private InstrucaoNormativaDao instrucaoNormativaDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testListarPorClassificador() {
        // Cenario
        int idClassificador = 2;
        String filtroNomeIntencao = " Nome ";
        Paginacao<InstrucaoNormativa> listapaginacao = new Paginacao<>();
        
        listapaginacao.setListaPaginada(Arrays.asList(
                                   umInstrucaoNormativa()
                                   .comId(idClassificador)
                                   .build()
                                    ));
        
        // Mock
        when(instrucaoNormativaDao.findByClassificadorNativo(idClassificador,
                filtroNomeIntencao, listapaginacao)).thenReturn(listapaginacao);
        
        // Açao
        instrucaoNormativaManager.listarPorClassificador(idClassificador, filtroNomeIntencao, listapaginacao);
        
        // Verificaçao
        verify(instrucaoNormativaDao, times(1)).findByClassificadorNativo(
                                                              idClassificador, 
                                                              filtroNomeIntencao, 
                                                              listapaginacao
                                                              );        
    }

    @Test
    public void testCriarIN() {
        // Cenario
        InstrucaoNormativaVO instrucaoNormativaVO = umInstrucaoNormativaVO()
                                                    .comId(2)
                                                    .comIdIntencao(3)
                                                    .comIntencao(null)
                                                    .comNumeroIN("Numero")
                                                    .comVrsAuxiliar(4)
                                                    .comVrsNormativa(5)
                                                    .comVrsProcedimento(6)
                                                    .comNomeIntencao("Nome")
                                                    .comStatus("Status")
                                                    .comEditarCampo(true)
                                                    .build();
        
        InstrucaoNormativa instrucaoNormativa = umInstrucaoNormativa()
                                                .comId(instrucaoNormativaVO.getId())
                                                .comIntencao(instrucaoNormativaVO.getIntencao())
                                                .comNumeroIN(instrucaoNormativaVO.getNumeroIN())
                                                .comEditarCampo(instrucaoNormativaVO.isEditarCampo())
                                                .build();
                
        // Açao
        instrucaoNormativaManager.criarIN(instrucaoNormativaVO);
        
        // Verificaçao
        assertThat(instrucaoNormativa).isNotNull();

    }

    @Test
    public void testCriarListaIN() {
        // Cenario
        List<InstrucaoNormativaVO> listaVO = Arrays.asList(umInstrucaoNormativaVO()
                                            .comId(2)
                                            .comIdIntencao(3)
                                            .comIntencao(null)
                                            .comNumeroIN("Numero")
                                            .comVrsAuxiliar(4)
                                            .comVrsNormativa(5)
                                            .comVrsProcedimento(6)
                                            .comNomeIntencao("Nome")
                                            .comStatus("Status")
                                            .comEditarCampo(true)
                                            .build());
        
        InstrucaoNormativaVO vo = listaVO.get(0);
        
        InstrucaoNormativa instrucaoNormativa = umInstrucaoNormativa()
                                                .comId(vo.getId())
                                                .comIntencao(vo.getIntencao())
                                                .comNumeroIN(vo.getNumeroIN())
                                                .comEditarCampo(vo.isEditarCampo())
                                                .build();
        
        List<InstrucaoNormativa> listaIN = new ArrayList<InstrucaoNormativa>();
        
        listaIN.add(instrucaoNormativa);
                
        // Açao
        instrucaoNormativaManager.criarListaIN(listaVO);
        
        // Verificaçao
        assertThat(listaIN).isNotNull();
    }

    @Test
    public void testCriarINVO() {
        // Cenario
        InstrucaoNormativa instrucaoNormativa = umInstrucaoNormativa()
                                                .comId(1)
                                                .comIntencao(null)
                                                .comNumeroIN("Numero")
                                                .comEditarCampo(true)
                                                .build();
        
        InstrucaoNormativaVO instrucaoNormativaVO = umInstrucaoNormativaVO()
                                                    .comId(instrucaoNormativa.getId())
                                                    .comIntencao(instrucaoNormativa.getIntencao())
                                                    .comNumeroIN(instrucaoNormativa.getNumeroIN())
                                                    .comEditarCampo(instrucaoNormativa.isEditarCampo())
                                                    .build();
        
        // Açao
        instrucaoNormativaManager.criarINVO(instrucaoNormativa);
        
        // Verificaçao
        assertThat(instrucaoNormativaVO).isNotNull();
    }

    @Test
    public void testCriarListaINVO() {
        // Cenario
        List<InstrucaoNormativa> listaIN = Arrays.asList(umInstrucaoNormativa()
                                                 .comId(1)
                                                 .comIntencao(null)
                                                 .comNumeroIN("Numero")
                                                 .comEditarCampo(true)
                                                 .build());
        
        InstrucaoNormativa vo = listaIN.get(0);
        
        InstrucaoNormativaVO instrucaoNormativaVO = umInstrucaoNormativaVO()
                                                    .comId(vo.getId())
                                                    .comIntencao(vo.getIntencao())
                                                    .comNumeroIN(vo.getNumeroIN())
                                                    .comEditarCampo(vo.isEditarCampo())
                                                    .build();
        
        // Açao
        instrucaoNormativaManager.criarListaINVO(listaIN);
        
        // Verificaçao
        assertThat(instrucaoNormativaVO).isNotNull();
        
    }
    
//    public static void main(String[] args) {
//      new BuilderMaster().gerarCodigoClasse(InstrucaoNormativa.class);
//      
//  }

}
