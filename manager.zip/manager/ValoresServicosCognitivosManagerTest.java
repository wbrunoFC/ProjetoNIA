package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import static br.com.bb.databuilder.ValoresServicosCognitivosBuilder.umValoresServicosCognitivos;

import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.ValoresServicosCognitivosDao;
import br.com.bb.gearq.c4coleta.model.ValoresServicosCognitivos;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class ValoresServicosCognitivosManagerTest {

    @InjectMocks
    private ValoresServicosCognitivosManager valoresServicosCognitivosManager;

    @Mock
    private PerguntaDao perguntaDao;
    
    @Mock
    private ValoresServicosCognitivosDao valoresServicosCognitivosDao;

    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    
    @Test
    public void testSalvarComDataInicioVigenciaAnteriorADataInicialMinima() {
        //Cenário
        
        Date dtInicial = FormatarData.formatarStringParaData("20/12/2019");

        ValoresServicosCognitivos valoresServicosCognitivos = umValoresServicosCognitivos().comDtIncVgc(dtInicial).build();
                
        String dataIncMinima = "30/12/2019";
        double valorSrvcCognitivoAnterior = 0.0371;
        String dataInicioVigenciaAnterior = "26/12/2019";
        
        
        //Ação
        assertThatThrownBy(() -> {
            valoresServicosCognitivosManager.salvar(valoresServicosCognitivos, dataIncMinima, valorSrvcCognitivoAnterior, dataInicioVigenciaAnterior);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Data do início da vigência não pode ser anterior a: "+dataIncMinima);
        
    }
    
    @Test
    public void testSalvarComDataInicioVigenciaNulo() {
        //Cenário
        ValoresServicosCognitivos valoresServicosCognitivos = umValoresServicosCognitivos().comDtIncVgc(null).build();
        String dataIncMinima = "25/12/2019";
        double valorSrvcCognitivoAnterior = 0.0371;
        String dataInicioVigenciaAnterior = "26/12/2019";
        
        
        //Ação
        assertThatThrownBy(() -> {
            valoresServicosCognitivosManager.salvar(valoresServicosCognitivos, dataIncMinima, valorSrvcCognitivoAnterior, dataInicioVigenciaAnterior);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Erro! O campo Data do início da vigência é obrigatório!");
        
    }
    
    
    @Test
    public void testSalvarComValorServicoCognitivoNaoAlterado() {
        //Cenário
        Date dtInicial = FormatarData.formatarStringParaData("31/12/2019");

        ValoresServicosCognitivos valoresServicosCognitivos = umValoresServicosCognitivos().comDtIncVgc(dtInicial).comValorSrvcCognitivo(0.0371).build();
                
        String dataIncMinima = "30/12/2019";
        double valorSrvcCognitivoAnterior = 0.0371;
        String dataInicioVigenciaAnterior = "26/12/2019";
        
        
        //Ação
        assertThatThrownBy(() -> {
            valoresServicosCognitivosManager.salvar(valoresServicosCognitivos, dataIncMinima, valorSrvcCognitivoAnterior, dataInicioVigenciaAnterior);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("O valor por chamada não foi alterado.");
        
    }
    
    
    @Test
    public void testSalvarComValorServicoCognitivoNulo() {
        //Cenário
        Date dtInicial = FormatarData.formatarStringParaData("31/12/2019");

        ValoresServicosCognitivos valoresServicosCognitivos = umValoresServicosCognitivos().comDtIncVgc(dtInicial).comValorSrvcCognitivo(null).build();
                
        String dataIncMinima = "30/12/2019";
        double valorSrvcCognitivoAnterior = 0.0371;
        String dataInicioVigenciaAnterior = "26/12/2019";
        
        
        //Ação
        assertThatThrownBy(() -> {
            valoresServicosCognitivosManager.salvar(valoresServicosCognitivos, dataIncMinima, valorSrvcCognitivoAnterior, dataInicioVigenciaAnterior);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Erro! O campo Valor por Chamada é obrigatório!");
        
    }
    
    @Test
    public void testSalvarComSucesso() {
        //Cenário
        Date dtInicial = FormatarData.formatarStringParaData("31/12/2019");

        ValoresServicosCognitivos valoresServicosCognitivos = umValoresServicosCognitivos().comId(null).comDtIncVgc(dtInicial).comValorSrvcCognitivo(0.04).build();
        valoresServicosCognitivos.getDtFimVgc();
        valoresServicosCognitivos.getServicosCognitivos();
                
        String dataIncMinima = "30/12/2019";
        double valorSrvcCognitivoAnterior = 0.0371;
        String dataInicioVigenciaAnterior = "26/12/2019";
        
        //Mock
        valoresServicosCognitivosDao.persist(valoresServicosCognitivos);
        
        
        //Ação
        valoresServicosCognitivosManager.salvar(valoresServicosCognitivos, dataIncMinima, valorSrvcCognitivoAnterior, dataInicioVigenciaAnterior);
        
      //Verificação
        verify(valoresServicosCognitivosDao, times(2)).persist(valoresServicosCognitivos);
        
    }
    
    @Test
    public void testSalvarComSucessoAtualizandoVigencia() {
        //Cenário
        Date dtInicial = FormatarData.formatarStringParaData("31/12/2019");

        ValoresServicosCognitivos valoresServicosCognitivos = umValoresServicosCognitivos().comId(1).comDtIncVgc(dtInicial).comValorSrvcCognitivo(0.04).build();
                
        String dataIncMinima = "30/12/2019";
        double valorSrvcCognitivoAnterior = 0.0371;
        String dataInicioVigenciaAnterior = "26/12/2019";
        
        //Mock
        valoresServicosCognitivosDao.persist(valoresServicosCognitivos);
        
        
        //Ação
        valoresServicosCognitivosManager.salvar(valoresServicosCognitivos, dataIncMinima, valorSrvcCognitivoAnterior, dataInicioVigenciaAnterior);
        
        //Verificação
        verify(valoresServicosCognitivosDao, times(3)).persist(valoresServicosCognitivos);
        
    }
    

}
