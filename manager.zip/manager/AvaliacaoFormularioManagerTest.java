package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.AvaliacaoFormularioBuilder.umAvaliacaoFormulario;
import static br.com.bb.databuilder.AvaliacaoMotivoBuilder.umAvaliacaoMotivo;
import static br.com.bb.databuilder.AvaliacaoNotaBuilder.umAvaliacaoNota;
import static br.com.bb.databuilder.AvaliacoesBuilder.umAvaliacoes;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.AvaliacaoFormularioDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacaoMotivoDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacaoNotaDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacoesDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoFormulario;
import br.com.bb.gearq.c4coleta.model.AvaliacaoMotivo;
import br.com.bb.gearq.c4coleta.model.AvaliacaoNota;
import br.com.bb.gearq.c4coleta.model.Avaliacoes;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.vo.FiltroAvaliacoesVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class AvaliacaoFormularioManagerTest {
    /**
     * @author c1312334 (Wallison Bruno)
     * @date 17/12/19
     */

    @InjectMocks
    private AvaliacaoFormularioManager avaliacaoFormularioManager;

    @Mock
    private AvaliacaoMotivoManager avaliacaoMotivoManager;
    
    @Mock
    private AvaliacaoFormularioDao avaliacaoFormularioDao; 
    
    @Mock
    private AvaliacaoMotivoDao avaliacaoMotivoDao;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Mock
    private AvaliacoesDao avaliacoesDao;
    
    @Mock
    private AvaliacaoNotaDao avaliacaoNotaDao;

    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testObter() {
        // Cenario
        Integer id = 10;
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().comId(10).build();
        avaliacaoFormulario.getQtdIteracoesExibir();
        avaliacaoFormulario.getListaAvaliacaoNota();
        
        // Mock
        when(avaliacaoFormularioDao.findById(id)).thenReturn(avaliacaoFormulario);
        
        // Ação
        avaliacaoFormularioManager.obter(id);
        
        // verificação
        verify(avaliacaoFormularioDao, times(1)).findById(id);
    }

//    ============ Cenário 1 (listaAvaliacaoMotivo = null) ===========
    @Test
    public void testSalvarFormularioComListaMotivoNULL() {
        // Cenario]
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().build();

        AvaliacaoFormulario formulario = umAvaliacaoFormulario().comId(1).build();

        List<AvaliacaoMotivo> listaAvaliacaoMotivo = null;

        // Mock
        when(avaliacaoFormularioDao.persistAndFlush(avaliacaoFormulario)).thenReturn(formulario);

        // Ação
        avaliacaoFormularioManager.salvar(avaliacaoFormulario);

        // Verificação
        assertNull(listaAvaliacaoMotivo);
    }

//   ============ Cenário 2 (listaAvaliacaoMotivo != null) ============
    @Test
    public void testSalvarFormulárioComListaMotivoDiferenteDeNULL() {
        
        
        // Cenario
        List<AvaliacaoMotivo> listaAvaliacaoMotivo = Arrays.asList(
                umAvaliacaoMotivo().comNome("Nome 1").comId(null).build(),
                umAvaliacaoMotivo().comNome("Nome 2").build());

        AvaliacaoFormulario formulario = umAvaliacaoFormulario().comId(1)
                .comListaListaAvaliacaoMotivo(listaAvaliacaoMotivo).build();
        
        // Mock
        when(avaliacaoFormularioDao.persistAndFlush(formulario)).thenReturn(formulario);
        when(avaliacaoMotivoDao.persistAndFlush(listaAvaliacaoMotivo.get(0))).thenReturn(listaAvaliacaoMotivo.get(0));
       
        // Ação
        avaliacaoFormularioManager.salvar(formulario);
       
        // Verificação
        assertNotNull(formulario);
        
    }
    
    @Test
    public void testListarFormularioEMotivo() {
        // Cenario
        List<AvaliacaoFormulario> avaliacao = Arrays.asList(
                umAvaliacaoFormulario().comId(1).build(),
                umAvaliacaoFormulario().comId(2).build()
                );
                
        List<AvaliacaoMotivo> listaMotivo = Arrays.asList(
                umAvaliacaoMotivo().comId(1).build(),
                umAvaliacaoMotivo().comId(2).build()
                );
        List<AvaliacaoNota> listaNota = Arrays.asList(
                umAvaliacaoNota().comId(1).build(),
                umAvaliacaoNota().comId(2).build()
                );
        
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario()
                                                  .comId(1)
                                                  .comListaListaAvaliacaoMotivo(listaMotivo)
                                                  .comListaListaAvaliacaoNota(listaNota)
                                                  .build();
        
        
        
        // Mock
        when(avaliacaoFormularioDao.listar("")).thenReturn(avaliacao);
        when(avaliacaoMotivoDao.findByIdFormulario(avaliacaoFormulario.getId())).thenReturn(listaMotivo);
        when(avaliacaoNotaDao.findAll()).thenReturn(listaNota);
        
        // Ação
        avaliacaoFormularioManager.listarFormularioEMotivo();
        
        // verificação
        verify(avaliacaoFormularioDao, times(1)).listar("");
        
    }
//    ============ Cenário 1 (avaliacaoFormulario = null) ============
    @Test
    public void testBuscarFormularioEMotivoPorIdComFormularioNULL() {
        // Cenario 
        int id = 10;
        
        AvaliacaoFormulario avaliacaoFormulario = null;
        
        // Mock
        when(avaliacaoFormularioDao.findById(id)).thenReturn(avaliacaoFormulario);
        
        // Ação
        avaliacaoFormularioManager.buscarFormularioEMotivoPorId(id);
        
        // Verificação
        assertNull(avaliacaoFormulario);
    }
    
//    ============ Cenário 2 (avaliacaoFormulario != null) ============
    @Test
    public void testBuscarFormularioEMotivoPorIdComFormularioDiferenteDeNULL() {
        // Cenario 
        int id = 10;
        
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().comId(10).build();
        
        // Mock
        when(avaliacaoFormularioDao.findById(id)).thenReturn(avaliacaoFormulario);
        
        // Ação
        avaliacaoFormularioManager.buscarFormularioEMotivoPorId(id);
        
        // Verificação
        assertNotNull(avaliacaoFormulario);
    }
    
    @Test
    public void testBuscarAvaliacaoFormulario() {
        // Cenario
        String titulo = "Titulo";
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().comTitulo(titulo).build();
        
        // Mock
        when(avaliacaoFormularioDao.listarPorTitulo(titulo)).thenReturn(avaliacaoFormulario);
        
        // Ação
        avaliacaoFormularioManager.buscarAvaliacaoFormulario(titulo);
        
        // Verificação
        verify(avaliacaoFormularioDao, times(1)).listarPorTitulo(titulo);
    }
    
//  ============ Cenário 1 (boolean existeAvaliacoes = false >> LINHA 104 <<) ============
    @Test
    public void testVerificarFormularioComAvaliacoes() {
        // Cenario
        
        List<AvaliacaoMotivo> listaMotivo = Arrays.asList(
                umAvaliacaoMotivo().comId(10).build(),
                umAvaliacaoMotivo().comId(20).build()
                );
        
        Paginacao<Avaliacoes> listaAvaliacoes  = new Paginacao<>();

        listaAvaliacoes.setListaPaginada(
                Arrays.asList(
                umAvaliacoes().comId(11).build(),
                umAvaliacoes().comId(21).build()
                ));
        listaAvaliacoes.setTotalRegistros((long) listaMotivo.size());
        
        ArgumentCaptor<FiltroAvaliacoesVO> filtroAvaliacoesVO = ArgumentCaptor.forClass(FiltroAvaliacoesVO.class);// capturar objeto criado na classe (Linha 106)
       
        // Mock
        when(avaliacaoMotivoManager.listar(listaMotivo.get(0).getId())).thenReturn(listaMotivo);
        when(avaliacoesDao.pesquisar(Mockito.any(FiltroAvaliacoesVO.class))).thenReturn(listaAvaliacoes);
        
        // Ação
        avaliacaoFormularioManager.verificarFormularioComAvaliacoes(listaMotivo.get(0).getId());
        
        // verificação
        assertNotNull(listaAvaliacoes);
    }
    
//  ============ Cenário 2 (boolean existeAvaliacoes = false >> LINHA 104 <<) ============
    @Test
    public void testVerificarFormularioComAvaliacoesComCondicaoTrue() {
        // Cenario
        int idFormulario = 10;
        
        List<AvaliacaoMotivo> listaMotivo = new ArrayList<>();
                
        Paginacao<Avaliacoes> listaAvaliacoes  = new Paginacao<>();

        // Mock
        when(avaliacaoMotivoDao.findByIdFormulario(idFormulario)).thenReturn(listaMotivo);
        
        // Ação
        avaliacaoFormularioManager.verificarFormularioComAvaliacoes(idFormulario);
        
        // verificação
        assertNotNull(listaMotivo);
        verify(avaliacaoMotivoDao, times(0)).findByIdFormulario(idFormulario);
    }
    
//  ============ Cenário 3 (listaAvaliacoes.getTotalRegistros() > 0)( >> LINHA 109 <<) ============
    @Test
    public void testVerificarFormularioComAvaliacoesSemRegistros() {
        int idFormulario = 10;
        
        List<AvaliacaoMotivo> listaMotivo = Arrays.asList(
                umAvaliacaoMotivo().comId(10).build(),
                umAvaliacaoMotivo().comId(20).build()
                );
        
        Paginacao<Avaliacoes> listaAvaliacoes  = new Paginacao<>();

        listaAvaliacoes.setListaPaginada(
                Arrays.asList(
                umAvaliacoes().comId(11).build(),
                umAvaliacoes().comId(21).build()
                ));

        listaAvaliacoes.setTotalRegistros(0L);
        
//        ArgumentCaptor<FiltroAvaliacoesVO> filtroAvaliacoesVO = ArgumentCaptor.forClass(FiltroAvaliacoesVO.class);// capturar objeto criado na classe (Linha 106)
       
        // Mock
        when(avaliacaoMotivoManager.listar(listaMotivo.get(0).getId())).thenReturn(listaMotivo);
        when(avaliacoesDao.pesquisar(Mockito.any(FiltroAvaliacoesVO.class))).thenReturn(listaAvaliacoes);
        
        // Ação
        avaliacaoFormularioManager.verificarFormularioComAvaliacoes(idFormulario);
        
        // verificação
        assertNotNull(listaAvaliacoes);
    }
    
//  ============ Cenário 1 (!nuvemWatsonDao.findByFormulario(idFormulario).isEmpty()) ============
    @Test
    public void testVerificarFormularioComNuvemCredencialComRegistroNaLista () {
        // Cenario
        int idFormulario = 10;
        
        List<NuvemWatson> nuvem = Arrays.asList(
                umNuvemWatson().comId(idFormulario).build()
                );
        
        // Mock
        when(nuvemWatsonDao.findByFormulario(idFormulario)).thenReturn(nuvem);
        
        // Ação
        avaliacaoFormularioManager.verificarFormularioComNuvemCredencial(idFormulario);
       
        // Verificação
        verify(nuvemWatsonDao, times(1)).findByFormulario(idFormulario);
        
    }
    
//  ============ Cenário 2 (nuvemWatsonDao.findByFormulario(idFormulario).isEmpty()) ============
    @Test
    public void testVerificarFormularioComNuvemCredencialComRegistroVazio() {
        // Cenario
        Integer idFormulario = 10;
        
        List<NuvemWatson> listnuvem = new ArrayList<NuvemWatson>();
        
        // Mock
        when(nuvemWatsonDao.findByFormulario(idFormulario)).thenReturn(listnuvem);
        
        // Ação
        avaliacaoFormularioManager.verificarFormularioComNuvemCredencial(idFormulario);
       
        // Verificação
        assertThat(listnuvem).isEmpty();
        
    }
    
    @Test
    public void testExcluir() {
        // Cenario
        
        List<AvaliacaoFormulario> listFormulario = Arrays.asList(
                umAvaliacaoFormulario().comId(2).build()
                );
                
        List<AvaliacaoMotivo> listaMotivo = Arrays.asList(
                umAvaliacaoMotivo().comId(2).build()
                );
        
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario()
                .comListaListaAvaliacaoMotivo(listaMotivo).comId(42).build();
        
        AvaliacaoMotivo avaliacaoMotivo = listaMotivo.get(0);
        
        // Mock
        when(avaliacaoFormularioDao.findById(avaliacaoFormulario.getId())).thenReturn(avaliacaoFormulario);
        when(avaliacaoMotivoManager.listar(avaliacaoFormulario.getId())).thenReturn(listaMotivo);
//        when(avaliacaoMotivoDao.persist(avaliacaoMotivo.getId())).thenReturn(avaliacaoMotivo);
        
        
        // Ação 
        avaliacaoFormularioManager.excluir(avaliacaoFormulario);
        
        // Verificação
        verify(avaliacaoFormularioDao).remove(avaliacaoFormulario);
    }
    
//    ============ Cenário 1 (avaliacaoFormulario != null) ============
    
    @Test
    public void testGetFormularioComMotivosComFormularioDiferenreDeNULL () {
        // Cenario
        Integer idFormulario = 10;
        
        List<AvaliacaoNota> notas = Arrays.asList(
                umAvaliacaoNota().build()
                );
        List<AvaliacaoMotivo> motivos = Arrays.asList(
                umAvaliacaoMotivo().comId(10).build()
                );
        
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().comId(idFormulario)
                                                                         .comListaListaAvaliacaoNota(notas)
                                                                         .comListaListaAvaliacaoMotivo(motivos).build();
        
        // Mock
        when(avaliacaoFormularioDao.findById(idFormulario)).thenReturn(avaliacaoFormulario);
        when(avaliacaoNotaDao.findAll()).thenReturn(notas);                

        // Ação
        avaliacaoFormularioManager.getFormularioComMotivos(idFormulario);
        
        // Verificação
        verify(avaliacaoFormularioDao, times(1)).findById(idFormulario);
    }
    
//  ============ Cenário 2 (avaliacaoFormulario = null) ============
    
  @Test
  public void testGetFormularioComMotivosComFormularioNULL () {
      // Cenario
      Integer idFormulario = 10;
      
      AvaliacaoFormulario avaliacaoFormulario = null;
      
      // Mock
      when(avaliacaoFormularioDao.findById(idFormulario)).thenReturn(avaliacaoFormulario);

      // Ação
      avaliacaoFormularioManager.getFormularioComMotivos(idFormulario);
      
      // Verificação
      verify(avaliacaoFormularioDao, times(1)).findById(idFormulario);
  }
  
  @Test
  public void testLista() {
      // Cenario
      List<AvaliacaoFormulario> lista = Arrays.asList(umAvaliacaoFormulario().build());
      
      // Mock
      when(avaliacaoFormularioDao.findAll()).thenReturn(lista);
      
      // Açao
      avaliacaoFormularioManager.lista();
      
      // Verificaçao
      verify(avaliacaoFormularioDao, times(1)).findAll();
  }
}
