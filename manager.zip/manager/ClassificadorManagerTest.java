package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AssuntoClassificadorBuilder.umAssuntoClassificador;
import static br.com.bb.databuilder.CasoDeTesteClassificadorBuilder.umCasoDeTesteClassificador;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.DialogoBuilder.umDialogo;
import static br.com.bb.databuilder.EntidadeBuilder.umEntidade;
import static br.com.bb.databuilder.FluxoBuilder.umFluxo;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.RespostaDialogoBuilder.umRespostaDialogo;
import static br.com.bb.databuilder.SlotsBuilder.umSlots;
import static br.com.bb.databuilder.TipoRespostaClassificadorBuilder.umTipoRespostaClassificador;
import static br.com.bb.databuilder.VariavelContextoBuilder.umVariavelContexto;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AssuntoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.CasoDeTesteClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DialogoDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeDao;
import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.SlotsDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.VariavelContextoDao;
import br.com.bb.gearq.c4coleta.model.AssuntoClassificador;
import br.com.bb.gearq.c4coleta.model.CasoDeTesteClassificador;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.RespostaDialogo;
import br.com.bb.gearq.c4coleta.model.Slots;
import br.com.bb.gearq.c4coleta.model.TipoRespostaClassificador;
import br.com.bb.gearq.c4coleta.model.VariavelContexto;

public class ClassificadorManagerTest {
    /**
     * @author c1312334
     */
    
    @InjectMocks
    private ClassificadorManager classificadorManager;
    
    @Mock
    private CacheProgresso cacheProgresso;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private FluxoManager fluxoManager;
    
    @Mock
    private FluxoDao fluxoDao;
    
    @Mock
    private IntencaoManager intencaoManager;
    
    @Mock
    private IntencaoDao intencaoDao;
    
    @Mock
    private EntidadeManager entidadeManager;
    
    @Mock
    private EntidadeDao entidadeDao;
    
    @Mock
    private RespostaDialogoManager respostaDialogoManager;
    
    @Mock
    private RespostaDialogoDao respostaDialogoDao;
    
    @Mock
    private SlotManager slotManager;
    
    @Mock
    private SlotsDao slotsDao;
    
    @Mock
    private DialogoManager dialogoManager;
    
    @Mock
    private DialogoDao dialogoDao;
    
    @Mock
    private VariavelContextoManager variavelContextoManager;
    
    @Mock
    private VariavelContextoDao  variavelContextoDao;
    
    @Mock
    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;
    
    @Mock
    private CasoDeTesteClassificadorDao casoDeTesteClassificadorDao;
    
    @Mock
    private AssuntoClassificadorManager assuntoClassificadorManager;
    
    @Mock
    private AssuntoClassificadorDao assuntoClassificadorDao;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Mock
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }
            
    /*@Test
    public void testExcluirComSucesso() {
        // Cenario
        int idClassificador = 10;
        
        Classificador classificador = umClassificador().build();
        classificador.setEstadoClassificador(null);
        
        List<NuvemWatson> listaNuvemVazio = new ArrayList<NuvemWatson>();
        
        // Mock
        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(listaNuvemVazio);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        
        // Açao
        classificadorManager.excluir(idClassificador);
    }
    
    @Test
    public void testFalharAoExcluirComNuvemWatson() {
        // Cenario
        int idClassificador = 10;
        
        Classificador classificador = new Classificador();
        
        List<NuvemWatson> listaNuvem = Arrays.asList(umNuvemWatson().comId(idClassificador).build());
        
        // Mock
        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(listaNuvem);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        
        // Açao
        assertThatThrownBy(() -> {
            classificadorManager.excluir(idClassificador);
        }).isInstanceOf(NegocioException.class)
      .hasMessageContaining("Existe credencial cadastrada com este Classificador. Para realizar a exclusão do mesmo, é necessário que seja excluída a seguinte credencial:");
        
    }
    
    @Test
    public void testFalharAoExcluirComNuvemWatson2() {
        // Cenario
        int idClassificador = 10;
        
        Classificador classificador = new Classificador();
        
        List<NuvemWatson> listaNuvem = Arrays.asList(umNuvemWatson().comId(1).build(),
                                                     umNuvemWatson().comId(2).build());
        
        // Mock
        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(listaNuvem);
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        
        // Açao
        assertThatThrownBy(() -> {
            classificadorManager.excluir(idClassificador);
        }).isInstanceOf(NegocioException.class)
      .hasMessageContaining("Existem credenciais cadastradas com este Classificador. Para realizar a exclusão do mesmo, é necessário que sejam excluídas as seguintes credenciais:");
        
    }*/
    
    
//    @Test
//    public void testFalharAoExcluirComNuvemWatson() {
//        // Cenario
//        int idClassificador = 10;
//        
//        Classificador classificador = new Classificador();
//        
//        List<NuvemWatson> listaNuvem = Arrays.asList(umNuvemWatson().comId(idClassificador).build());
//        
//        // Mock
//        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(listaNuvem);
//        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
//        
//        
//        // Açao
//        assertThatThrownBy(() -> {
//            classificadorManager.excluir(idClassificador);
//        }).isInstanceOf(NegocioException.class)
//      .hasMessageContaining("No Classificador selecionado já existem as mesmas perguntas das seguintes intenções:");
//        
//    }
    
    
/*    @Test
    public void testExcluirComClassificadorNull() {
        // Cenario
        int idClassificador = 10;
        
        // Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(null);

        // Açao/Verificacao
        assertThatThrownBy(() -> {
            classificadorManager.excluir(idClassificador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Classificador não encontrado.");
    }*/

    @Test
    public void testGetClassificadorPorServico() {
        // Cenario
        String sigla = new String("Sigla");
        
        Classificador classificador = umClassificador().build();

        // Mock
        when(classificadorDao.findByServicoInfra(sigla)).thenReturn(Arrays.asList(classificador));
        
        // Açao
        classificadorManager.getClassificadorPorServico(sigla);
        
        // verificaçao
        verify(classificadorDao, times(1)).findByServicoInfra(sigla);
    }
    
    @Test
    public void testGetClassificadorPorServicoNull() {
        // Cenario
        String sigla = new String("Sigla");
        
        // Mock
        when(classificadorDao.findByServicoInfra(sigla)).thenReturn(Arrays.asList());
        
        // Açao
        classificadorManager.getClassificadorPorServico(sigla);
        
        // verificaçao
        verify(classificadorDao, times(1)).findByServicoInfra(sigla);
    }

    @Test
    public void testObter() {
        // Cenario
        Integer idClassificador = 12;
        Classificador classificador = umClassificador().comId(idClassificador).build();
        
        // Mock
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        
        // Açao
        classificadorManager.obter(idClassificador);
        
        // verificaçao
        verify(classificadorDao, times(1)).findById(idClassificador);
        
    }

    @Test
    public void testLimpar() {
        // Cenario
        Integer idClassificador = 13;
        
        List<Fluxo> fluxo = Arrays.asList(umFluxo().comId(idClassificador).build());
        fluxo.get(0).getEntidade();
        fluxo.get(0).getTipoResp();
        fluxo.get(0).getItemPaiNaoValida();
        fluxo.get(0).getTextoFormatado();
        fluxo.get(0).getHashNuvem();
        
        List<Intencao> intencoes = Arrays.asList(umIntencao().comId(idClassificador).build());
        intencoes.get(0).getUuid();
        intencoes.get(0).setUuid(null);
        intencoes.get(0).getDataCriacao();
        intencoes.get(0).getClassificador();
        intencoes.get(0).getIdStatus();
        intencoes.get(0).getIdStatus();
        intencoes.get(0).getAssuntos();
        intencoes.get(0).setAssuntos(null);
        intencoes.get(0).getFluxo();
        intencoes.get(0).getDataModificacao();
        intencoes.get(0).setIdStatus(null);
        
        List<Entidade> entidades = Arrays.asList(umEntidade().comId(idClassificador).build());
        entidades.get(0).getUuid();
        entidades.get(0).getClassificador();
        entidades.get(0).getIdClassificador();
        entidades.get(0).getDataModificacao();
        entidades.get(0).hashCode();
        
        List<RespostaDialogo> reposta = Arrays.asList(umRespostaDialogo().comIdTipoComponente(idClassificador).build());
        
        List<Slots> slots = Arrays.asList(umSlots().comId(idClassificador).build());
        
        List<Dialogo> dialogo = Arrays.asList(umDialogo().comId(idClassificador).build());
        dialogo.get(0).getClassificador();
        Classificador classificador = umClassificador().comId(12).build();
        dialogo.get(0).setClassificador(classificador);
        dialogo.get(0).getIdEnviarPara();
        dialogo.get(0).getHashNuvem();
        dialogo.get(0).setSlots(null);
        dialogo.get(0).setiNs(null);
        dialogo.get(0).setAssuntos(null);
        dialogo.get(0).setIdTransbordo(null);
        dialogo.get(0).setFilhos(null);
        dialogo.get(0).hashCode();
        Object obj = new Object();
        dialogo.get(0).equals(obj);
        
        List<VariavelContexto> variavel = Arrays.asList(umVariavelContexto().comId(idClassificador).build());
        
        List<CasoDeTesteClassificador> caso = Arrays.asList(umCasoDeTesteClassificador().comId(idClassificador).build());
        caso.get(0).getId();
        caso.get(0).getIdClassificador();
        caso.get(0).getNomeCasoDeTeste();
        caso.get(0).getDataInclusao();
        caso.get(0).getSecoes();
        caso.get(0).setSecoes(null);
        
        List<AssuntoClassificador> assuntos = Arrays.asList(umAssuntoClassificador().comId(idClassificador).build());
        
        // Mock
        when(fluxoDao.listarVersao(idClassificador)).thenReturn(fluxo);
        when(intencaoDao.listarVersao(idClassificador)).thenReturn(intencoes);
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidades);
        when(respostaDialogoDao.listarVersao(idClassificador)).thenReturn(reposta);
        when(slotsDao.listarVersao(idClassificador)).thenReturn(slots);
        when(dialogoDao.listarVersao(idClassificador)).thenReturn(dialogo);
        when(variavelContextoDao.findByIdClassificador(idClassificador)).thenReturn(variavel);
        when(casoDeTesteClassificadorDao.listarVersao(idClassificador)).thenReturn(caso);
        when(assuntoClassificadorDao.listarVersao(idClassificador)).thenReturn(assuntos);
        // Açao
        classificadorManager.limpar(idClassificador);
        
        // verificaçao
        verify(fluxoDao, times(0)).listarVersao(idClassificador);
        verify(intencaoDao, times(0)).listarVersao(idClassificador);
        verify(entidadeDao, times(0)).listarVersao(idClassificador);
        verify(respostaDialogoDao, times(0)).listarVersao(idClassificador);
        verify(slotsDao, times(0)).listarSlotsPorDialogo(idClassificador);
        verify(dialogoDao, times(0)).listarVersao(idClassificador);
        verify(variavelContextoDao, times(0)).findByIdClassificador(idClassificador);
        verify(casoDeTesteClassificadorDao, times(0)).listarVersao(idClassificador);
        verify(assuntoClassificadorDao, times(0)).listarVersao(idClassificador);
    }
    
    @Test
    public void testLimpar_ComGetSetVAzioENull() {
        // Cenario
        Integer idClassificador = 13;
        
        List<Fluxo> fluxo = Arrays.asList(umFluxo().comId(idClassificador).build());
        fluxo.get(0).getEntidade();
        fluxo.get(0).getTipoResp();
        fluxo.get(0).getItemPaiNaoValida();
        fluxo.get(0).getTextoFormatado();
        fluxo.get(0).getHashNuvem();
        
        List<Intencao> intencoes = Arrays.asList(umIntencao().comId(idClassificador).build());
        intencoes.get(0).getUuid();
        intencoes.get(0).setUuid(null);
        intencoes.get(0).getDataCriacao();
        intencoes.get(0).getClassificador();
        intencoes.get(0).getIdStatus();
        intencoes.get(0).getIdStatus();
        intencoes.get(0).getAssuntos();
        intencoes.get(0).setAssuntos(null);
        intencoes.get(0).getFluxo();
        intencoes.get(0).getDataModificacao();
        intencoes.get(0).setIdStatus(null);
        
        List<Entidade> entidades = Arrays.asList(umEntidade().comId(idClassificador).build());
        entidades.get(0).getUuid();
        entidades.get(0).getClassificador();
        entidades.get(0).getIdClassificador();
        entidades.get(0).getDataModificacao();
        entidades.get(0).hashCode();
        
        List<RespostaDialogo> reposta = Arrays.asList(umRespostaDialogo().comIdTipoComponente(idClassificador).build());
        
        List<Slots> slots = Arrays.asList(umSlots().comId(idClassificador).build());
        
        List<Dialogo> dialogo = Arrays.asList(umDialogo().comId(idClassificador).build());
        dialogo.get(0).getClassificador();
        Classificador classificador = null;
        dialogo.get(0).setClassificador(classificador);
        dialogo.get(0).getIdEnviarPara();
        dialogo.get(0).getHashNuvem();
        dialogo.get(0).setSlots(null);
        dialogo.get(0).setiNs(null);
        dialogo.get(0).setAssuntos(null);
        dialogo.get(0).setIdTransbordo(null);
        dialogo.get(0).setFilhos(null);
        dialogo.get(0).hashCode();
        Object obj = null;
        dialogo.get(0).equals(obj);
        
        List<VariavelContexto> variavel = Arrays.asList(umVariavelContexto().comId(idClassificador).build());
        
        List<CasoDeTesteClassificador> caso = Arrays.asList(umCasoDeTesteClassificador().comId(idClassificador).build());
        
        List<AssuntoClassificador> assuntos = Arrays.asList(umAssuntoClassificador().comId(idClassificador).build());
        
        // Mock
        when(fluxoDao.listarVersao(idClassificador)).thenReturn(fluxo);
        when(intencaoDao.listarVersao(idClassificador)).thenReturn(intencoes);
        when(entidadeDao.listarVersao(idClassificador)).thenReturn(entidades);
        when(respostaDialogoDao.listarVersao(idClassificador)).thenReturn(reposta);
        when(slotsDao.listarVersao(idClassificador)).thenReturn(slots);
        when(dialogoDao.listarVersao(idClassificador)).thenReturn(dialogo);
        when(variavelContextoDao.findByIdClassificador(idClassificador)).thenReturn(variavel);
        when(casoDeTesteClassificadorDao.listarVersao(idClassificador)).thenReturn(caso);
        when(assuntoClassificadorDao.listarVersao(idClassificador)).thenReturn(assuntos);
        // Açao
        classificadorManager.limpar(idClassificador);
        
        // verificaçao
        verify(fluxoDao, times(0)).listarVersao(idClassificador);
        verify(intencaoDao, times(0)).listarVersao(idClassificador);
        verify(entidadeDao, times(0)).listarVersao(idClassificador);
        verify(respostaDialogoDao, times(0)).listarVersao(idClassificador);
        verify(slotsDao, times(0)).listarSlotsPorDialogo(idClassificador);
        verify(dialogoDao, times(0)).listarVersao(idClassificador);
        verify(variavelContextoDao, times(0)).findByIdClassificador(idClassificador);
        verify(casoDeTesteClassificadorDao, times(0)).listarVersao(idClassificador);
        verify(assuntoClassificadorDao, times(0)).listarVersao(idClassificador);
    }
    
    @Test
    public void testlistarTiposResposta() {
        // Cenario
        Integer idClassificador = 1;
        
        List<TipoRespostaClassificador> listaTipoResposta = Arrays.asList(umTipoRespostaClassificador().build());
        
        // Mock
        when(tipoRespostaClassificadorDao.findByClassificador(idClassificador)).thenReturn(listaTipoResposta);
        
        // Açao
        classificadorManager.listarTiposResposta(idClassificador);
        
        // verificaçao
        verify(tipoRespostaClassificadorDao, times(1)).findByClassificador(idClassificador);
    
    }
}
