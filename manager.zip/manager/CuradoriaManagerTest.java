package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AgruparEntidadeSinonimosBuilder.umAgruparEntidadeSinonimos;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.FiltrosPesquisaVOBuilder.umFiltrosPesquisaVO;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.LogNiaInfraBuilder.umLogNiaInfra;
import static br.com.bb.databuilder.PerguntaBuilder.umPergunta;
import static br.com.bb.databuilder.PerguntaRevisaoBuilder.umPerguntaRevisao;
import static br.com.bb.databuilder.PerguntaRevisaoEntidadeBuilder.umPerguntaRevisaoEntidade;
import static br.com.bb.databuilder.PerguntaRevisaoIntencaoBuilder.umPerguntaRevisaoIntencao;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.LogNiaInfraDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoEntidadeDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.AgruparEntidadeSinonimos;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.LogNiaInfra;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoEntidade;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoIntencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.vo.ContextoConversaVO;
import br.com.bb.gearq.c4coleta.vo.FiltrosPesquisaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.UsuarioDialogoVO;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class CuradoriaManagerTest {
    /**
     * @author c1312334
     */
    
    @InjectMocks
    private CuradoriaManager curadoriaManager;
    
    @Mock
    private PerguntaRevisaoDao perguntaRevisaoDao;
    
    @Mock
    private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;

    @Mock
    private PerguntaRevisaoEntidadeDao perguntaRevisaoEntidadeDao;

    @Mock
    private IntencaoDao intencaoDao;
    
    @Mock
    private PerguntaDao perguntaDao;
    
    @Mock
    private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
    
    @Mock
    private EmailManager emailManager;
    
    @Mock
    private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
    
    @Mock
    private LogNiaInfraDao logNiaInfraDao;
    
    @Mock
    private FluxoDao fluxoDao;
    
    @Mock
    private RespostaDialogoDao respostaDialogoDao;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private RespostaDialogoSlotDao respostaDialogoSlotDao;
    
    @Mock
    private EntidadeManager entidadeManager;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testIntencaoRevisao() {
        // Cenario
        int idPerguntaRevisao = 1;
        Integer idClassificador = new Integer(2);
        String intencao =  new String();
        
        List<Intencao> intencao2 = Arrays.asList(umIntencao().build());
        Paginacao<PerguntaRevisaoIntencao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisaoIntencao()
                .comId(3)
                .comIntencao(intencao2.get(0))
                .build()));
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao)).thenReturn(paginacao);
        when(intencaoDao.findListaIntencoes(idClassificador, intencao)).thenReturn(intencao2);
        
        // Açao
        curadoriaManager.intencaoRevisao(idPerguntaRevisao, idClassificador, intencao, paginacao);
        
        // Verificaçao
        verify(perguntaRevisaoIntencaoDao, times(1)).findByIntencoesRevisao(idPerguntaRevisao,paginacao);
        verify(intencaoDao, times(0)).findListaIntencoes(idClassificador, intencao);
    }
    
    @Test
    public void testIntencaoRevisao_ComPaginacaoNull() {
        // Cenario
        int idPerguntaRevisao = 1;
        Integer idClassificador = new Integer(2);
        String intencao =  new String();
        
        List<Intencao> intencao2 = Arrays.asList(umIntencao().build());
        Paginacao<PerguntaRevisaoIntencao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(null);
        paginacao.getListaPaginada();
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao)).thenReturn(paginacao);
        when(intencaoDao.findListaIntencoes(idClassificador, intencao)).thenReturn(intencao2);
        
        // Açao
        curadoriaManager.intencaoRevisao(idPerguntaRevisao, idClassificador, intencao, paginacao);
        
        // Verificaçao
        verify(perguntaRevisaoIntencaoDao, times(1)).findByIntencoesRevisao(idPerguntaRevisao,paginacao);
        verify(intencaoDao, times(1)).findListaIntencoes(idClassificador, intencao);
    }
    
    @Test
    public void testIntencaoRevisao_ComStringIntencaoDiferenteDeVazio() {
        // Cenario
        int idPerguntaRevisao = 1;
        Integer idClassificador = new Integer(2);
        String intencao =  new String("String");
        
        List<Intencao> intencao2 = Arrays.asList(umIntencao().build());
        Paginacao<PerguntaRevisaoIntencao> paginacao = new Paginacao<>();// Teste com paginaçao inicializada
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisaoIntencao()
                .comId(3)
                .comIntencao(intencao2.get(0))
                .build()));
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao)).thenReturn(paginacao);
        when(intencaoDao.findListaIntencoes(idClassificador, intencao)).thenReturn(intencao2);
        
        // Açao
        curadoriaManager.intencaoRevisao(idPerguntaRevisao, idClassificador, intencao, paginacao);
        
        // Verificaçao
        verify(perguntaRevisaoIntencaoDao, times(1)).findByIntencoesRevisao(idPerguntaRevisao,paginacao);
        verify(intencaoDao, times(1)).findListaIntencoes(idClassificador, intencao);
    }
    
    @Test
    public void testIntencaoRevisao_ComPaginacaoVazia() {
        // Cenario
        int idPerguntaRevisao = 1;
        Integer idClassificador = new Integer(2);
        String intencao =  new String("String");
        
        List<Intencao> intencao2 = Arrays.asList(umIntencao().build());
        Paginacao<PerguntaRevisaoIntencao> paginacao = new Paginacao<>();
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao)).thenReturn(paginacao);
        when(intencaoDao.findListaIntencoes(idClassificador, intencao)).thenReturn(intencao2);
        
        // Açao
        curadoriaManager.intencaoRevisao(idPerguntaRevisao, idClassificador, intencao, paginacao);
        
        // Verificaçao
        verify(perguntaRevisaoIntencaoDao, times(1)).findByIntencoesRevisao(idPerguntaRevisao,paginacao);
        verify(intencaoDao, times(1)).findListaIntencoes(idClassificador, intencao);
    }
    
    @Test
    public void testIntencaoRevisao_ComIntecaoNull() {
        // Cenario
        int idPerguntaRevisao = 1;
        Integer idClassificador = new Integer(2);
        String intencao =  new String("");
        
        Paginacao<PerguntaRevisaoIntencao> paginacao = new Paginacao<>();
        paginacao.getListaPaginada();
        
        PerguntaRevisaoIntencao per = new PerguntaRevisaoIntencao();
        per.getPerguntaRevisao();
        per.getNomeConfianca();
        
        List<Intencao> intencao2 = null;
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao)).thenReturn(paginacao);
        when(intencaoDao.findListaIntencoes(idClassificador, intencao)).thenReturn(intencao2);
        
        // Açao
        curadoriaManager.intencaoRevisao(idPerguntaRevisao, idClassificador, intencao, paginacao);
        
        // Verificaçao
        verify(perguntaRevisaoIntencaoDao, times(1)).findByIntencoesRevisao(idPerguntaRevisao,paginacao);
        verify(intencaoDao, times(1)).findListaIntencoes(idClassificador, intencao);
    }
    
    @Test
    public void testIntencaoRevisao_ComIntecaoVazia() {
        // Cenario
        int idPerguntaRevisao = 1;
        Integer idClassificador = new Integer(2);
        String intencao =  new String("");
        
        Paginacao<PerguntaRevisaoIntencao> paginacao = new Paginacao<>();
        paginacao.getListaPaginada();
        
        List<Intencao> intencao2 = new ArrayList<Intencao>();
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao)).thenReturn(paginacao);
        when(intencaoDao.findListaIntencoes(idClassificador, intencao)).thenReturn(intencao2);
        
        // Açao
        curadoriaManager.intencaoRevisao(idPerguntaRevisao, idClassificador, intencao, paginacao);
        
        // Verificaçao
        verify(perguntaRevisaoIntencaoDao, times(1)).findByIntencoesRevisao(idPerguntaRevisao,paginacao);
        verify(intencaoDao, times(1)).findListaIntencoes(idClassificador, intencao);
    }

    @Test
    public void testEntidadeAgrupadorRevisao() {
        // Cenario
        int idPerguntaRevisao = 1;
        List<PerguntaRevisaoEntidade> listaIp = new ArrayList<>();
        
        // Mock
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(idPerguntaRevisao)).thenReturn(listaIp);
        
        // Açao
        curadoriaManager.entidadeAgrupadorRevisao(idPerguntaRevisao);
        
        // Verificaçao
        verify(perguntaRevisaoEntidadeDao, times(1)).findByEntidadesRevisao(idPerguntaRevisao);
    }

    @Test
    public void testMapear() {
        // Cenario
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao().build());
        boolean vincular = true;

        // Verificação
        assertThatThrownBy(() -> {
            curadoriaManager.mapear(perguntasRevisao, vincular);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é possível mapear, existem perguntas com a coluna intenção vazio.");
    }
    
    @Test
    public void testMapear_ComIntencaoRevisao() {
        // Cenario
        PerguntaRevisaoIntencao intencaoRevisao = new PerguntaRevisaoIntencao();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .build());
        boolean vincular = true;

        // Verificação
        assertThatThrownBy(() -> {
            curadoriaManager.mapear(perguntasRevisao, vincular);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é possível mapear, existem perguntas com intenção não cadastradas");
    }
    
    @Test
    public void testMapear_ComIntencaoRevisaoEIntencao() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comId(15)
                .comIntencao(intencao)
                .build());
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComVincularFalse() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = false;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comId(15)
                .comIntencao(intencao)
                .build());
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComStatusDeIntencaoRevisaoDiferente() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.AUTOMATICO)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comId(15)
                .comIntencao(intencao)
                .build());
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComStatusDeIntencaoRevisaoDiferenteEPerguntasNull() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.AUTOMATICO)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = null;
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComIdIntencaoRevisaoIgualAoIdPerguntas() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(14)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .build();
        Classificador classificador = umClassificador()
                .comId(19)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(20)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("perguntasRevisao")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        Intencao intencao2 = umIntencao()
                .comId(17)
                .build();
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comId(intencao.getId())
                .comIntencao(intencao2)
                .build(),
                
                umPergunta()
                .comId(18)
                .comIntencao(intencao)
                .build());
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComIntencao() {// Verificar line 239
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(14)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .build();
        Classificador classificador = umClassificador()
                .comId(19)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(20)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("perguntasRevisao")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        Classificador classificador2 = umClassificador()
                .comId(11)
                .build();
        PerguntaRevisao pgRev = umPerguntaRevisao()
                .comId(21)
                .comClassificador(classificador2)
                .comPergunta("pgrev")
                .build();
        
        /*Segundo Bloco de teste*/
        Intencao intencao2 = umIntencao()
                .comId(17)
                .build();
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comId(intencao.getId())
                .comIntencao(intencao2)
                .build(),
                
                umPergunta()
                .comId(18)
                .comIntencao(intencao)
                .build());
        
        List<Pergunta> perguntas2 = Arrays.asList(umPergunta()
                .comId(intencao.getId())
                .comIntencao(intencao2)
                .build(),
                
                umPergunta()
                .comId(18)
                .comIntencao(intencao)
                .build());
        
        // Mock
        when(perguntaDao.findIgual(pgRev.getClassificador().getId(), pgRev.getPergunta())).thenReturn(perguntas2);
        
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), perguntasRevisao.get(0).getPergunta()))
                .thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComPerguntasNull() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = null;
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComPerguntasNullEVincularFalse() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = false;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = null;
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComPerguntasVazio() {
        // Cenario
        /*Primeiro Bloco de teste*/
        boolean vincular = true;
        Intencao intencao = umIntencao()
                .comId(12)
                .build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao()
                .comIntencao(intencao)
                .comId(intencao.getId())
                .comId(14)
                .build();
        Classificador classificador = umClassificador()
                .comId(10)
                .build();
        List<PerguntaRevisao> perguntasRevisao = Arrays.asList(umPerguntaRevisao()
                .comIntencaoRevisao(intencaoRevisao)
                .comClassificador(classificador)
                .comId(13)
                .comIdIntencaoRevisao(intencaoRevisao.getId())
                .comPergunta("")
                .comStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA)
                .comIntencao(intencao)
                .build());
        
        /*Segundo Bloco de teste*/
        List<Pergunta> perguntas = new ArrayList<>();
        
        // Mock
        when(perguntaDao.findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta())).thenReturn(perguntas);
        
        // Acao
        curadoriaManager.mapear(perguntasRevisao, vincular);
        
        // Verificacao
        verify(perguntaDao, times(2)).findIgual(perguntasRevisao.get(0).getClassificador().getId(), 
                perguntasRevisao.get(0).getPergunta());
    }
    
    @Test
    public void testMapear_ComListPerguintaRevisaoVazia() {
        // Cenario
        List<PerguntaRevisao> perguntasRevisao = new ArrayList<>();
        boolean vincular = true;

        // Verificação
        assertThatThrownBy(() -> {
            curadoriaManager.mapear(perguntasRevisao, vincular);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Selecione ao menos uma pergunta");
    }
    
    @Test
    public void testMapear_ComListPerguntasRevisaoNull() {
        // Cenario
        List<PerguntaRevisao> perguntasRevisao = null;
        boolean vincular = true;

        // Verificação
        assertThatThrownBy(() -> {
            curadoriaManager.mapear(perguntasRevisao, vincular);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Selecione ao menos uma pergunta");
    }

    @Test
    public void testMapearTodas() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()// Teste com obj null
                .comIdEntidade(1)/*Teste com valor null*/
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(100)// Teste com null e zero
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .comIdIntencaoRevisao(100)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        perRevEntidade.get(0).getId();
        perRevEntidade.get(0).getPerguntaRevisao();
        perRevEntidade.get(0).getEntidade();
        perRevEntidade.get(0).getAgrupador();
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(1)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_ComValorZeroParaPaginacao() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()
                .comIdEntidade(1)
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(0)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(0)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_ComValorNullParaPaginacao() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()
                .comIdEntidade(1)
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .comCurada(true)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(null)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(0)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_ComAnotacaoCuradaFalseDeFiltro() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()
                .comIdEntidade(1)
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .comCurada(false)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(null)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(0)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_ComAnotacaoCuradaNullDeFiltro() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()
                .comIdEntidade(1)
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .comCurada(null)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(null)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(0)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_SemAnotacaoCuradaDeFiltro() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()
                .comIdEntidade(1)
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(null)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(0)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_ComIdEntidadeDeAgrupadorEntiNull() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = umAgruparEntidadeSinonimos()
                .comIdEntidade(null)
                .build();
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(2.00)
                .comNome("Nome intencaoRevisao")
                .comId(122)
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(100)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .comIdIntencaoRevisao(100)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(1)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }
    
    @Test
    public void testMapearTodas_ComAgrupadorEntiNull() {
        // Cenario
        AgruparEntidadeSinonimos agrupadorEnti = null;
        FiltrosPesquisaVO filtro = umFiltrosPesquisaVO()
                .comAgrupador(agrupadorEnti)
                .build();
        
        PerguntaRevisaoIntencao intencaoRevisao =  umPerguntaRevisaoIntencao()
                .comNomeConfianca("Confiança")
                .comConfianca(0.00)
                .comNome("Nome intencaoRevisao")
                .build(); 
        Paginacao<PerguntaRevisao> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umPerguntaRevisao()
                .comIdIntencaoRevisao(100)
                .comIntencaoRevisao(intencaoRevisao)
                .build()));
        
        PerguntaRevisao pergunta = umPerguntaRevisao()
                .comId(2)
                .comIdIntencaoRevisao(100)
                .build();
        
        List<PerguntaRevisaoEntidade> perRevEntidade = Arrays.asList(umPerguntaRevisaoEntidade()
                .comId(4)
                .build());
        
        // Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId())).thenReturn(perRevEntidade);
        when(perguntaRevisaoDao.findPerguntaRevisao(filtro)).thenReturn(paginacao);
        
        // Ação
        curadoriaManager.mapearTodas(filtro);
        
        // Verificação
        verify(perguntaRevisaoIntencaoDao, times(1)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoEntidadeDao, times(0)).findByEntidadesRevisao(pergunta.getId());
        verify(perguntaRevisaoDao, times(1)).findPerguntaRevisao(filtro);
    }

    @Test
    public void testPerguntaRevisaoUsuario() {
        // Cenario
        UsuarioDialogoVO usuariosVO = new UsuarioDialogoVO();
        Paginacao<PerguntaRevisaoUsuario> paginacao = new Paginacao<>();
        
        // Mock
        when(perguntaRevisaoUsuarioDao.findPergunta(usuariosVO)).thenReturn(paginacao);
        
        // Açao
        curadoriaManager.perguntaRevisaoUsuario(usuariosVO);
        
        // Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findPergunta(usuariosVO);
    }
    
    @Test
    public void testPerguntaRevisaoUsuario_ComObjetosVerificados() {
        // Cenario
        UsuarioDialogoVO usuariosVO = new UsuarioDialogoVO();
        UsuarioDialogoVO verificar = usuariosVO;
        
        Paginacao<PerguntaRevisaoUsuario> paginacao = new Paginacao<>();
        
        // Mock
        when(perguntaRevisaoUsuarioDao.findPergunta(usuariosVO)).thenReturn(paginacao);
        
        // Açao
        curadoriaManager.perguntaRevisaoUsuario(usuariosVO);
        
        // Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findPergunta(usuariosVO);
        Assert.assertSame(verificar, usuariosVO);
        Assert.assertNotNull(usuariosVO);
        Assert.assertNotNull(paginacao);
    }

    @Test
    public void testUsuarioPergunta() {
        // Cenario
        Paginacao<PerguntaRevisaoUsuario> paginacao = new Paginacao<>();
        String usuario = new String("usuario");
        Integer idClassificador = new Integer(2);
        
        // mock
        when(perguntaRevisaoUsuarioDao.findUsuario(paginacao, usuario,  idClassificador)).thenReturn(paginacao);
        
        // Açao
        curadoriaManager.usuarioPergunta(paginacao, usuario, idClassificador);
        
        // Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findUsuario(paginacao, usuario, idClassificador);
    }
    
    @Test
    public void testUsuarioPergunta_ComObjtosVerificados() {
        // Cenario
        Paginacao<PerguntaRevisaoUsuario> paginacao = new Paginacao<>();
        String usuario = new String("usuario");
        Integer idClassificador = new Integer(2);
        
        // mock
        when(perguntaRevisaoUsuarioDao.findUsuario(paginacao, usuario,  idClassificador)).thenReturn(paginacao);
        
        // Açao
        curadoriaManager.usuarioPergunta(paginacao, usuario, idClassificador);
        
        // Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findUsuario(paginacao, usuario, idClassificador);
        Assert.assertEquals("usuario", usuario);
        Assert.assertEquals(new Integer(2), idClassificador);
        Assert.assertNotNull(paginacao);
        Assert.assertNotNull(usuario);
        Assert.assertNotNull(idClassificador);
        
    }

    @Test
    public void testRecuperarContextoConversa() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comChaveTipoEntrada("123")
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComParseIntNaChaveTipoEntrada() {
        // cenario
        /*Bloco da Acao*/
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        /*Primeiro Bloco de teste*/
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comJson("{\r\n" + 
                        "\r\n" + 
                        "  \"context\": {\r\n" + 
                        "\r\n" + 
                        "    \"conversation_id\": \"70d5497c-5a0e-466e-bf45-300e3694cc62\",\r\n" + 
                        "\r\n" + 
                        "    \"system\": {\r\n" + 
                        "\r\n" + 
                        "      \"dialog_request_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"dialog_stack\": [\r\n" + 
                        "\r\n" + 
                        "        {\r\n" + 
                        "\r\n" + 
                        "          \"dialog_node\": \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"dialog_turn_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"_node_output_map\": {\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao51350\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_identificacao52910\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      },\r\n" + 
                        "\r\n" + 
                        "      \"initialized\": true\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"tag\": \"RESPOSTA_SEM_FEEDBACK\",\r\n" + 
                        "\r\n" + 
                        "    \"nome\": \"AMANDA\"\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"entities\": [],\r\n" + 
                        "\r\n" + 
                        "  \"intents\": [\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.07052217960357667,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"xingamento\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06649450302124024,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"vender\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06298837184906007,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"expandir\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.0624042820930481,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"prazo\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06185028076171876,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"conceito\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05962044477462769,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"consulta\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058773782253265384,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"Horus\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058502235412597664,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"insatisfacao\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05798287749290468,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"falar\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05756081342697144,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"ganhar\"\r\n" + 
                        "\r\n" + 
                        "    }\r\n" + 
                        "\r\n" + 
                        "  ],\r\n" + 
                        "\r\n" + 
                        "  \"output\": {\r\n" + 
                        "\r\n" + 
                        "    \"output_watson\": {\r\n" + 
                        "\r\n" + 
                        "      \"text\": [\r\n" + 
                        "\r\n" + 
                        "       \r\n" + 
                        "\r\n" + 
                        "        \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "        \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"titulo\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"nodes_visited\": [\r\n" + 
                        "\r\n" + 
                        "        \"node_Forma_de_tratamento52915\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_momentos_de_vida_conceito54231\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_nulo_conceito54239\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"log_messages\": []\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"text\": [\r\n" + 
                        "\r\n" + 
                        "      \"É um prazer conversar com você, AMAND\",\r\n" + 
                        "\r\n" + 
                        "      \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "      \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"titulo\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "    ]\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"input\": {\r\n" + 
                        "\r\n" + 
                        "    \"text\": \"nome\"\r\n" + 
                        "\r\n" + 
                        "  }\r\n" + 
                        "}")
                .comChaveTipoEntrada("123")
                .build());
        
        ContextoConversaVO usuario = new ContextoConversaVO();
        usuario.setChaveTipoEntrada(Integer.parseInt(log.get(0).getChaveTipoEntrada()));
        
        Integer comparacao = new Integer(123);
        
        /*Segundo Bloco de teste*/
        List<Classificador> classificadores = Arrays.asList(umClassificador().build());
        
        // Mock
        when(classificadorDao.findByServicoInfra(siglaServico)).thenReturn(classificadores);
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada().contains("123"));
        Assert.assertEquals(comparacao, usuario.getChaveTipoEntrada());
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComSplit() {
        // cenario
        /*Bloco da Acao*/
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        /*Primeiro Bloco de teste*/
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comJson("{\r\n" + 
                        "\r\n" + 
                        "  \"context\": {\r\n" + 
                        "\r\n" + 
                        "    \"conversation_id\": \"70d5497c-5a0e-466e-bf45-300e3694cc62\",\r\n" + 
                        "\r\n" + 
                        "    \"system\": {\r\n" + 
                        "\r\n" + 
                        "      \"dialog_request_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"dialog_stack\": [\r\n" + 
                        "\r\n" + 
                        "        {\r\n" + 
                        "\r\n" + 
                        "          \"dialog_node\": \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"dialog_turn_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"_node_output_map\": {\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao51350\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_identificacao52910\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      },\r\n" + 
                        "\r\n" + 
                        "      \"initialized\": true\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"tag\": \"RESPOSTA_SEM_FEEDBACK\",\r\n" + 
                        "\r\n" + 
                        "    \"nome\": \"AMANDA\"\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"entities\": [],\r\n" + 
                        "\r\n" + 
                        "  \"intents\": [\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.07052217960357667,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"xingamento\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06649450302124024,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"vender\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06298837184906007,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"expandir\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.0624042820930481,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"prazo\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06185028076171876,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"conceito\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05962044477462769,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"consulta\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058773782253265384,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"Horus\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058502235412597664,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"insatisfacao\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05798287749290468,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"falar\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05756081342697144,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"ganhar\"\r\n" + 
                        "\r\n" + 
                        "    }\r\n" + 
                        "\r\n" + 
                        "  ],\r\n" + 
                        "\r\n" + 
                        "  \"output\": {\r\n" + 
                        "\r\n" + 
                        "    \"output_watson\": {\r\n" + 
                        "\r\n" + 
                        "      \"text\": [\r\n" + 
                        "\r\n" + 
                        "       \r\n" + 
                        "\r\n" + 
                        "        \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "        \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"titulo\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"nodes_visited\": [\r\n" + 
                        "\r\n" + 
                        "        \"node_Forma_de_tratamento52915\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_momentos_de_vida_conceito54231\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_nulo_conceito54239\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"log_messages\": []\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"text\": [\r\n" + 
                        "\r\n" + 
                        "      \"É um prazer conversar com você, AMAND\",\r\n" + 
                        "\r\n" + 
                        "      \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "      \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"titulo\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "    ]\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"input\": {\r\n" + 
                        "\r\n" + 
                        "    \"text\": \"nome\"\r\n" + 
                        "\r\n" + 
                        "  }\r\n" + 
                        "}")
                .comChaveTipoEntrada("123")
                .build());
        
        ContextoConversaVO usuario = new ContextoConversaVO();
        usuario.setChaveTipoEntrada(Integer.parseInt(log.get(0).getChaveTipoEntrada()));
        
        Integer comparacao = new Integer(123);
        
        /*Segundo Bloco de teste*/
        List<Classificador> classificadores = Arrays.asList(umClassificador()
                .comIndDialogo(false)
                .build());
        
        // Mock
        when(classificadorDao.findByServicoInfra(siglaServico)).thenReturn(classificadores);
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada().contains("123"));
        Assert.assertEquals(comparacao, usuario.getChaveTipoEntrada());
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComTituloDoJsonDiferente() {
        // cenario
        /*Bloco da Acao*/
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        /*Primeiro Bloco de teste*/
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comJson("{\r\n" + 
                        "\r\n" + 
                        "  \"context\": {\r\n" + 
                        "\r\n" + 
                        "    \"conversation_id\": \"70d5497c-5a0e-466e-bf45-300e3694cc62\",\r\n" + 
                        "\r\n" + 
                        "    \"system\": {\r\n" + 
                        "\r\n" + 
                        "      \"dialog_request_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"dialog_stack\": [\r\n" + 
                        "\r\n" + 
                        "        {\r\n" + 
                        "\r\n" + 
                        "          \"dialog_node\": \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"dialog_turn_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"_node_output_map\": {\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao51350\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_identificacao52910\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      },\r\n" + 
                        "\r\n" + 
                        "      \"initialized\": true\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"tag\": \"RESPOSTA_SEM_FEEDBACK\",\r\n" + 
                        "\r\n" + 
                        "    \"nome\": \"AMANDA\"\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"entities\": [],\r\n" + 
                        "\r\n" + 
                        "  \"intents\": [\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.07052217960357667,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"xingamento\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06649450302124024,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"vender\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06298837184906007,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"expandir\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.0624042820930481,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"prazo\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06185028076171876,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"conceito\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05962044477462769,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"consulta\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058773782253265384,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"Horus\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058502235412597664,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"insatisfacao\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05798287749290468,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"falar\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05756081342697144,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"ganhar\"\r\n" + 
                        "\r\n" + 
                        "    }\r\n" + 
                        "\r\n" + 
                        "  ],\r\n" + 
                        "\r\n" + 
                        "  \"output\": {\r\n" + 
                        "\r\n" + 
                        "    \"output_watson\": {\r\n" + 
                        "\r\n" + 
                        "      \"text\": [\r\n" + 
                        "\r\n" + 
                        "        \"É um prazer conversar com vocêAMAND\",\r\n" + 
                        "\r\n" + 
                        "        \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "        \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"titulos\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"nodes_visited\": [\r\n" + 
                        "\r\n" + 
                        "        \"node_Forma_de_tratamento52915\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_momentos_de_vida_conceito54231\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_nulo_conceito54239\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"log_messages\": []\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"text\": [\r\n" + 
                        "\r\n" + 
                        "      \"É um prazer conversar com você, AMAND\",\r\n" + 
                        "\r\n" + 
                        "      \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "      \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"titulos\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "    ]\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"input\": {\r\n" + 
                        "\r\n" + 
                        "    \"text\": \"nome\"\r\n" + 
                        "\r\n" + 
                        "  }\r\n" + 
                        "}")
                .comChaveTipoEntrada("123")
                .build());
        
        ContextoConversaVO usuario = new ContextoConversaVO();
        usuario.setChaveTipoEntrada(Integer.parseInt(log.get(0).getChaveTipoEntrada()));
        
        Integer comparacao = new Integer(123);
        
        /*Segundo Bloco de teste*/
        List<Classificador> classificadores = Arrays.asList(umClassificador().build());
        
        // Mock
        when(classificadorDao.findByServicoInfra(siglaServico)).thenReturn(classificadores);
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada().contains("123"));
        Assert.assertEquals(comparacao, usuario.getChaveTipoEntrada());
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComJsonTituloNull() {
        // cenario
        /*Bloco da Acao*/
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        /*Primeiro Bloco de teste*/
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comJson("{ \"context\": { \"conversation_id\": \"1f7462b3-051b-4ef1-aaf4-2ad50a22abb5\", \"system\": { \"dialog_stack\": "
                        + "[ { \"dialog_node\": \"root\" } ], \"dialog_turn_counter\": 1.0, \"dialog_request_counter\": 1.0, "
                        + "\"_node_output_map\": { \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\": [ 0.0, 1.0, 3.0, 0.0, "
                        + "2.0 ] } } }, \"entities\": [ { \"entity\": \"TIPO_SOLUCOES_DE_RENEGOCIACAO\", \"location\": [ 6, 9 ],"
                        + " \"value\": \"OPERACOES_DO_COP\" } ], \"intents\": [ { \"confidence\": 0.9858242497424985, \"intent\": \"especifica_-sistemas-_cop_ok\" },"
                        + " { \"confidence\": 0.01358861856550986, \"intent\": \"especifica_-fora_de_contexto-_outros\" }, { \"confidence\": 8.256236567348257E-5, "
                        + "\"intent\": \"especifica_-solucoes-renegociacao_cop-operacoes_passiveis_de_renegociacao-certificada_dirao-\" }, { \"confidence\": 4.049265842418279E-5,"
                        + " \"intent\": \"especifica_-solucoes-rao-_termo_de_compromisso_de_pagamento_voltar_repositorio\" }, { \"confidence\": 3.495899124016063E-5, "
                        + "\"intent\": \"especifica_-conceitos_gerais-_cabb_ok\" }, { \"confidence\": 3.323007338802068E-5, "
                        + "\"intent\": \"especifica_-procedimentos-linhas_de_renegociacao_cop-conta_corrente_bloqueada-certificada_dirao-\" }, { \"confidence\": 2.994008331495524E-5,"
                        + " \"intent\": \"especifica_-procedimentos-renegociacao_de_dividas-propostas_diferentes_para_a_mesma_operacao-em_construcao-\" }, { "
                        + "\"confidence\": 2.975929636762993E-5, \"intent\": \"especifica_-conceitos_gerais-_campanha_de_renegociacao_de_dividas_ok\" }, { \"confidence\": "
                        + "2.9316874530767788E-5, \"intent\": \"especifica_-fora_de_contexto-_seguros_ok\" }, { \"confidence\": 2.8944179660049627E-5, "
                        + "\"intent\": \"especifica_-anotacoes_cadastrais-_anotacao_234_voltar_link\" } ], \"output\": { \"log_messages\": [], \"text\": [ "
                        + "\"Olá! Deseja alguma ajuda sobre Solução de Dívidas?\" ], \"nodes_visited\": [ \"node_1_4cd13a08-d36b-11e6-bb4f-4ec2a9b97a0e\" ] }, "
                        + "\"input\": { \"text\": \"TESTE COP\" }}")
                .comChaveTipoEntrada("123")
                .build());
        
        ContextoConversaVO usuario = new ContextoConversaVO();
        usuario.setChaveTipoEntrada(Integer.parseInt(log.get(0).getChaveTipoEntrada()));
        
        Integer comparacao = new Integer(123);
        
        /*Segundo Bloco de teste*/
        List<Classificador> classificadores = Arrays.asList(umClassificador().build());
        
        // Mock
        when(classificadorDao.findByServicoInfra(siglaServico)).thenReturn(classificadores);
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada().contains("123"));
        Assert.assertEquals(comparacao, usuario.getChaveTipoEntrada());
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComJsonMaiorQue36Caractere() {
        // cenario
        /*Bloco da Acao*/
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        /*Primeiro Bloco de teste*/
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comJson("{\r\n" + 
                        "\r\n" + 
                        "  \"context\": {\r\n" + 
                        "\r\n" + 
                        "    \"conversation_id\": \"70d5497c-5a0e-466e-bf45-300e3694cc62\",\r\n" + 
                        "\r\n" + 
                        "    \"system\": {\r\n" + 
                        "\r\n" + 
                        "      \"dialog_request_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"dialog_stack\": [\r\n" + 
                        "\r\n" + 
                        "        {\r\n" + 
                        "\r\n" + 
                        "          \"dialog_node\": \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"dialog_turn_counter\": 2,\r\n" + 
                        "\r\n" + 
                        "      \"_node_output_map\": {\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao51350\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_identificacao52910\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        },\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\": {\r\n" + 
                        "\r\n" + 
                        "          \"0\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ],\r\n" + 
                        "\r\n" + 
                        "          \"1\": [\r\n" + 
                        "\r\n" + 
                        "            0,\r\n" + 
                        "\r\n" + 
                        "            0\r\n" + 
                        "\r\n" + 
                        "          ]\r\n" + 
                        "\r\n" + 
                        "        }\r\n" + 
                        "\r\n" + 
                        "      },\r\n" + 
                        "\r\n" + 
                        "      \"initialized\": true\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"tag\": \"RESPOSTA_SEM_FEEDBACK\",\r\n" + 
                        "\r\n" + 
                        "    \"nome\": \"AMANDA\"\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"entities\": [],\r\n" + 
                        "\r\n" + 
                        "  \"intents\": [\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.07052217960357667,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"xingamento\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06649450302124024,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"vender\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06298837184906007,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"expandir\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.0624042820930481,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"prazo\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.06185028076171876,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"conceito\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05962044477462769,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"consulta\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058773782253265384,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"Horus\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.058502235412597664,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"insatisfacao\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05798287749290468,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"falar\"\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    {\r\n" + 
                        "\r\n" + 
                        "      \"confidence\": 0.05756081342697144,\r\n" + 
                        "\r\n" + 
                        "      \"intent\": \"ganhar\"\r\n" + 
                        "\r\n" + 
                        "    }\r\n" + 
                        "\r\n" + 
                        "  ],\r\n" + 
                        "\r\n" + 
                        "  \"output\": {\r\n" + 
                        "\r\n" + 
                        "    \"output_watson\": {\r\n" + 
                        "\r\n" + 
                        "      \"text\": [\r\n" + 
                        "\r\n" + 
                        "        \"É um prazer conversar com você AMANDA.\",\r\n" + 
                        "\r\n" + 
                        "        \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "        \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"nodes_visited\": [\r\n" + 
                        "\r\n" + 
                        "        \"node_Forma_de_tratamento52915\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saudacao_personalizada52911\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_momentos_de_vida_conceito54231\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Contexto_nulo_conceito54239\",\r\n" + 
                        "\r\n" + 
                        "        \"node_Saida_momentos_de_vida_conceito51981\"\r\n" + 
                        "\r\n" + 
                        "      ],\r\n" + 
                        "\r\n" + 
                        "      \"log_messages\": []\r\n" + 
                        "\r\n" + 
                        "    },\r\n" + 
                        "\r\n" + 
                        "    \"text\": [\r\n" + 
                        "\r\n" + 
                        "      \"É um prazer conversar com você, AMANDA.\",\r\n" + 
                        "\r\n" + 
                        "      \"Em qualquer estágio da sua vida: se é importante pra você, pode contar com a gente.\",\r\n" + 
                        "\r\n" + 
                        "      \"{\\\"replies\\\":[{\\\"nome\\\":\\\"Novo Lar\\\",\\\"valor\\\":\\\"Novo Lar\\\"},{\\\"nome\\\":\\\"Viagem\\\",\\\"valor\\\":\\\"Viagem\\\"},{\\\"nome\\\":\\\"Estudo\\\",\\\"valor\\\":\\\"Estudo\\\"},{\\\"nome\\\":\\\"Filhos\\\",\\\"valor\\\":\\\"Filhos\\\"},{\\\"nome\\\":\\\"Aposentadoria\\\",\\\"valor\\\":\\\"Aposentadoria\\\"},{\\\"nome\\\":\\\"Casamento\\\",\\\"valor\\\":\\\"Casamento\\\"},{\\\"nome\\\":\\\"Primeiro Emprego\\\",\\\"valor\\\":\\\"Primeiro Emprego\\\"},{\\\"nome\\\":\\\"Empreendedor\\\",\\\"valor\\\":\\\"Empreendedor\\\"},{\\\"nome\\\":\\\"Outro\\\",\\\"valor\\\":\\\"Outro\\\"}],\\\"idTipoComponente\\\":4,\\\"nomeTipoComponente\\\":\\\"Quick Replies\\\",\\\"\\\":\\\"E aí, qual é o seu momento?\\\"}\"\r\n" + 
                        "\r\n" + 
                        "    ]\r\n" + 
                        "\r\n" + 
                        "  },\r\n" + 
                        "\r\n" + 
                        "  \"input\": {\r\n" + 
                        "\r\n" + 
                        "    \"text\": \"nome\"\r\n" + 
                        "\r\n" + 
                        "  }\r\n" + 
                        "}")
                .comChaveTipoEntrada("123")
                .build());
        
        ContextoConversaVO usuario = new ContextoConversaVO();
        usuario.setChaveTipoEntrada(Integer.parseInt(log.get(0).getChaveTipoEntrada()));
        
        Integer comparacao = new Integer(123);
        
        /*Segundo Bloco de teste*/
        List<Classificador> classificadores = Arrays.asList(umClassificador().build());
        
        // Mock
        when(classificadorDao.findByServicoInfra(siglaServico)).thenReturn(classificadores);
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada().contains("123"));
        Assert.assertEquals(comparacao, usuario.getChaveTipoEntrada());
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComChaveTipoEntradaVazio() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comChaveTipoEntrada("")
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComChaveTipoEntradaVazioECamposVerificados() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comChaveTipoEntrada("")
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada().isEmpty());
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComChaveTipoEntradaNull() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comChaveTipoEntrada(null)
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComChaveTipoEntradaNullECamposVerificados() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("Input")
                .comChaveTipoEntrada(null)
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getChaveTipoEntrada() == null);
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComInputSemMensagem() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("")
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComInputSemMensagemEVerificacaoDeCampos() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput("")
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getInput().length() == 0);
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
        
    }
    
    @Test
    public void testRecuperarContextoConversa_ComInputDoLogNull() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput(null)
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComInputDoLogNullECamposVerificados() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra()
                .comInput(null)
                .build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertTrue(log.get(0).getInput() == null);
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }
    
    @Test
    public void testRecuperarContextoConversa_ComCamposVerificados() {
        // cenario
        String idConversa = "idConversa";
        String siglaServico = "Sigla";
        
        List<LogNiaInfra> log = Arrays.asList(umLogNiaInfra().build());
        
        // Mock
        when(logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)).thenReturn(log);
        
        // Acao
        curadoriaManager.recuperarContextoConversa(idConversa, siglaServico, 0);
        
        // Verificacao
        verify(logNiaInfraDao, times(1)).findContextoConversa(idConversa, "S", siglaServico);
        Assert.assertNotNull(idConversa);
        Assert.assertNotNull(siglaServico);
        Assert.assertNotNull(log);
    }

}
