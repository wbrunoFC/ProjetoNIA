package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.PerguntaBuilder.umPergunta;
import static br.com.bb.databuilder.PerguntaRevisaoBuilder.umPerguntaRevisao;
import static br.com.bb.databuilder.PerguntaRevisaoUsuarioBuilder.umPerguntaRevisaoUsuario;
import static br.com.bb.databuilder.UsuarioBuilder.umUsuario;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.model.Usuario;
import br.com.bb.sos.infra.exceptions.NegocioException;


public class MapeamentoManagerTest {
    
    @InjectMocks
    private MapeamentoManager mapeamentoManager;

    @Mock
    private PerguntaDao perguntaDao;

    @Mock
    private PerguntaRevisaoDao perguntaRevisaoDao;
    
    @Mock
    private UsuarioDao usuarioDao;
    
    @Mock
    private IntencaoDao intencaoDao;
    
    @Mock 
    private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
    
    @Mock
    UsuarioVO funci;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testColetarComPerguntasCorpusDiferenteDeNulo() {
        //Cenário
/*        Parâmetros de entrada*/
        Classificador classificador = umClassificador().comId(1).build();
        
        PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comClassificador(classificador).comPergunta("Pergunta 01").comQuantidade(null).build();
        
        List<Pergunta> perguntasCorpus = Arrays.asList(umPergunta().build());
        
                
        //Mock
        when(perguntaDao.findIgual(perguntaRevisao.getClassificador().getId(),perguntaRevisao.getPergunta())).thenReturn(perguntasCorpus);
                
        //Ação
        mapeamentoManager.coletar(perguntaRevisao);
    }
    
    
    @Test
    public void testColetarComPerguntasDiferenteDeNulo() {
        //Cenário
/*        Parâmetros de entrada*/
        Classificador classificador = umClassificador().comId(1).build();
        
        PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comClassificador(classificador).comPergunta("Pergunta 01").comQuantidade(null).build();
        
        List<Pergunta> perguntasCorpus = null;
        
        List<PerguntaRevisao> perguntas = Arrays.asList(
                umPerguntaRevisao().comId(1).comPergunta("Pergunta 01").comClassificador(classificador).comQuantidade(null).build()
                );


        Usuario usuario = umUsuario().comChave("C1234567").build();
        
        PerguntaRevisaoUsuario perguntaRevisaoUsuario = umPerguntaRevisaoUsuario()
                                                        .comEmail(false)
                                                        .comPerguntaRevisao(perguntaRevisao)
                                                        .comUsuario(usuario.getChave())
                                                        .build();
        perguntaRevisaoUsuario.getId();
        perguntaRevisaoUsuario.getEmail();
        perguntaRevisaoUsuario.getPerguntaRevisao();
        perguntaRevisaoUsuario.getIdConversa();
        perguntaRevisaoUsuario.getFeedback();
        
        //Mock
        when(perguntaDao.findIgual(perguntaRevisao.getClassificador().getId(),perguntaRevisao.getPergunta())).thenReturn(perguntasCorpus);
        when(perguntaRevisaoDao.findPergunta(perguntaRevisao.getPergunta(),perguntaRevisao.getClassificador().getId(), PerguntaRevisaoStatus.REVISAO)).thenReturn(perguntas);
        
        perguntaRevisaoDao.persist(perguntaRevisao);
        when(usuarioDao.findByChave(funci.getChave())).thenReturn(usuario);
        perguntaRevisaoUsuarioDao.persist(perguntaRevisaoUsuario);
        
        //Ação
        mapeamentoManager.coletar(perguntaRevisao);
    }
    
        @Test
        public void testColetarComPerguntasEQuantidadeDiferentesDeNulo() {
            //Cenário
    /*        Parâmetros de entrada*/
            Classificador classificador = umClassificador().comId(1).build();
            
            PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comClassificador(classificador).comPergunta("Pergunta 01").build();
            
            List<Pergunta> perguntasCorpus = new ArrayList<>();
            
            List<PerguntaRevisao> perguntas = Arrays.asList(
                    umPerguntaRevisao().comId(1).comPergunta("Pergunta 01").comClassificador(classificador).comQuantidade(1).build()
                    );


            Usuario usuario = umUsuario().comChave("C1234567").build();
            
            PerguntaRevisaoUsuario perguntaRevisaoUsuario = umPerguntaRevisaoUsuario()
                                                            .comEmail(false)
                                                            .comPerguntaRevisao(perguntaRevisao)
                                                            .comUsuario(usuario.getChave())
                                                            .build();
            
            
            //Mock
            when(perguntaDao.findIgual(perguntaRevisao.getClassificador().getId(),perguntaRevisao.getPergunta())).thenReturn(perguntasCorpus);
            when(perguntaRevisaoDao.findPergunta(perguntaRevisao.getPergunta(),perguntaRevisao.getClassificador().getId(), PerguntaRevisaoStatus.REVISAO)).thenReturn(perguntas);
            
            perguntaRevisaoDao.persist(perguntaRevisao);
            when(usuarioDao.findByChave(funci.getChave())).thenReturn(usuario);
            perguntaRevisaoUsuarioDao.persist(perguntaRevisaoUsuario);        
            
            //Ação
            mapeamentoManager.coletar(perguntaRevisao);
        
    }
    
    @Test
    public void testColetarComPerguntasNulo() {
        //Cenário
        Classificador classificador = umClassificador().comId(1).build();
        
        PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comClassificador(classificador).comPergunta("Pergunta 01").build();
        
        List<Pergunta> perguntasCorpus = new ArrayList<>();
        
        List<PerguntaRevisao> perguntas = null;
        
        Usuario usuario = umUsuario().comChave("C1234567").build();
        
        PerguntaRevisaoUsuario perguntaRevisaoUsuario = umPerguntaRevisaoUsuario()
                                                        .comEmail(false)
                                                        .comPerguntaRevisao(perguntaRevisao)
                                                        .comUsuario(usuario.getChave())
                                                        .build();
        
        
        //Mock
        when(perguntaDao.findIgual(perguntaRevisao.getClassificador().getId(),perguntaRevisao.getPergunta())).thenReturn(perguntasCorpus);
        when(perguntaRevisaoDao.findPergunta(perguntaRevisao.getPergunta(),perguntaRevisao.getClassificador().getId(), PerguntaRevisaoStatus.REVISAO)).thenReturn(perguntas);
        perguntaRevisaoDao.persist(perguntaRevisao);
        when(usuarioDao.findByChave(funci.getChave())).thenReturn(usuario);
        perguntaRevisaoUsuarioDao.persist(perguntaRevisaoUsuario);
        
        //Ação
        mapeamentoManager.coletar(perguntaRevisao);
    
    }
    
    @Test
    public void testColetarComPerguntasVazio() {
        //Cenário
        Classificador classificador = umClassificador().comId(1).build();
        
        PerguntaRevisao perguntaRevisao = umPerguntaRevisao().comClassificador(classificador).comPergunta("Pergunta 01").comQuantidade(null).build();
        
        List<Pergunta> perguntasCorpus = new ArrayList<>();
        
        List<PerguntaRevisao> perguntas = new ArrayList<>();
        
        Usuario usuario = umUsuario().comChave("C1234567").build();
        
        PerguntaRevisaoUsuario perguntaRevisaoUsuario = umPerguntaRevisaoUsuario()
                                                        .comEmail(false)
                                                        .comPerguntaRevisao(perguntaRevisao)
                                                        .comUsuario(usuario.getChave())
                                                        .build();
        
        
        //Mock
        when(perguntaDao.findIgual(perguntaRevisao.getClassificador().getId(),perguntaRevisao.getPergunta())).thenReturn(perguntasCorpus);
        when(perguntaRevisaoDao.findPergunta(perguntaRevisao.getPergunta(),perguntaRevisao.getClassificador().getId(), PerguntaRevisaoStatus.REVISAO)).thenReturn(perguntas);
        perguntaRevisaoDao.persist(perguntaRevisao);
        when(usuarioDao.findByChave(funci.getChave())).thenReturn(usuario);
        perguntaRevisaoUsuarioDao.persist(perguntaRevisaoUsuario);
        
        //Ação
        mapeamentoManager.coletar(perguntaRevisao);
    
    }
    
    
    @Test
    public void testFalharAoMigrarPerguntaSemPergunta() {
        //Cenário
        List<Pergunta> perguntas = new ArrayList<>();
        
        Integer idItencaoDestino = 10;

        
        //Ação
        assertThatThrownBy(() -> {
            mapeamentoManager.migrar(perguntas, idItencaoDestino);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione ao menos uma pergunta");
        
    }
    
    @Test
    public void testFalharAoMigrarPerguntaComPerguntaNulo() {
        //Cenário
        List<Pergunta> perguntas = null;
        
        Integer idItencaoDestino = 10;
     
        //Ação
        assertThatThrownBy(() -> {
            mapeamentoManager.migrar(perguntas, idItencaoDestino);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione ao menos uma pergunta");
        
    }
    
    @Test
    public void testFalharAoMigrarPerguntaSemIntencaoDestino() {
        //Cenário
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comPergunta("Pergunta").build());
        
        Integer idItencaoDestino = 0;
     
        //Ação
        assertThatThrownBy(() -> {
            mapeamentoManager.migrar(perguntas, idItencaoDestino);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione uma intenção");
        
    }
    
    @Test
    public void testFalharAoMigrarPerguntaComIntencaoDestinoNulo() {
        //Cenário
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comPergunta("Pergunta").build());
        
        Integer idItencaoDestino = null;
     
        //Ação
        assertThatThrownBy(() -> {
            mapeamentoManager.migrar(perguntas, idItencaoDestino);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione uma intenção");
        
    }
   
    
    @Test
    public void testMigrarPerguntaComSucesso() {
        //Cenário
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comPergunta("Pergunta").build());
        
        Integer idItencaoDestino = 10;
        
        Intencao intencao = umIntencao().comId(1).comIdClassificador(20).build();
        
        Pergunta pergunta = perguntas.get(0);

        //Mock
        when(intencaoDao.findById(idItencaoDestino)).thenReturn(intencao);      
        perguntaDao.persist(pergunta);
        
        //Ação
        mapeamentoManager.migrar(perguntas, idItencaoDestino);
        ArgumentCaptor<Pergunta> perguntaCapturada = ArgumentCaptor.forClass(Pergunta.class);
        
        //Verificação
        verify(perguntaDao, times(2)).persist(perguntaCapturada.capture());
        verify(perguntaDao, times(1)).flush();
    }

    @Test
    public void testMigrarPerguntaComIntencaoNula() {
        //Cenário
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comPergunta("Pergunta").build());
        
        Integer idItencaoDestino = 10;
        
        Intencao intencao = null;
        

        //Mock
        when(intencaoDao.findById(idItencaoDestino)).thenReturn(intencao);      
        
        //Ação
        mapeamentoManager.migrar(perguntas, idItencaoDestino);
        
        
        //Verificação
        verify(intencaoDao, times(1)).findById(idItencaoDestino);

    }

}
