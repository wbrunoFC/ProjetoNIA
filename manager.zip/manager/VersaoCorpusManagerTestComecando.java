package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.CorpusVersaoVoV1Builder.umCorpusVersaoVoV1;
import static br.com.bb.databuilder.DialogoVersaoV1Builder.umDialogoVersaoV1;
import static br.com.bb.databuilder.RespostaDialogoVersaoV1Builder.umRespostaDialogoVersaoV1;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import br.com.bb.gearq.c4coleta.dao.VersaoCorpusDao;
import br.com.bb.gearq.c4coleta.versionamento.v1.CorpusVersaoVoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.RespostaDialogoVersaoV1;
import br.com.bb.gearq.c4coleta.vo.DiffVersao;
import br.com.bb.gearq.c4coleta.vo.RespostaComparacaoVersaoVO;

public class VersaoCorpusManagerTestComecando {
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Spy
    VersaoCorpusManager versaoCorpusManager;
    
    @Mock
    VersaoCorpusDao versaoCorpusDao;
    
    CorpusVersaoVoV1 corpusV1;
    CorpusVersaoVoV1 corpusV2;

    RespostaDialogoVersaoV1 texto1 = umRespostaDialogoVersaoV1()
            .comUuid("713Yzyx2b")
            .comIdTipoResposta(1)
            .comSequenciaBloco(1)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta1")
            .build();
    RespostaDialogoVersaoV1 texto2 = umRespostaDialogoVersaoV1()
            .comUuid("yl39HnVOC")
            .comIdTipoResposta(1)
            .comSequenciaBloco(2)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta2")
            .build();
    
    RespostaDialogoVersaoV1 texto2Editado = umRespostaDialogoVersaoV1()
            .comUuid("yl39HnVOC")
            .comIdTipoResposta(1)
            .comSequenciaBloco(2)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta2 EDITADO")
            .build();
    
    RespostaDialogoVersaoV1 texto3 = umRespostaDialogoVersaoV1()
            .comUuid("01Rhxn9fO")
            .comIdTipoResposta(1)
            .comSequenciaBloco(3)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta3 REMOVIDA")
            .build();
    
    RespostaDialogoVersaoV1 texto4 = umRespostaDialogoVersaoV1()
            .comUuid("O465M9d3l")
            .comIdTipoResposta(1)
            .comSequenciaBloco(4)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta 4")
            .build();
    
    RespostaDialogoVersaoV1 texto4Editado = umRespostaDialogoVersaoV1()
            .comUuid("O465M9d3l")
            .comIdTipoResposta(1)
            .comSequenciaBloco(4)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta 4 EDITADO")
            .build();
    
    RespostaDialogoVersaoV1 texto5 = umRespostaDialogoVersaoV1()
            .comUuid("s0xK4iuiC")
            .comIdTipoResposta(1)
            .comSequenciaBloco(5)
            .comSequenciaItem(1)
            .comTextoResposta("Texto resposta 5")
            .build();

    @Test
    public void testDeveEncontrarRespostasRemovidas() {
        
        DialogoVersaoV1[] dialogosV1 = {
                umDialogoVersaoV1()
                .comUuid("ZjQ4NGU5")
                .comNome("Dialogo editado")
                .comSequencia(1)
                .comListaRespostas(texto1,texto2,texto3,texto4,texto5)
                .build(),
        };

        DialogoVersaoV1[] dialogosV2 = {
                umDialogoVersaoV1()
                .comUuid("ZjQ4NGU5")
                .comNome("Dialogo editado")
                .comSequencia(1)
                .comListaRespostas(texto1,texto2Editado)
                .build(),
        };

//        System.out.println(dialogosV1[0].getRespostas().size());
        corpusV1 = umCorpusVersaoVoV1().comListaDialogos(dialogosV1).build();
        corpusV2  = umCorpusVersaoVoV1().comListaDialogos(dialogosV2).build();
        RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1,corpusV2);
        
        //Editados
//        System.out.println("Respostas Removidas:------->>>>");
//        imprimeValoresEditados(resposta.getDialogosEditados());
//        DiffVersao diffVersao = resposta.getDialogosEditados().get("Dialogo editado").get(0);

        DiffVersao diffTextoRespostaEditada = new DiffVersao("[Dialogo editado] -> textoResposta", 
                texto2Editado.getTextoResposta(), texto2.getTextoResposta());

        assertThat(resposta.getDialogosEditados()).hasSize(1);
        assertThat(resposta.getDialogosEditados().get("Dialogo editado")).contains(diffTextoRespostaEditada);
    }
    
    @Test
    public void testDeveEncontrarDialogosAdicionados() {

        DialogoVersaoV1[] dialogosV1 = {
          umDialogoVersaoV1()
          .comUuid("ZjQ4NGU5")
          .comNome("Dialogo editado")
          .comListaRespostas(texto1,texto2)
          .build(),
          
          umDialogoVersaoV1()
          .comUuid("XtQ5NGU7")
          .comNome("Dialogo editado 2 com resposta removida")
          .comListaRespostas(texto1,texto2,texto4)
          .build(),
          
          umDialogoVersaoV1()
          .comUuid("YjBkODQz")
          .comNome("Dialogo removido").build(),
          
          umDialogoVersaoV1()
          .comUuid("MDM0NGE1")
          .comNome("Nome igual com TipoNo diferente").comCdTipoNo(12).build(),
        };

        
        DialogoVersaoV1[] dialogosV2 = {
          umDialogoVersaoV1()
          .comUuid("ZjQ4NGU5")
          .comNome("Dialogo editado")
          .comListaRespostas(texto1,texto2Editado)
          .build(),
          
          umDialogoVersaoV1()
          .comUuid("XtQ5NGU7")
          .comNome("Dialogo editado 2 com resposta removida")
          .comListaRespostas(texto1,texto2)
          .build(),
          
          umDialogoVersaoV1()
          .comUuid("enIsvgo6")
          .comNome("Dialogo adicionado").build(),
        };

        corpusV1 = umCorpusVersaoVoV1().comListaDialogos(dialogosV1).build();
        corpusV2  = umCorpusVersaoVoV1().comListaDialogos(dialogosV2).build();
        
        RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1,corpusV2);
//        System.out.println("Dialogos Removido:------->>>>");
//        imprimeValoresEditados(resposta.getDialogosEditados());
        
        assertThat(resposta.getDialogosRemovidos()).hasSize(2);
        assertThat(resposta.getDialogosAdicionados()).hasSize(1);
        assertThat(resposta.getDialogosEditados()).hasSize(2);
    }
    
    @Test
    public void testDeveRemoverRespostaDoDialogo() {
        
        DialogoVersaoV1[] dialogosV1 = {
                umDialogoVersaoV1()
                .comUuid("ZjQ4NGU5")
                .comNome("Dialogo editado")
                .comListaRespostas(texto1,texto3)
                .build(),
              };
              
              DialogoVersaoV1[] dialogosV2 = {
                umDialogoVersaoV1()
                .comUuid("ZjQ4NGU5")
                .comNome("Dialogo editado")
                .comListaRespostas(texto1,texto4)
                .build(),
              };

              corpusV1 = umCorpusVersaoVoV1().comListaDialogos(dialogosV1).build();
              corpusV2  = umCorpusVersaoVoV1().comListaDialogos(dialogosV2).build();
//              System.out.println("Show:");
//              System.out.println(corpusV1.equals(corpusV2)+"");
              
              RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1,corpusV2);
//              System.out.println("Dialogos Editados:------->>>>");
//              imprimeValoresEditados(resposta.getDialogosEditados());
              
              assertThat(resposta.getDialogosEditados()).hasSize(1);
    }
    
    private void imprimeValoresEditados(Map<String, List<DiffVersao>> editados) {
        for (Entry<String, List<DiffVersao>> itemEditado : editados.entrySet()) {
              System.out.println("#################");
              for (DiffVersao versaoDiff : itemEditado.getValue()) {
                  System.out.println("\tCampo Editado:");
                  System.out.println("\t\t"+versaoDiff.getCampoEditado());
                  System.out.println("\tValor Origem:");
                  System.out.println("\t\t"+versaoDiff.getValorOrigem());
                  System.out.println("\tValor Destino:");
                  System.out.println("\t\t"+versaoDiff.getValorDestino());
                  System.out.println("------------------");
            }
          }
    }
}
