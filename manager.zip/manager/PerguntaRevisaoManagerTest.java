package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.ControleIdPerguntaRevisaoBuilder.umControleIdPerguntaRevisao;
import static br.com.bb.databuilder.PerguntaLogVOBuilder.umPerguntaLogVO;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.ControleIdPerguntaRevisao;
import br.com.bb.gearq.c4coleta.vo.PerguntaLogVO;

public class PerguntaRevisaoManagerTest {
    @InjectMocks
    private PerguntaRevisaoManager perguntaRevisaoManager;

    @Mock 
    private PerguntaRevisaoDao perguntaRevisaoDao;
    
    @Mock 
    private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;

    @Mock 
    ControleIdPerguntaRevisaoManager controleIdPerguntaRevisaoManager;
    
    @Mock 
    ControleIdPerguntaRevisao controle;
    
    @Mock 
    ClassificadorManager classificadorManager;
    
    @Mock 
    FeedbackManager feedbackManager;
    
    @Mock
    LogNiaInfraManager logNiaInfraManager;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testColetarLogComIdClassificador() {
        //Cenário
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().comId(1).comIdInicioPerguntaRevisao(50).comIdFimPerguntaRevisao(51).comDataConsulta(null).build();

        /*executar*/
        List<PerguntaLogVO> logs = Arrays.asList(umPerguntaLogVO().comId(2)
                                                                  .comInput("input")
                                                                  .comServico("Serviço")
                                                                  .comChave("C1234567")
                                                                  .comQuantidade(BigInteger.valueOf(1))
                                                                  .comIdClassificador(1)
                                                                  .comJson("json")
                                                                  .comDataHora(new Date())
                                                                  .comTemExemplo(true)
                                                                  .build());
        
        /*getClassificador*/
        Classificador classificador = umClassificador().build();
        
        //Mock
        when(controleIdPerguntaRevisaoManager.getControlePerguntaRevisao()).thenReturn(controle);
        controleIdPerguntaRevisaoManager.incrementar(controle, 4000);
        when(logNiaInfraManager.findLogPerguntas(controle.getIdInicioPerguntaRevisao(), controle.getIdFimPerguntaRevisao())).thenReturn(logs);
        when(classificadorManager.obter(logs.get(0).getIdClassificador())).thenReturn(classificador);
        feedbackManager.coletar(logs.get(0).getInput(), classificador, logs.get(0).getChave(), false, logs.get(0).getJson(), logs.get(0).getQuantidade().intValue(), logs.get(0).getHasExemplo(), logs.get(0).getDataHora());
        controleIdPerguntaRevisaoManager.atualizarControle(controle, logs.get(0).getId());
        controleIdPerguntaRevisaoManager.salvar(controle);
        
        //Ação
        perguntaRevisaoManager.coletarLog();
        
        //Verificação
        verify(controleIdPerguntaRevisaoManager, times(2)).atualizarControle(controle, logs.get(0).getId());
        verify(controleIdPerguntaRevisaoManager, times(2)).salvar(controle);
        
    }
    
     
    @Test
    public void testColetarLogComIdClassificadorNulo() {
        //Cenário
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().comId(1).comIdInicioPerguntaRevisao(50).comIdFimPerguntaRevisao(51).comDataConsulta(null).build();

        /*executar*/
        List<PerguntaLogVO> logs = Arrays.asList(umPerguntaLogVO().comId(2)
                                                                  .comInput("input")
                                                                  .comServico("Serviço")
                                                                  .comChave("C1234567")
                                                                  .comQuantidade(BigInteger.valueOf(1))
                                                                  .comIdClassificador(null)
                                                                  .comJson("json")
                                                                  .comDataHora(new Date())
                                                                  .comTemExemplo(true)
                                                                  .build());
        
        /*getClassificador*/
        Classificador classificador = umClassificador().build();
        
        //Mock
        when(controleIdPerguntaRevisaoManager.getControlePerguntaRevisao()).thenReturn(controle);
        controleIdPerguntaRevisaoManager.incrementar(controle, 4000);
        when(logNiaInfraManager.findLogPerguntas(controle.getIdInicioPerguntaRevisao(), controle.getIdFimPerguntaRevisao())).thenReturn(logs);
        when(classificadorManager.obter(logs.get(0).getIdClassificador())).thenReturn(classificador);
        feedbackManager.coletar(logs.get(0).getInput(), classificador, logs.get(0).getChave(), false, logs.get(0).getJson(), logs.get(0).getQuantidade().intValue(), logs.get(0).getHasExemplo(), logs.get(0).getDataHora());
        controleIdPerguntaRevisaoManager.atualizarControle(controle, logs.get(0).getId());
        controleIdPerguntaRevisaoManager.salvar(controle);
        
        //Ação
        perguntaRevisaoManager.coletarLog();
        
        //Verificação
        verify(controleIdPerguntaRevisaoManager, times(2)).atualizarControle(controle, logs.get(0).getId());
        verify(controleIdPerguntaRevisaoManager, times(2)).salvar(controle);
    }
    
    @Test
    public void testRemoverVinculoIntencaoPorClassificador() {
        //Cenário
        Integer idClassificador = 1;
        
        //Mock
        perguntaRevisaoIntencaoDao.removerVinculoIntencaoPorClassificador(idClassificador);
        perguntaRevisaoDao.removerVinculoIntencaoPorClassificador(idClassificador);
        
        //Ação
        perguntaRevisaoManager.removerVinculoIntencaoPorClassificador(idClassificador);
        
        //Verificação
        verify(perguntaRevisaoIntencaoDao, times(2)).removerVinculoIntencaoPorClassificador(idClassificador);
        verify(perguntaRevisaoDao, times(2)).removerVinculoIntencaoPorClassificador(idClassificador);
        
    }
    

}
