package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AssuntoClassificadorBuilder.umAssuntoClassificador;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AssuntoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.CasoDeTesteClassificadorDao;
import br.com.bb.gearq.c4coleta.model.AssuntoClassificador;
import br.com.bb.gearq.c4coleta.versionamento.v1.AssuntoClassificadorVersaoV1;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class AssuntoClassificadorManagerTest {
    /**
     * @author c1312334
     */
    @InjectMocks
    private AssuntoClassificadorManager assuntoClassificadorManager;
    
    @Mock
    private AssuntoClassificadorDao assuntoClassificadorDao;
    
    @Mock
    private CasoDeTesteClassificadorDao casoDeTesteClassificadorDao;
    
    @Mock
    private CacheProgresso cacheProgresso;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }

    @Test
    public void testListarVersao() {
        // Cenario
        Integer idClassificador = new Integer(2);
        List<AssuntoClassificador> assuntos = new ArrayList<>();
        
        // Mock
        when(assuntoClassificadorDao.listarVersao(idClassificador)).thenReturn(assuntos);
        
        // Açao
        assuntoClassificadorManager.listarVersao(idClassificador);
        
        // verificaçao
        verify(assuntoClassificadorDao, times(1)).listarVersao(idClassificador);
    }
    
    @Test
    public void testListarComAssuntoVersaoAdd() {
        // Cenario
        Integer idClassificador = new Integer(2);
        List<AssuntoClassificador> assuntos = Arrays.asList(umAssuntoClassificador().build());
        
        AssuntoClassificador assunto = umAssuntoClassificador().build();
        List<AssuntoClassificadorVersaoV1> assuntosVersao = new ArrayList<>();
        assuntosVersao.add(new AssuntoClassificadorVersaoV1(assunto));
        // Mock
        when(assuntoClassificadorDao.listarVersao(idClassificador)).thenReturn(assuntos);
        
        // Açao
        assuntoClassificadorManager.listarVersao(idClassificador);
        
        // verificaçao
        verify(assuntoClassificadorDao, times(1)).listarVersao(idClassificador);
    }

    @Test
    public void testSalvar() {
        // Cenario
        int idClassificador = 3;
        int idAssunto = 4;
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comId(5)
                .build();
        
        AssuntoClassificador assuntoConsultado = umAssuntoClassificador()
                .comNome("Assunto Consultado")
                .comIdClassificador(6)
                .build();
        
        List<AssuntoClassificador> listaAssuntos = Arrays.asList(umAssuntoClassificador()
                .comId(7)
                .comNome("Assunto Lista")
                .build());
        
        
        AssuntoClassificador assuntoAux = umAssuntoClassificador()
                .comId(8)
                .comNome("Assunto Aux")
                .build();
        
        // Mock
        when(assuntoClassificadorDao.findIdAssunto(idAssunto)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(assuntoClassificador.getId())).thenReturn(assuntoConsultado);
        when(assuntoClassificadorDao.findByClassificador(idClassificador)).thenReturn(listaAssuntos);
        when(assuntoClassificadorDao.findByClassificador(assuntoAux.getId())).thenReturn(listaAssuntos);
        
        // Açao
        assuntoClassificadorManager.salvar(idClassificador, assuntoClassificador);
        
        // Verificaçao
        verify(assuntoClassificadorDao, times(0)).findIdAssunto(idAssunto);
        verify(assuntoClassificadorDao, times(1)).findIdAssunto(assuntoClassificador.getId());
        verify(assuntoClassificadorDao, times(1)).findByClassificador(idClassificador);
        verify(assuntoClassificadorDao, times(0)).findByClassificador(assuntoAux.getId());
    }
    
    @Test
    public void testSalvarComAssuntoCadastrado() {
        // Cenario
        int idClassificador = 3;
        int idAssunto = 4;
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comId(5)
                .build();
        
        AssuntoClassificador assuntoConsultado = umAssuntoClassificador()
                .comNome("Assunto Consultado")
                .comIdClassificador(6)
                .build();
        
        List<AssuntoClassificador> listaAssuntos = Arrays.asList(umAssuntoClassificador()
                .comId(7)
                .comNome("Assunto Classificador")
                .build());
        
        
        AssuntoClassificador assuntoAux = umAssuntoClassificador()
                .comId(8)
                .comNome("Assunto Aux")
                .build();
        
        // Mock
        when(assuntoClassificadorDao.findIdAssunto(idAssunto)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(assuntoClassificador.getId())).thenReturn(assuntoConsultado);
        when(assuntoClassificadorDao.findByClassificador(idClassificador)).thenReturn(listaAssuntos);
        when(assuntoClassificadorDao.findByClassificador(assuntoAux.getId())).thenReturn(listaAssuntos);
        
        // Açao
        assertThatThrownBy(() -> {
        assuntoClassificadorManager.salvar(idClassificador, assuntoClassificador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Entidade: Assunto Classificador já existe!");
        
    }
    
    @Test
    public void testSalvarComIDsIguisListaAssuntoEAssuntoAux() {
        // Cenario
        int idClassificador = 3;
        int idAssunto = 4;
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comId(5)
                .build();
        
        AssuntoClassificador assuntoConsultado = umAssuntoClassificador()
                .comNome("Assunto Consultado")
                .comIdClassificador(6)
                .build();
        
        List<AssuntoClassificador> listaAssuntos = Arrays.asList(umAssuntoClassificador()
                .comId(5)
                .comNome("Assunto Classificador")
                .build());
        
        
        AssuntoClassificador assuntoAux = umAssuntoClassificador()
                .comId(8)
                .comNome("Assunto Aux")
                .build();
        
        // Mock
        when(assuntoClassificadorDao.findIdAssunto(idAssunto)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(assuntoClassificador.getId())).thenReturn(assuntoConsultado);
        when(assuntoClassificadorDao.findByClassificador(idClassificador)).thenReturn(listaAssuntos);
        when(assuntoClassificadorDao.findByClassificador(assuntoAux.getId())).thenReturn(listaAssuntos);
        
        // Açao
        assuntoClassificadorManager.salvar(idClassificador, assuntoClassificador);
        
        // Verificaçao
        verify(assuntoClassificadorDao, times(0)).findIdAssunto(idAssunto);
        verify(assuntoClassificadorDao, times(1)).findIdAssunto(assuntoClassificador.getId());
        verify(assuntoClassificadorDao, times(1)).findByClassificador(idClassificador);
        verify(assuntoClassificadorDao, times(0)).findByClassificador(assuntoAux.getId());
        
    }
    
    @Test
    public void testSalvarComNomesIguisNomeAssuntoFormularioEAssuntoConsulta() {
        // Cenario
        int idClassificador = 3;
        int idAssunto = 4;
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comId(5)
                .build();
        
        AssuntoClassificador assuntoConsultado = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comIdClassificador(6)
                .build();
        
        List<AssuntoClassificador> listaAssuntos = Arrays.asList(umAssuntoClassificador()
                .comId(5)
                .comNome("Assunto Classificador")
                .build());
        
        
        AssuntoClassificador assuntoAux = umAssuntoClassificador()
                .comId(8)
                .comNome("Assunto Aux")
                .build();
        
        // Mock
        when(assuntoClassificadorDao.findIdAssunto(idAssunto)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(assuntoClassificador.getId())).thenReturn(assuntoConsultado);
        when(assuntoClassificadorDao.findByClassificador(idClassificador)).thenReturn(listaAssuntos);
        when(assuntoClassificadorDao.findByClassificador(assuntoAux.getId())).thenReturn(listaAssuntos);
        
        // Açao
        assuntoClassificadorManager.salvar(idClassificador, assuntoClassificador);
        
        // Verificaçao
        verify(assuntoClassificadorDao, times(0)).findIdAssunto(idAssunto);
        verify(assuntoClassificadorDao, times(1)).findIdAssunto(assuntoClassificador.getId());
        verify(assuntoClassificadorDao, times(0)).findByClassificador(idClassificador);
        verify(assuntoClassificadorDao, times(0)).findByClassificador(assuntoAux.getId());
        
    }
    
    @Test
    public void testSalvarComIdZeroDoAssuntoClassificador() {
        // Cenario
        int idClassificador = 3;
        int idAssunto = 4;
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comId(0)
                .build();
        
        AssuntoClassificador a = new AssuntoClassificador();
        
        // Mock
        when(assuntoClassificadorDao.findIdAssunto(idAssunto)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(idClassificador)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(assuntoClassificador.getId())).thenReturn(a);
        when(assuntoClassificadorDao.persist(assuntoClassificador)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.persist(a)).thenReturn(assuntoClassificador);
        assuntoClassificadorDao.flush();
        
        // Açao
        assuntoClassificadorManager.salvar(idClassificador, assuntoClassificador);
        
        // Verificaçao
        verify(assuntoClassificadorDao, times(0)).findIdAssunto(idAssunto);
        verify(assuntoClassificadorDao, times(1)).findByClassificador(idClassificador);
        verify(assuntoClassificadorDao, times(0)).findIdAssunto(assuntoClassificador.getId());
        verify(assuntoClassificadorDao, times(1)).persist(assuntoClassificador);
        verify(assuntoClassificadorDao, times(0)).persist(a);
        verify(assuntoClassificadorDao, times(2)).flush();
    }
    
    @Test
    public void testSalvarComIdNullDoAssuntoClassificador() {
        // Cenario
        int idClassificador = 3;
        int idAssunto = 4;
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comNome("Assunto Classificador")
                .comId(null)
                .build();
        
        // Mock
        when(assuntoClassificadorDao.findIdAssunto(idAssunto)).thenReturn(assuntoClassificador);
        when(assuntoClassificadorDao.findIdAssunto(idClassificador)).thenReturn(assuntoClassificador);

        // Açao
        assuntoClassificadorManager.salvar(idClassificador, assuntoClassificador);
        
        // Verificaçao
        verify(assuntoClassificadorDao, times(0)).findIdAssunto(idAssunto);
        verify(assuntoClassificadorDao, times(1)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testLimparPorClassificador() {
        // Cenario
        Integer idClassificador = new Integer(10);
        List<AssuntoClassificador> assuntos = Arrays.asList(umAssuntoClassificador()
                .comIdClassificador(12)
                .build());
        
        AssuntoClassificador assuntoClassificador = umAssuntoClassificador()
                .comId(11)
                .comIdClassificador(122)
                .build();
        
        assuntoClassificador.getIdClassificador();
        
        // Mock
        when(assuntoClassificadorDao.listarVersao(idClassificador)).thenReturn(assuntos);
        when(assuntoClassificadorDao.listarVersao(assuntoClassificador.getId())).thenReturn(assuntos);
        // Açao
        assuntoClassificadorManager.limparPorClassificador(idClassificador);
        
        // Verificaçao
        verify(assuntoClassificadorDao, times(1)).listarVersao(idClassificador);
        verify(assuntoClassificadorDao, times(0)).listarVersao(assuntoClassificador.getId());
        
    }

}
