package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.AgruparEntidadeSinonimosVersaoV1Builder.umAgruparEntidadeSinonimosVersaoV1;
import static br.com.bb.databuilder.AssuntoClassificadorVersaoV1Builder.umAssuntoClassificadorVersaoV1;
import static br.com.bb.databuilder.CorpusVersaoVoV1Builder.umCorpusVersaoVoV1;
import static br.com.bb.databuilder.DialogoVersaoV1Builder.umDialogoVersaoV1;
import static br.com.bb.databuilder.EntidadeVersaoV1Builder.umEntidadeVersaoV1;
import static br.com.bb.databuilder.InstrucaoNormativaVersaoV1Builder.umInstrucaoNormativaVersaoV1;
import static br.com.bb.databuilder.IntencaoVersaoV1Builder.umIntencaoVersaoV1;
import static br.com.bb.databuilder.RespostaDialogoSlotVersaoV1Builder.umRespostaDialogoSlotVersaoV1;
import static br.com.bb.databuilder.RespostaDialogoVersaoV1Builder.umRespostaDialogoVersaoV1;
import static br.com.bb.databuilder.SinonimoVersaoV1Builder.umSinonimoVersaoV1;
import static br.com.bb.databuilder.SlotVersaoV1Builder.umSlotVersaoV1;
import static br.com.bb.databuilder.VersaoCorpusBuilder.umVersaoCorpus;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.lang3.builder.DiffResult;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.VersaoCorpusDao;
import br.com.bb.gearq.c4coleta.enums.DialogoTipoJump;
import br.com.bb.gearq.c4coleta.model.StatusDialogo;
import br.com.bb.gearq.c4coleta.model.TipoAgrupador;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.versionamento.v1.AgruparEntidadeSinonimosVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.AssuntoClassificadorVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.CorpusVersaoVoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.EntidadeVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.InstrucaoNormativaVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.IntencaoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.RespostaDialogoSlotVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.RespostaDialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.SinonimoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.SlotVersaoV1;
import br.com.bb.gearq.c4coleta.vo.DiffVersao;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.RespostaComparacaoVersaoVO;

public class VersaoCorpusManagerTest {
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @InjectMocks
    private VersaoCorpusManager versaoCorpusManager;
    
    @Mock
    private VersaoCorpusDao versaoCorpusDao;

    @Mock
    private ClassificadorManager classificadorManager;

    @Mock
    private IntencaoManager intencaoManager;

    @Mock
    private EntidadeManager entidadeManager;

    @Mock
    private DialogoManager dialogoManager;

    @Mock
    private AssuntoClassificadorManager assuntoClassificadorManager;

    @Mock
    private SlotManager slotManager;

    @Mock
    private VariavelContextoManager variavelContextoManager;

    @Mock
    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;

    @Mock
    private UsuarioManager usuarioManager;
    
    @Mock
    private TagManager tagManager;
    
    CorpusVersaoVoV1 corpusV1;
    CorpusVersaoVoV1 corpusV2;

    @Test
    public void testeCriar() {
        // Cenario
        int idClassificador = 2;
        String descricao = new String();
        String jsonNia = new String();
        String jsonWatson = new String();
        
        UsuarioVO funci = new UsuarioVO();
        VersaoCorpus versaoCorpus = new VersaoCorpus();
        versaoCorpus.setIdClassificador(idClassificador);
        versaoCorpus.setDataCriacao(new Date());
        
        // Mock
        when(versaoCorpusDao.getProximaVersao(idClassificador)).thenReturn(122);
        
        // Acao
        versaoCorpusManager.criar(idClassificador, descricao, jsonNia, jsonWatson, funci);
        
    }
    
    @Test
    public void testeObter() {
        // Cenario
        Integer idVersao = new Integer(0);
        VersaoCorpus versao =  new VersaoCorpus();
        
        // Mock
        when(versaoCorpusDao.findById(idVersao)).thenReturn(versao);
        // Acao
        versaoCorpusManager.obter(idVersao);
    }
    
    @Test
    public void testeObterPorVersao() {
        // Cenario
        Integer idClassificador =  new Integer(0);
        Integer versao = new Integer(0);

        // Acao
        versaoCorpusManager.obterPorVersao(idClassificador, versao);
    }
    
    @Test
    public void testMontarNovaVersaoStr() {
        Integer idClassificador = 12;
        
        //Acao
        versaoCorpusManager.montarNovaVersaoStr(idClassificador);
    }
    
    @Test
    public void testParseJsonToCorpus() {
        String json = new String("{}");
        
        //Acao
        versaoCorpusManager.parseJsonToCorpus(json);
    }
    
    @Test
    public void testFindById() {
        int idVersao = 10;
        
        //Acao
        versaoCorpusManager.findById(idVersao);
    }
    
    @Test
    public void testListarPorClassificador() {
        Integer idClassificador = new Integer(12);
        
        //Acao
        versaoCorpusManager.listarPorClassificador(idClassificador);
    }
    
    @Test
    public void testListarUltimoPorClassificador() {
        Integer idClassificador = new Integer(12);
        
        //Acao
        versaoCorpusManager.listarUltimoPorClassificador(idClassificador);
    }
    
    @Test
    public void testFindVersoesPaginacao() {
        int idClassificador = 10;
        int versao = 12;
        
        Paginacao<VersaoCorpus> paginacao = new Paginacao<>(); 
        paginacao.setListaPaginada(Arrays.asList(umVersaoCorpus().build()));
        
        when(versaoCorpusDao.findVersoesPaginacao(paginacao, idClassificador, versao)).thenReturn(paginacao);
        
        //Acao
        versaoCorpusManager.findVersoesPaginacao(paginacao, idClassificador, versao);
    }
    
    @Test
    public void testDiff() throws InvocationTargetException {
        AssuntoClassificadorVersaoV1 assuntoA = umAssuntoClassificadorVersaoV1()
                .comUuid("QjQ4NGU5")
                .comNome("Assunto A")
                .build();
        AssuntoClassificadorVersaoV1 assuntoB = umAssuntoClassificadorVersaoV1()
                .comUuid("QjQ4NGU5")
                .comNome("Assunto B")
                .build();

        IntencaoVersaoV1 intencao1 = umIntencaoVersaoV1().comUuid("QmY0YmU1").comNome("B1")
        .comDescricao("Descricao Antiga qualquer")
        .comListaAssuntos(assuntoA)
        .build();

        IntencaoVersaoV1 intencao2 = umIntencaoVersaoV1().comUuid("QmY0YmU1").comNome("B2")
        .comListaAssuntos(assuntoB)
        .comDescricao("Nova descricao")
        .build();

        DiffResult diffs = intencao1.diff(intencao2);
        StringBuilder left = new StringBuilder();
        StringBuilder right = new StringBuilder();
        for (Diff<?> diff : diffs) {
            left.append(diff.getLeft()).append(", ");
            right.append(diff.getRight()).append(", ");
        }

        assertThat(left).as("Descricao Antiga qualquer, Assunto B, B1, ");
        assertThat(right).as("Nova descricao, Assunto A, B2, ");
    }

    @Test
    public void testDeveSepararIntencoesEditadasAdicionadasERemovidas() {
      AssuntoClassificadorVersaoV1 assuntoA = umAssuntoClassificadorVersaoV1().comUuid("QjQ4NGU5").comNome("Assunto A").build();
      AssuntoClassificadorVersaoV1 assuntoB = umAssuntoClassificadorVersaoV1().comUuid("QjQ4NGU5").comNome("Assunto B").build();
      InstrucaoNormativaVersaoV1 instrucaoNormativa1 = umInstrucaoNormativaVersaoV1().comNumeroIN("42").build();
      
      IntencaoVersaoV1[] intencoesV1 = {
        umIntencaoVersaoV1().comUuid("ZjQ4NGU5").comNome("A1").build(),
        umIntencaoVersaoV1().comUuid("QmY0YmU1").comNome("B1")
        .comDescricao("Descricao Antiga qualquer")
        .comListaINs(instrucaoNormativa1)
        .comListaAssuntos(assuntoA).build(),
        umIntencaoVersaoV1().comUuid("XWYwZTlh").comNome("D1").build(),
        umIntencaoVersaoV1().comUuid("ZWNmYzFh").comNome("E1").build(),
      };

      IntencaoVersaoV1[] intencoesV2 = {
        umIntencaoVersaoV1().comUuid("ZjQ4NGU5").comNome("A1").build(),
        umIntencaoVersaoV1().comUuid("QmY0YmU1").comNome("B2")
        .comDescricao("Nova descricao")
        .comListaAssuntos(assuntoB).build(),
        umIntencaoVersaoV1().comUuid("OGI1ZjZj").comNome("C1").build(),
        umIntencaoVersaoV1().comUuid("ZWNmYzFh").comNome("E2").build(),
      };
      
      corpusV1 = umCorpusVersaoVoV1().comListaIntencoes(intencoesV1).build();
      corpusV2  = umCorpusVersaoVoV1().comListaIntencoes(intencoesV2).build();
      RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1, corpusV2);
      
//      System.out.println("\nEditados");
//      imprimeValoresEditados(resposta.getIntencoesEditadas());
      
      assertThat(resposta.getIntencoesEditadas().get("E1").get(0).getValorDestino()).isEqualTo("E2");
      assertThat(resposta.getIntencoesEditadas()).hasSize(2);
      assertThat(resposta.getIntencoesAdicionadas()).hasSize(1);
      assertThat(resposta.getIntencoesRemovidas()).hasSize(1);
      
      assertThat(resposta.getIntencoesAdicionadas()).contains(
          umIntencaoVersaoV1().comUuid("OGI1ZjZj").comNome("C1").build()
          );
      
      assertThat(resposta.getIntencoesRemovidas()).contains(
          umIntencaoVersaoV1().comUuid("XWYwZTlh").comNome("D1").build()
          );
    }
    
//TODO ascrescentar UUID nas intencoes
    @Test
    public void testDeveEncontrarIntencoesAdicionadasRemovidasEditadas() {
        AssuntoClassificadorVersaoV1 assuntoA = umAssuntoClassificadorVersaoV1()
                .comUuid("QjQ4NGU5").comNome("Assunto A").build();
        AssuntoClassificadorVersaoV1 assuntoB = umAssuntoClassificadorVersaoV1()
                .comUuid("QjQ4NGU5").comNome("Assunto B").build();
        InstrucaoNormativaVersaoV1 instrucaoNormativa1 = umInstrucaoNormativaVersaoV1()
                .comUuid("Qobxt8GW7").comNumeroIN("42").build();
        
        IntencaoVersaoV1[] intencoesV1 = {
            umIntencaoVersaoV1().comUuid("ZjQ4NGU5").comNome("Nao Foi Editado").build(),
            umIntencaoVersaoV1().comUuid("QmY0YmU1").comNome("Registro Editado")
            .comDescricao("Descricao da Intencao")
            .comListaINs(instrucaoNormativa1)
            .comListaAssuntos(assuntoA).build(),
            umIntencaoVersaoV1().comUuid("XWYwZTlh").comNome("D1").build(),
            umIntencaoVersaoV1().comUuid("FqpOvsEpR").comNome("F1").build(),
          };

          IntencaoVersaoV1[] intencoesV2 = {
            umIntencaoVersaoV1().comUuid("ZjQ4NGU5").comNome("Nao Foi Editado").build(),
            umIntencaoVersaoV1().comUuid("QmY0YmU1").comNome("Registro Editado")
            .comDescricao("Nova descricao")
            .comListaAssuntos(assuntoB).build(),
            umIntencaoVersaoV1().comUuid("OGI1ZjZj").comNome("C1").build(),
            umIntencaoVersaoV1().comUuid("ZWNmYzFh").comNome("E2").build(),
          };
              
        corpusV1 = umCorpusVersaoVoV1().comListaIntencoes(intencoesV1).build();
        corpusV2  = umCorpusVersaoVoV1().comListaIntencoes(intencoesV2).build();
        RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1,corpusV2);

        assertThat(resposta.getIntencoesAdicionadas()).containsOnly(intencoesV2[2],intencoesV2[3]);
        assertThat(resposta.getIntencoesRemovidas()).containsOnly(intencoesV1[2],intencoesV1[3]);
        assertThat(resposta.getIntencoesEditadas()).containsKey(intencoesV1[1].getNome());
    }

    @Test
    public void testDeveEncontrarEntidadesAdicionadas() {
	
    	SinonimoVersaoV1 sinonimoV1 = umSinonimoVersaoV1().comUuid("kDN888fn").comNome("sinonimo 1").build();
    	SinonimoVersaoV1 sinonimoV1Editado = umSinonimoVersaoV1().comUuid("kDN888fn").comNome("sinonimo 1 Editado").build();
    	SinonimoVersaoV1 sinonimoV2Editado = umSinonimoVersaoV1().comUuid("TwgZJ1H1m").comNome("sinonimo 2 Editado").build();
    	SinonimoVersaoV1 sinonimoV2 = umSinonimoVersaoV1().comUuid("TwgZJ1H1m").comNome("sinonimo 2").build();
    	SinonimoVersaoV1 sinonimoV3 = umSinonimoVersaoV1().comUuid("PyRXoBvKJ").comNome("sinonimo 3").build();
	
        AgruparEntidadeSinonimosVersaoV1 agrupadorV1 = 
        	umAgruparEntidadeSinonimosVersaoV1()
        	.comNome("Garantia")
        	.comUuid("RvBV8WQ2Z")
        	.comListaSinonimos(sinonimoV1,sinonimoV2)
        	.comTipo(TipoAgrupador.SINONIMOS)
        	.build();
        
        AgruparEntidadeSinonimosVersaoV1 agrupadorV1Editado = 
                umAgruparEntidadeSinonimosVersaoV1()
                .comNome("Garantia Editado")
                .comUuid("RvBV8WQ2Z")
                .comListaSinonimos(sinonimoV1Editado,sinonimoV2Editado,sinonimoV3)
                .comTipo(TipoAgrupador.SINONIMOS)
                .build();
        AgruparEntidadeSinonimosVersaoV1 agrupadorV2 = 
        	umAgruparEntidadeSinonimosVersaoV1()
        	.comNome("Agrupador 2")
        	.comUuid("nMPLY918T")
        	.comListaSinonimos(sinonimoV1,sinonimoV2)
        	.comTipo(TipoAgrupador.PATTERNS).build();

        EntidadeVersaoV1[] entidadesV1 = {
            umEntidadeVersaoV1().comNome("Nome igual com Agrupadores V1 e V2")
            .comUuid("5jTlhtGmI")
            .comListaAgrupadores(agrupadorV1,agrupadorV2)
            .build(),
            umEntidadeVersaoV1().comNome("Nome igual")
            .comUuid("TWpBgXhew")
            .comListaAgrupadores(agrupadorV2)
            .build(),
        };
        
        EntidadeVersaoV1[] entidadesV2 = {
            umEntidadeVersaoV1().comNome("Nome igual com Agrupadores V1 e V2")
            .comUuid("5jTlhtGmI")
        	.comListaAgrupadores(agrupadorV1Editado)
        	.build(),
            umEntidadeVersaoV1().comNome("Nome diferente2")
            .comUuid("TWpBgXhew")
            .comListaAgrupadores(agrupadorV2)
            .build(),
        };

        corpusV1 = umCorpusVersaoVoV1().comListaEntidades(entidadesV1).build();
        corpusV2  = umCorpusVersaoVoV1().comListaEntidades(entidadesV2).build();
        
        RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1,corpusV2);

//      System.out.println("Entidades Editados:");
//      imprimeValoresEditados(resposta.getEntidadesEditadas());
        
      assertThat(resposta.getEntidadesEditadas()).hasSize(2);
      assertThat(resposta.getEntidadesAdicionadas()).isEmpty();
      assertThat(resposta.getEntidadesRemovidas()).isEmpty();
    }

    @Test
    public void testDeveEncontrarDialogosAdicionados() {
        
        RespostaDialogoVersaoV1 resposta1 = umRespostaDialogoVersaoV1().comTextoResposta("Texto resposta1").build();
        RespostaDialogoVersaoV1 resposta2 = umRespostaDialogoVersaoV1().comTextoResposta("Texto resposta2").build();
        RespostaDialogoVersaoV1 resposta3 = umRespostaDialogoVersaoV1().comTextoResposta("Texto resposta3").build();
        
        RespostaDialogoSlotVersaoV1 respostaDialogoSlot1 = umRespostaDialogoSlotVersaoV1()
                .comTextoResposta("Texto Resposta 1").build();
        RespostaDialogoSlotVersaoV1 respostaDialogoSlot2 = umRespostaDialogoSlotVersaoV1()
                .comTextoResposta("Texto Resposta 2").build();
        
        SlotVersaoV1 slot1 = umSlotVersaoV1().comListaRespostas(respostaDialogoSlot1).build();
        slot1.getSerialversionuid();
        SlotVersaoV1 slot2 = umSlotVersaoV1().comListaRespostas(respostaDialogoSlot2).build();
        
        DialogoVersaoV1[] dialogosV1 = {
          umDialogoVersaoV1()
          .comUuid("ZjQ4NGU5")
          .comNome("Nome igual com ListaRespostas em ordem diferente nao contam como mudanca")
          .comListaRespostas(resposta1,resposta2).build(),
          umDialogoVersaoV1()
          .comUuid("YjBkODQz")
          .comNome("Nome igual").build(),
          umDialogoVersaoV1()
          .comUuid("MDM0NGE1")
          .comNome("Nome igual com TipoNo diferente").comCdTipoNo(12).build(),
          umDialogoVersaoV1()
          .comUuid("MzAwNDQ4")
          .comNome("Nome igual com condicao diferente").comCondicao("condicao").build(),
          umDialogoVersaoV1()
          .comUuid("N2VmMGFk")
          .comNome("Nome igual com IdSequencia diferente").comSequencia(12).build(),
          umDialogoVersaoV1()
          .comUuid("MzFkZGJi")
          .comNome("Nome igual com JumpSelector diferente").comJumpSelector("Jump").build(),
          umDialogoVersaoV1()
          .comUuid("YmM5NmY0")
          .comNome("Nome igual com ListaRespostas diferente")
          .comListaRespostas(resposta1,resposta3).build(),
          umDialogoVersaoV1()
          .comUuid("YTk1OTU3")
          .comNome("Nome igual com PossuiDesambiguacao diferente").comPossuiDesambiguacao(true).build(),
          umDialogoVersaoV1()
          .comUuid("NTVhNjFk")
          .comNome("Nome igual com RespostaMultipla diferente").comRespostaMultipla(true).build(),
          umDialogoVersaoV1()
          .comUuid("NDE2ZWFk")
          .comNome("Nome igual com StatusDialogo diferente").comStatus(StatusDialogo.ATIVO).build(),
          umDialogoVersaoV1()
          .comNome("Nome igual com StatusDialogo diferente").comStatus(StatusDialogo.getStatus(0)).build(),
          umDialogoVersaoV1()
          .comNome("Nome igual com DialogoTipoJump diferente").comTipoResp(DialogoTipoJump.DIRETA).build(),
          umDialogoVersaoV1()
          .comUuid("Uuid123")
          .comNome("Dialogo removido").build(),
          umDialogoVersaoV1()
          .comUuid("MGIwM2Y0")
          .comNome("Nome igual com UuidEnviarPara diferente").comUuidEnviarPara("Enviar para 12").build(),
          umDialogoVersaoV1()
          .comUuid("ZjVlZjZh")
          .comNome("Slot editado")
          .comListaSlots(slot1)
          .build(),
        };
        
        DialogoVersaoV1[] dialogosV2 = {
          umDialogoVersaoV1()
          .comUuid("ZjQ4NGU5")
          .comNome("Nome igual com ListaRespostas em ordem diferente nao contam como mudanca")
          .comListaRespostas(resposta2,resposta1).build(),
          umDialogoVersaoV1()
          .comUuid("YjBkODQz")
          .comNome("Nome diferente").build(),
          umDialogoVersaoV1()
          .comUuid("MDM0NGE1")
          .comNome("Nome igual com TipoNo diferente").comCdTipoNo(42).build(),
          umDialogoVersaoV1()
          .comUuid("MzAwNDQ4")
          .comNome("Nome igual com condicao diferente").comCondicao("condicao diferente").build(),
          umDialogoVersaoV1()
          .comUuid("N2VmMGFk")
          .comNome("Nome igual com IdSequencia diferente").comSequencia(42).build(),
          umDialogoVersaoV1()
          .comUuid("MzFkZGJi")
          .comNome("Nome igual com JumpSelector diferente").comJumpSelector("Jump diferente").build(),
          umDialogoVersaoV1()
          .comUuid("YmM5NmY0")
          .comNome("Nome igual com ListaRespostas diferente")
          .comListaRespostas(resposta1,resposta2).build(),
          umDialogoVersaoV1()
          .comUuid("YTk1OTU3")
          .comNome("Nome igual com PossuiDesambiguacao diferente").comPossuiDesambiguacao(false).build(),
          umDialogoVersaoV1()
          .comUuid("NTVhNjFk")
          .comNome("Nome igual com RespostaMultipla diferente").comRespostaMultipla(false).build(),
          umDialogoVersaoV1()
          .comUuid("NDE2ZWFk")
          .comNome("Nome igual com StatusDialogo diferente").comStatus(StatusDialogo.ATIVO).build(),
          umDialogoVersaoV1()
          .comNome("Nome igual com DialogoTipoJump diferente").comTipoResp(DialogoTipoJump.PULAR_ENTRADA).build(),
          umDialogoVersaoV1()
          .comUuid("Uuid347")
          .comNome("Dialogo Adicionado").build(),
          umDialogoVersaoV1()
          .comUuid("MGIwM2Y0")
          .comNome("Nome igual com UuidEnviarPara diferente").comUuidEnviarPara("Enviar para 42").build(),
          umDialogoVersaoV1()
          .comUuid("ZjVlZjZh")
          .comNome("Slot editado")
          .comListaSlots(slot2)
          .build(),
        };
        
        corpusV1 = umCorpusVersaoVoV1().comListaDialogos(dialogosV1).build();
        corpusV2  = umCorpusVersaoVoV1().comListaDialogos(dialogosV2).build();
        RespostaComparacaoVersaoVO resposta = new RespostaComparacaoVersaoVO(corpusV1,corpusV2);
        
//        System.out.println("Dialogos Editados:");
//        imprimeValoresEditados(resposta.getDialogosEditados());
        
        assertThat(resposta.getDialogosAdicionados()).hasSize(1); //Dialogos adicionados
        assertThat(resposta.getDialogosAdicionados()).contains(
                umDialogoVersaoV1()
                .comUuid("Uuid347")
                .comNome("Dialogo Adicionado").build());
        assertThat(resposta.getDialogosRemovidos()).hasSize(1); //Dialogos removidos
        assertThat(resposta.getDialogosRemovidos()).contains(
                umDialogoVersaoV1()
                .comUuid("Uuid123")
                .comNome("Dialogo removido").build());
        assertThat(resposta.getDialogosEditados()).hasSize(12); //Numero de dialogos editados
        assertThat(resposta.getDialogosAdicionados()).doesNotContain(
                umDialogoVersaoV1().comNome("Nome igual com ListaRespostas em ordem diferente nao contam como mudanca")
          .comListaRespostas(resposta2,resposta1).build());
    }
    
    private void imprimeValoresEditados(Map<String, List<DiffVersao>> editados) {
        for (Entry<String, List<DiffVersao>> itemEditado : editados.entrySet()) {
              System.out.println("#################");
              for (DiffVersao versaoDiff : itemEditado.getValue()) {
                  System.out.println("\tCampo Editado:");
                  System.out.println("\t\t"+versaoDiff.getCampoEditado());
                  System.out.println("\tValor Origem:");
                  System.out.println("\t\t"+versaoDiff.getValorOrigem());
                  System.out.println("\tValor Destino:");
                  System.out.println("\t\t"+versaoDiff.getValorDestino());
                  System.out.println("------------------");
            }
          }
    }
}
