package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.DialogoBuilder.umDialogo;
import static br.com.bb.databuilder.EntidadeBuilder.umEntidade;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import br.com.bb.databuilder.FluxoVOBuilder;
import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DialogoDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.enums.DialogoTipoJump;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.StatusIntencao;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.vo.CriarNodeVo;
import br.com.bb.gearq.c4coleta.vo.DialogoListagemVO;
import br.com.bb.gearq.c4coleta.vo.DialogoSimplesVo;
import br.com.bb.gearq.c4coleta.vo.DialogoVO;
import br.com.bb.gearq.c4coleta.vo.FiltroDialogoVO;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;
import br.com.bb.gearq.c4coleta.vo.MoverNodeVo;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class DialogoManagerTest {
    /**
     * @author c1312334
     */

    @InjectMocks
    private DialogoManager dialogoManager;

    @Mock
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;

    @Mock
    private RespostaDialogoDao respostaDialogoDao;

    @Mock
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @Mock
    private DialogoDao dialogoDao;

    @Mock
    private RespostaDialogoSlotDao respostaDialogoSlotDao;

    @Mock
    private RespostaDialogoManager respostaDialogoManager;

    @Mock
    private InstrucaoNormativaDialogoManager instrucaoNormativaDialogoManager;

    @Mock
    private SlotManager slotManager;

    @Mock
    private IntencaoDao intencaoDao;

    @Mock
    private IntencaoManager intencaoManager;

    @Mock
    private EntidadeManager entidadeManager;

    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;

    @Mock
    private CacheProgresso cacheProgresso;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testPesquisarVazio() {
        FiltroDialogoVO filtroVO = new FiltroDialogoVO();

        Paginacao<Dialogo> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(new ArrayList<>());

        when(dialogoDao.pesquisar(filtroVO.getPaginacao(), filtroVO.getId(), filtroVO.getIdClassificador(),
                filtroVO.getIdSaudacao(), filtroVO.getIdNaoAtendida(), filtroVO.getStatus(), filtroVO.getNome(),
                filtroVO.getResposta(), filtroVO.getCondicao(), filtroVO.getUuid(), filtroVO.getInstrucaoNormativa()))
                        .thenReturn(paginacao);

        DialogoListagemVO nodes = dialogoManager.pesquisar(filtroVO);

        assertEquals(0, nodes.getDialogos().size());
    }

    private FiltroDialogoVO criarCenarioPesquisa(Paginacao<Dialogo> paginacao) {
        int idClassificador = 1;

        Dialogo saudacao = umDialogo().comId(1).build();
        Dialogo naoatendida = umDialogo().comId(2).build();

        FiltroDialogoVO filtroVO = new FiltroDialogoVO();
        filtroVO.setIdSaudacao(saudacao.getId());
        filtroVO.setIdNaoAtendida(naoatendida.getId());
        filtroVO.setIdClassificador(idClassificador);

        when(dialogoDao.findByNome(idClassificador, "NIAC4_SAUDACAO", 0, 0, false)).thenReturn(Arrays.asList(saudacao));
        when(dialogoDao.findByNome(idClassificador, "NIAC4_NAO_ATENDIA", 0, 0, false))
                .thenReturn(Arrays.asList(naoatendida));

        when(dialogoDao.pesquisar(filtroVO.getPaginacao(), filtroVO.getId(), filtroVO.getIdClassificador(),
                filtroVO.getIdSaudacao(), filtroVO.getIdNaoAtendida(), filtroVO.getStatus(), filtroVO.getNome(),
                filtroVO.getResposta(), filtroVO.getCondicao(), filtroVO.getUuid(), filtroVO.getInstrucaoNormativa()))
                        .thenReturn(paginacao);

        return filtroVO;
    }

    @Test
    public void testPesquisarNodesRaiz() {
        Dialogo node1 = umDialogo().comId(3).comCdTipoNo(0).build();
        Dialogo node2 = umDialogo().comId(4).comCdTipoNo(3).build();

        Paginacao<Dialogo> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(node1, node2));

        FiltroDialogoVO filtroVO = criarCenarioPesquisa(paginacao);
        DialogoListagemVO nodes = dialogoManager.pesquisar(filtroVO);
        assertEquals(2, nodes.getDialogos().size());
    }

    @Test
    public void testPesquisarFilhos() {
        Dialogo pai = umDialogo().comId(3).comCdTipoNo(0).build();
        Dialogo filho = umDialogo().comId(4).comPai(pai).comCdTipoNo(0).build();
        Dialogo filhoResposta = umDialogo().comId(4).comPai(pai).comCdTipoNo(1).build();

        Paginacao<Dialogo> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(pai, filho, filhoResposta));

        FiltroDialogoVO filtroVO = criarCenarioPesquisa(paginacao);
        DialogoListagemVO nodes = dialogoManager.pesquisar(filtroVO);
        assertEquals(1, nodes.getDialogos().size());
    }

    @Test
    public void testObterDialogoSimplesSemFilhos() {
        Integer idDialogo = 1;
        Dialogo dialogo = umDialogo().comId(idDialogo).build();

        when(dialogoDao.findById(idDialogo)).thenReturn(dialogo);

        DialogoSimplesVo nodeSimples = dialogoManager.obterDialogoSimples(1, false);

        assertEquals(nodeSimples.getId(), idDialogo);

    }

    @Test
    public void testObterDialogoSimplesComFilhos() {
        Integer idDialogo = 1;
        Dialogo dialogo = umDialogo().comId(idDialogo).build();
        Dialogo filho = umDialogo().comId(2).comPai(dialogo).build();
        List<Dialogo> filhos = Arrays.asList(filho);

        when(dialogoDao.findById(idDialogo)).thenReturn(dialogo);
        when(dialogoDao.listarFilhosDialogoPadrao(idDialogo)).thenReturn(filhos);

        DialogoSimplesVo nodeSimples = dialogoManager.obterDialogoSimples(1, true);

        assertEquals(nodeSimples.getId(), idDialogo);
    }

    @Test
    public void testSalvarNovo() {
        Dialogo node = umDialogo().comId(null).build();
        Integer idDialogo = 1;

        when(dialogoDao.persist(node)).thenAnswer(new Answer<Dialogo>() {
            public Dialogo answer(InvocationOnMock invocation) throws Throwable {
                Dialogo dialogo = (Dialogo) invocation.getArguments()[0];
                dialogo.setId(idDialogo);
                return dialogo;
            }
        });

        Dialogo novoNode = dialogoManager.salvar(node);
        assertEquals(novoNode.getId(), idDialogo);
    }

    @Test
    public void testSalvarEditar() {
        // Cenario
        Integer idDialogo = 1;
        Integer idFilho = 2;
        Integer idClassificador = 1;

        Dialogo filho = umDialogo().comId(idFilho).comIdClassificador(idClassificador).build();
        Dialogo node = umDialogo().comId(idDialogo).comIdClassificador(idClassificador)
                .comTextoResposta("Resposta teste").comListaFilhos(filho).comInstrucaoNormativa("111-1").build();

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(node);
        when(dialogoDao.findById(idFilho)).thenReturn(filho);

        // Acao
        dialogoManager.salvar(node);

        // Test
        assertEquals(node.getId(), idDialogo);
    }

    @Test
    public void testEditar() {
        // Cenario
        Integer idDialogo = 1;
        Integer idClassificador = 1;

        Dialogo node = umDialogo().comId(idDialogo).comIdClassificador(idClassificador).comSlot(null, "@teste", "teste")
                .comTextoResposta("").comInstrucaoNormativa("").comSlot(null, "", "").comSlot(null, null, "")
                .comSlot(1, "slot editado", "").build();
        Dialogo nodeVelho = umDialogo().comId(idDialogo).comIdClassificador(idClassificador)
                .comTextoResposta("Resposta excluida").comInstrucaoNormativa("in excluida")
                .comSlot(1, "slot editado 1", "").comSlot(2, "slot excluido", "").build();

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(nodeVelho);

        // Acao
        dialogoManager.salvar(node);

        // Test
        assertEquals(node.getId(), idDialogo);
    }

    @Test
    public void testEditarComMultiplaRespostaHandler() {
        // Cenario
        Integer idDialogo = 1;
        Integer idNodeResposta = 2;
        Integer idNodeHandler = 3;
        Integer idClassificador = 1;

        Dialogo nodeResposta = umDialogo().comId(idNodeResposta).comIdClassificador(idClassificador).build();
        Dialogo nodeHandler = umDialogo().comId(idNodeHandler).comIdClassificador(idClassificador).build();
        Dialogo node = umDialogo().comId(idDialogo).comIdClassificador(idClassificador)
                .comTipoResp(DialogoTipoJump.DIRETA).comMultiplaResposta(idNodeResposta, "node 2", "")
                .comHandler(idNodeHandler, "node handler", "").build();
        Dialogo nodeVelho = umDialogo().comId(idDialogo).comIdClassificador(idClassificador)
                .comMultiplaResposta(nodeResposta).comHandler(nodeHandler).comMultiplaResposta(3, "node excluido", "")
                .comHandler(4, "handler excluido", "").build();

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(nodeVelho);
        when(dialogoDao.findById(idNodeResposta)).thenReturn(nodeResposta);
        when(dialogoDao.findById(idNodeHandler)).thenReturn(nodeHandler);

        // Acao
        dialogoManager.salvar(node);

        // Test
        assertEquals(node.getId(), idDialogo);
    }

    @Test
    public void testEditarComJump() {
        // Cenario
        Integer idDialogo = 1;
        Integer idClassificador = 1;
        Integer idEnviarPara = 2;

        Dialogo node = umDialogo().comId(idDialogo).comIdClassificador(idClassificador)
                .comTipoResp(DialogoTipoJump.ENVAR_PARA).comIdEnviarPara(idEnviarPara).build();

        when(dialogoDao.findById(idDialogo)).thenReturn(node);

        // Acao
        dialogoManager.salvar(node);

        // Test
        assertEquals(node.getId(), idDialogo);
    }

    @Test
    public void testCriarPrimeiroNode() {
        // Cenario
        Integer idClassificador = 1;
        Integer idDialogo = 1;

        CriarNodeVo vo = new CriarNodeVo();
        vo.setIdClassificador(idClassificador);

        // Mock
        doAnswer((InvocationOnMock invocation) -> {
            Dialogo node = (Dialogo) invocation.getArguments()[0];
            node.setId(idDialogo);
            return null;
        }).when(dialogoDao).persist(any(Dialogo.class));

        // Acao
        Dialogo dialogo = dialogoManager.criar(vo);

        // Test
        assertEquals(dialogo.getId(), idDialogo);
    }

    @Test
    public void testCriarFilho() {
        // Cenario
        Integer idPai = 1;
        Integer idClassificador = 1;
        Dialogo pai = umDialogo().comId(idPai).comIdClassificador(idClassificador).build();

        CriarNodeVo vo = new CriarNodeVo();
        vo.setIdClassificador(idClassificador);
        vo.setIdDialogoAlvo(idPai);

        // Mock
        when(dialogoDao.findById(idPai)).thenReturn(pai);

        // Acao
        Dialogo dialogo = dialogoManager.criar(vo);

        // Test
        assertEquals(dialogo.getIdPai(), idPai);
    }

    @Test
    public void testCriarIrmao() {
        // Cenario
        Integer idClassificador = 1;
        Integer idPai = 1;
        Dialogo pai = umDialogo().comId(idPai).comIdClassificador(idClassificador).build();
        Integer idIrmao = 2;
        Dialogo irmao = umDialogo().comId(idIrmao).comIdClassificador(idClassificador).comPai(pai).build();

        CriarNodeVo vo = new CriarNodeVo();
        vo.setIdClassificador(idClassificador);
        vo.setIdDialogoAlvo(idIrmao);
        vo.setPosicao(1);

        // Mock
        when(dialogoDao.findById(idIrmao)).thenReturn(irmao);

        // Acao
        Dialogo dialogo = dialogoManager.criar(vo);

        // Test
        // Devem ter o mesmo pai
        assertEquals(dialogo.getIdPai(), idPai);
    }

    @Test(expected = NegocioException.class)
    public void testExcluirNulo() {
        Integer idDialogo = 1;

        when(dialogoDao.findById(idDialogo)).thenReturn(null);

        dialogoManager.excluir(idDialogo);

    }

    @Test
    public void testExcluir() {
        // Cenario
        Integer idDialogo = 1;
        Integer idNodeComJump = 2;
        Integer idPai = 3;
        Dialogo pai = umDialogo().comId(idPai).comTipoResp(DialogoTipoJump.PULAR_ENTRADA).build();
        Dialogo node = umDialogo().comId(idDialogo).comTextoResposta("Resposta teste")
                .comListaFilhos(umDialogo().build()).comInstrucaoNormativa("111-1").comSlot(1, "@produto", "produto")
                .comPai(pai).build();
        Dialogo nodeComJump = umDialogo().comId(idNodeComJump).comEnviarPara(node).build();

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(node);
        when(dialogoDao.listarFilhosDialogoPadrao(idPai)).thenReturn(new ArrayList<>());
        when(dialogoDao.findByEnviarPara(idDialogo)).thenReturn(Arrays.asList(nodeComJump));

        // Acao
        dialogoManager.excluir(idDialogo);

        // Test
        verify(dialogoDao, times(1)).remove(node);
    }

    @Test
    public void testExcluirComIrmaos() {
        // Cenario
        Integer idPai = 1;
        Dialogo pai = umDialogo().comId(idPai).build();
        Dialogo node = umDialogo().comId(2).comPai(pai).build();
        List<Dialogo> irmaos = Arrays.asList(umDialogo().build());

        // Mock
        when(dialogoDao.listarFilhosDialogoPadrao(idPai)).thenReturn(irmaos);

        // Acao
        dialogoManager.excluir(node);

        // Test
        verify(dialogoDao, times(1)).remove(node);
    }

    @Test
    public void testMoverComoFilho() {
        // Cenario
        Integer idDialogo = 1;
        Integer idAlvo = 2;
        Integer idClassificador = 1;
        Long quantidadeFilhos = 0L;
        Dialogo node = umDialogo().comId(idDialogo).comIdClassificador(idClassificador).build();
        Dialogo nodeAlvo = umDialogo().comId(idAlvo).comIdClassificador(idClassificador).build();

        MoverNodeVo vo = new MoverNodeVo();
        vo.setIdDialogo(idDialogo);
        vo.setIdDialogoAlvo(idAlvo);
        vo.setPosicao(0);

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(node);
        when(dialogoDao.findById(idAlvo)).thenReturn(nodeAlvo);
        when(dialogoDao.listarFilhosDialogoPadrao(idDialogo)).thenReturn(new ArrayList<>());
        when(dialogoDao.listarFilhosDialogoPadrao(idAlvo)).thenReturn(new ArrayList<>());
        when(dialogoDao.contaFilhosDialogoPadrao(idClassificador, idAlvo)).thenReturn(quantidadeFilhos);

        // Acao
        dialogoManager.mover(vo);

        // Test
        assertEquals(node.getIdPai(), idAlvo);

    }

    @Test
    public void testMoverParaOutroNode() {
        // Cenario
        Integer idDialogo = 1;
        Integer idAlvo = 2;
        Integer idClassificador = 1;
        Long quantidadeFilhos = 0L;
        Dialogo node = umDialogo().comId(idDialogo).comPai(umDialogo().comId(3).build())
                .comIdClassificador(idClassificador).build();
        Dialogo nodeAlvo = umDialogo().comId(idAlvo).comIdClassificador(idClassificador).build();

        MoverNodeVo vo = new MoverNodeVo();
        vo.setIdDialogo(idDialogo);
        vo.setIdDialogoAlvo(idAlvo);
        vo.setPosicao(0);

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(node);
        when(dialogoDao.findById(idAlvo)).thenReturn(nodeAlvo);
        when(dialogoDao.listarFilhosDialogoPadrao(idDialogo)).thenReturn(new ArrayList<>());
        when(dialogoDao.listarFilhosDialogoPadrao(idAlvo)).thenReturn(new ArrayList<>());
        when(dialogoDao.contaFilhosDialogoPadrao(idClassificador, idAlvo)).thenReturn(quantidadeFilhos);

        // Acao
        dialogoManager.mover(vo);

        // Test
        assertEquals(node.getIdPai(), idAlvo);
    }

    @Test
    public void testMoverAoLadoIrmao() {
        // Cenario
        Integer idDialogo = 1;
        Integer idAlvo = 2;
        Integer idClassificador = 1;
        Long quantidadeFilhos = 0L;
        Dialogo node = umDialogo().comId(idDialogo).comIdClassificador(idClassificador).build();
        Dialogo nodeAlvo = umDialogo().comId(idAlvo).comIdClassificador(idClassificador).build();

        MoverNodeVo vo = new MoverNodeVo();
        vo.setIdDialogo(idDialogo);
        vo.setIdDialogoAlvo(idAlvo);
        vo.setPosicao(1);

        // Mock
        when(dialogoDao.findById(idDialogo)).thenReturn(node);
        when(dialogoDao.findById(idAlvo)).thenReturn(nodeAlvo);
        when(dialogoDao.listarFilhosDialogoPadrao(idDialogo)).thenReturn(new ArrayList<>());
        when(dialogoDao.listarFilhosDialogoPadrao(idAlvo)).thenReturn(new ArrayList<>());
        when(dialogoDao.listarDialogosRaiz(idClassificador)).thenReturn(Arrays.asList(node, nodeAlvo));
        when(dialogoDao.contaFilhosDialogoPadrao(idClassificador, idAlvo)).thenReturn(quantidadeFilhos);

        // Acao
        dialogoManager.mover(vo);

        // Test
        assertEquals(1, node.getIdSequencia().intValue());

    }

    @Test
    public void testLimparPorClassificador() {
        // Cenario
        Integer idClassificador = 2;
        Dialogo node = umDialogo().comId(1).comIdClassificador(idClassificador).build();
        Dialogo nodeComPai = umDialogo().comId(2).comIdClassificador(idClassificador).comIdPai(1).build();

        // Mock
        when(dialogoDao.listarVersao(idClassificador)).thenReturn(Arrays.asList(node, nodeComPai));

        // Acao
        dialogoManager.limparPorClassificador(idClassificador);

        // Test
        verify(dialogoDao, times(1)).remove(node);
    }

    @Test
    public void testListarVersao() {
        // Cenario
        Integer idClassificador = 2;
        Dialogo node = umDialogo().comId(1).comIdClassificador(idClassificador).build();

        // Mock
        when(dialogoDao.listarVersao(idClassificador)).thenReturn(Arrays.asList(node));

        // Acao
        List<DialogoVersaoV1> nodesVersao = dialogoManager.listarVersao(idClassificador);

        // Test
        assertEquals(1, nodesVersao.size());
    }

    @Test
    public void testValidarCondicaoIntencao() {
        // Cenario
        String intencaoExiste = "desbloquear";
        String intencaoNaoExiste = "intnaoexiste";
        Integer idClassificador = 1;
        Intencao intencao = umIntencao().comIdClassificador(idClassificador).comNome(intencaoExiste).build();

        // Mock
        when(intencaoManager.buscarPorNomeExato(intencaoExiste, idClassificador)).thenReturn(Arrays.asList(intencao));

        // Acao
        boolean resultValida = dialogoManager.validarCondicao("#" + intencaoExiste, idClassificador);
        boolean resultValidaComNegacao = dialogoManager.validarCondicao("!#" + intencaoExiste, idClassificador);
        boolean resultInvalida = dialogoManager.validarCondicao("#" + intencaoNaoExiste, idClassificador);
        boolean resultVazio = dialogoManager.validarCondicao("", idClassificador);

        assertEquals(true, resultValida);
        assertEquals(true, resultValidaComNegacao);
        assertEquals(false, resultInvalida);
        assertEquals(true, resultVazio);
    }

    @Test
    public void testValidarCondicaoEntidade() {
        // Cenario
        String entidadeExiste = "produto";
        String entidadeNaoExiste = "intnaoexiste";
        Integer idClassificador = 1;

        Entidade entidade = umEntidade().build();

        // Mock
        when(entidadeManager.buscarEntidadePorNomeExato(entidadeExiste, idClassificador))
                .thenReturn(Arrays.asList(entidade));

        // Acao
        boolean resultValida = dialogoManager.validarCondicao("@" + entidadeExiste, idClassificador);
        boolean resultInvalida = dialogoManager.validarCondicao("@" + entidadeNaoExiste, idClassificador);
        boolean resultComValor = dialogoManager.validarCondicao("@" + entidadeExiste + ":cartao", idClassificador);
        boolean resultComLiteral = dialogoManager.validarCondicao("@" + entidadeExiste + ".literal", idClassificador);

        assertEquals(true, resultValida);
        assertEquals(false, resultInvalida);
        assertEquals(true, resultComValor);
        assertEquals(true, resultComLiteral);
    }

    @Test
    public void testValidarCondicoesClassificador() {
        // Cenario
        Integer idClassificador = 1;
        String intencaoNome = "desbloquear";
        String condicao = "#" + intencaoNome;
        Dialogo node1 = umDialogo().comId(1).comIdClassificador(idClassificador).comCondicao(condicao).build();
        Dialogo node2 = umDialogo().comId(2).comIdClassificador(idClassificador).comCondicao("#naoexiste").build();
        Intencao intencao = umIntencao().comIdClassificador(idClassificador).comNome(intencaoNome).build();

        // Mock
        when(dialogoDao.findByClassificador(idClassificador)).thenReturn(Arrays.asList(node1, node2));
        when(intencaoManager.buscarPorNomeExato(intencaoNome, idClassificador)).thenReturn(Arrays.asList(intencao));

        // Acao
        List<Map<String, String>> validarCondicoes = dialogoManager.validarCondicoes(idClassificador);

        // Test
        assertEquals(1, validarCondicoes.size());
    }

    @Test
    public void testPesquisarDialogo() {
        // Cenario
        Integer idClassificador = 2;
        String nome = "Nome";
        Integer idSaudacao = 3;
        Integer idNaoAtendida = 4;
        Dialogo node = umDialogo().build();

        // Mock
        when(dialogoDao.findByNome(idClassificador, nome, idSaudacao, idNaoAtendida, true))
                .thenReturn(Arrays.asList(node));

        // Acao
        List<Dialogo> nodes = dialogoManager.pesquisarDialogo(idClassificador, nome, idSaudacao, idNaoAtendida);

        // Test
        assertEquals(1, nodes.size());
    }

    @Test
    public void testObterPorUuid() {
        // Cenario
        int idClassificador = 1;
        String uuid = "uuid";

        List<Dialogo> dialogos = new ArrayList<Dialogo>();

        // Mock
        when(dialogoDao.findByUuid(idClassificador, uuid)).thenReturn(dialogos);

        // Acao
        Dialogo result = dialogoManager.obterPorUuid(idClassificador, uuid);

        // Test
        assertEquals(null, result);

    }

    @Test
    public void testObterPorUuid_ComDialogoNull() {
        // Cenario
        int idClassificador = 1;
        String uuid = "uuid";

        Dialogo node = umDialogo().build();

        List<Dialogo> dialogos = Arrays.asList(node);

        // Mock
        when(dialogoDao.findByUuid(idClassificador, uuid)).thenReturn(dialogos);

        // Acao
        Dialogo result = dialogoManager.obterPorUuid(idClassificador, uuid);

        // Test
        assertEquals(node, result);
    }

    @Test
    public void testMigrarDialogo() {
        // Cenario
        Integer idClassificador = 1;
        Classificador classificador = umClassificador().comId(idClassificador).build();
        Integer idIntencao = 1;
        Intencao intencao = umIntencao().comId(idIntencao).comNome("desbloquear")
                .comStatus(StatusIntencao.VALIDADO).comNecessitaDesambiguacao(true).build();
        FluxoVO fluxoVO = FluxoVOBuilder.umFluxoVO().build();

        // Mock
        when(intencaoDao.findByClassificador(idClassificador)).thenReturn(Arrays.asList(intencao));
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(tipoRespostaIntencaoDao.findAll(intencao.getId(), null)).thenReturn(Arrays.asList());
        when(intencaoManager.buscaFluxo(intencao.getId())).thenReturn(fluxoVO);

        // Acao
        DialogoVO migrarDialogo = dialogoManager.migrarDialogo(idClassificador);

        // Test
        assertEquals(1, migrarDialogo.getDialogos().size());
    }
}
