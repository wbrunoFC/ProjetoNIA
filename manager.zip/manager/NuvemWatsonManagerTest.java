package br.com.bb.gearq.c4coleta.manager;


import static br.com.bb.databuilder.AcessosChatBuilder.umAcessosChat;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.CredencialWatsonBuilder.umCredencialWatson;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static br.com.bb.databuilder.ParametroServicoBotBuilder.umParametroWatson;
import static br.com.bb.databuilder.VersaoCorpusBuilder.umVersaoCorpus;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.AcessosChatDao;
import br.com.bb.gearq.c4coleta.dao.CredencialWatsonDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.ParametroServicoBotDao;
import br.com.bb.gearq.c4coleta.dao.SincronizacaoDao;
import br.com.bb.gearq.c4coleta.model.AcessosChat;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.CredencialWatson;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.ParametroServicoBot;
import br.com.bb.gearq.c4coleta.model.ParametroWatsonTipoCampo;
import br.com.bb.gearq.c4coleta.model.ServicoBot;
import br.com.bb.gearq.c4coleta.model.Sincronizacao;
import br.com.bb.gearq.c4coleta.model.StatusNuvem;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.vo.NuvemWatsonVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class NuvemWatsonManagerTest {
    @InjectMocks
    private NuvemWatsonManager nuvemWatsonManager;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Mock
    private SincronizacaoDao sincronizacaoDao;
    
    @Mock
    private CredencialWatsonDao credencialWatsonDao;
    
    @Mock
    private ParametroServicoBotDao parametroServicoBotDao;
    
    @Mock
    private AcessosChatDao acessosChatDao;
    
    @Mock
    private SincronizacaoManager sincronizacaoManager;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testObter() {
        //Cenário
        int idNuvem = 1;
        
        NuvemWatson nuvem = umNuvemWatson().build();
        
        //Mock
        when(nuvemWatsonDao.findById(idNuvem)).thenReturn(nuvem);
        
        //Ação
        nuvemWatsonManager.obter(idNuvem);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findById(idNuvem);
    }

    @Test
    public void testSalvar() {
        //Cenário
        
        Classificador classificador = umClassificador().comId(1).build();
        
        List<CredencialWatson> listaCredencial = Arrays.asList(
                umCredencialWatson().comId(1).comNome("Nome1").build(),
                umCredencialWatson().comId(3).comNome("Nome3").build());
        
        NuvemWatson nuvemWatson = umNuvemWatson().comId(0)
                                                .comNome("Nome")
                                                .comClassificador(classificador)
                                                .comStatusNuvem(null)
                                                .comSiglaNuvem("")
                                                .comAssunto("")
                                                .comSelecionado(false)
                                                .comListaListaCredencialParametro(listaCredencial)
                                                .comWorkspaceId("Workspace_id")
                                                .comIdVersao(0)
                                                .comVersaoCorpusResposta(null)
                                                .comIdFormularioAvaliacao(0)
                                                .comSiglaNuvemRedirecionar("")
                                                .comMensagemRedirecionamento("")
                                                .build();
        
        //Sincronizacao s = umSincronizacao().build();
        Sincronizacao s = new Sincronizacao();
        
        //Mock
        sincronizacaoDao.persist(s);
        credencialWatsonDao.preSalvar(listaCredencial.get(0));
        credencialWatsonDao.preSalvar(listaCredencial.get(1));
        when(nuvemWatsonDao.persistAndFlush(nuvemWatson)).thenReturn(nuvemWatson);
        credencialWatsonDao.persistAndFlush(listaCredencial.get(0));
        credencialWatsonDao.persistAndFlush(listaCredencial.get(1));
        
        
        //Ação
        nuvemWatsonManager.salvar(nuvemWatson);
        
        //Verificação
        verify(credencialWatsonDao, times(2)).preSalvar(listaCredencial.get(0));
        verify(nuvemWatsonDao, times(1)).persistAndFlush(nuvemWatson);
        verify(credencialWatsonDao, times(2)).persistAndFlush(listaCredencial.get(0));
    }
    
    /*Não será realizado teste com Power Mock no momento.
     * Linha que necessita do power mock para cobertuda de teste: final UsuarioVO funci = (UsuarioVO) Component.getInstance("funci");) */
    @Ignore
    public void testSalvarComWorkspaceIdModificado() {
        //Cenário
        
        Classificador classificador = umClassificador().comId(1).build();
        
        List<CredencialWatson> listaCredencial = Arrays.asList(
                umCredencialWatson().comId(1).comNome("Nome1").build(),
                umCredencialWatson().comId(2).comNome("Nome1").build(),
                umCredencialWatson().comId(3).comNome("Nome3").build());
        
        NuvemWatson nuvemWatson = umNuvemWatson().comId(0)
                                                 .comNome("Nome")
                                                .comClassificador(classificador)
                                                .comStatusNuvem(null)
                                                .comSiglaNuvem("")
                                                .comAssunto("")
                                                .comSelecionado(false)
                                                .comListaListaCredencialParametro(listaCredencial)
                                                .comWorkspaceId("Workspace_id")
                                                .comIdVersao(0)
                                                .comVersaoCorpusResposta(null)
                                                .comIdFormularioAvaliacao(0)
                                                .comSiglaNuvemRedirecionar("")
                                                .comMensagemRedirecionamento("")
                                                .build();
        
        //Sincronizacao s = umSincronizacao().build();
        Sincronizacao s = new Sincronizacao();
        
        //Mock
        sincronizacaoDao.persist(s);
        credencialWatsonDao.preSalvar(listaCredencial.get(0));
        credencialWatsonDao.preSalvar(listaCredencial.get(1));
        credencialWatsonDao.preSalvar(listaCredencial.get(2));
        when(nuvemWatsonDao.persistAndFlush(nuvemWatson)).thenReturn(nuvemWatson);
        credencialWatsonDao.persistAndFlush(listaCredencial.get(0));
        credencialWatsonDao.persistAndFlush(listaCredencial.get(1));
        credencialWatsonDao.persistAndFlush(listaCredencial.get(2));
        
        
        //Ação
        nuvemWatsonManager.salvar(nuvemWatson);
        
        //Verificação
        verify(credencialWatsonDao, times(2)).preSalvar(listaCredencial.get(0));
        verify(nuvemWatsonDao, times(1)).persistAndFlush(nuvemWatson);
        verify(credencialWatsonDao, times(2)).persistAndFlush(listaCredencial.get(0));
    }
    
    
    @Test
    public void testSalvarSemListaCredencial() {
        //Cenário
        
        NuvemWatson nuvemWatson = umNuvemWatson().comId(0)
                                                 .comNome("Nome")
                                                .comClassificador(null)
                                                .comStatusNuvem(null)
                                                .comSiglaNuvem("")
                                                .comAssunto("")
                                                .comSelecionado(false)
                                                .comListaListaCredencialParametro(null)
                                                .comWorkspaceId("")
                                                .comIdVersao(0)
                                                .comVersaoCorpusResposta(null)
                                                .comIdFormularioAvaliacao(0)
                                                .comSiglaNuvemRedirecionar("")
                                                .comMensagemRedirecionamento("")
                                                .build();
        
        //Mock
        when(nuvemWatsonDao.persistAndFlush(nuvemWatson)).thenReturn(nuvemWatson);
        
        //Ação
        nuvemWatsonManager.salvar(nuvemWatson);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).persistAndFlush(nuvemWatson);
    }

    
    @Test
    public void testRecuperarCredenciais() {
        //Cenário
        Integer idNuvemWatson = 1;
        
        ParametroServicoBot parametro = umParametroWatson().comId(1).build();
        
        List<CredencialWatson> listaCredencial = Arrays.asList(umCredencialWatson().comId(1).comParametroWatson(parametro).build());
        
        List<ParametroServicoBot> parametros = Arrays.asList(umParametroWatson().comId(1).build());
        //Mock
        when(credencialWatsonDao.findByIdNuvemIdParametro(idNuvemWatson, null)).thenReturn(listaCredencial);
        when(parametroServicoBotDao.findAll()).thenReturn(parametros);
        
        //Ação
        nuvemWatsonManager.recuperarCredenciais(idNuvemWatson);
        
        //Verificação
        verify(credencialWatsonDao, times(1)).findByIdNuvemIdParametro(idNuvemWatson, null);
        verify(parametroServicoBotDao, times(1)).findAll();
    }
    
    
    @Test
    public void testRecuperarCredenciaisComIdDiferente() {
        //Cenário
        Integer idNuvemWatson = 1;
        
        ParametroServicoBot parametro = umParametroWatson().comId(1).comNome("Nome do Parâmetro")
                                                                .comCampoObrigatorio(true)
                                                                .comCodigoTipoParametro(ParametroWatsonTipoCampo.TEXTO)                                                             
                                                                //.comNomeAgrupador("Agrupador")
                                                                .comTextoPadrao("Parametro 1")
                                                                .comTextoTratamentoAcesso("PARAMETRO_1")
                                                                .build();
        parametro.getNome();
        parametro.isCampoObrigatorio();
        parametro.getTextoTratamentoAcesso();
        parametro.getCodigoTipoParametro();
       // parametro.getCodigoAgrupador();
        //parametro.getNomeAgrupador();
        
        NuvemWatson nuvem = umNuvemWatson().build();
        
        List<CredencialWatson> listaCredencial = new ArrayList<CredencialWatson>(Arrays.asList(umCredencialWatson().comId(2)
                                                                                   .comNome("Credencial")
                                                                                   .comParametroWatson(parametro)
                                                                                   .comNuvemWatson(nuvem)
                                                                                   .build()));
        
        
        List<ParametroServicoBot> parametros = Arrays.asList(umParametroWatson().comId(3)
                                                                            .comNome("Nome do Parâmetro")
                                                                            .comCampoObrigatorio(true)        
                                                                            //.comNomeAgrupador("Agrupador")
                                                                            .comTextoPadrao("Parametro 2")
                                                                            .comTextoTratamentoAcesso("PARAMETRO_2")
                                                                            .build());
        //Mock
        when(credencialWatsonDao.findByIdNuvemIdParametro(idNuvemWatson, null)).thenReturn(listaCredencial);
        when(parametroServicoBotDao.findAll()).thenReturn(parametros);
        
        //Ação
        nuvemWatsonManager.recuperarCredenciais(idNuvemWatson);
        
        //Verificação
        verify(credencialWatsonDao, times(1)).findByIdNuvemIdParametro(idNuvemWatson, null);
        verify(parametroServicoBotDao, times(1)).findAll();
    }
    
    
    @Test
    public void testRecuperarCredenciaisComListaCredencialNull() {
        //Cenário
        Integer idNuvemWatson = 1;
        
        List<CredencialWatson> listaCredencial = null;
        
        List<ParametroServicoBot> parametros = Arrays.asList(umParametroWatson().comId(1).build());
        //Mock
        when(credencialWatsonDao.findByIdNuvemIdParametro(idNuvemWatson, null)).thenReturn(listaCredencial);
        when(parametroServicoBotDao.findAll()).thenReturn(parametros);
        
        //Ação
        nuvemWatsonManager.recuperarCredenciais(idNuvemWatson);
        
        //Verificação
        verify(credencialWatsonDao, times(1)).findByIdNuvemIdParametro(idNuvemWatson, null);
        verify(parametroServicoBotDao, times(1)).findAll();
    }

    @Test
    public void testFindBySigla() {
      //Cenário
        String sigla = "Sigla";
        
        List<NuvemWatson> retorno = Arrays.asList(umNuvemWatson().build());
        
        //Mock
        when(nuvemWatsonDao.findBySigla(sigla)).thenReturn(retorno);
        
        //Ação
        nuvemWatsonManager.findBySigla(sigla);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findBySigla(sigla);
    }

    @Test
    public void testFindCorpusRoteador() {
      //Cenário
        String sigla = "Sigla";
        
        List<NuvemWatson> retorno = Arrays.asList(umNuvemWatson().build());
        
        //Mock
        when(nuvemWatsonDao.findCorpusRoteador(sigla)).thenReturn(retorno);
        
        //Ação
        nuvemWatsonManager.findCorpusRoteador(sigla);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findCorpusRoteador(sigla);
    }

    @Test
    public void testFindListarCredenciaisWatson() {
        //Cenário
        
        Classificador classificador = umClassificador().comId(42).build();
        List<Object[]> o = new ArrayList<Object[]>();
        NuvemWatson objetoNuvem = umNuvemWatson()
                .comSiglaNuvem("Sigla")
                .comNome("Nome")
                .comIdFormularioAvaliacao(42)
                .comClassificador(classificador)
                .comWorkspaceId("1212")
                .comAssunto("Assunto")
                .comStatusNuvem(StatusNuvem.PUBLICADO)
                .comId(42)
                .comMensagemRedirecionamento("Mensagem de redirecionamento")
                .build();
        
        
        Object[] arrayObj = parseNuvemToArray(objetoNuvem);
        o.add(arrayObj);

        List<AcessosChat> acessosBase = Arrays.asList(umAcessosChat().comSigla("Sigla").build());
        acessosBase.get(0).getId();
        acessosBase.get(0).getClassificador();
        
        //Mock
        when(nuvemWatsonDao.findListarCredenciaisWatson()).thenReturn(o);
        when(acessosChatDao.findByClassificador(objetoNuvem.getClassificador().getId())).thenReturn(acessosBase);
        
        //Ação
        nuvemWatsonManager.findListarCredenciaisWatson();
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findListarCredenciaisWatson();
    }
    
    @Test
    public void testFindListarCredenciaisWatsonSemAcesso() {
        //Cenário
        
        Classificador classificador = umClassificador().comId(42).build();
        List<Object[]> o = new ArrayList<Object[]>();
        NuvemWatson objetoNuvem = umNuvemWatson()
                .comSiglaNuvem("Sigla")
                .comNome("Nome")
                .comIdFormularioAvaliacao(42)
                .comClassificador(classificador)
                .comWorkspaceId("1212")
                .comAssunto("Assunto")
                .comStatusNuvem(StatusNuvem.PUBLICADO)
                .comId(42)
                .comMensagemRedirecionamento("Mensagem de redirecionamento")
                .build();
        
        
        Object[] arrayObj = parseNuvemToArray(objetoNuvem);
        o.add(arrayObj);
        
        List<AcessosChat> acessosBase = null;
        
        //Mock
        when(nuvemWatsonDao.findListarCredenciaisWatson()).thenReturn(o);
        when(acessosChatDao.findByClassificador(objetoNuvem.getClassificador().getId())).thenReturn(acessosBase);
        
        //Ação
        nuvemWatsonManager.findListarCredenciaisWatson();
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findListarCredenciaisWatson();
    }
    
    @Test
    public void testFindListarCredenciaisWatsonComIdClassificador0() {
        //Cenário
        
        Classificador classificador = umClassificador().comId(0).build();
        List<Object[]> o = new ArrayList<Object[]>();
        NuvemWatson objetoNuvem = umNuvemWatson()
                .comSiglaNuvem("Sigla")
                .comNome("Nome")
                .comIdFormularioAvaliacao(42)
                .comClassificador(classificador)
                .comWorkspaceId("1212")
                .comAssunto("Assunto")
                .comStatusNuvem(StatusNuvem.PUBLICADO)
                .comId(42)
                .comMensagemRedirecionamento("Mensagem de redirecionamento")
                .build();
        
        Object[] arrayObj = parseNuvemToArray(objetoNuvem);
        o.add(arrayObj);
        
        
        //Mock
        when(nuvemWatsonDao.findListarCredenciaisWatson()).thenReturn(o);
        
        //Ação
        nuvemWatsonManager.findListarCredenciaisWatson();
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findListarCredenciaisWatson();
    }

    private Object[] parseNuvemToArray(NuvemWatson objetoNuvem) {
        Object[] arrayObj = new Object[10];
        arrayObj[0] = objetoNuvem.getId();
        arrayObj[1] = objetoNuvem.getSiglaNuvem();
        arrayObj[2] = objetoNuvem.getSiglaNuvemRedirecionar();
        arrayObj[3] = objetoNuvem.getNome();
        arrayObj[4] = objetoNuvem.getIdFormularioAvaliacao();
        arrayObj[5] = objetoNuvem.getClassificador().getId();
        arrayObj[6] = objetoNuvem.getAssunto();
        arrayObj[7] = objetoNuvem.getMensagemRedirecionamento();
        arrayObj[8] = objetoNuvem.getStatusNuvem();
        arrayObj[9] = "permisao1";
        return arrayObj;
    }

    @Test
    public void testFindByAssunto() {
        //Cenário
        String assunto = "Assunto";
        
        List<NuvemWatson> retorno = Arrays.asList(umNuvemWatson().build());
        
        //Mock
        when(nuvemWatsonDao.findByAssunto(assunto)).thenReturn(retorno);
        
        //Ação
        nuvemWatsonManager.findByAssunto(assunto);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findByAssunto(assunto);
    }

    @Test
    public void testFindAll() {
        //Cenário
        Paginacao<NuvemWatson> paginacao = new Paginacao<>();
        String nome = "Nome Nuvem";
        String nomeClassificador = "Nome Classificador";
        String sigla = "Sigla";
        String workspaceId = "Workspace_id";
        
        //Mock
        when(nuvemWatsonDao.findAll(paginacao, nome, nomeClassificador, sigla, workspaceId)).thenReturn(paginacao);
        
        //Ação
        nuvemWatsonManager.findAll(paginacao, nome, nomeClassificador, sigla, workspaceId);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findAll(paginacao, nome, nomeClassificador, sigla, workspaceId);
    }

    @Test
    public void testFindByClassificadorStatus() {
        //Cenário
        Integer idClassificador = 1;
        StatusNuvem status = StatusNuvem.RASCUNHO;
        
        NuvemWatson retorno = umNuvemWatson().build();
        
        //Mock
        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, status)).thenReturn(retorno);
        
        //Ação
        nuvemWatsonManager.findByClassificadorStatus(idClassificador, status);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, status);
    }
    
    @Test
    public void testFindByClassificadorStatusLista() {
        //Cenário
        Integer idClassificador = 1;
        StatusNuvem status = StatusNuvem.RASCUNHO;
        
        List<NuvemWatson> retorno = Arrays.asList(umNuvemWatson().build());
        
        //Mock
        when(nuvemWatsonDao.findByClassificadorStatusLista(idClassificador, status)).thenReturn(retorno);
        
        //Ação
        nuvemWatsonManager.findByClassificadorStatusLista(idClassificador, status);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findByClassificadorStatusLista(idClassificador, status);
    }

    @Test
    public void testAtualizarWorkspaceidVersao() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().comId(1).comListaListaCredencialParametro(null).build();

        VersaoCorpus versaoCorpus = umVersaoCorpus().build();
        String workspaceid = "Workspace_id";
        
        List<CredencialWatson> credenciais = Arrays.asList(umCredencialWatson().build());
        credenciais.get(0).getId();
        credenciais.get(0).getNuvemWatson();
        
        //Mock
        when(credencialWatsonDao.findByIdNuvemIdParametro(nuvem.getId(), 3)).thenReturn(credenciais);
        credencialWatsonDao.persist(credenciais.get(0));
        when(nuvemWatsonDao.persistAndFlush(nuvem)).thenReturn(nuvem);
        
        //Ação
        nuvemWatsonManager.atualizarWorkspaceidVersao(nuvem, versaoCorpus, workspaceid);
        
        //Verificação
        verify(credencialWatsonDao, times(1)).findByIdNuvemIdParametro(nuvem.getId(), 3);
        verify(credencialWatsonDao, times(2)).persist(credenciais.get(0));
        verify(nuvemWatsonDao, times(1)).persistAndFlush(nuvem);
    }
    
    @Test
    public void testAtualizarWorkspaceidVersaoComWorkspaceidNull() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().comId(1).comListaListaCredencialParametro(null).build();

        VersaoCorpus versaoCorpus = umVersaoCorpus().build();
        String workspaceid = null;
        
        //Mock
        when(nuvemWatsonDao.persistAndFlush(nuvem)).thenReturn(nuvem);
        
        //Ação
        nuvemWatsonManager.atualizarWorkspaceidVersao(nuvem, versaoCorpus, workspaceid);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).persistAndFlush(nuvem);
    }
    
    @Test
    public void testListarPorClassificadorToVO() {
        // Cenário
        Integer idClassificador = 1;
        NuvemWatson nuvem = umNuvemWatson().comId(1).comListaListaCredencialParametro(null).build();
        ServicoBot servicoBot = new ServicoBot();
        servicoBot.setId(1);
        servicoBot.setNome("Nome do serviço");
        nuvem.setServicoBot(servicoBot);

        // Mock
        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(Arrays.asList(nuvem));

        // Acao
        List<NuvemWatsonVO> nuvens = nuvemWatsonManager.listarPorClassificadorToVO(idClassificador);
        
        // Test
        assertEquals(1, nuvens.size());
    }
    
    @Test
    public void testObterSimplificadoPorSigla() {
        // Cenario
        String sigla = "teste";
        Integer id = 1;
        Object[] nuvem = new Object[] { 1, sigla, 1, true, true, false, true, 24, false, "ATIVO", true, true };
        Object[] cred = new Object[] { "chave", "valor" };
        List<Object[]> creds = new ArrayList<>();
        creds.add(cred);

        // Mock
        when(nuvemWatsonDao.obterSimplificadoPorSigla(sigla)).thenReturn(nuvem);
        when(credencialWatsonDao.buscarCredenciaisSimplificado(id)).thenReturn(creds);
        
        // Acao
        JSONObject json = nuvemWatsonManager.obterSimplificadoPorSigla(sigla);

        // Test
        assertEquals(sigla, json.get("nome"));
                
    }
    
    @Test
    public void testObterSimplificadoPorSiglaNulo() {
        // Cenario
        String sigla = "teste";
        Integer id = 1;

        // Mock
        when(nuvemWatsonDao.obterSimplificadoPorSigla(sigla)).thenReturn(null);
        
        // Acao
        JSONObject json = nuvemWatsonManager.obterSimplificadoPorSigla(sigla);

        // Test
        assertEquals(null, json);
                
    }

}
