package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ParametroServicoBotBuilder.umParametroWatson;
import static br.com.bb.databuilder.ServicoBotBuilder.umServicoBotV1;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.ParametroServicoBotDao;
import br.com.bb.gearq.c4coleta.dao.ServicoBotDao;
import br.com.bb.gearq.c4coleta.model.ParametroServicoBot;
import br.com.bb.gearq.c4coleta.model.ServicoBot;
import br.com.bb.gearq.c4coleta.vo.Paginacao;



public class ServicoBotManagerTest {
    
    

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @InjectMocks
    private ServicoBotManager servicoBotManager;
    
    
    @Mock
    private ServicoBotDao servicoBotDao;
    
    @Mock
    private ParametroServicoBotDao parametroServicoBotDao;
    
    
    
    @Test
    public void testFindAll() {
        
        //Cenário
        Paginacao<ServicoBot> paginacao = new Paginacao<>();
        String nome = "Nome Nuvem";
        
        //Mock
        when(servicoBotDao.findAll(paginacao, nome)).thenReturn(paginacao);
        
        //Ação
        servicoBotManager.findAll(paginacao, nome);
        
        //Verificação
    }

    @Test
    public void testFindAllComCampos() {
      //Cenário
        Paginacao<ServicoBot> paginacao = new Paginacao<>();
        String nome = "Nome Nuvem";
        
        //Mock
        when(servicoBotDao.findComCampos(paginacao, nome)).thenReturn(paginacao);
        
        //Ação
        servicoBotManager.findAllComCampos(paginacao, nome);
        
        //Verificação
    }

    @Test
    public void testObterPorNome() {
        //Cenário
        String nome = "rasa";
        
        //Mock
        
        //Ação
        servicoBotManager.obterPorNome(nome);
        
        //Verificação
    }

    @Test
    public void testSalvarServico() {
      //Cenário
        List<ParametroServicoBot> parametros = Arrays.asList(umParametroWatson().comId(1).comNome("url").build());
        
        ServicoBot servico = umServicoBotV1().comId(1).comListaParametrosFilhos(parametros).build(); 
        //Mock
        
        //Ação
        //servicoBotManager.salvar(servico);
        
        //Verificação
    }
    
    @Test
    public void testSalvarServicoComIdNull() {
      //Cenário
        Integer idServ = null;
        ServicoBot servicoIdNull = umServicoBotV1().comNome("teste").comId(idServ).build();
        
        //Mock
        
        //Acao
        //servicoBotManager.salvar(servicoIdNull);
        
        //Verificação
    }
    
    @Test
    public void testSalvarServicoComParametroFilhoNull() {
      //Cenário
        ServicoBot servico1 = umServicoBotV1().comId(1).build(); 
        
        //Mock
        
        //Acao
        //servicoBotManager.salvar(servico1);
        
        //Verificação
    }
    
    @Test
    public void testSalvarServicoComParametroFilhoEmpty() {
      //Cenário
        List<ParametroServicoBot> ps = new ArrayList<>();
        ServicoBot servico1 = umServicoBotV1().comId(1).comListaParametrosFilhos(ps).build(); 
        
        //Mock
        
        //Acao
        //servicoBotManager.salvar(servico1);
        
        //Verificação
    }

    @Test
    public void testSalvarEditarParametros() {
      //Cenário
        String nome = "Nome Nuvem";
        
        //Mock
        
        //Ação
        servicoBotDao.findByName(nome);
        
        //Verificação
    }

    @Test
    public void testBuscarRemoverServico() {
      //Cenário
        List<ParametroServicoBot> parametros = Arrays.asList(umParametroWatson().comId(1).comNome("url").build());
        
        ServicoBot servico1 = umServicoBotV1().comId(1).comListaParametrosFilhos(parametros).build(); 
        //Mock
        
        //Ação
        servicoBotManager.buscarRemoverServico(servico1);
        //Verificação
    }
    
    @Test
    public void testBuscarRemoverServicoComServicoNull() {
      //Cenário
        ServicoBot servicoNull = null;
        
        //Mock
        
        //Acao
        servicoBotManager.buscarRemoverServico(servicoNull);
        //Verificação
    }
    
    @Test
    public void testBuscarRemoverServicoComServicoIdNull() {
      //Cenário
        Integer idServ = null;
        ServicoBot servicoIdNull = umServicoBotV1().comNome("teste").comId(idServ).build();
        
        //Mock
        
        //Acao
        servicoBotManager.buscarRemoverServico(servicoIdNull);
        //Verificação
    }
    
    @Test
    public void testBuscarRemoverServicoComParametroFilhoNull() {
      //Cenário
        ServicoBot servico1 = umServicoBotV1().comId(1).build(); 
        
        //Mock
        
        //Acao
        servicoBotManager.buscarRemoverServico(servico1);
        
        //Verificação
    }
    
    @Test
    public void testBuscarRemoverServicoComParametroFilhoEmpty() {
      //Cenário
        List<ParametroServicoBot> ps = new ArrayList<>();
        ServicoBot servico1 = umServicoBotV1().comId(1).comListaParametrosFilhos(ps).build(); 
        
        //Mock
        
        //Acao
        servicoBotManager.buscarRemoverServico(servico1);
        
        //Verificação
    }

    @Test
    public void testRemoverParametroComSucesso() {
      //Cenário
        int idParametro = 1;
        ParametroServicoBot p = new ParametroServicoBot();
        p.setTextoPadrao("teste padrao");
        
        //Mock
        when(parametroServicoBotDao.findById(idParametro)).thenReturn(p);
        
        //Ação
        servicoBotManager.buscarRemoverParametro(idParametro);
        
        //Verificação
        
    }
    
    @Test
    public void testRemoverParametroComIdParametroZero() {
      //Cenário
        int idParametro = 0;
        
        //Mock
        
        //Ação
        servicoBotManager.buscarRemoverParametro(idParametro);
        
        //Verificação
        
    }

    @Test
    public void testBuscarServicoBot() {
      //Cenário
        String nome = "Nome Nuvem";
        
        //Mock
        
        //Ação
        servicoBotDao.findByName(nome);
        
        //Verificação
    }

}
