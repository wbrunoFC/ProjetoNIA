package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.DashboardBuilder.umDashboard;
import static br.com.bb.databuilder.IntecoesMaisSugeridasBuilder.umIntecoesMaisSugeridas;
import static br.com.bb.databuilder.UsuarioBuilder.umUsuario;
import static br.com.bb.databuilder.UsuarioDashboardBuilder.umUsuarioDashboard;
import static br.com.bb.databuilder.UsuarioDashboardVOBuilder.umUsuarioDashboardVO;
import static br.com.bb.databuilder.UsuariosAtivosBuilder.umUsuariosAtivos;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import br.com.bb.gearq.c4coleta.audit.dto.IntecoesMaisSugeridas;
import br.com.bb.gearq.c4coleta.audit.dto.UsuarioDashboardVO;
import br.com.bb.gearq.c4coleta.audit.dto.UsuariosAtivos;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DashboardGeralDao;
import br.com.bb.gearq.c4coleta.dao.IdentificadorIntencaoDashboardDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.SecaoConversaBotDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDashboardDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Dashboard;
import br.com.bb.gearq.c4coleta.model.IdentificadorIntencaoDashboard;
import br.com.bb.gearq.c4coleta.model.Usuario;
import br.com.bb.gearq.c4coleta.model.UsuarioDashboard;

public class ProcessarDashboardManagerTest {
    @InjectMocks
    private ProcessarDashboardManager processarDashboardManager;

    @Mock
    private DashboardGeralDao dashboardGeralDao;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private PerguntaRevisaoDao perguntaRevisaoDao;
    
    @Mock
    private IntencaoDao intencaoDao;
    
    @Mock
    private PerguntaDao perguntaDao;
    
    @Mock
    private UsuarioDao usuarioDao;
  
    @Mock
    private SecaoConversaBotDao secaoConversaBotDao;
    
    @Mock
    private UsuarioDashboardDao usuarioDashboardDao;
    
    @Mock
    private IdentificadorIntencaoDashboardDao identificadorIntencaoDashboardDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testProcessarDashboardComJobLivreVerdadeiro() {
        //Cenário
        Integer idClassificador = 1;
        Date dataDia = new Date();
        
        boolean jobLivre = true;
        Integer job_diario = 0;
        
        Usuario usuario = umUsuario().build();
        
        List<Classificador> listaClass = Arrays.asList(
                umClassificador().comId(1)
                .comAtivo(false)
                .comDataCriacao(new Date())
                .comDataFinalizacao(new Date())
                .comDataVerificacao(new Date())
                .comDescricao("Descição")
                .comLinguagem("Linguagem")
                .comNome("Classificador 1")
                .comFeedbackColeta(false)
                .comReducaoCuradoria(false)
                .comPorcentagemCuradoria(0)
                .comPorcentagemIntencao(0)
                .comRespostaNia(false)
                .comNomeTipoServicoInfra("")
                .comUsuario(usuario)
                .comStatusClassificador(null)
                .comTipoCorpus(null)
                .comServicoNlc(null)
                .comSituacao("Situação")
                .comPossuiStatusColeta(false)
                .comPossuiStatusCuradoria(false)
                .comPossuiStatusTerminado(false)
                .comPossuiStatusColetaCuradoria(false)
                .comIndDialogo(false)
                .comBoasVindas("Olá")
                .comNaoAtendida("Desculpe")
                .comTaxaConfianca(0)
                .comRespostaConfianca("RespostaConfianca")
                .comRespostaCancelarTransferencia("RespostaCancelarTransferencia")
                .comCondicaoCancelarTransferencia("CondicaoCancelarTransferencia")
                .comTipoCuradoriaSentimento(0)
                .build());
        
        Classificador c = listaClass.get(0);
        
        BigInteger qtPerguntasCuradasCurador = new BigInteger("1");
        BigInteger qtdPerguntasCuradasExcluida = new BigInteger("1");
        BigInteger qtPerguntasCuradasRegua = new BigInteger("1");
        BigInteger qtTotalPerguntasEnvGestor = new BigInteger("1");
        Long qtTotalIntencoes = 1L;
        Float mediaGrauConhecimento = 1F;
        BigInteger qtTotalSecao = new BigInteger("1");
        
        Dashboard dashboard = umDashboard().comIdClassificador(1)
                .comQtPerguntasCuradasCurador(qtPerguntasCuradasCurador.intValue())
                .comQtdPerguntasCuradasExcluida(qtdPerguntasCuradasExcluida.intValue())
                .comQtPerguntasCuradasRegua(qtPerguntasCuradasRegua.intValue())
                .comQtPerguntasNaocuradas(1)
                .comQtTotalPerguntasEnvGestor(qtTotalPerguntasEnvGestor.intValue())
                .comQtTotalIntencoes(qtTotalIntencoes.intValue())
                .comQtPerguntasCorpoValidada(1)
                .comQtPerguntasCorpoNaoValidada(1)
                .comDataConsulta(new Date())
                .comMediaGrauConhecimento(mediaGrauConhecimento)
                .comQtTotalSecao(qtTotalSecao.intValue())
                .build();
        
        //Mock
        when(dashboardGeralDao.isJobLivre("JOB_DIARIO")).thenReturn(jobLivre);
        when(dashboardGeralDao.registrarExecucaoJob("JOB_DIARIO")).thenReturn(job_diario);
        when(perguntaRevisaoDao.totalPerguntasCuradasPorIntervaloData(c.getId(), dataDia,dataDia)).thenReturn(qtPerguntasCuradasCurador);
        when(perguntaRevisaoDao.totalPerguntasCuradasPorExcluida(c.getId(), dataDia,dataDia)).thenReturn(qtdPerguntasCuradasExcluida);
        when(perguntaRevisaoDao.totalPerguntasCuradasReguaPorIntervaloData(c.getId(), dataDia,dataDia)).thenReturn(qtPerguntasCuradasRegua);
        when(perguntaRevisaoDao.findAllQuantidadePerguntasNaoCuradasIntervaloData(c.getId(), dataDia,dataDia)).thenReturn(dashboard.getQtPerguntasNaocuradas());
        when(perguntaRevisaoDao.perguntasEnviadasGestor(c.getId(), dataDia, dataDia)).thenReturn(qtTotalPerguntasEnvGestor);
        when(intencaoDao.findByQuantidadeIntencaoByClassificador(c.getId())).thenReturn(qtTotalIntencoes);
        when(perguntaDao.qtdPerguntasCorpus(c.getId(), true)).thenReturn(dashboard.getQtPerguntasCorpoValidada());
        when(perguntaDao.qtdPerguntasCorpus(c.getId(), false)).thenReturn(dashboard.getQtPerguntasCorpoNaoValidada());
        when(perguntaRevisaoDao.grauMedioCorpoDiario(c.getId(), dataDia,dataDia)).thenReturn(mediaGrauConhecimento);
        when(secaoConversaBotDao.totalSecoesPorIntervaloData(c.getId(), dataDia, dataDia)).thenReturn(qtTotalSecao);
        when(dashboardGeralDao.persist(Mockito.any(Dashboard.class))).thenReturn(dashboard);
        
        /*processarUsuDashboard*/
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
        String d = fmt.format(dashboard.getDataConsulta());
        UsuarioDashboardVO usuAti = umUsuarioDashboardVO().build();
        UsuariosAtivos usuariosAtivos = umUsuariosAtivos().comListaUsuariosColetores(usuAti).comListaUsuariosCuradores(usuAti).build();
        when(usuarioDao.findAllUsuariosAtivosDashboard(dashboard.getIdClassificador(),d)).thenReturn(usuariosAtivos);
        UsuarioDashboard usu = umUsuarioDashboard().build();
        usu.getId();
        usu.getDashboard();
        usu.getChaveUsuario();
        usu.getTipoUsuario();
        usu.getSerialversionuid();
        usu.getNomeUsuario();
        usu.getQtAcionamentos();
        usu.getQtCuradas();
        usu.getQtDesconsideradas();
        
        
        usuarioDashboardDao.persist(usu);

        //Ação
        processarDashboardManager.processarDashboard(idClassificador, dataDia);
        
        //Verificação
        verify(dashboardGeralDao, times(1)).isJobLivre("JOB_DIARIO");
        verify(dashboardGeralDao, times(1)).registrarExecucaoJob("JOB_DIARIO");
        verify(perguntaRevisaoDao, times(1)).totalPerguntasCuradasPorIntervaloData(c.getId(), dataDia,dataDia);
        verify(perguntaRevisaoDao, times(1)).totalPerguntasCuradasPorExcluida(c.getId(), dataDia,dataDia);
        verify(perguntaRevisaoDao, times(1)).totalPerguntasCuradasReguaPorIntervaloData(c.getId(), dataDia,dataDia);
        verify(perguntaRevisaoDao, times(1)).findAllQuantidadePerguntasNaoCuradasIntervaloData(c.getId(), dataDia,dataDia);
        verify(perguntaRevisaoDao, times(1)).perguntasEnviadasGestor(c.getId(), dataDia, dataDia);
        verify(intencaoDao, times(1)).findByQuantidadeIntencaoByClassificador(c.getId());
        verify(perguntaDao, times(1)).qtdPerguntasCorpus(c.getId(), true);
        verify(perguntaDao, times(1)).qtdPerguntasCorpus(c.getId(), false);
        verify(perguntaRevisaoDao, times(1)).grauMedioCorpoDiario(c.getId(), dataDia,dataDia);
        verify(secaoConversaBotDao, times(1)).totalSecoesPorIntervaloData(c.getId(), dataDia, dataDia);
        verify(dashboardGeralDao, times(1)).persist(Mockito.any(Dashboard.class));
        
    }
    
    @Test
    public void testProcessarDashboardComJobLivreVerdadeiroEClassificadorNulo() {
        //Cenário
        Integer idClassificador = null;
        Date dataDia = new Date();
        
        boolean jobLivre = true;
        Integer job_diario = 0;
        
        List<Classificador> listaClass = Arrays.asList(umClassificador().build());
        
        //Mock
        when(dashboardGeralDao.isJobLivre("JOB_DIARIO")).thenReturn(jobLivre);
        when(dashboardGeralDao.registrarExecucaoJob("JOB_DIARIO")).thenReturn(job_diario);
        when(classificadorDao.findAll()).thenReturn(listaClass);
        
        //Ação
        processarDashboardManager.processarDashboard(idClassificador, dataDia);
        
        //Verificação
        
    }
    
    @Test
    public void testProcessarDashboardComJobLivreFalso() {
        //Cenário
        Integer idClassificador = 1;
        Date dataDia = new Date();
        
        boolean jobLivre = false;
        
        //Mock
        when(dashboardGeralDao.isJobLivre("JOB_DIARIO")).thenReturn(jobLivre);
        
        //Ação
        processarDashboardManager.processarDashboard(idClassificador, dataDia);
        
        //Verificação
        verify(dashboardGeralDao, times(1)).isJobLivre("JOB_DIARIO");
        assertFalse(jobLivre);
        
    }

    @Test
    public void testProcessarItnDashboard() {
        //Cenário
        Dashboard dashboard = umDashboard().comIdClassificador(1)
                .comQtPerguntasCuradasCurador(1)
                .comQtdPerguntasCuradasExcluida(1)
                .comQtPerguntasCuradasRegua(1)
                .comQtPerguntasNaocuradas(1)
                .comQtTotalPerguntasEnvGestor(1)
                .comQtTotalIntencoes(1)
                .comQtPerguntasCorpoValidada(1)
                .comQtPerguntasCorpoNaoValidada(1)
                .comDataConsulta(new Date())
                .comMediaGrauConhecimento(1F)
                .comQtTotalSecao(1)
                .build();
        
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");    
        String d = fmt.format(dashboard.getDataConsulta());
        List<IntecoesMaisSugeridas> intencoesSugeridas = Arrays.asList(
                umIntecoesMaisSugeridas().comIntencao(1).comNegativo(1).comNome("Nome").comPosistivo(2).comQuantidade(3).build()
                );
        
        IdentificadorIntencaoDashboard itn = new IdentificadorIntencaoDashboard();
        itn.getDashboard();
        itn.getIdentificadorIntencao();
        itn.getQtTotalAcionamentos();
        itn.getSerialversionuid();
        itn.getId();
        itn.setId(2);
        itn.getNomeIntencao();
        
        //Mock
        when(perguntaRevisaoDao.findIntecoesMaisSugeridasPeriodoData(d, d, dashboard.getIdClassificador())).thenReturn(intencoesSugeridas);
        identificadorIntencaoDashboardDao.persist(itn);
        
        //Ação
        processarDashboardManager.processarItnDashboard(dashboard);
        
        //Verificação
        verify(perguntaRevisaoDao, times(1)).findIntecoesMaisSugeridasPeriodoData(d, d, dashboard.getIdClassificador());
        verify(identificadorIntencaoDashboardDao, times(1)).persist(itn);
    }
    
    @Test
    public void testProcessarItnDashboardComDadosdeIntencoesSugeridasNulo() {
        //Cenário
        Dashboard dashboard = umDashboard().comIdClassificador(1)
                .comQtPerguntasCuradasCurador(1)
                .comQtdPerguntasCuradasExcluida(1)
                .comQtPerguntasCuradasRegua(1)
                .comQtPerguntasNaocuradas(1)
                .comQtTotalPerguntasEnvGestor(1)
                .comQtTotalIntencoes(1)
                .comQtPerguntasCorpoValidada(1)
                .comQtPerguntasCorpoNaoValidada(1)
                .comDataConsulta(new Date())
                .comMediaGrauConhecimento(1F)
                .comQtTotalSecao(1)
                .build();
        
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");    
        String d = fmt.format(dashboard.getDataConsulta());
        List<IntecoesMaisSugeridas> intencoesSugeridas = Arrays.asList(
                umIntecoesMaisSugeridas().comIntencao(null).comNegativo(null).comNome("Nome").comPosistivo(null).comQuantidade(null).build()
                );
        
        IdentificadorIntencaoDashboard itn = new IdentificadorIntencaoDashboard();
        
        //Mock
        when(perguntaRevisaoDao.findIntecoesMaisSugeridasPeriodoData(d, d, dashboard.getIdClassificador())).thenReturn(intencoesSugeridas);
        identificadorIntencaoDashboardDao.persist(itn);
        
        //Ação
        processarDashboardManager.processarItnDashboard(dashboard);
        
        //Verificação
        verify(perguntaRevisaoDao, times(1)).findIntecoesMaisSugeridasPeriodoData(d, d, dashboard.getIdClassificador());
        verify(identificadorIntencaoDashboardDao, times(1)).persist(itn);
    }

    
}
