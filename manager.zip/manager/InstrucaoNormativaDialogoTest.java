package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.InstrucaoNormativaDialogoBuilder.umInstrucaoNormativaDialogo;
import static br.com.bb.databuilder.InstrucaoNormativaVOBuilder.umInstrucaoNormativaVO;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDialogoDao;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativaDialogo;
import br.com.bb.gearq.c4coleta.vo.InstrucaoNormativaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class InstrucaoNormativaDialogoTest {
    /**
     * @author c1312334 (Wallison Bruno)
     * @date 20/12/19
     */

    @InjectMocks
    private InstrucaoNormativaDialogoManager instrucaoNormativaDialogoManager;

    @Mock
    private InstrucaoNormativaDialogoDao instrucaoNormativaDialogoDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testObter() {
        // Cenario
        Integer id = 10;
        InstrucaoNormativaDialogo instrucaoNormativaDialogo = umInstrucaoNormativaDialogo().comId(id).build();

        // Mock
        when(instrucaoNormativaDialogoDao.findById(id)).thenReturn(instrucaoNormativaDialogo);

        // Ação
        instrucaoNormativaDialogoManager.obter(id);

        // Verificação
        verify(instrucaoNormativaDialogoDao, times(1)).findById(id);

    }

    @Test
    public void testSalvar() {
        // Cenario
        InstrucaoNormativaDialogo instrucaoNormativaDialogo = new InstrucaoNormativaDialogo();

        // Mock
        when(instrucaoNormativaDialogoDao.persist(instrucaoNormativaDialogo)).thenReturn(instrucaoNormativaDialogo);

        // Ação
        instrucaoNormativaDialogoManager.salvar(instrucaoNormativaDialogo);

        // Verificação
        verify(instrucaoNormativaDialogoDao).persist(instrucaoNormativaDialogo);

    }

    @Test
    public void testExcluir() {
        // Cenario
        Integer id = 2;
        InstrucaoNormativaDialogo instrucaoNormativaDialogo = umInstrucaoNormativaDialogo().comId(id).build();

        // Mock

        // Ação
        instrucaoNormativaDialogoManager.excluir(instrucaoNormativaDialogo);
        instrucaoNormativaDialogoManager.excluir(id);

        // verificação
        verify(instrucaoNormativaDialogoDao).remove(instrucaoNormativaDialogo);

    }

    @Test
    public void testCriarIN() {
        // Cenario

        InstrucaoNormativaVO instrucaoNormativaVO = umInstrucaoNormativaVO()
                                                    .comId(2)
                                                    .comIdCxDialogo(10)
                                                    .comNumeroIN("Numero")
                                                    .comVrsAuxiliar(20)
                                                    .comVrsNormativa(30)
                                                    .comVrsProcedimento(40)
                                                    .comStatus("Status")
                                                    .comEditarCampo(true)
                                                    .build();
                    
        InstrucaoNormativaDialogo instrucaoNormativaDialogo = umInstrucaoNormativaDialogo()
                                                    .comId(instrucaoNormativaVO.getId())
                                                    .comIdCxDialogo(instrucaoNormativaVO.getIdCxDialogo())
                                                    .comNumeroIN(instrucaoNormativaVO.getNumeroIN())
                                                    .comVrsAuxiliar(instrucaoNormativaVO.getVrsAuxiliar())
                                                    .comVrsNormativa(instrucaoNormativaVO.getVrsNormativa())
                                                    .comVrsProcedimento(instrucaoNormativaVO.getVrsProcedimento())
                                                    .comStatus(instrucaoNormativaVO.getStatus())
                                                    .comEditarCampo(instrucaoNormativaVO.isEditarCampo())
                                                    .build();
        
        Dialogo dialogo = new Dialogo();
        instrucaoNormativaDialogo.setDialogo(dialogo);
        instrucaoNormativaDialogo.getNomeDialogo();

        // Ação
        instrucaoNormativaDialogoManager.criarIN(instrucaoNormativaVO);

        // Verificação
        Assert.assertNotNull(instrucaoNormativaVO);
    }
    
    @Test
    public void testCriarIN_ComDialogoNull() {
        // Cenario

        InstrucaoNormativaVO instrucaoNormativaVO = umInstrucaoNormativaVO()
                                                    .comId(2)
                                                    .comIdCxDialogo(10)
                                                    .comNumeroIN("Numero")
                                                    .comVrsAuxiliar(20)
                                                    .comVrsNormativa(30)
                                                    .comVrsProcedimento(40)
                                                    .comStatus("Status")
                                                    .comEditarCampo(true)
                                                    .build();
                    
        InstrucaoNormativaDialogo instrucaoNormativaDialogo = umInstrucaoNormativaDialogo()
                                                    .comId(instrucaoNormativaVO.getId())
                                                    .comIdCxDialogo(instrucaoNormativaVO.getIdCxDialogo())
                                                    .comNumeroIN(instrucaoNormativaVO.getNumeroIN())
                                                    .comVrsAuxiliar(instrucaoNormativaVO.getVrsAuxiliar())
                                                    .comVrsNormativa(instrucaoNormativaVO.getVrsNormativa())
                                                    .comVrsProcedimento(instrucaoNormativaVO.getVrsProcedimento())
                                                    .comStatus(instrucaoNormativaVO.getStatus())
                                                    .comEditarCampo(instrucaoNormativaVO.isEditarCampo())
                                                    .build();
        instrucaoNormativaDialogo.getDialogo();
        
        Dialogo dialogo = null;
        instrucaoNormativaDialogo.setDialogo(dialogo);

        // Ação
        instrucaoNormativaDialogoManager.criarIN(instrucaoNormativaVO);

        // Verificação
        Assert.assertNotNull(instrucaoNormativaVO);
    }

    @Test
    public void testCriarINVO() {
        // Cenario
        InstrucaoNormativaDialogo instrucaoNormativaDialogo = 
                                    umInstrucaoNormativaDialogo()
                                    .comId(2)
                                    .comIdCxDialogo(10)
                                    .comNumeroIN("Numero")
                                    .comVrsAuxiliar(20)
                                    .comVrsNormativa(30)
                                    .comVrsProcedimento(40)
                                    .comStatus("Status")
                                    .comEditarCampo(true)
                                    .build
                                     ();

        InstrucaoNormativaVO instrucaoNormativaVO = umInstrucaoNormativaVO()
                                    .comId(instrucaoNormativaDialogo.getId())
                                    .comIdIntencao(0)
                                    .comIdCxDialogo(instrucaoNormativaDialogo.getIdCxDialogo())
                                    .comIntencao(null)
                                    .comNumeroIN(instrucaoNormativaDialogo.getNumeroIN())
                                    .comVrsAuxiliar(instrucaoNormativaDialogo.getVrsAuxiliar())
                                    .comVrsNormativa(instrucaoNormativaDialogo.getVrsNormativa())
                                    .comVrsProcedimento(instrucaoNormativaDialogo.getVrsProcedimento())
                                    .comStatus(instrucaoNormativaDialogo.getStatus())
                                    .comEditarCampo(instrucaoNormativaDialogo.isEditarCampo())
                                    .comInIntencao(false)
                                    .build();

        // Ação
        InstrucaoNormativaVO criarINVO = instrucaoNormativaDialogoManager.criarINVO(instrucaoNormativaDialogo);

        // Verificação
        Assert.assertNotNull(criarINVO);

    }
    
    @Test
    public void testListarPorClassificador() {
        // Cenario
        int idClassificador = 10;
        String filtroNomeDialogo = "Nome";

        Paginacao<InstrucaoNormativaDialogo> listpeginacao = new Paginacao<>();
                                            listpeginacao.setListaPaginada(Arrays.asList(
                                                          umInstrucaoNormativaDialogo()
                                                          .comId(idClassificador)
                                                          .comNomeDialogo(filtroNomeDialogo)
                                                          .build()
                                                          ));
                                            
        // Mock
        when(instrucaoNormativaDialogoDao.findByClassificadorNativo(idClassificador, filtroNomeDialogo, listpeginacao))
                                                                    .thenReturn(
                                                                     listpeginacao
                                                                     );
        
        // Ação
        instrucaoNormativaDialogoManager.listarPorClassificador(idClassificador, filtroNomeDialogo, listpeginacao);

        // Verificação
        verify(instrucaoNormativaDialogoDao, times(1)).findByClassificadorNativo(
                                           idClassificador, 
                                           filtroNomeDialogo, 
                                           listpeginacao
                                           );
    }
}
