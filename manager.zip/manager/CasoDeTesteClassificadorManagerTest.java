//package br.com.bb.gearq.c4coleta.manager;
//import static br.com.bb.databuilder.CasoDeTesteClassificadorBuilder.umCasoDeTesteClassificador;
//import static br.com.bb.databuilder.SecaoCasoDeTesteBuilder.umSecaoCasoDeTeste;
//import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
//import static br.com.bb.databuilder.VersaoCorpusBuilder.umVersaoCorpus;
//import static br.com.bb.databuilder.CenarioEsperadoBuilder.umCenarioEsperado;
//import static br.com.bb.databuilder.TipoElementoBuilder.umTipoElemento;
//import static br.com.bb.databuilder.TipoCondicaoBuilder.umTipoCondicao;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import org.bouncycastle.asn1.pkcs.CertificationRequestInfo;
//import org.drools.lang.DRLParser.when_part_return;
//import org.json.JSONObject;
//import org.junit.Before;
//import org.junit.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//
//import br.com.bb.gearq.c4coleta.dao.CasoDeTesteClassificadorDao;
//import br.com.bb.gearq.c4coleta.dao.CenarioEsperadoDao;
//import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
//import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
//import br.com.bb.gearq.c4coleta.dao.SecaoCasoDeTesteDao;
//import br.com.bb.gearq.c4coleta.model.CasoDeTesteClassificador;
//import br.com.bb.gearq.c4coleta.model.CenarioEsperado;
//import br.com.bb.gearq.c4coleta.model.NuvemWatson;
//import br.com.bb.gearq.c4coleta.model.SecaoCasoDeTeste;
//import br.com.bb.gearq.c4coleta.model.StatusNuvem;
//import br.com.bb.gearq.c4coleta.model.TipoCondicao;
//import br.com.bb.gearq.c4coleta.model.TipoElemento;
//import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
//import br.com.bb.gearq.c4coleta.vo.Paginacao;
//import buildermaster.BuilderMaster;
//
//public class CasoDeTesteClassificadorManagerTest {
//    /**
//     * @author c1312334
//     */
//    
//    @InjectMocks
//    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;
//    
//    @Mock
//    private CasoDeTesteClassificadorDao casoDeTesteClassificadorDao;
//    
//    @Mock
//    private CenarioEsperadoDao cenarioEsperadoDao;
//    
//    @Mock
//    private ClassificadorDao classificadorDao;
//    
//    @Mock
//    private NuvemWatsonDao nuvemWatsonDao;
//    
//    @Mock
//    private SecaoCasoDeTesteDao secaoCasoDeTesteDao;
//    
//    @Mock
//    private SecaoCasoDeTesteManager secaoCasoDeTesteManager;
//    
//    @Mock
//    private CenarioEsperado cenarioEsperado;
//    
//    @Mock
//    private VersaoCorpusManager versaoCorpusManager;
//    
//    @Before
//    public void setUp() {
//        MockitoAnnotations.initMocks(this);
//      }
//
//    @Test
//    public void testObter() {
//        // Cenario
//        Integer idCasoDeTeste = 10;
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador().comId(idCasoDeTeste).build();
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(idCasoDeTeste)).thenReturn(caso);
//        
//        
//        // Açao
//        casoDeTesteClassificadorManager.obter(idCasoDeTeste);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findById(idCasoDeTeste);
//    }
//
//    @Test
//    public void testSalvarIntCasoDeTesteClassificador() {
//        // Cenario
//        int idClassificador = 100;
//        
//        List<SecaoCasoDeTeste> secao2 = Arrays.asList(umSecaoCasoDeTeste().comId(10).build());
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador().comId(10).comListaSecoes(secao2).build();
//        SecaoCasoDeTeste secao = umSecaoCasoDeTeste().comId(10).build();
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.persist(caso)).thenReturn(caso);// Mock do metodo salvar
//        secaoCasoDeTesteDao.persist(secao);        
//        secaoCasoDeTesteManager.salvar(Mockito.any(SecaoCasoDeTeste.class));
//        
//        // Açao
//        casoDeTesteClassificadorManager.salvar(idClassificador, caso);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao,times(1)).persist(caso);
//        verify(secaoCasoDeTesteDao).persist(secao);
//        verify(secaoCasoDeTesteManager).salvar(Mockito.any(SecaoCasoDeTeste.class));
//    }
//        
//    @Test
//    public void testSalvarCasoDeTesteClassificador() {
//        // Cenario
//        List<SecaoCasoDeTeste> secao = Arrays.asList(umSecaoCasoDeTeste().comId(10).build());
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador().comListaSecoes(secao).comId(2).build();
//        SecaoCasoDeTeste secao1 = umSecaoCasoDeTeste().comId(10).build();
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.persist(caso)).thenReturn(caso);
//        secaoCasoDeTesteDao.persist(secao1);
//        
//        // Açao
//        casoDeTesteClassificadorManager.salvar(caso);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).persist(caso);
//        verify(secaoCasoDeTesteDao).persist(secao1);
//    }
//
//    @Test
//    public void testExcluirCasoDeTesteClassificador() {
//        // Cenario
//        Integer idCaso = new Integer(2);
//        
//        List<SecaoCasoDeTeste> secao = Arrays.asList(umSecaoCasoDeTeste().comId(12).build());
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador().comId(idCaso).comListaSecoes(secao).build();
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(idCaso)).thenReturn(caso);
//        casoDeTesteClassificadorDao.remove(caso);
//        secaoCasoDeTesteManager.excluir(Mockito.any(SecaoCasoDeTeste.class));
//        
//        // Açao
//        casoDeTesteClassificadorManager.excluir(caso);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findById(idCaso);
//        verify(casoDeTesteClassificadorDao, times(2)).remove(caso);
//        verify(secaoCasoDeTesteManager).excluir(Mockito.any(SecaoCasoDeTeste.class));
//    }
//
//    @Test
//    public void testExcluirInteger() {
//        // Cenario
//        Integer idCaso = new Integer(2);
//        
//        List<SecaoCasoDeTeste> secao = Arrays.asList(umSecaoCasoDeTeste().comId(10).build());
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador().comId(10).comListaSecoes(secao).build();
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(idCaso)).thenReturn(caso);
//        casoDeTesteClassificadorDao.remove(caso);
//        secaoCasoDeTesteManager.excluir(Mockito.any(SecaoCasoDeTeste.class));
//        
//        
//        // Açao
//        casoDeTesteClassificadorManager.excluir(idCaso);
//        
//        // veririficaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findById(idCaso);
//        verify(casoDeTesteClassificadorDao, times(2)).remove(caso);
//        verify(secaoCasoDeTesteManager).excluir(Mockito.any(SecaoCasoDeTeste.class));
//    }
//    
//    @Test
//    public void testCriarEntradaExecucao () {// Caminho de chamada métodos: formatarEntradaExecucao() -> (criarCorpus() + criarWatsonData()) 
//        // Cenario
//        int idCasoDeTesteClassificador = 10; 
//        int idClassificador = 20;
//        
//        VersaoCorpus versaoCorpus = umVersaoCorpus().comIdClassificador(idCasoDeTesteClassificador).build();
//        
//        NuvemWatson nuvem = umNuvemWatson().build();
//        
//        // Mock
//        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE)).thenReturn(nuvem);
//        when(versaoCorpusManager.listarUltimoPorClassificador(Mockito.anyInt())).thenReturn(versaoCorpus);
//        
//        // Açao
//        casoDeTesteClassificadorManager.criarEntradaExecucao(idCasoDeTesteClassificador, idClassificador);
//        
//        // Verificaçao
//        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
//        verify(versaoCorpusManager, times(1)).listarUltimoPorClassificador(Mockito.anyInt());
//    }
//
//    @Test
//    public void testCriarListaEntradaExecucao() {
//        // Cenario
//        Integer idCasoDeTeste = 30;
//        int idClassificador = 20;
//        Integer idCasoClassificador = 45;
//        
//        NuvemWatson nuvem = umNuvemWatson().build();
//        
//        List<CasoDeTesteClassificador> listaCaso = Arrays.asList(umCasoDeTesteClassificador()
//                .comIdClassificador(idCasoClassificador)
//                .build());
//        
//        TipoElemento elemento = umTipoElemento().comNome("Entidade").build();
//        TipoCondicao tipoCondicao = umTipoCondicao().comNome("Igual").build();
//        
//        List<CenarioEsperado> cenarios = Arrays.asList(
//                umCenarioEsperado()
//                .comTipoCondicao(tipoCondicao)
//                .comTextoElemento("Texto Primeiro Elemento")
//                .comTipoElemento(elemento)
//                .comId(125)
//                .build(),
//                
//                umCenarioEsperado()
//                .comTipoCondicao(tipoCondicao)
//                .comTextoElemento("Texto Primeiro Elemento")
//                .comTipoElemento(elemento)
//                .comId(125)
//                .build());
//        
//        List<SecaoCasoDeTeste> secoes2 = Arrays.asList(umSecaoCasoDeTeste()
//                                                .comListaCenarios(cenarios)
//                                                .comId(100)
//                                                .comTextoEntrada("Texto")
//                                                .build());
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comIdClassificador(idCasoDeTeste)
//                                        .comListaSecoes(secoes2)
//                                        .comId(idCasoClassificador)
//                                        .build();
//        
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(listaCaso.get(0).getId())).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.findById(cenarios)).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.buscarTodosPorIdClassificador(idClassificador)).thenReturn(listaCaso);
//        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE)).thenReturn(nuvem);
//        
//        // Açao
//        casoDeTesteClassificadorManager.criarListaEntradaExecucao(idClassificador);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).buscarTodosPorIdClassificador(idClassificador);
//        verify(casoDeTesteClassificadorDao, times(0)).findById(idCasoDeTeste);
//        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
//    }
//    
//    @Test
//    public void testCriarEntradaExecucaoComNuvemNull () {// Caminho de chamada métodos: formatarEntradaExecucao() -> (criarCorpus() + criarWatsonData())
//     // Cenario
//        Integer idCasoDeTeste = 30;
//        int idClassificador = 20;
//        Integer idCasoClassificador = 45;
//        
//        NuvemWatson nuvem = null;
//        
//        List<CasoDeTesteClassificador> listaCaso = Arrays.asList(umCasoDeTesteClassificador()
//                .comIdClassificador(idCasoClassificador)
//                .build());
//        
//        TipoElemento elemento = umTipoElemento().comNome("Intenção").build();
//        
//        TipoCondicao tipoCondicao = umTipoCondicao().comNome("Não contém").build();
//        
//        List<CenarioEsperado> cenario = Arrays.asList(umCenarioEsperado().comTipoCondicao(tipoCondicao).comTipoElemento(elemento).comId(125).build());
//        
//        List<SecaoCasoDeTeste> secoes2 = Arrays.asList(umSecaoCasoDeTeste()
//                                                .comListaCenarios(cenario)
//                                                .comId(100)
//                                                .comTextoEntrada("Texto")
//                                                .build());
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comIdClassificador(idCasoDeTeste)
//                                        .comNomeCasoDeTeste("Nome")
//                                        .comListaSecoes(secoes2)
//                                        .comId(idCasoClassificador)
//                                        .build();
//        
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(listaCaso.get(0).getId())).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.findById(cenario.get(0))).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.buscarTodosPorIdClassificador(idClassificador)).thenReturn(listaCaso);
//        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE)).thenReturn(nuvem);
//        
//        // Açao
//        casoDeTesteClassificadorManager.criarListaEntradaExecucao(idClassificador);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).buscarTodosPorIdClassificador(idClassificador);
//        verify(casoDeTesteClassificadorDao, times(0)).findById(idCasoDeTeste);
//        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
//    }
//    
//    @Test
//    public void testCriarEntradaExecucaoComNuvem () {// Caminho de chamada métodos: formatarEntradaExecucao() -> (criarCorpus() + criarWatsonData())
//     // Cenario
//        Integer idCasoDeTeste = 30;
//        int idClassificador = 20;
//        Integer idCasoClassificador = 45;
//        
//        NuvemWatson nuvem = umNuvemWatson().build();
//        
//        List<CasoDeTesteClassificador> listaCaso = Arrays.asList(umCasoDeTesteClassificador()
//                .comIdClassificador(idCasoClassificador)
//                .build());
//        
//        TipoElemento elemento = umTipoElemento().comNome("Intenção").build();
//        
//        TipoCondicao tipoCondicao = umTipoCondicao().comNome("Não contém").build();
//        
//        List<CenarioEsperado> cenario = Arrays.asList(umCenarioEsperado().comTipoCondicao(tipoCondicao).comTipoElemento(elemento).comId(125).build());
//        
//        List<SecaoCasoDeTeste> secoes2 = Arrays.asList(umSecaoCasoDeTeste()
//                                                .comListaCenarios(cenario)
//                                                .comId(100)
//                                                .comTextoEntrada("Texto")
//                                                .build());
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comIdClassificador(idCasoDeTeste)
//                                        .comNomeCasoDeTeste("Nome")
//                                        .comListaSecoes(secoes2)
//                                        .comId(idCasoClassificador)
//                                        .build();
//        
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(listaCaso.get(0).getId())).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.findById(cenario.get(0))).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.buscarTodosPorIdClassificador(idClassificador)).thenReturn(listaCaso);
//        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE)).thenReturn(nuvem);
//        
//        // Açao
//        casoDeTesteClassificadorManager.criarListaEntradaExecucao(idClassificador);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).buscarTodosPorIdClassificador(idClassificador);
//        verify(casoDeTesteClassificadorDao, times(0)).findById(idCasoDeTeste);
//        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
//    }
//
//    @Test
//    public void testNódeDialogo () { // Linha 152
//        // Cenario
//        Integer idCasoDeTeste = 30;
//        int idClassificador = 20;
//        Integer idCasoClassificador = 45;
//        
////      MOCK 1 ==============================================================
//        NuvemWatson nuvem = umNuvemWatson().build();
//        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE)).thenReturn(nuvem);
//        
////      Mock 2 ===============================================================
//        List<CasoDeTesteClassificador> listaCaso = Arrays.asList(umCasoDeTesteClassificador()
//                .comIdClassificador(idCasoClassificador)
//                .build());
//        
//        when(casoDeTesteClassificadorDao.buscarTodosPorIdClassificador(idClassificador)).thenReturn(listaCaso);
////      =======================================================================
//        
//        TipoElemento elemento = umTipoElemento().comNome("Nó de diálogo").build();
//        
//        TipoCondicao tipoCondicao = umTipoCondicao().comNome("Contém").build();
//        
//        List<CenarioEsperado> cenario = Arrays.asList(umCenarioEsperado().comTipoCondicao(tipoCondicao).comTipoElemento(elemento).comId(125).build());
//        
//        List<SecaoCasoDeTeste> secoes2 = Arrays.asList(umSecaoCasoDeTeste()
//                                                .comListaCenarios(cenario)
//                                                .comId(100)
//                                                .comTextoEntrada("Texto")
//                                                .build());
//        
////      MOCK 3 =====================================================
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comIdClassificador(idCasoDeTeste)
//                                        .comNomeCasoDeTeste("Nome")
//                                        .comListaSecoes(secoes2)
//                                        .comId(idCasoClassificador)
//                                        .build();
//        
//        when(casoDeTesteClassificadorDao.findById(listaCaso.get(0).getId())).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.findById(cenario.get(0))).thenReturn(caso);
//        
//        // Açao
//        casoDeTesteClassificadorManager.criarListaEntradaExecucao(idClassificador);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).buscarTodosPorIdClassificador(idClassificador);
//        verify(casoDeTesteClassificadorDao, times(0)).findById(idCasoDeTeste);
//        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
//    }
//    
//    @Test
//    public void testContexto () {// Linha 154
//        // Cenario
//        Integer idCasoDeTeste = 30;
//        int idClassificador = 20;
//        Integer idCasoClassificador = 45;
//        
//        NuvemWatson nuvem = umNuvemWatson().build();
//        
//        List<CasoDeTesteClassificador> listaCaso = Arrays.asList(umCasoDeTesteClassificador()
//                .comIdClassificador(idCasoClassificador)
//                .build());
//        
//        TipoElemento elemento = umTipoElemento().comNome("Contexto").build();
//        
//        TipoCondicao tipoCondicao = umTipoCondicao().comNome("Diferente").build();
//        
//        List<CenarioEsperado> cenario = Arrays.asList(umCenarioEsperado()
//                                                    .comTextoElementoValor("equals")
//                                                    .comTipoCondicao(tipoCondicao)
//                                                    .comTipoElemento(elemento)
//                                                    .comId(125)
//                                                    .build());
//        
//        List<SecaoCasoDeTeste> secoes2 = Arrays.asList(umSecaoCasoDeTeste()
//                                                .comListaCenarios(cenario)
//                                                .comId(100)
//                                                .comTextoEntrada("Texto")
//                                                .build());
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comIdClassificador(idCasoDeTeste)
//                                        .comNomeCasoDeTeste("Nome")
//                                        .comListaSecoes(secoes2)
//                                        .comId(idCasoClassificador)
//                                        .build();
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(listaCaso.get(0).getId())).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.findById(cenario.get(0))).thenReturn(caso);
//        when(casoDeTesteClassificadorDao.buscarTodosPorIdClassificador(idClassificador)).thenReturn(listaCaso);
//        when(nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE)).thenReturn(nuvem);
//        
//        // Açao
//        casoDeTesteClassificadorManager.criarListaEntradaExecucao(idClassificador);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).buscarTodosPorIdClassificador(idClassificador);
//        verify(casoDeTesteClassificadorDao, times(0)).findById(idCasoDeTeste);
//        verify(nuvemWatsonDao, times(1)).findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
//    }
//    
//    @Test
//    public void testFindByIdClassificador() {
//        // Cenario
//        Integer idClassificador = new Integer(17);
//        
//        Paginacao<CasoDeTesteClassificador> paginacao = new Paginacao<>();
//        paginacao.setListaPaginada(Arrays.asList(
//                                                umCasoDeTesteClassificador()
//                                                .comId(idClassificador)
//                                                .build()
//                                                ));
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findByIdClassificador(idClassificador, paginacao)).thenReturn(paginacao);
//        
//        // Açao
//        casoDeTesteClassificadorManager.findByIdClassificador(idClassificador, paginacao);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findByIdClassificador(idClassificador, paginacao);
//    }
//    
//
//    @Test
//    public void testMoverSecao() {
//        // Cenario
//        Integer idCasoDeTeste = new Integer(122);
//        Integer posicao = new Integer(1);
//        
//        
//        List<SecaoCasoDeTeste> secao = new ArrayList<>();
//        secao.add(umSecaoCasoDeTeste().comIdCasoDeTesteClassificador(idCasoDeTeste).build());
//        
//        SecaoCasoDeTeste secao2 = umSecaoCasoDeTeste().comIdCasoDeTesteClassificador(idCasoDeTeste).comId(10).build();
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comId(130)
//                                        .comIdClassificador(secao2.getIdCasoDeTesteClassificador())
//                                        .comListaSecoes(secao)
//                                        .build();
//        
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(idCasoDeTeste)).thenReturn(caso);
//        secaoCasoDeTesteManager.salvar(Mockito.any(SecaoCasoDeTeste.class));
//        
//        // Açao
//        casoDeTesteClassificadorManager.moverSecao(secao2, posicao);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findById(idCasoDeTeste);
//        verify(secaoCasoDeTesteManager, times(2)).salvar(Mockito.any(SecaoCasoDeTeste.class));
//    }
//    
//    @Test
//    public void testAtualizarSequenciaSalvar () {
//        // Cenario
//        Integer idCasoDeTeste = 12;
//        
//        List<SecaoCasoDeTeste> secao = new ArrayList<>();
//        secao.add(umSecaoCasoDeTeste().comIdCasoDeTesteClassificador(idCasoDeTeste).build());
//        
//        SecaoCasoDeTeste secao2 = umSecaoCasoDeTeste().comIdCasoDeTesteClassificador(idCasoDeTeste).comId(10).build();
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador()
//                                        .comId(130)
//                                        .comIdClassificador(secao2.getIdCasoDeTesteClassificador())
//                                        .comListaSecoes(secao)
//                                        .build();
//        // Mock
//        when(casoDeTesteClassificadorDao.findById(idCasoDeTeste)).thenReturn(caso);
//        
//        // Açao
//        casoDeTesteClassificadorManager.atualizarSequenciaSalvar(idCasoDeTeste);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findById(idCasoDeTeste);
//    }
//
//    @Test
//    public void testListarVersao() {
//        // Cenario
//        Integer idClassificador = 10;
//        
//        List<SecaoCasoDeTeste> secao = Arrays.asList(umSecaoCasoDeTeste().comId(12).build());
//        
//        List<CasoDeTesteClassificador> casos = Arrays.asList(umCasoDeTesteClassificador().comListaSecoes(secao).comIdClassificador(idClassificador).build());
//        
//        // Mock
//        when(casoDeTesteClassificadorDao.listarVersao(idClassificador)).thenReturn(casos);
//        
//        // Açao
//        casoDeTesteClassificadorManager.listarVersao(idClassificador);
//    }
//
//    @Test
//    public void testLimparPorClassificador() {
//        // Cenario
//        Integer idClassificador = 12;
//        
//        Integer idCaso = new Integer(2);
//        
//        List<SecaoCasoDeTeste> secao2 = Arrays.asList(umSecaoCasoDeTeste().comId(10).build());
//        List<CasoDeTesteClassificador> caso2 =  Arrays.asList(umCasoDeTesteClassificador().comId(idCaso).comListaSecoes(secao2).build());
//        
//        CasoDeTesteClassificador caso = umCasoDeTesteClassificador().comId(idCaso).comListaSecoes(secao2).build();
//        
//     // Mock testExcluirCasoDeTesteClassificador
//        when(casoDeTesteClassificadorDao.findById(idCaso)).thenReturn(caso); 
//        casoDeTesteClassificadorDao.remove(caso);
//        secaoCasoDeTesteManager.excluir(Mockito.any(SecaoCasoDeTeste.class));
//        
//        when(casoDeTesteClassificadorDao.listarVersao(idClassificador)).thenReturn(caso2); // Mock testLimparPorClassificador
//        
//        // Açao
//        casoDeTesteClassificadorManager.limparPorClassificador(idClassificador);
//        
//        // Verificaçao
//        verify(casoDeTesteClassificadorDao, times(1)).findById(idCaso);
//        verify(casoDeTesteClassificadorDao, times(2)).remove(caso);
//        verify(secaoCasoDeTesteManager).excluir(Mockito.any(SecaoCasoDeTeste.class));
//    }
//    
//}
