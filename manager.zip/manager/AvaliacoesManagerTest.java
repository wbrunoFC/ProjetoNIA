package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AvaliacaoMotivoBuilder.umAvaliacaoMotivo;
import static br.com.bb.databuilder.AvaliacoesBuilder.umAvaliacoes;
import static br.com.bb.databuilder.FiltroAvaliacoesVOBuilder.umFiltroAvaliacoesVO;
import static br.com.bb.databuilder.ItemCacheProgressoBuilder.umItemCacheProgresso;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.databuilder.ItemCacheProgressoBuilder;
import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AvaliacoesDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoMotivo;
import br.com.bb.gearq.c4coleta.model.Avaliacoes;
import br.com.bb.gearq.c4coleta.vo.FiltroAvaliacoesVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class AvaliacoesManagerTest {
    /**
     * @author c1312334
     * 
     */
    
    @InjectMocks
    private AvaliacoesManager avaliacoesManager;
    
    @Mock
    private AvaliacoesDao avaliacoesDao;
    
    @Mock
    private CacheProgresso cacheProgresso;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testListar() {
        // Cenario
        FiltroAvaliacoesVO filtroAvaliacoesVO = umFiltroAvaliacoesVO().comIdMotivo(10).build();
        AvaliacaoMotivo avaliacaoMotivo = umAvaliacaoMotivo().build();
        
        Paginacao<Avaliacoes> paginacao = new Paginacao<>();
        paginacao.setListaPaginada(Arrays.asList(umAvaliacoes()
                                                .comIdMotivo(filtroAvaliacoesVO.getIdMotivo())
                                                .comAvaliacaoMotivo(avaliacaoMotivo)
                                                .build()));
        
        // Mock
        when(avaliacoesDao.pesquisar(filtroAvaliacoesVO)).thenReturn(paginacao);
        
        // Açao
        avaliacoesManager.listar(filtroAvaliacoesVO);
        
        // verificaçao
        Assertions.assertThat(filtroAvaliacoesVO).isNotNull();
        Assertions.assertThat(avaliacaoMotivo).isNotNull();
        Assertions.assertThat(paginacao).isNotNull();
        verify(avaliacoesDao,times(1)).pesquisar(filtroAvaliacoesVO);
    }

    @Test
    public void testGravarAvaliacao() {
        // Cenario
        FiltroAvaliacoesVO filtroAvaliacoesVO = umFiltroAvaliacoesVO().comIdMotivo(10).build();
        
        // Mock
        avaliacoesDao.gravarAvaliacao(filtroAvaliacoesVO);
        
        // Açao
        avaliacoesManager.gravarAvaliacao(filtroAvaliacoesVO);
        
        // verificaçao
        Assertions.assertThat(filtroAvaliacoesVO).isNotNull();
    }

    @Test
    public void testListarAll() {
        // Cenario
        List<Avaliacoes> avaliacoes  = Arrays.asList(umAvaliacoes().comId(2).build());
        
        // Mock
        when(avaliacoesDao.listaAll()).thenReturn(avaliacoes);
        
        // Açao
        avaliacoesManager.listarAll();
        
        // verificaçao
        verify(avaliacoesDao, times(1)).listaAll();
    }

    @Test
    public void testGetAvaliacoes() {
        // Cenario
        
        AvaliacaoMotivo avaliacaoMotivo = umAvaliacaoMotivo().comId(15).comNome("Nome").build();
        
        List<Avaliacoes> avaliacoes = Arrays.asList(umAvaliacoes()
                                            .comId(4)
                                            .comChave("Chave")
                                            .comNota(10)
                                            .comAvaliacaoMotivo(avaliacaoMotivo)
                                            .build());
        
       
        // Mock
        when(avaliacoesDao.listaAll()).thenReturn(avaliacoes);
        
        // Açao
        avaliacoesManager.getAvaliacoes();
        
        // verificaçao
        Assertions.assertThat(avaliacoes).isNotNull();
        verify(avaliacoesDao, times(1)).listaAll();
    }
    
    @Test
    public void testGetAvaliacoes2() {
        // Cenario
        String nomeItem = "PROGRESSO";
        ItemCacheProgressoBuilder item = umItemCacheProgresso()
                                         .comId(nomeItem)
                                         .comAndamento(0)
                                         .comTotal(4)
                                         .comConteudo(null);
        
        // Açao
        avaliacoesManager.getAvaliacoes();
        
        Assertions.assertThat(item).isNotNull();
        
    }
    
    @Ignore
    public void testPesquisar () {
    }
}
