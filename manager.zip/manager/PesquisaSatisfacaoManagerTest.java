package br.com.bb.gearq.c4coleta.manager;


import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

import static br.com.bb.databuilder.AvaliacaoFormularioBuilder.umAvaliacaoFormulario;
import static br.com.bb.databuilder.PesquisaSatisfacaoBuilder.umPesquisaSatisfacao;
import static br.com.bb.databuilder.PesquisaSatisfacaoEnvioBuilder.umPesquisaSatisfacaoEnvio;

import br.com.bb.gearq.c4coleta.dao.PesquisaSatisfacaoDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoFormulario;
import br.com.bb.gearq.c4coleta.model.PesquisaSatisfacao;
import br.com.bb.gearq.c4coleta.model.PesquisaSatisfacaoEnvio;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class PesquisaSatisfacaoManagerTest {
    @InjectMocks
    PesquisaSatisfacaoManager pesquisaSatisfacaoManager;
    
    @Mock
    private PesquisaSatisfacaoDao pesquisaSatisfacaoDao;
    
    @Mock
    LogNiaInfraManager logNiaInfraManager;
    
    @Mock
    PesquisaSatisfacaoEnvioManager pesquisaSatisfacaoEnvioManager;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testListaLogNiaInfraQuantidadeIteracaoPorChave() throws NegocioException, Exception {
        //Cenário
        String origem = "Origem";
        String servico =  "Serviço";
        String dataInicioCadastro = "2019-01-01";
        String dataFimCadastro = "2019-01-02";
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().build();
        
        List<String> listaLog = Arrays.asList("F1234567_3_9"); 
        
        PesquisaSatisfacao pesquisaSatisfacao = umPesquisaSatisfacao().comId(1).comChave("F1234567").build();
        PesquisaSatisfacaoEnvio pesquisaSatisfacaoEnvio = umPesquisaSatisfacaoEnvio().comPesquisaSatisfacao(pesquisaSatisfacao).build();
        
        //Mock
        when(logNiaInfraManager.listaLogNiaInfraQuantidadeIteracaoPorChave(dataInicioCadastro, dataFimCadastro, servico, avaliacaoFormulario, origem)).thenReturn(listaLog);
        when(pesquisaSatisfacaoDao.persist(pesquisaSatisfacao)).thenReturn(pesquisaSatisfacao);
        pesquisaSatisfacaoEnvioManager.salvar(pesquisaSatisfacaoEnvio);
        
        //Ação
        pesquisaSatisfacaoManager.listaLogNiaInfraQuantidadeIteracaoPorChave(origem, servico, dataInicioCadastro, dataFimCadastro, avaliacaoFormulario);
        
        
    }
    

    @Test
    public void testListarPesquisaSatisfacao() throws ParseException {
        //Cenário
        String origem = "Origem";
        String servico =  "Serviço";
        String dataInicioCadastro = "2019-01-01";
        String dataFimCadastro = "2019-01-02";
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().build();
        
        List<PesquisaSatisfacao> lista = Arrays.asList(umPesquisaSatisfacao().build());
        lista.get(0).getId();
        lista.get(0).getDataHoraCadastro();
        lista.get(0).getChave();
        lista.get(0).getListaPesquisaSatisfacaoEnvio();
        
        //Mock
        when(pesquisaSatisfacaoDao.listar(origem, servico, dataInicioCadastro, dataFimCadastro, avaliacaoFormulario)).thenReturn(lista);
        
        //Ação
        pesquisaSatisfacaoManager.listarPesquisaSatisfacao(origem, servico, dataInicioCadastro, dataFimCadastro, avaliacaoFormulario);
        
        //Verificação
        verify(pesquisaSatisfacaoDao, times(1)).listar(origem, servico, dataInicioCadastro, dataFimCadastro, avaliacaoFormulario);
        
    }
}
