package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.FluxoBuilder.umFluxo;
import static br.com.bb.databuilder.FluxoVOBuilder.umFluxoVO;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;

public class FluxoManagerTest {
    
    /**
     * @author c1312334
     * @date 27/12/19
     */
    
    @InjectMocks
    private FluxoManager fluxoManager;
    
    @Mock
    private FluxoDao fluxoDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testObter() {
        // Cenario
        Integer idFluxo = 2;
        
        Fluxo fluxo = umFluxo().comId(idFluxo).build();
        
        // Mock
        when(fluxoDao.findById(idFluxo)).thenReturn(fluxo);
        
        // Acao
        fluxoManager.obter(idFluxo);
        
        // Verificacao
        verify(fluxoDao, times(0)).findById(fluxo);
        verify(fluxoDao).findById(idFluxo);
    }

    @Test
    public void testExcluirInt() {
        // Cenario
        int idFluxo = 10;
        
        Fluxo fluxo = umFluxo().comId(idFluxo).build();
        Fluxo fluxoFliho = umFluxo().comId(12).build();
         
        when(fluxoDao.findById(idFluxo)).thenReturn(fluxo);
        when(fluxoDao.findByidFluxoPai(fluxo.getId())).thenReturn(Arrays.asList(fluxoFliho));
        
        // Acao
        fluxoManager.excluir(idFluxo);
        
        // Verificaçao
        verify(fluxoDao, times(0)).findById(fluxo);
        verify(fluxoDao).findByidFluxoPai(idFluxo);
    }
    
    @Test
    public void testExcluirInt2() {
        // Cenario
        Fluxo fluxo = umFluxo().comId(10).build();
        Fluxo fluxoFliho = umFluxo().comId(12).build();
        
        // Mock
        when(fluxoDao.findByidFluxoPai(fluxo.getId())).thenReturn(Arrays.asList(fluxoFliho));
        
        // Acao
        fluxoManager.excluir(fluxo);
        
        // Verificaçao
        verify(fluxoDao).findByidFluxoPai(fluxo.getId());
        verify(fluxoDao, times(1)).findByidFluxoPai(fluxoFliho.getId());
        
    }

    @Test
    public void testSalvar() {
        // Cenario
        Fluxo fluxo = umFluxo().build();
        fluxo.getAgrupador();
        
        // Mock
        when(fluxoDao.persist(fluxo)).thenReturn(fluxo);
        
        // Acao
        fluxoManager.salvar(fluxo);

        // Verificacao
        verify(fluxoDao, times(1)).persist(fluxo);
        verify(fluxoDao).persist(fluxo);
    }

    @Test
    public void testListarPorIntencao() {
        // Cenario
        Integer idIntencao = 2;
        
        List<Fluxo> fluxo = Arrays.asList(
                umFluxo()
                .comId(idIntencao)
                .build()
                );
        
        // Mock
        when(fluxoDao.findByFluxo(idIntencao)).thenReturn(fluxo);

        // Acao
        fluxoManager.listarPorIntencao(idIntencao);

        // Verificacao
        verify(fluxoDao, timeout(2)).findByFluxo(idIntencao);
        verify(fluxoDao).findByFluxo(idIntencao);
    }

    @Test
    public void testListarPorAgrupador() {
        // Cenario
        Integer id = 10;
        
        List<Fluxo> fluxo = Arrays.asList(
                umFluxo()
                .comId(id)
                .build()
                );

        // Mock
        when(fluxoDao.findByidAgrupador(id)).thenReturn(fluxo);

        // Acao
        fluxoManager.listarPorAgrupador(id);
        
        // Verificacao
        verify(fluxoDao, times(1)).findByidAgrupador(id);
        verify(fluxoDao).findByidAgrupador(id);
    }

    @Test
    public void testFluxo() {
        // Cenario
        Integer idIntencao = 2;
        
        FluxoVO fluxoVO = umFluxoVO().comId(idIntencao).build();
        
        // Mock
        when(fluxoDao.fluxo(idIntencao)).thenReturn(fluxoVO);
        
        // Acao
        fluxoManager.fluxo(idIntencao);

        // Verificacao
        verify(fluxoDao).fluxo(idIntencao);
    }

    @Test
    public void testLimparPorClassificador() {
        // Cenario
        Integer idClassificador = 2;

        Fluxo fluxo = umFluxo().comId(idClassificador).build();
        Fluxo fluxoFliho = umFluxo().comId(12).build();
        
        // Mock
        when(fluxoDao.listarVersao(idClassificador)).thenReturn(Arrays.asList(fluxo));
        when(fluxoDao.listarVersao(idClassificador)).thenReturn(Arrays.asList(fluxoFliho));

        // Acao
        fluxoManager.limparPorClassificador(idClassificador);

    }
}
