package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ControleIdPerguntaRevisaoBuilder.umControleIdPerguntaRevisao;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;

import java.util.Arrays;
import java.util.List;

import org.assertj.core.api.AssertJProxySetup;
import org.jdom.Verifier;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.Times;
import org.openid4java.consumer.VerificationResult;

import br.com.bb.gearq.c4coleta.dao.ControleIdPerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.LogNiaInfraDao;
import br.com.bb.gearq.c4coleta.model.ControleIdPerguntaRevisao;

public class ControleIdPerguntaRevisaoTest {

    @InjectMocks
    private ControleIdPerguntaRevisaoManager controleIdPerguntaRevisaoManager;

    @Mock
    private ControleIdPerguntaRevisaoDao controleIdPerguntaRevisaoDao;

    @Mock
    LogNiaInfraManager logNiaInfraManager;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

    }

    @Test
    public void testPerguntaRevisão() {
        // cenario
        List<ControleIdPerguntaRevisao> controleIdPerguntaRevisao = Arrays.asList(
                umControleIdPerguntaRevisao().build(),
                umControleIdPerguntaRevisao().build()
                );
        
        // mock
        when(controleIdPerguntaRevisaoDao.findAll()).thenReturn(controleIdPerguntaRevisao);
//        when(logNiaInfraManager.ultimoIdLogNiaInfra()).thenReturn(ultimoIdLog);

        // ação
        controleIdPerguntaRevisaoManager.getControlePerguntaRevisao();// nome da classe e nome do metodo da classe.java
        ControleIdPerguntaRevisao resultadoEsperado = controleIdPerguntaRevisao.get(0);
      
        // verificação
        assertEquals(controleIdPerguntaRevisao.get(0), resultadoEsperado);
    }

    @Test
    public void revisaoPerguntaComListaVazia() {
       //cenario
        List<ControleIdPerguntaRevisao> controleIdPerguntaRevisao = Arrays.asList();
        Integer ultimoIdLog =10;
        
        //mock
        when(controleIdPerguntaRevisaoDao.findAll()).thenReturn(controleIdPerguntaRevisao);
        when(logNiaInfraManager.ultimoIdLogNiaInfra()).thenReturn(ultimoIdLog);
        
        //ação
        ControleIdPerguntaRevisao controlePerguntaRevisao = controleIdPerguntaRevisaoManager.getControlePerguntaRevisao();
        
        
        //verificação
        System.out.println("Aqui");
        
    }

    @Test
    public void salvarControle() {
        // cenario
        ControleIdPerguntaRevisao controleIdPerguntaRevisao = umControleIdPerguntaRevisao().build();
        controleIdPerguntaRevisao.getId();
        controleIdPerguntaRevisao.getDataConsulta();

        // mock
        when(controleIdPerguntaRevisaoDao.persist(controleIdPerguntaRevisao)).thenReturn(controleIdPerguntaRevisao);

        // ação
        controleIdPerguntaRevisaoManager.salvar(controleIdPerguntaRevisao);
        ControleIdPerguntaRevisao resultado = controleIdPerguntaRevisaoManager.salvar(controleIdPerguntaRevisao);

        // verificação
        assertEquals(controleIdPerguntaRevisao, resultado);
    }

    @Test
    public void testUltimoIncremento() {
        // cenario
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().build();
        Integer ultimoIdLog = 4;

        // mock

        // ação
        controleIdPerguntaRevisaoManager.incrementarParaUltimo(controle);
        logNiaInfraManager.ultimoIdLogNiaInfra();
        
        // verificação
        System.out.println(logNiaInfraManager.ultimoIdLogNiaInfra());
        assertTrue(true);
    }

    @Test
    public void testIncrementar() {
        // cenario
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().comIdFimPerguntaRevisao(100).build();
        int quantidade = 100;
        Integer ultimoIdLog = 10;
        
        // ação
        controleIdPerguntaRevisaoManager.incrementar(controle, quantidade);
        when(logNiaInfraManager.ultimoIdLogNiaInfra()).thenReturn(ultimoIdLog);
        logNiaInfraManager.ultimoIdLogNiaInfra();
        
        //verificação
        System.out.println(logNiaInfraManager.ultimoIdLogNiaInfra());
        assertTrue(true);
    }
    
    @Test
    public void testIncrementarComIdFimMenor() {
        // cenario
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().comIdFimPerguntaRevisao(0).build();
        int quantidade = 0;
        Integer ultimoIdLog = 1000;
        
        // ação
        controleIdPerguntaRevisaoManager.incrementar(controle, quantidade);
        when(logNiaInfraManager.ultimoIdLogNiaInfra()).thenReturn(ultimoIdLog);
        logNiaInfraManager.ultimoIdLogNiaInfra();
        
        //verificação
        System.out.println(logNiaInfraManager.ultimoIdLogNiaInfra());
    }
    
    @Test
    public void testTerminar() {
        // cenario
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().comIdFimPerguntaRevisao(10).build();
        Integer ultimoIdLog = 10;

        // ação
        when(logNiaInfraManager.ultimoIdLogNiaInfra()).thenReturn(ultimoIdLog);
        boolean resultado = controleIdPerguntaRevisaoManager.terminou(controle);
        
        assertTrue(resultado);
        
    }
    
    @Test
    public void testTerminarParaValoresDiferentes() {
        // cenario
        ControleIdPerguntaRevisao controle = umControleIdPerguntaRevisao().comIdFimPerguntaRevisao(10).build();
        Integer ultimoIdLog = 100;
        
        // ação
        when(logNiaInfraManager.ultimoIdLogNiaInfra()).thenReturn(ultimoIdLog);
        boolean resultado = controleIdPerguntaRevisaoManager.terminou(controle);
        
        assertTrue(true);

    }
//    public static void main(String[] args) {
//        new BuilderMaster().gerarCodigoClasse(ControleIdPerguntaRevisao.class);
//        
//    }
}