package br.com.bb.gearq.c4coleta.manager;


import static org.mockito.Mockito.when;
import static br.com.bb.databuilder.AcionamentoIntencaoDiaBuilder.umAcionamentoIntencaoDia;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;


import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.AcionamentoIntencaoDiaDao;
import br.com.bb.gearq.c4coleta.dao.DialogoDao;
import br.com.bb.gearq.c4coleta.model.AcionamentoIntencaoDia;


public class AcionamentoIntencaoManagerTest {
    
    @InjectMocks
    private AcionamentoIntencaoManager acionamentoIntencaoManager;
    
    @Mock
    private AcionamentoIntencaoDiaDao acionamentoIntencaoDiaDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
     }
    
    
    
    @Test
    public void testProcessarQuantidadeDeAcinamentoDasIntencoesNoDia () {
        
        //Cenário
        List<AcionamentoIntencaoDia> lista = Arrays.asList(
                umAcionamentoIntencaoDia().build(),
                umAcionamentoIntencaoDia().build()
                );  
        lista.get(0).getId();
        lista.get(0).getClassificador();
        lista.get(0).getIntencao();
        lista.get(0).getQtacmt();
        lista.get(0).getDataAcionamento();
        
        List<AcionamentoIntencaoDia> listaRetornada = Arrays.asList(
                umAcionamentoIntencaoDia().build()
                );  
        
        
     // Mocks
        when(acionamentoIntencaoDiaDao.findByDadosDia()).thenReturn(lista);
        when(acionamentoIntencaoDiaDao.findConsultaDia(lista.get(0))).thenReturn(listaRetornada);
        when(acionamentoIntencaoDiaDao.persist(lista.get(0))).thenReturn(lista.get(0));
        
        // acionamentoIntencaoManager.processarQtd();
        
     
     // Ação
        acionamentoIntencaoManager.processarQtd();
        ArgumentCaptor<AcionamentoIntencaoDia> acionamentoIntencaoDiaCapturado = ArgumentCaptor.forClass(AcionamentoIntencaoDia.class);        
     
     // Verificao
        verify(acionamentoIntencaoDiaDao, times(1)).persist(acionamentoIntencaoDiaCapturado.capture());
        
    }
    


}
