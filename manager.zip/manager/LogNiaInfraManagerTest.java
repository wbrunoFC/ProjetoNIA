package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AvaliacaoFormularioBuilder.umAvaliacaoFormulario;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.CuradoriaLogDao;
import br.com.bb.gearq.c4coleta.dao.LogNiaInfraDao;
import br.com.bb.gearq.c4coleta.dao.LogNiaInfraSlaveDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoFormulario;
import br.com.bb.gearq.c4coleta.model.LogNiaInfra;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class LogNiaInfraManagerTest {
    /**
     * @author c1312334
     */
    
    @InjectMocks
    private LogNiaInfraManager logNiaInfraManager;
    
    @Mock
    private LogNiaInfraSlaveDao logNiaInfraSlaveDao;
    
    @Mock
    private LogNiaInfraDao logNiaInfraDao;
    
    @Mock
    private CuradoriaLogDao curadoriaLogDao;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }

    @Test
    public void testFindPorPeriodoEServicoETipo_ComListaSiglaNuvemVazio() {
        // Cenariopublic static void main(String[] args) {
//      new BuilderMaster().gerarCodigoClasse(LogNiaInfra.class);
//  }
        String dataInicial = "21/02/2020";
        String dataFinal = "22/02/2020";
        String tipoConsulta = new String("Consulta");
        String filtroServico = new String("FiltroServiço");
        int idClassificador = 2;
        List<String> listaSiglaNuvem = new ArrayList<String>();
        Paginacao<LogNiaInfra> paginacao = new Paginacao<>();
        
        List<NuvemWatson> listaNuvemWatson = Arrays.asList(umNuvemWatson().build());
        listaNuvemWatson.get(0).getListaCredencial();
        listaNuvemWatson.get(0).getSerialversionuid();
        listaNuvemWatson.get(0).getVersaoCorpusResposta();
        listaNuvemWatson.get(0).getAcessos();
        listaNuvemWatson.get(0).getIdVersao();
        listaNuvemWatson.get(0).getSiglaNuvemRedirecionar();
        
        // Mock
        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(listaNuvemWatson);
        when(logNiaInfraDao.findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, listaSiglaNuvem)).thenReturn(paginacao);
        
        // Açao
        logNiaInfraManager.findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, idClassificador, filtroServico);
        
        // verificao
        verify(nuvemWatsonDao, times(1)).findByClassificador(idClassificador);
        verify(logNiaInfraDao, times(0)).findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, listaSiglaNuvem);
    }
    
//    @Test
//    public void testFindPorPeriodoEServicoETipo_ComListaSiglaNuvempreenchida() {
//        // Cenario
//        String dataInicial = "21/02/2020";
//        String dataFinal = "22/02/2020";
//        String tipoConsulta = new String("Consulta");
//        String filtroServico = null;// caso de teste com nome preenchido
//        int idClassificador = 2;
//        List<String> listaSiglaNuvem = new ArrayList<String>();
//        
//        LogNiaInfra log = umLogNiaInfra()
//                .comListaRespostas()
//                .comJson("Json log")
//                .build();
//        
//        Paginacao<LogNiaInfra> paginacao = new Paginacao<>();
//        paginacao.setListaPaginada(Arrays.asList(umLogNiaInfra()
//                .comJson(log.getJson())
//                .build()));
//        
//        List<NuvemWatson> listaNuvemWatson = Arrays.asList(umNuvemWatson().build());
//        
//        NuvemWatson nuvemWatson = umNuvemWatson()
//                .comNome(filtroServico)// caso de teste nao conter filtroServiço
//                .build();
//                
//        // Mock
//        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(listaNuvemWatson);
//        when(nuvemWatsonDao.findByClassificador(nuvemWatson.getId())).thenReturn(listaNuvemWatson);
//        when(logNiaInfraDao.findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, listaSiglaNuvem)).thenReturn(paginacao);
//        when(logNiaInfraDao.findPorPeriodoEServicoETipo(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(paginacao);
//        
//        // Açao
//        LogNiaInfraManager.findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, idClassificador, filtroServico);
//        
//        // verificao
//        verify(nuvemWatsonDao, times(1)).findByClassificador(idClassificador);
//        verify(logNiaInfraDao, times(0)).findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, listaSiglaNuvem);
//    }

//    @Test
//    public void testFindByLogNiaInfraDialogos() {
//        // Cenario
//        String dataInicial = "02/02/2020";
//        String dataFinal = "03/02/2020";
//        String chave = "";// Caso de teste com String preenchida
//        String idConversa = "";// Caso de teste com String preenchida
//        String servico = "Serviço";
//        Integer idClassificador = 2;
//        
//        Paginacao<LogNiaInfra> paginacao = new Paginacao<>();
//        
//        List<NuvemWatson> listaNuvemWatson = Arrays.asList(umNuvemWatson().build());
//        
//        // Mock
//        when(nuvemWatsonDao.findByClassificador(Mockito.any())).thenReturn(listaNuvemWatson);
//        
//        // Açao
//        LogNiaInfraManager.findByLogNiaInfraDialogos(paginacao, dataInicial, dataFinal, chave, idConversa, servico, idClassificador);
//        
//        // verificaçao
//    }

    @Test
    public void testFindByLogNiaInfra() {
        // Cenario
         String dataInicial = "02/02/2020";
        String dataFinal = "03/02/2020";
        String tipoServicoInfra = "";
        String pergunta = "";
        String tipoOrdem = "";
        String hash = "";
        String chave = "";
        String idConversa = "";
        String tipoConsulta = "";
        Integer idClassificador = 1;
        
        Paginacao<LogNiaInfra> paginacao = new Paginacao<>();
        LogNiaInfra infra = new LogNiaInfra();
        infra.getId();
        infra.getTipoLog();
        infra.getTipoConsulta();
        infra.getServico();
        infra.getEndpoint();
        infra.getChave();
        infra.getHash();
        infra.getIdConversa();
        infra.getClasse();
        infra.getPrefixo();
        infra.getOrigem();
        infra.getNomeServicoCognitivo();
        infra.getRespostas();
        infra.getCuradoriaLog();
        infra.getTipoDocumento();
        infra.getTipoEntrada();
        
        // Açao
        logNiaInfraManager.findByLogNiaInfra(paginacao, dataInicial, dataFinal, tipoServicoInfra, pergunta, tipoOrdem, hash, chave, idConversa, tipoConsulta, idClassificador);

    }

    @Test
    public void testFindLogPerguntas() {
        // Cenario
        int idInicio = 1;
        int idFim = 2;
        
        List<Object[]> object = new ArrayList<>();
        
        // Mock
        when(logNiaInfraSlaveDao.findLogPerguntas(idInicio, idFim)).thenReturn(object);
        
        // Açao
        logNiaInfraManager.findLogPerguntas(idInicio, idFim);
        
        // Verificaçao
        verify(logNiaInfraSlaveDao, times(1)).findLogPerguntas(idInicio, idFim);
    }

    @Test
    public void testMaxAndMinDateLogNiaInfra() {
        // Cenario
        LogNiaInfra lni = new LogNiaInfra();
        
        // Mock
        when(logNiaInfraSlaveDao.getMaxAndMinDate()).thenReturn(lni);
        
        // Açao
        logNiaInfraManager.getMaxAndMinDate();
        
        // Verificaçao
        verify(logNiaInfraSlaveDao, times(1)).getMaxAndMinDate();
    }
    
    @Test
    public void testUltimoIdLogNiaInfra() {
        // Cenario
        Integer ultimo = 2;
        
        // Mock
        when(logNiaInfraSlaveDao.ultimoIdLogNiaInfra()).thenReturn(ultimo);
        
        // Açao
        logNiaInfraManager.ultimoIdLogNiaInfra();
        
        // Verificaçao
        verify(logNiaInfraSlaveDao, times(1)).ultimoIdLogNiaInfra();
    }

    @Test
    public void testMapLogNiaInfraQuantidadeIteracaoPorChave() throws ParseException {
        String dataInicial = "02/02/2020";
        String dataFinal = "03/02/2020";
        String servico = "Serviço";
        String origem = "Origem";
           
        AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().build();
        
        // Açao
        logNiaInfraManager.mapLogNiaInfraQuantidadeIteracaoPorChave(dataInicial, dataFinal, servico, avaliacaoFormulario, origem);
    }

    @Test
    public void testListaLogNiaInfraQuantidadeIteracaoPorChave() throws ParseException {
     // Cenario
     String dataInicial = "02/02/2020";
     String dataFinal = "03/02/2020";
     String servico = "Serviço";
     String origem = "Origem";
        
     AvaliacaoFormulario avaliacaoFormulario = umAvaliacaoFormulario().build();

     //Açao
     logNiaInfraManager.listaLogNiaInfraQuantidadeIteracaoPorChave(dataInicial, dataFinal, servico, avaliacaoFormulario, origem);
        
    }
    
//    public static void main(String[] args) {
//        new BuilderMaster().gerarCodigoClasse(LogNiaInfra.class);
//    }

}
