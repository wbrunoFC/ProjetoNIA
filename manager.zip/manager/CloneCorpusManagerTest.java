package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AgruparEntidadeSinonimosBuilder.umAgruparEntidadeSinonimos;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.EntidadeBuilder.umEntidade;
import static br.com.bb.databuilder.FluxoItemVOBuilder.umFluxoItemVO;
import static br.com.bb.databuilder.FluxoVOBuilder.umFluxoVO;
import static br.com.bb.databuilder.InstrucaoNormativaBuilder.umInstrucaoNormativa;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.PerguntaBuilder.umPergunta;
import static br.com.bb.databuilder.TipoRespostaBuilder.umTipoResposta;
import static br.com.bb.databuilder.TipoRespostaIntencaoBuilder.umTipoRespostaIntencao;
import static br.com.bb.databuilder.TipoRespostaIntencaoPKBuilder.umTipoRespostaIntencaoPK;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeDao;
import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.AgruparEntidadeSinonimos;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativa;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencaoPK;
import br.com.bb.gearq.c4coleta.stub.EntidadeManagerStub;
import br.com.bb.gearq.c4coleta.vo.FluxoItemVO;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class CloneCorpusManagerTest extends EntidadeManager{
    private static final Paginacao<Entidade> Entidade = null;

    /**
     * @author c1312334
     */
    
    @InjectMocks
    private CloneCorpusManager cloneCorpusManager;
    
    @Mock
    private IntencaoDao intencaoDao;
    
    @Spy
    private IntencaoDao intencaoDaoStub;
    
    @Mock
    private EntidadeDao entidadeDao;

    @Mock
    private IntencaoManager intencaoManager;
    
    @Spy
    private EntidadeManagerStub entidadeManager;
    
    @Spy
    private EntidadeManager entidadeManager2;

    @Mock
    private ClassificadorDao classificadorDao;

    @Mock
    private InstrucaoNormativaDao instrucaoNormativaDao;

    @Mock
    private TipoRespostaIntencaoDao tipoRespostaIntencaoDao; 

    @Mock
    private PerguntaDao perguntaDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testClonarCorpus() {
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 4;
        Integer pagina = 5;
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAZero() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 0;
        Integer pagina = 5;
        int idClassificador = 6;
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                .comId(22)
                .build());
        
        // Mock
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testClonarCorpus_ComPaginacaoNUll() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 0;
        Integer pagina = 5;
        int idClassificador = 6;
        
        List<Entidade> listaEntidade = Arrays.asList(umEntidade()
                .comId(22)
                .build());
        
        Paginacao<Entidade> paginacao = new Paginacao<Entidade>();
        
        // Mock
        when(entidadeDao.findByClassificador(idClassificador)).thenReturn(listaEntidade);
        when(entidadeManager.listarEntidades(idClassificadorOrigem, null, paginacao, 0, true)).thenReturn(null);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUm() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .build());
        
        List<TipoRespostaIntencao> respostasClone = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)// Teste com id diferente
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(13)), Mockito.any())).thenReturn(respostasClone);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmECampoBooleanIgualATrue() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        TipoRespostaIntencaoPK pk = umTipoRespostaIntencaoPK().build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .comId(pk)
                .build());
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comPergunta("Pergunta")// Com valor Null
                .build());
        List<Pergunta> perguntasClone = Arrays.asList(umPergunta()
                .comPergunta("Pergunta")// Teste com pergunta diferente
                .build());
        
        // Mock
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(perguntasClone);
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(perguntas);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmECampoBooleanIgualATrueComPerguntasDiferentes() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        TipoRespostaIntencaoPK pk = umTipoRespostaIntencaoPK().build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .comId(pk)
                .build());
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comPergunta("Pergunta")
                .build());
        List<Pergunta> perguntasClone = Arrays.asList(umPergunta()
                .comPergunta("Pergunta Diferente")
                .build());
        
        // Mock
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(perguntasClone);
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(perguntas);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmECampoBooleanIgualATrueComMetodoPerguntasNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        TipoRespostaIntencaoPK pk = umTipoRespostaIntencaoPK().build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .comId(pk)
                .build());
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta()
                .comPergunta(null)
                .build());
        List<Pergunta> perguntasClone = Arrays.asList(umPergunta()
                .comPergunta("Pergunta")
                .build());
        
        // Mock
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(perguntasClone);
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(perguntas);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmECampoBooleanIgualATrueEPerguntasNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        TipoRespostaIntencaoPK pk = umTipoRespostaIntencaoPK().build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .comId(pk)
                .build());
        
        List<Pergunta> perguntas = null;
        List<Pergunta> perguntasClone = new ArrayList<Pergunta>();
        
        // Mock
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(perguntasClone);
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(perguntas);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmECampoBooleanIgualATrueEIdDePaginaçãoDestinoNUll() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(null)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        TipoRespostaIntencaoPK pk = umTipoRespostaIntencaoPK().build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .comId(pk)
                .build());
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta().build());// Teste com valor Null
        List<Pergunta> perguntasClone = new ArrayList<Pergunta>();
        
        // Mock
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(perguntasClone);
        when(perguntaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(perguntas);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmDiferente() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        TipoRespostaIntencaoPK pk = umTipoRespostaIntencaoPK().build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .comId(pk)
                .build());
        
        TipoResposta tipoResposta2 = umTipoResposta()
                .comId(114)
                .build();
        List<TipoRespostaIntencao> respostasClone = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta2)
                .comId(pk)
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(13)), Mockito.any())).thenReturn(respostasClone);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmComRespostasNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .build());
        
        TipoResposta tipoResposta = umTipoResposta()
                .comId(113)
                .build();
        List<TipoRespostaIntencao> respostas = null;
        
        List<TipoRespostaIntencao> respostasClone = Arrays.asList(umTipoRespostaIntencao()
                .comTipoResposta(tipoResposta)
                .build());
        
        // Mock
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(13)), Mockito.any())).thenReturn(respostasClone);
        when(tipoRespostaIntencaoDao.findAll(Mockito.eq(new Integer(10)), Mockito.any())).thenReturn(respostas);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmComNumeroIN() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;// Teste com pagina menor que um, igual a um  ou null.
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .comNumeroIN("19")
                .build());
        
        // Mock
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmComNumeroINNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;// Teste com pagina menor que um, igual a um  ou null.
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .comNumeroIN(null)
                .build());
        
        // Mock
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmComNumeroINsNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;// Teste com pagina menor que um, igual a um  ou null.
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = Arrays.asList(umInstrucaoNormativa()
                .comIntencao(intOrigem)
                .comEditarCampo(true)
                .comNumeroIN(null)
                .build());
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comEditarCampo(true)
                .comNumeroIN(null)
                .build());
        
        // Mock
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualAUmEINsNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(122).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Origem")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .comFluxo(fluxo)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        List<InstrucaoNormativa> INs = null;
        
        List<InstrucaoNormativa> INsClone = Arrays.asList(umInstrucaoNormativa()
                .comNumeroIN("19")
                .build());
        
        // Mock
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(13)))).thenReturn(INsClone);
        when(instrucaoNormativaDao.findByIntencao(Mockito.eq(new Integer(10)))).thenReturn(INs);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComNomesDePaginacaoDiferentes() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;// Teste com pagina menor que um, igual a um  ou null.
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(idClassificadorOrigem)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao Origem")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao()
                .comId(13)
                .comNome("Intencao Destino")
                .comIdClassificador(idClassificadorDestino)
                .build()));
        
        Intencao intOrigem = umIntencao()
                .comNome("Intencao Origem")
                .comId(11)
                .build();
        
        List<TipoRespostaIntencao> respostasOrigem = Arrays.asList(umTipoRespostaIntencao().build());
        
        // Mock
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        when(tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null)).thenReturn(respostasOrigem);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualADois() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
//        #######################################################################################
//        #######################################################################################
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao")
                .build();// Teste com valor null
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome("paginacao")// Teste com nome diferente, null e vazio
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()// Teste com valor null
                .comEntidade(entidade)
                .comId(16)
                .comNome("paginacao")
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()// teste com obj null
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(entidadeDao.findById(Mockito.any())).thenReturn(entidade);
        when(intencaoDao.findByNomeIntencao(nome,idClassificadorDestino)).thenReturn(intencoesDestino);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_SemNomeNAgrupador() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
//        #######################################################################################
//        #######################################################################################
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao")
                .build();// Teste com valor null
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome("paginacao")// Teste com nome diferente, null e vazio
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()// Teste com valor null
                .comEntidade(entidade)
                .comId(16)
                .comNome(" ")
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()// teste com obj null
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(entidadeDao.findById(Mockito.any())).thenReturn(entidade);
        when(intencaoDao.findByNomeIntencao(nome,idClassificadorDestino)).thenReturn(intencoesDestino);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComNomeAgrupadorNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao")
                .build();
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome("paginacao")
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comId(16)
                .comNome(" ")
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(entidadeDao.findById(Mockito.any())).thenReturn(entidade);
        when(intencaoDao.findByNomeIntencao(nome,idClassificadorDestino)).thenReturn(intencoesDestino);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComNomeDoAgrupadorNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao")
                .build();
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome(null)
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comId(16)
                .comNome(entidade.getNome())
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(entidadeDao.findById(Mockito.any())).thenReturn(entidade);
        when(intencaoDao.findByNomeIntencao(nome,idClassificadorDestino)).thenReturn(intencoesDestino);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComNomeDoAgrupadorVazio() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao")
                .build();
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome("")
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comId(16)
                .comNome(entidade.getNome())
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(entidadeDao.findById(Mockito.any())).thenReturn(entidade);
        when(intencaoDao.findByNomeIntencao(nome,idClassificadorDestino)).thenReturn(intencoesDestino);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualADoisEComJumpNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        String nome2 = "Nome 2";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao2")
                .build();
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome("Entidade")
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comNome("Paginacao")
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> jump = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .comIdClassificador(1)
                .build());
        
        List<Intencao> intencoesDestino2 = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(115)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.eq(new String("Intencao")),Mockito.eq(new Integer(2)))).thenReturn(intencoesDestino2);
        when(intencaoDao.findByNomeIntencao(Mockito.eq(new String("Intencao2")),Mockito.eq(new Integer(2)))).thenReturn(null);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(jump.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComAtualizarFluxo() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        String nome2 = "Nome 2";
        
        Classificador classificador = umClassificador().comId(1).build();
        Intencao intencao = umIntencao()
                .comNome("Intecao")
                .build();
        Entidade entidade = umEntidade()
                .comId(15)
                .comNome("Entidade")
                .build();
        AgruparEntidadeSinonimos agrupador = umAgruparEntidadeSinonimos()
                .comEntidade(entidade)
                .comNome("Paginacao")
                .build();
        FluxoItemVO bloco = umFluxoItemVO().comId(122).build();
        FluxoItemVO fluxoItem = umFluxoItemVO()
                .comAgrupador(agrupador)
                .comIntencaoAcionada(intencao)
                .comListaBlocoFluxos(bloco)
                .comId(123)
                .build();
        FluxoVO fluxo = umFluxoVO()
                .comId(0)
                .comListaFluxos(fluxoItem)
                .build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        List<Intencao> intencoesDestino2 = Arrays.asList(umIntencao()
                .comId(110)
                .comNome(nome2)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.eq(new String("Nome 2")),Mockito.eq(new Integer(2)))).thenReturn(intencoesDestino2);
        when(intencaoDao.findByNomeIntencao(Mockito.eq(new String("Nome")),Mockito.eq(new Integer(1)))).thenReturn(intencoesDestino);
        when(entidadeDao.findById(fluxoItem.getAgrupador().getEntidade().getId())).thenReturn(entidade);
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino2);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(2)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComFluxoVOVazio() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComNecessitaDesambiguacaoFalse() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoItemVO fluxoItem = umFluxoItemVO().build();
        FluxoVO fluxo = umFluxoVO().comId(0).comListaFluxos(fluxoItem).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(false)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(0)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(0)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComIntencoesDestinoNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoItemVO fluxoItem = umFluxoItemVO().build();
        FluxoVO fluxo = umFluxoVO().comId(0).comListaFluxos(fluxoItem).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = null;
        
        FluxoVO flxDestino = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoDao.findByNomeIntencao(nome,idClassificadorDestino)).thenReturn(intencoesDestino);
        when(intencaoManager.buscaFluxo(Mockito.any())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(0)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComflxDestinoId22() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoItemVO fluxoItem = umFluxoItemVO().build();
        FluxoVO fluxo = umFluxoVO().comId(0).comListaFluxos(fluxoItem).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = umFluxoVO().comId(22).build();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(0)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComflxDestinoNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoItemVO fluxoItem = umFluxoItemVO().build();
        FluxoVO fluxo = umFluxoVO().comId(0).comListaFluxos(fluxoItem).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        FluxoVO flxDestino = null;
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoManager.buscaFluxo(intencoesDestino.get(0).getId())).thenReturn(flxDestino);
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComFluxoItemVOVazio() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoItemVO fluxoItem = new FluxoItemVO();
        FluxoVO fluxo = umFluxoVO().comId(0).comListaFluxos(fluxoItem).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comFluxo(fluxo)
                .comId(114)
                .build());
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComFluxoNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(null)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comId(114)
                .build());
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoManager.buscaFluxo(fluxo.getId())).thenReturn(fluxo);
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
        verify(intencaoManager, times(1)).buscaFluxo(fluxo.getId());
    }
    
    @Test
    public void testClonarCorpus_ComListIntencaoNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = null;
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComListIntencaoVazia() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(1)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = new ArrayList<Intencao>();
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(1)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualADois_ComPaginacaoPreenchido() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(null);
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comId(114)
                .build());
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(Arrays.asList(umIntencao().build()));
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(0)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualADois_ComPaginacaonull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 2;
        Integer pagina = 2;
        String nome = "Nome";
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(null);
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comId(114)
                .build());
        
        Paginacao<Intencao> paginacaoDestino = new Paginacao<Intencao>();
        paginacaoDestino.setListaPaginada(null);
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(1)), Mockito.any())).thenReturn(paginacaoIntencao);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.eq(new Integer(2)), Mockito.any())).thenReturn(paginacaoDestino);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(0)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComOrdemIgualATres() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 3;
        Integer pagina = 2;
        String nome = "Nome";
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().comId(0).build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(0)
                .comIdClassificador(11)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        List<Intencao> intencoesDestino = Arrays.asList(umIntencao()
                .comNome(nome)
                .comId(114)
                .build());
        
        // Mock
        when(intencaoDao.findByNomeIntencao(Mockito.any(),Mockito.any())).thenReturn(intencoesDestino);
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(paginacaoIntencao);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(intencaoDao, times(0)).findByNomeIntencao(Mockito.any(),Mockito.any());
        verify(intencaoDao, times(2)).findIntencao(Mockito.any(), Mockito.any(), Mockito.any());
    }
    
    @Test
    public void testClonarCorpus_ComPaginaIgualA2() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 2;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(11)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        paginacaoIntencao.getListaPaginada();
        
        // Mock
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(paginacaoIntencao);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testClonarCorpus_ComPaginaMenorQueUm() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = 0;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(11)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        paginacaoIntencao.getListaPaginada();
        
        // Mock
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(paginacaoIntencao);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
    }
    
    @Test
    public void testClonarCorpus_ComPaginaNull() throws NoSuchMethodError, SecurityException, IllegalAccessError,
                                                                IllegalArgumentException, InvocationTargetException, NoSuchMethodException {
        
        // Cenario
        Integer idClassificadorOrigem = 1;
        Integer idClassificadorDestino = 2;
        Integer ordem = 1;
        Integer pagina = null;
        int idClassificador = 6;
        
        Classificador classificador = umClassificador().comId(1).build();
        FluxoVO fluxo = umFluxoVO().build();
        
        Paginacao<Intencao> paginacaoIntencao = new Paginacao<Intencao>();
        paginacaoIntencao.setListaPaginada(Arrays.asList(umIntencao()
                .comClassificador(classificador)
                .comDataCriacao(new Date(02/02/2020))
                .comDataModificacao(new Date(03/02/2020))
                .comDescricao("Descricao")
                .comFluxo(fluxo)
                .comHashNuvem("Nuvem")
                .comId(10)
                .comIdClassificador(11)
                .comNecessitaDesambiguacao(true)
                .comNome("Intencao")
                .comPerguntaCanonica("Pergunta")
                .build()));
        
        paginacaoIntencao.getListaPaginada();
        
        // Mock
        when(intencaoDao.findIntencao(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(paginacaoIntencao);
        
        // Açao
        cloneCorpusManager.clonarCorpus(idClassificadorOrigem, idClassificadorDestino, ordem, pagina);
        
        // Verificaçao
        verify(entidadeDao, times(0)).findByClassificador(idClassificador);
    }
}

