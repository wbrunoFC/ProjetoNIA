package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.AvaliacaoMotivoBuilder.umAvaliacaoMotivo;
import static br.com.bb.databuilder.AvaliacoesBuilder.umAvaliacoes;
import static br.com.bb.databuilder.FiltroAvaliacoesVOBuilder.umFiltroAvaliacoesVO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.AvaliacaoMotivoDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacoesDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoMotivo;
import br.com.bb.gearq.c4coleta.model.Avaliacoes;
import br.com.bb.gearq.c4coleta.vo.FiltroAvaliacoesVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

public class AvaliacaoMotivoManagerTest {
    /**
     * @author c1312334
     * @date 08/01/2020
     */
    
    @InjectMocks
    private AvaliacaoMotivoManager avaliacaoMotivoManager;
    
    @Mock
    private AvaliacaoMotivoDao avaliacaoMotivoDao;
    
    @Mock
    private AvaliacoesDao avaliacoesDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }

    @Test
    public void testListar() {
        // Cenario
        int idFormulario = 10;
        
        List<AvaliacaoMotivo> listar = Arrays.asList(umAvaliacaoMotivo().comId(idFormulario).build());
        
                
        // Mock
        when(avaliacaoMotivoDao.findByIdFormulario(idFormulario)).thenReturn(listar);
        
        // Acao
        avaliacaoMotivoManager.listar(idFormulario);
        
        
        // Verificacao
        verify(avaliacaoMotivoDao, times(1)).findByIdFormulario(idFormulario);
        
    }
    
//    ===== Cenario 2 >> if(lista = null) >> LINHA 37
    @Test
    public void testListaNull () {
     // Cenario
        int idFormulario = 10;
        
        List<AvaliacaoMotivo> listar = null;
        
     // Mock
        when(avaliacaoMotivoDao.findByIdFormulario(idFormulario)).thenReturn(listar);
        
     // Acao
     avaliacaoMotivoManager.listar(idFormulario);
        
        
     // Verificacao
     verify(avaliacaoMotivoDao, times(1)).findByIdFormulario(idFormulario);
    }
    
// ===== Cenario 1 ====
    @Test
    public void testVerificarMotivoComAvaliacoes() {
        // Cenario
        int idMotivo = 10;
        Paginacao<Avaliacoes> listaAvaliacoes = returnListaAvaliacoes();
        
        // Mock
        when(avaliacoesDao.pesquisar(Mockito.any(FiltroAvaliacoesVO.class))).thenReturn(listaAvaliacoes);
        
        // Acao
        boolean verificarMotivoComAvaliacoes = avaliacaoMotivoManager.verificarMotivoComAvaliacoes(idMotivo);

        assertThat(verificarMotivoComAvaliacoes).isTrue();
        
    }

// ==== Cenario 2 ==== if(listaAvaliacoes.getTotalRegistros() == 0)
    @Test
    public void testTotalRegistrosZero() {
        // Cenario
        int idMotivo = 0;
        FiltroAvaliacoesVO filtroAvaliacoesVO = umFiltroAvaliacoesVO().comIdMotivo(idMotivo).build(); 
        
        Paginacao<Avaliacoes> listaAvaliacoes = new Paginacao<>();
        
        listaAvaliacoes.setTotalRegistros(0L);
        
        // Mock
        when(avaliacoesDao.pesquisar(Mockito.any(FiltroAvaliacoesVO.class))).thenReturn(listaAvaliacoes);
        
        // Açao
        boolean verificarMotivoComAvaliacoes = avaliacaoMotivoManager.verificarMotivoComAvaliacoes(idMotivo);

        // Verificaçao
        assertThat(verificarMotivoComAvaliacoes).isFalse();
        
    }
    
//  ==== Cenario 1 ====
    @Test
    public void testExcluir() {
        // Cenario
        AvaliacaoMotivo avaliacaoMotivo = umAvaliacaoMotivo().comId(12).build();
        
        // Mock
        when(avaliacaoMotivoDao.persist(avaliacaoMotivo)).thenReturn(avaliacaoMotivo);
        when(avaliacaoMotivoDao.findById(avaliacaoMotivo.getId())).thenReturn(avaliacaoMotivo);
        avaliacaoMotivoDao.remove(avaliacaoMotivo);
        
        Paginacao<Avaliacoes> listaAvaliacoes = returnListaAvaliacoes();
        
        when(avaliacoesDao.pesquisar(Mockito.any(FiltroAvaliacoesVO.class))).thenReturn(listaAvaliacoes);
        
        // Acao
        avaliacaoMotivoManager.excluir(avaliacaoMotivo);
        
        // Verificacao
        verify(avaliacaoMotivoDao, times(1)).persist(avaliacaoMotivo);
        verify(avaliacaoMotivoDao, times(0)).findById(avaliacaoMotivo);
        verify(avaliacaoMotivoDao).remove(avaliacaoMotivo);
    }

//  ==== Cenario 2 ====
    @Test
    public void testExcluir2 () {
        // Cenario
        AvaliacaoMotivo avaliacaoMotivo = umAvaliacaoMotivo().comId(10).build();
        
        Paginacao<Avaliacoes> listaAvaliacoes = new Paginacao<>();
        
        listaAvaliacoes.setTotalRegistros(0L);
        
        // Mock
        when(avaliacoesDao.pesquisar(Mockito.any(FiltroAvaliacoesVO.class))).thenReturn(listaAvaliacoes);
        when(avaliacaoMotivoDao.findById(avaliacaoMotivo.getId())).thenReturn(avaliacaoMotivo);
//        avaliacaoMotivo.getNotas().clear();
//        avaliacaoMotivoDao.remove(avaliacaoMotivo);
        
        // Açao
        avaliacaoMotivoManager.excluir(avaliacaoMotivo);
        
        // verificaçao
    }
    @Test
    public void testDesabilitar() {
        // Cenario
        AvaliacaoMotivo avaliacaoMotivo = umAvaliacaoMotivo().comId(12).build();
        avaliacaoMotivo.getIdAvaliacaoFormulario();
        avaliacaoMotivo.getRespostaAberta();
        avaliacaoMotivo.getNotasSimples();
        avaliacaoMotivo.getStatus();
        
        // Mock
        when(avaliacaoMotivoDao.persist(avaliacaoMotivo)).thenReturn(avaliacaoMotivo);
        
        // Acao
        avaliacaoMotivoManager.desabilitar(avaliacaoMotivo);
        
        // Verificacao
        verify(avaliacaoMotivoDao, times(1)).persist(avaliacaoMotivo);
    }
    
// =========== Metodo extraído =============
    private Paginacao<Avaliacoes> returnListaAvaliacoes() {
        int idMotivo = 10;
        FiltroAvaliacoesVO filtroAvaliacoesVO = umFiltroAvaliacoesVO().comIdMotivo(idMotivo).build(); 
        
        Paginacao<Avaliacoes> listaAvaliacoes = new Paginacao<>();
        listaAvaliacoes.setListaPaginada(Arrays.asList(umAvaliacoes()
                .comIdMotivo(filtroAvaliacoesVO.getIdMotivo())
                .build()));
        
        listaAvaliacoes.setTotalRegistros(1L);
        
        return listaAvaliacoes;
    }
}
