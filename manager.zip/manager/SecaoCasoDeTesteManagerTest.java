package br.com.bb.gearq.c4coleta.manager;
import static br.com.bb.databuilder.CenarioEsperadoBuilder.umCenarioEsperado;
import static br.com.bb.databuilder.SecaoCasoDeTesteBuilder.umSecaoCasoDeTeste;
import static br.com.bb.databuilder.SecaoCasoDeTesteNoSalvarVoBuilder.umSecaoCasoDeTesteNoSalvarVo;
import static br.com.bb.databuilder.SecaoCasoDeTesteNoVoBuilder.umSecaoCasoDeTesteNoVo;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.SecaoCasoDeTesteDao;
import br.com.bb.gearq.c4coleta.model.CenarioEsperado;
import br.com.bb.gearq.c4coleta.model.SecaoCasoDeTeste;
import br.com.bb.gearq.c4coleta.vo.SecaoCasoDeTesteNoSalvarVo;
import br.com.bb.gearq.c4coleta.vo.SecaoCasoDeTesteNoVo;

public class SecaoCasoDeTesteManagerTest {
    /**
     * @author c1312334
     */

    @InjectMocks
    private SecaoCasoDeTesteManager secaoCasoDeTesteManager;
    
    @Mock
    private SecaoCasoDeTesteDao secaoCasoDeTesteDao;
    
    @Mock
    private CenarioEsperadoManager cenarioEsperadoManager; 
    
    @Mock
    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
      }
    
    @Test
    public void testObter() {
        // Cenario
        Integer idSecao = new Integer(2);
        
        SecaoCasoDeTeste secao  = umSecaoCasoDeTeste().comId(idSecao).build();
        
        // Mock
        when( secaoCasoDeTesteDao.findById(idSecao)).thenReturn(secao);
       
        // Açao
        secaoCasoDeTesteManager.obter(idSecao);
        
        // verifcaçao
        verify(secaoCasoDeTesteDao, times(1)).findById(idSecao);
    }

    @Test
    public void testListar() {
        // Cenario
        Integer idCasoDeTesteClassificador = new Integer(10);
        
        List<SecaoCasoDeTeste> secao = Arrays.asList(umSecaoCasoDeTeste()
                                                     .comId(idCasoDeTesteClassificador)
                                                     .build());
        
        secao.get(0).getCasoDeTeste();
        secao.get(0).getTextoEntrada();
        secao.get(0).getJson();
        secao.get(0).hashCode();
        Object obj = new Object();
        secao.get(0).equals(obj);
        
        // Mock
        when(secaoCasoDeTesteDao.findByIdCasoDeTesteClassificador(idCasoDeTesteClassificador)).thenReturn(secao);
        
        // Açao
        secaoCasoDeTesteManager.listar(idCasoDeTesteClassificador);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(1)).findByIdCasoDeTesteClassificador(idCasoDeTesteClassificador);
    }
    
    @Test
    public void testListar_ComObjNull() {
        // Cenario
        Integer idCasoDeTesteClassificador = new Integer(10);
        
        List<SecaoCasoDeTeste> secao = Arrays.asList(umSecaoCasoDeTeste()
                                                     .comId(idCasoDeTesteClassificador)
                                                     .build());
        
        secao.get(0).getCasoDeTeste();
        secao.get(0).getTextoEntrada();
        secao.get(0).getJson();
        secao.get(0).hashCode();
        Object obj = null;
        secao.get(0).equals(obj);
        
        // Mock
        when(secaoCasoDeTesteDao.findByIdCasoDeTesteClassificador(idCasoDeTesteClassificador)).thenReturn(secao);
        
        // Açao
        secaoCasoDeTesteManager.listar(idCasoDeTesteClassificador);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(1)).findByIdCasoDeTesteClassificador(idCasoDeTesteClassificador);
    }

//    ===== Cenario 1 ===== (secao.getCenarios() = null)
    @Test
    public void testSalvar() {
     // Cenario
        List<CenarioEsperado> cenarioEsperado = null;
        
        SecaoCasoDeTeste secao = new SecaoCasoDeTeste();
        secao.setCenarios(cenarioEsperado);
        secao.setId(null);
        
        CenarioEsperado cenario = null;
        
        // Mock
        secaoCasoDeTesteDao.persist(secao);
        when(cenarioEsperadoManager.salvar(Mockito.any(CenarioEsperado.class))).thenReturn(cenario);
        
        // Açao
        secaoCasoDeTesteManager.salvar(secao);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(2)).persist(secao);
    }
    
//    ===== Cenario 2 ===== (secao.getCenarios() != null)
    @Test
    public void testSecaoDiferenteDeNull () {
        // Cenario
        List<CenarioEsperado> cenarioEsperado = Arrays.asList(umCenarioEsperado().comId(120).build());

        SecaoCasoDeTeste secao = new SecaoCasoDeTeste();
        secao.setCenarios(cenarioEsperado);
        secao.setId(cenarioEsperado.get(0).getId());
        
        CenarioEsperado cenario = umCenarioEsperado().comId(1).build();
        
        // Mock
        when(secaoCasoDeTesteDao.persist(secao)).thenReturn(secao);
        when(cenarioEsperadoManager.salvar(Mockito.any(CenarioEsperado.class))).thenReturn(cenario);
        
        // Açao
        secaoCasoDeTesteManager.salvar(secao);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(1)).persist(secao);
    }
    
    @Test
    public void testCriar() {
        // Cenario
        SecaoCasoDeTesteNoSalvarVo secaoSelecionado = umSecaoCasoDeTesteNoSalvarVo().comIdSecaoSelecionado(188).build();
        
        SecaoCasoDeTesteNoSalvarVo salvaNo = umSecaoCasoDeTesteNoSalvarVo()
                                            .comIdSecaoSelecionado(secaoSelecionado.getIdSecaoSelecionado())
                                            .comSequenciaRegistroHierarquia(13)
                                            .comIdCasoDeTesteClassificador(10)
                                            .build();
        
        SecaoCasoDeTesteNoVo casoDeTesteNoVo = umSecaoCasoDeTesteNoVo().comId(45).build();
        
        SecaoCasoDeTeste secaoCasoDeTeste = umSecaoCasoDeTeste()
                                            .comId(casoDeTesteNoVo.getId())
                                            .comNumeroSequencial(88)
                                            .build();
        
        CenarioEsperado cenarioEsperado = umCenarioEsperado().comId(122).build();
        
        // Mock
        ArgumentCaptor<SecaoCasoDeTeste> secaoCapturAada = ArgumentCaptor.forClass(SecaoCasoDeTeste.class);
        when(secaoCasoDeTesteDao.persist(secaoCapturAada.capture())).thenReturn(secaoCasoDeTeste);
        when(cenarioEsperadoManager.criar(Mockito.anyInt())).thenReturn(cenarioEsperado);
        when(secaoCasoDeTesteDao.findById(salvaNo.getIdSecaoSelecionado())).thenReturn(secaoCasoDeTeste);
        
        // Açao
        secaoCasoDeTesteManager.criar(salvaNo);
        
        // Verificaçao
       verify(secaoCasoDeTesteDao, times(1)).persist(secaoCapturAada.capture());
       verify(cenarioEsperadoManager).criar(Mockito.anyInt());
       verify(secaoCasoDeTesteDao, times(1)).findById(salvaNo.getIdSecaoSelecionado());
    }
    
//    ===== Cenario 1 ===== (salvaNo.getIdSecaoSelecionado() = null && salvaNo.getSequenciaRegistroHierarquia() = null)
    @Test
    public void testCriarDiferenteDeNull() {
        // Cenario
        SecaoCasoDeTesteNoSalvarVo salvaNo = umSecaoCasoDeTesteNoSalvarVo()
                .comIdSecaoSelecionado(12)
                .comSequenciaRegistroHierarquia(12)
                .build();

        SecaoCasoDeTesteNoVo casoDeTesteNoVo = umSecaoCasoDeTesteNoVo().comId(45).build();
        
        SecaoCasoDeTeste secaoCasoDeTeste = umSecaoCasoDeTeste()
                        .comId(casoDeTesteNoVo.getId())
                        .build();
        
        CenarioEsperado cenarioEsperado = umCenarioEsperado().comId(122).build();
        
        // Mock
        ArgumentCaptor<SecaoCasoDeTeste> secaoCapturAada = ArgumentCaptor.forClass(SecaoCasoDeTeste.class);
        when(secaoCasoDeTesteDao.persist(secaoCapturAada.capture())).thenReturn(secaoCasoDeTeste);
        when(cenarioEsperadoManager.criar(Mockito.anyInt())).thenReturn(cenarioEsperado);
        when(secaoCasoDeTesteDao.findById(salvaNo.getIdSecaoSelecionado())).thenReturn(null);
        
        // Açao
        secaoCasoDeTesteManager.criar(salvaNo);
        
        // verificaçao
        verify(secaoCasoDeTesteDao, times(1)).persist(secaoCapturAada.capture());
        verify(cenarioEsperadoManager).criar(Mockito.anyInt());
        verify(secaoCasoDeTesteDao, times(1)).findById(salvaNo.getIdSecaoSelecionado());
        
    }
    
    @Test
    public void testSequenciaRegistroHierarquiaNull() {
        // Cenario
        SecaoCasoDeTesteNoSalvarVo salvaNo = umSecaoCasoDeTesteNoSalvarVo()
                .comIdSecaoSelecionado(12)
                .comSequenciaRegistroHierarquia(null)
                .build();

        SecaoCasoDeTesteNoVo casoDeTesteNoVo = umSecaoCasoDeTesteNoVo().comId(45).build();
        
        SecaoCasoDeTeste secaoCasoDeTeste = umSecaoCasoDeTeste()
                        .comId(casoDeTesteNoVo.getId())
                        .build();
        
        CenarioEsperado cenarioEsperado = umCenarioEsperado().comId(122).build();
        
        // Mock
        ArgumentCaptor<SecaoCasoDeTeste> secaoCapturAada = ArgumentCaptor.forClass(SecaoCasoDeTeste.class);
        when(secaoCasoDeTesteDao.persist(secaoCapturAada.capture())).thenReturn(secaoCasoDeTeste);
        when(cenarioEsperadoManager.criar(Mockito.anyInt())).thenReturn(cenarioEsperado);
        
        // Açao
        secaoCasoDeTesteManager.criar(salvaNo);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(1)).persist(secaoCapturAada.capture());
        verify(cenarioEsperadoManager).criar(Mockito.anyInt());
    }
    
    @Test
    public void testIdSecaoSelecionadoNull() {
        // Cenario
        SecaoCasoDeTesteNoSalvarVo salvaNo = umSecaoCasoDeTesteNoSalvarVo()
                .comIdSecaoSelecionado(null)
                .comSequenciaRegistroHierarquia(12)
                .build();

        SecaoCasoDeTesteNoVo casoDeTesteNoVo = umSecaoCasoDeTesteNoVo().comId(45).build();
        
        SecaoCasoDeTeste secaoCasoDeTeste = umSecaoCasoDeTeste()
                        .comId(casoDeTesteNoVo.getId())
                        .build();
        
        CenarioEsperado cenarioEsperado = umCenarioEsperado().comId(122).build();
        
        // Mock
        ArgumentCaptor<SecaoCasoDeTeste> secaoCapturAada = ArgumentCaptor.forClass(SecaoCasoDeTeste.class);
        when(secaoCasoDeTesteDao.persist(secaoCapturAada.capture())).thenReturn(secaoCasoDeTeste);
        when(cenarioEsperadoManager.criar(Mockito.anyInt())).thenReturn(cenarioEsperado);
        
        // Açao
        secaoCasoDeTesteManager.criar(salvaNo);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(1)).persist(secaoCapturAada.capture());
        verify(cenarioEsperadoManager).criar(Mockito.anyInt());
    }

    @Test
    public void testExcluirAtualizarSequencia() {
        // Cenario
        Integer idSecao = new Integer(22);
        Integer idCaso = new Integer(32);
        
        SecaoCasoDeTeste secao = umSecaoCasoDeTeste().comId(idSecao).comIdCasoDeTesteClassificador(idCaso).build();

        // Mock
        when(secaoCasoDeTesteDao.findById(idSecao)).thenReturn(secao);
        cenarioEsperadoManager.excluir(Mockito.any(CenarioEsperado.class));

        // Açao
        secaoCasoDeTesteManager.excluirAtualizarSequencia(idSecao);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(0)).findById(idCaso);
    }

    @Test
    public void testExcluir() {
        // Cenario
        List<CenarioEsperado> cenarios = Arrays.asList(umCenarioEsperado().comId(14).build());
        
        SecaoCasoDeTeste secao = umSecaoCasoDeTeste().comListaCenarios(cenarios).build();

        // Mock
        cenarioEsperadoManager.excluir(Mockito.any(CenarioEsperado.class));
        secaoCasoDeTesteDao.remove(secao);
        
        // Açao
        secaoCasoDeTesteManager.excluir(secao);
        
        // Verificaçao
        verify(secaoCasoDeTesteDao, times(2)).remove(secao);
    }
}
