package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;

import static br.com.bb.databuilder.ServicoNlcBuilder.umServicoNlc;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static br.com.bb.databuilder.ServicosCognitivosBuilder.umServicosCognitivos;
import static br.com.bb.databuilder.UtilizacaoServicosCognitivosVOBuilder.umUtilizacaoServicosCognitivosVO;
import static br.com.bb.databuilder.FiltrosUtilizacaoServicoVOBuilder.umFiltrosUtilizacaoServicoVO;
import static br.com.bb.databuilder.DadosPeriodoUtilizacaoVOBuilder.umDadosPeriodoUtilizacaoVO;
import static br.com.bb.databuilder.ConsolidadoDemandanteVOBuilder.umConsolidadoDemandanteVO;
import static br.com.bb.databuilder.ResumoPeriodoVOBuilder.umResumoPeriodoVO;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.ServicoNlcDao;
import br.com.bb.gearq.c4coleta.dao.ServicosCognitivosDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.ServicosCognitivos;
import br.com.bb.gearq.c4coleta.vo.ConsolidadoDemandanteVO;
import br.com.bb.gearq.c4coleta.vo.DadosPeriodoUtilizacaoVO;
import br.com.bb.gearq.c4coleta.vo.FiltrosUtilizacaoServicoVO;
import br.com.bb.gearq.c4coleta.vo.ResumoPeriodoVO;
import br.com.bb.gearq.c4coleta.vo.UtilizacaoServicosCognitivosVO;

public class RelatorioUtilizacaoServicoManagerTest {
    
    @InjectMocks
    private RelatorioUtilizacaoServicoManager relatorioUtilizacaoServicoManager;
    
    @Mock
    private ServicoNlcDao servicoNlcDao;
    
    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private ServicosCognitivosDao servicosCognitivosDao;
    
    @Mock
    private NuvemWatsonDao nuvemWatsonDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    
    @Test
    public void testServiçosNuvem() {
        //Cenário        
        List<ServicoNlc> listaServico = Arrays.asList(
                umServicoNlc().build()
                );
        
        //Mock
        when(servicoNlcDao.findByServicoNuvem()).thenReturn(listaServico);
        
        //Ação
        relatorioUtilizacaoServicoManager.serviçosNuvem();
        
        //Verificação
        verify(servicoNlcDao, times(1)).findByServicoNuvem();
        
    }
    
    
    @Test
    public void testClassificadorNuvemInformandoOServico() {
        //Cenário       
        int idServico = 1;
        
        List<Classificador> listaServico = Arrays.asList(
                umClassificador().build(),
                umClassificador().build()
                );
               
        //Mock
        when(classificadorDao.classificadorNuvemServico(idServico)).thenReturn(listaServico);
        
        //Ação
        relatorioUtilizacaoServicoManager.classificadorNuvem(idServico);
        
        //Verificação
        verify(classificadorDao, times(1)).classificadorNuvemServico(idServico);
    }
    
    
    @Test
    public void testClassificadorNuvemNãoInformandoOServico() {
        //Cenário       
        int idServico = 0;
        
        List<Classificador> listaServico = Arrays.asList(
                umClassificador().build()
                );
        
        //Mock
        when(classificadorDao.classificadorNuvem()).thenReturn(listaServico);
        
        //Ação
        relatorioUtilizacaoServicoManager.classificadorNuvem(idServico);
        
        //Verificação
        verify(classificadorDao, times(1)).classificadorNuvem();
        
    }
    
    
    @Test
    public void testNuvemCredencialInformandoOClassificador() {
        //Cenário      
        int idClassificador = 1;
        
        List<NuvemWatson> lista = Arrays.asList(
                umNuvemWatson().build(),
                umNuvemWatson().build()
                );
        
        //Mock
        when(nuvemWatsonDao.findByClassificador(idClassificador)).thenReturn(lista);
        
        //Ação
        relatorioUtilizacaoServicoManager.nuvemCredencial(idClassificador);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findByClassificador(idClassificador);
    }

    
    @Test
    public void testNuvemCredencialNaoInformandoOClassificador() {
        //Cenário      
        int idClassificador = 0;
        
        List<NuvemWatson> lista = Arrays.asList(
                umNuvemWatson().build(),
                umNuvemWatson().build()
                );
        
        //Mock
        when(nuvemWatsonDao.findCredenciaisNuvem()).thenReturn(lista);
        
        //Ação
        relatorioUtilizacaoServicoManager.nuvemCredencial(idClassificador);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findCredenciaisNuvem();
    }
    
    @Test
    public void testListaServicosCognitivos() {
        //Cenário      
        List<ServicosCognitivos> lista = Arrays.asList(
                umServicosCognitivos().build(),
                umServicosCognitivos().build()
                );
        lista.get(0).getId();
        lista.get(0).getNome();
        lista.get(0).getStatus();
        
        //Mock
        when(servicosCognitivosDao.findAll()).thenReturn(lista);
        
        //Ação
        relatorioUtilizacaoServicoManager.listaServicosCognitivos();
        
        //Verificação
        verify(servicosCognitivosDao, times(1)).findAll();
    }
    
    @Test
    public void testPesquisa() {
        //Cenário          
        FiltrosUtilizacaoServicoVO filtro = umFiltrosUtilizacaoServicoVO().build();
        
        List<DadosPeriodoUtilizacaoVO> listaDados = Arrays.asList( 
                umDadosPeriodoUtilizacaoVO().comNomeBot("Bot 1").build(),
                umDadosPeriodoUtilizacaoVO().comNomeBot("Bot 2").build()
                );
              
        List<ConsolidadoDemandanteVO> listaDemandante = Arrays.asList(
                umConsolidadoDemandanteVO().comNomeDemandante("Gserv").build(),
                umConsolidadoDemandanteVO().comNomeDemandante("Coger").build()
                );
        
        List<ResumoPeriodoVO> listaResumo = Arrays.asList(
                umResumoPeriodoVO().comNomeDemandante("Gserv").build(),
                umResumoPeriodoVO().comNomeDemandante("Coger").build()
                );
        
        UtilizacaoServicosCognitivosVO utilizacao = umUtilizacaoServicosCognitivosVO()
                                                    .comListaDadosPeriodo(listaDados)
                                                    .comListaConsolidadoDemandante(listaDemandante)
                                                    .comListaResumoPeriodo(listaResumo)
                                                    .build();
        
        //Mock
        when(nuvemWatsonDao.findUtilizacaoServicoCognitivoDadosPeriodo(filtro)).thenReturn(listaDados);
        when(nuvemWatsonDao.findUtilizacaoServicoCognitivoConsolidadoDemandante(filtro)).thenReturn(listaDemandante);
        when(nuvemWatsonDao.findUtilizacaoServicoCognitivoResumoPeriodo(filtro)).thenReturn(listaResumo);
        
        //Ação
        relatorioUtilizacaoServicoManager.pesquisa(filtro);
        
        //Verificação
        verify(nuvemWatsonDao, times(1)).findUtilizacaoServicoCognitivoDadosPeriodo(filtro);
        verify(nuvemWatsonDao, times(1)).findUtilizacaoServicoCognitivoConsolidadoDemandante(filtro);
        verify(nuvemWatsonDao, times(1)).findUtilizacaoServicoCognitivoResumoPeriodo(filtro);
        
        assertNotNull(utilizacao);
    }
  

}
