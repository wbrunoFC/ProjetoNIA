package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.AtivarSincronizacaoVOBuilder.umAtivarSincronizacaoVO;
import static br.com.bb.databuilder.CredencialWatsonBuilder.umCredencialWatson;
import static br.com.bb.databuilder.NuvemWatsonBuilder.umNuvemWatson;
import static br.com.bb.databuilder.SincronizacaoBuilder.umSincronizacao;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import br.com.bb.gearq.c4coleta.dao.CredencialWatsonDao;
import br.com.bb.gearq.c4coleta.dao.SincronizacaoDao;
import br.com.bb.gearq.c4coleta.model.CredencialWatson;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.Sincronizacao;
import br.com.bb.gearq.c4coleta.vo.AtivarSincronizacaoVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class SincronizacaoManagerTest {
    @InjectMocks
    private SincronizacaoManager sincronizacaoManager;

    @Mock
    private SincronizacaoDao sincronizacaoDao;
    
    @Mock
    private CredencialWatsonDao credencialWatsonDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testConsultarUltimaSincronizacao() {
        //Cenário
        int idClassificador = 1;
        
        Sincronizacao s = umSincronizacao().comId(1).build();
        s.setClassificador(null);
        
        //Mock
        when(sincronizacaoDao.findByClassificador(idClassificador)).thenReturn(s);
        
        //Ação
        sincronizacaoManager.consultarUltimaSincronizacao(idClassificador);
        
        //Verificação
        verify(sincronizacaoDao, times(1)).findByClassificador(idClassificador);
        
    }
    
    @Test
    public void testListaSincronizacaoClassificador() {
        //Cenário
        Paginacao paginacao = new Paginacao<>();
        int idClassificador = 1;
        
        //Mock
        when(sincronizacaoDao.findByListaSincronizacao(paginacao, idClassificador)).thenReturn(paginacao);
        
        //Ação
        sincronizacaoManager.listaSincronizacaoClassificador(paginacao, idClassificador);
        
        //Verificação
        verify(sincronizacaoDao, times(1)).findByListaSincronizacao(paginacao, idClassificador);
        
    }
    
    @Test
    public void testAtivarSincronizacaoComSelecionadoNulo() {
      //Cenário
        NuvemWatson nuvem = umNuvemWatson().comSelecionado(null).build();
        AtivarSincronizacaoVO ativarSincronizacaoVO = umAtivarSincronizacaoVO().comListaListaNuvemWatson(nuvem).build();
        
        
        //Ação
        assertThatThrownBy(() -> {
            sincronizacaoManager.ativarSincronizacao(ativarSincronizacaoVO);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione uma ou mais Credenciais");
        
        
        //Verificação
    }
    
    @Test
    public void testAtivarSincronizacao() {
        //Cenário
        NuvemWatson nuvem = umNuvemWatson().comSelecionado(true).build();
        AtivarSincronizacaoVO ativarSincronizacaoVO = umAtivarSincronizacaoVO().comListaListaNuvemWatson(nuvem).build();
        
        List<CredencialWatson> credenciais = Arrays.asList(umCredencialWatson().comId(1)
                                                                               .comNome("Nome da Credencial")
                                                                               .comNuvemWatson(nuvem)
                                                                               .build());
        String workspaceQueDeveSerInativado = credenciais.get(0).getNome();
        
        List<Sincronizacao> listaAux = Arrays.asList(umSincronizacao().build());
        listaAux.get(0).getId();
        listaAux.get(0).getIdClassificador();
        listaAux.get(0).getClassificador();
        listaAux.get(0).getCdWorkspace();
        listaAux.get(0).getDataSincronizacao();
        listaAux.get(0).getIndicadorAtivo();
        listaAux.get(0).getVersaoCorpusResposta();
        listaAux.get(0).getNuvemWatson();
        listaAux.get(0).getIdUsuario();
        listaAux.get(0).getUsuario();
        listaAux.get(0).getDescricaoAtividade();
        
        //Mock
        when(credencialWatsonDao.findByIdNuvemIdParametro(nuvem.getId(), 3)).thenReturn(credenciais);
        when(sincronizacaoDao.findBySincronizacaoCdWorkspace(workspaceQueDeveSerInativado)).thenReturn(listaAux);
        
        //Ação
        sincronizacaoManager.ativarSincronizacao(ativarSincronizacaoVO);
        
        //Verificação
        verify(credencialWatsonDao, times(1)).findByIdNuvemIdParametro(nuvem.getId(), 3);
        verify(sincronizacaoDao, times(1)).findBySincronizacaoCdWorkspace(workspaceQueDeveSerInativado);
        
        
    }
    
}

