package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.TipoElementoBuilder.umTipoElemento;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.TipoElementoDao;
import br.com.bb.gearq.c4coleta.manager.TipoElementoManager;
import br.com.bb.gearq.c4coleta.model.TipoElemento;


public class TipoElementoManagerTest {
    
    @InjectMocks
    private TipoElementoManager tipoElementoManager;

    @Mock
    private TipoElementoDao tipoElementoDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testListar() {
        //Cenário
        List<TipoElemento> lista = Arrays.asList(umTipoElemento().build());
        lista.get(0).getId();
        lista.get(0).getNome();
        lista.get(0).getInValor();
        Object obj = new Object();
        lista.get(0).equals(obj);
        lista.get(0).hashCode();
        
        //Mock
        when(tipoElementoDao.findAll()).thenReturn(lista);
        
        //Ação
        tipoElementoManager.listar();
        
        //Verificação
        verify(tipoElementoDao, times(1)).findAll();
        
    }
    
    @Test
    public void testListar_ComObjNull() {
        //Cenário
        List<TipoElemento> lista = Arrays.asList(umTipoElemento().build());
        lista.get(0).getId();
        lista.get(0).getNome();
        lista.get(0).getInValor();
        Object obj = null;
        lista.get(0).equals(obj);
        lista.get(0).hashCode();
        
        //Mock
        when(tipoElementoDao.findAll()).thenReturn(lista);
        
        //Ação
        tipoElementoManager.listar();
        
        //Verificação
        verify(tipoElementoDao, times(1)).findAll();
        
    }
    

}
