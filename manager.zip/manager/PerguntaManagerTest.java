package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.PerguntaBuilder.umPergunta;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class PerguntaManagerTest {
    
    @InjectMocks
    private PerguntaManager perguntaManager;
    
    @Mock
    private PerguntaDao perguntaDao;
    
    @Mock
    private IntencaoDao intencaoDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testMigrarExemplo() {
        //Cenario
        
        List<Intencao> intencoes = Arrays.asList(
            umIntencao().comId(1).build(),
            umIntencao().comId(2).build(),
            umIntencao().comId(3).build()
            );
        
        List<Pergunta> listaDePerguntas = Arrays.asList(
                umPergunta().comIntencao(intencoes.get(0)).comPergunta("Ola").build(),
                umPergunta().comIntencao(intencoes.get(1)).comPergunta("Quero desbloquear senha").build(),
                umPergunta().comIntencao(intencoes.get(2)).comPergunta("Quero desbloquear cartao").build());

        int idClassificador = 140;
        
        //Acao
        perguntaManager.migrarExemplos(listaDePerguntas, idClassificador);
        ArgumentCaptor<Pergunta> argumentoCapturado = ArgumentCaptor.forClass(Pergunta.class);
        verify(perguntaDao, times(3)).persist(argumentoCapturado.capture());
        verify(perguntaDao, times(1)).flush();
        
    }
    
// ========== Cenario 1 >> if (intencao == null) << >> LINHA 49 << =========
    @Test
    public void testIntençaoNull () {
        // Cenario
        Intencao intencao = umIntencao().comId(2).build();
            
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(0).comIntencao(null).build());

        int idClassificador = 140;

        // Mock
        when(intencaoDao.findById(perguntas.get(0).getIdIntencao())).thenReturn(intencao);
        
        // Açao
        perguntaManager.migrarExemplos(perguntas, idClassificador);
     
        // Verificaçao
        verify(intencaoDao,times(0)).findById(intencao);
    }
    
 // ========== Cenario 2 >> if (intencao.getIdClassificador().equals(idClassificador)) << >> LINHA 52 << =========
    
    @Test
    public void testComparaçaoComId() {
        // Cenario
        int idClassificador = 0;
        
        Intencao intencao = umIntencao().comId(idClassificador).build();
        intencao.getHashNuvem();
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(10).comIntencao(null).build());
        
        // Mock
        when(intencaoDao.findById(perguntas.get(0).getIdIntencao())).thenReturn(intencao);
        
        // Açao
        perguntaManager.migrarExemplos(perguntas, idClassificador);
        
        // Verificaçao
        verify(intencaoDao, times(0)).findById(perguntas);
        
    }

    @Test
    public void testComparaçaoComIdDiferente() {
        // Cenario
        int idClassificador = 10;
        
        Intencao intencao = umIntencao().comId(idClassificador).build();
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(10).comIntencao(null).build());
        
        // Mock
        when(intencaoDao.findById(perguntas.get(0).getIdIntencao())).thenReturn(intencao);
        
        // Açao
        perguntaManager.migrarExemplos(perguntas, idClassificador);
        
        // Verificaçao
        verify(intencaoDao, times(0)).findById(intencao);
    }
    
    @Test
    public void testIdClassisficarIgualMaiorQueZero () {
        // Cenario
        int idClassificador = 10;
        
        Intencao intencao = umIntencao().comIdClassificador(idClassificador).build();
        
        List<Pergunta> perguntas = Arrays.asList(umPergunta().comId(1).comPergunta("pergunta").comIntencao(intencao).build());
                
        
        Pergunta p1 = umPergunta().comPergunta(perguntas.get(0).getPergunta()).build();
        
        // Mock
        when(perguntaDao.persist(p1)).thenReturn(p1);
        perguntaDao.flush();
        
        //Açao
        perguntaManager.migrarExemplos(perguntas, idClassificador);
        
        // verificaçao
    }
    
    @Test
    public void testFalharAoMigrarExemploComClassificadorDiferenteComPerguntaIgual() {
        //Cenario
        Classificador classificador140 = umClassificador().comId(140).build();
        Intencao intencao = umIntencao().build();
        
        List<Pergunta> listaDePerguntas = Arrays.asList(
                umPergunta().comPergunta("Ola").comIntencao(intencao).build(),
                umPergunta().comPergunta("Quero desbloquear senha").comIntencao(intencao).build(),
                umPergunta().comPergunta("Quero desbloquear cartao").comIntencao(intencao).build());
        int idClassificador = 150;
        when(perguntaDao.findIgual(Mockito.anyInt(), Mockito.anyString())).thenReturn(listaDePerguntas);
        
        //Acao
        assertThatThrownBy(() -> { 
            perguntaManager.migrarExemplos(listaDePerguntas, idClassificador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Não é permitido migrar as perguntas listadas abaixo, pois as mesmas já existem no corpus selecionado: ")
        .hasMessageContaining("Ola")
        .hasMessageContaining("Quero desbloquear senha")
        .hasMessageContaining("Quero desbloquear cartao");
    }
    
    @Test
    public void testFalharAoMigrarExemploComListaDePerguntasVazia() {
        //Cenario
        int idClassificador = 140;
        List<Pergunta> listaVazia = Arrays.asList();

        ArgumentCaptor<Pergunta> argumentoCapturado = ArgumentCaptor.forClass(Pergunta.class);
        when(perguntaDao.findIgual(Mockito.anyInt(), Mockito.anyString())).thenReturn(listaVazia);
        
        //Acao
        assertThatThrownBy(() -> { 
            perguntaManager.migrarExemplos(listaVazia, idClassificador);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Selecione uma ou mais Perguntas.");
    }
    
    @Test
    public void testMigrarExemploComClassificadorDiferente() {
        //Cenario
        Classificador classificador140 = umClassificador().comId(140).build();
        Intencao intencao = umIntencao().build();
        
        List<Pergunta> listaDePerguntas = Arrays.asList(
                umPergunta().comPergunta("Ola").comIntencao(intencao).build(),
                umPergunta().comPergunta("Quero desbloquear senha").comIntencao(intencao).build(),
                umPergunta().comPergunta("Quero liberar senha").comIntencao(intencao).build(),
                umPergunta().comPergunta("Quero desbloquear cartao").comIntencao(intencao).build());
        int idClassificador = 150;
        
        //Acao
        perguntaManager.migrarExemplos(listaDePerguntas, idClassificador);
        ArgumentCaptor<Pergunta> argumentoCapturado = ArgumentCaptor.forClass(Pergunta.class);
        verify(perguntaDao, times(4)).persist(argumentoCapturado.capture());
        verify(perguntaDao, times(1)).flush();
    }
    
    @Test
    public void testObterQuantidadePorIntencao () {
        // Cenario
        Integer idIntencao = 2;
        
        Long num = new Long(10);
        
        // Mock
        when(perguntaDao.obterQuantidadePorIntencao(idIntencao)).thenReturn(num);
        
        // Açao
        perguntaManager.obterQuantidadePorIntencao(idIntencao);
        
        // Verificaçao
        verify(perguntaDao, times(1)).obterQuantidadePorIntencao(idIntencao);
    }
}
