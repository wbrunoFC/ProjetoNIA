package br.com.bb.gearq.c4coleta.manager;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static br.com.bb.databuilder.TipoCondicaoBuilder.umTipoCondicao;

import br.com.bb.gearq.c4coleta.dao.TipoCondicaoDao;
import br.com.bb.gearq.c4coleta.model.TipoCondicao;

public class TipoCondicaoManagerTest {
    
    @InjectMocks
    private TipoCondicaoManager tipoCondicaoManager;
    
    @Mock
    private TipoCondicaoDao tipoCondicaoDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testListar() {
        //Cenário
        List<TipoCondicao> lista = Arrays.asList(umTipoCondicao().build());
        lista.get(0).getId();
        lista.get(0).getNome();
        
        //Mock
        when(tipoCondicaoDao.findAll()).thenReturn(lista);
        
        //Ação
        tipoCondicaoManager.listar();
        
        //Verificação
        verify(tipoCondicaoDao, times(1)).findAll();
        
    }
    

}
