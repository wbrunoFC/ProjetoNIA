package br.com.bb.gearq.c4coleta.manager;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.ParametroAlertaBuilder.umParametroAlerta;

import java.util.Arrays;
import java.util.List;

import br.com.bb.gearq.c4coleta.dao.AcionamentoIntencaoDiaDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.ParametroAlertaDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.ParametroAlerta;

public class ProcessarCriseManagerTest {
    @InjectMocks
    private ProcessarCriseManager processarCriseManager;

    @Mock
    private ClassificadorDao classificadorDao;
    
    @Mock
    private ParametroAlertaDao parametroAlertaDao;
    
    @Mock
    private AcionamentoIntencaoDiaDao acionamentoIntencaoDiaDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testProcessarCrise() {
        //Cenário
        List<Classificador> listaClass = Arrays.asList(umClassificador().build());
        
        Classificador c = listaClass.get(0);
        
        ParametroAlerta pA = umParametroAlerta().comId(1).build();
        pA.getDataCriacao();
        pA.getClassificador();
        pA.getPercentual();
        
        //Mock
        when(classificadorDao.findAll()).thenReturn(listaClass);
        when(parametroAlertaDao.buscaItemEdicao(c.getId())).thenReturn(pA);
        acionamentoIntencaoDiaDao.QtdIntencaoAcionadas(c.getId(), pA.getQtDias());
        
        //Ação
        processarCriseManager.processarCrise();
        
        //Verificação
        verify(classificadorDao, times(1)).findAll();
        verify(parametroAlertaDao, times(1)).buscaItemEdicao(c.getId());
        verify(acionamentoIntencaoDiaDao, times(2)).QtdIntencaoAcionadas(c.getId(), pA.getQtDias());
        
    }
    


}
