package br.com.bb.gearq.c4coleta.manager;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

import static br.com.bb.databuilder.NivelAcessoServicoBuilder.umNivelAcessoServico;
import static br.com.bb.databuilder.ServicoNlcBuilder.umServicoNlc;
import static br.com.bb.databuilder.NivelAcessoClassificadorBuilder.umNivelAcessoClassificador;
import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.TipoUsuarioFerramentaBuilder.umTipoUsuarioFerramenta;
import static br.com.bb.databuilder.TipoUsuarioServicoBuilder.umTipoUsuarioServico;

import br.com.bb.gearq.c4coleta.dao.NivelAcessoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoServicoDao;
import br.com.bb.gearq.c4coleta.dao.ServicoNlcDao;
import br.com.bb.gearq.c4coleta.dao.TipoUsuarioFerramentaDao;
import br.com.bb.gearq.c4coleta.dao.TipoUsuarioServicoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.NivelAcessoClassificador;
import br.com.bb.gearq.c4coleta.model.NivelAcessoServico;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.TipoNivelAcesso;
import br.com.bb.gearq.c4coleta.model.TipoUsuarioFerramenta;
import br.com.bb.gearq.c4coleta.model.TipoUsuarioServico;
import br.com.bb.gearq.c4coleta.util.PermissaoUsuario;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class PermissaoUsuarioManagerTest {
    @InjectMocks
    private PermissaoUsuarioManager permissaoUsuarioManager;

    @Mock
    private PermissaoUsuario permissaoUsuario;
    
    @Mock
    private NivelAcessoServicoDao nivelAcessoServicoDao;
    
    @Mock
    private NivelAcessoClassificadorDao nivelAcessoClassificadorDao;
    
    @Mock
    private ServicoNlcDao servicoNlcDao;
    
    @Mock
    private TipoUsuarioFerramentaDao tipoUsuarioFerramentaDao;
    
    @Mock
    private TipoUsuarioServicoDao tipoUsuarioServicoDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testRecuperarPermissaoServico1() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = false;
        
        //Mock
        when(permissaoUsuario.isMaster()).thenReturn(false);
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
    }
    
    
    @Test
    public void testRecuperarPermissaoServico2() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = false;
        
        //Mock
        when(permissaoUsuario.isMaster()).thenReturn(true);
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
    }
    
    @Test
    public void testRecuperarPermissaoServico3() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = false;
        
        ServicoNlc servico = umServicoNlc().build();
        
        List<NivelAcessoServico> permissoes = Arrays.asList(
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.AUDITOR).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.MASTER).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.CURADOR_MASTER).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.CURADOR).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.COLETOR).build()
                );
        permissoes.get(0).getId();
        permissoes.get(0).getServicoNlc();
        
        //Mock
        when(nivelAcessoServicoDao.findByServico(id)).thenReturn(permissoes);
        when(permissaoUsuario.isMaster()).thenReturn(false);
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
        verify(nivelAcessoServicoDao, times(1)).findByServico(id);
    }
    
    @Test
    public void testRecuperarPermissaoServico4() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = false;
        
        //Mock
        when(permissaoUsuario.isMaster()).thenReturn(true);
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
    }
    
    @Test
    public void testRecuperarPermissaoServico5() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = false;
        
        ServicoNlc servico = umServicoNlc().build();
        
        List<NivelAcessoServico> permissoes = Arrays.asList(
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.AUDITOR).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.MASTER).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.CURADOR_MASTER).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.CURADOR).build(),
                umNivelAcessoServico().comId(1).comServicoNlc(servico).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.COLETOR).build()
                );
        
        //Mock
        when(nivelAcessoServicoDao.findByServico(id)).thenReturn(permissoes);
        when(permissaoUsuario.isMaster()).thenReturn(false);
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
        verify(nivelAcessoServicoDao, times(1)).findByServico(id);
    }
    
    @Test
    public void testRecuperarPermissaoServicoComPermissoesNulo() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = false;
        
        List<NivelAcessoServico> permissoes = null;
        
        //Mock
        when(nivelAcessoServicoDao.findByServico(id)).thenReturn(permissoes);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
        verify(nivelAcessoServicoDao, times(1)).findByServico(id);
        
    }
    
    @Test
    public void testRecuperarPermissaoClassificadores1() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = true;
        
        //Mock
        when(permissaoUsuario.isMaster()).thenReturn(true);
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
    }
    
    @Test
    public void testRecuperarPermissaoClassificadores2() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = true;
        
        Classificador classificador = umClassificador().build();
        
        List<NivelAcessoClassificador> permissoes = Arrays.asList(
                umNivelAcessoClassificador().comId(1).comClassificador(classificador).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.CURADOR_MASTER).build(),
                umNivelAcessoClassificador().comId(1).comClassificador(classificador).comSiglaAcesso("CURADOR").comTipo(TipoNivelAcesso.CURADOR).build(),
                umNivelAcessoClassificador().comId(1).comClassificador(classificador).comSiglaAcesso("COLETOR").comTipo(TipoNivelAcesso.COLETOR).build()
                );
        permissoes.get(0).getId();
        permissoes.get(0).getClassificador();
        
        //Mock
        when(nivelAcessoClassificadorDao.findByClassificador(id)).thenReturn(permissoes);
        when(permissaoUsuario.isMaster()).thenReturn(false);
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
        verify(nivelAcessoClassificadorDao, times(1)).findByClassificador(id);
        
    }
    
    @Test
    public void testRecuperarPermissaoClassificadores3() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = true;
        
        //Mock
        when(permissaoUsuario.isMaster()).thenReturn(true);
        when(permissaoUsuario.isAuditor()).thenReturn(false);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
    }
    
    @Test
    public void testRecuperarPermissaoClassificadores4() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = true;
        
        Classificador classificador = umClassificador().build();
        
        List<NivelAcessoClassificador> permissoes = Arrays.asList(
                umNivelAcessoClassificador().comId(1).comClassificador(classificador).comSiglaAcesso("SIGLA").comTipo(TipoNivelAcesso.CURADOR_MASTER).build(),
                umNivelAcessoClassificador().comId(1).comClassificador(classificador).comSiglaAcesso("CURADOR").comTipo(TipoNivelAcesso.CURADOR).build(),
                umNivelAcessoClassificador().comId(1).comClassificador(classificador).comSiglaAcesso("COLETOR").comTipo(TipoNivelAcesso.COLETOR).build()
                );
        
        //Mock
        when(nivelAcessoClassificadorDao.findByClassificador(id)).thenReturn(permissoes);
        when(permissaoUsuario.isMaster()).thenReturn(false);
        when(permissaoUsuario.isAuditor()).thenReturn(true);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
        verify(nivelAcessoClassificadorDao, times(1)).findByClassificador(id);
    }
    
    @Test
    public void testRecuperarPermissaoClassificadoresComPermissoesNulo() {
        //Cenário
        Integer id = 1;
        boolean tipoPesquisa = true;
        
        List<NivelAcessoClassificador> permissoes = null;
        
        //Mock
        when(nivelAcessoClassificadorDao.findByClassificador(id)).thenReturn(permissoes);
        
        //Ação
        permissaoUsuarioManager.recuperarPermissao(id, tipoPesquisa);
        
        //Verificação
        
    }
    

    @Test
    public void testImportarComErro() {
        //Cenário
        Integer idServico = 1;
        InputStream isXls = null;
        
        ServicoNlc servicoNlc = umServicoNlc().build();
        TipoUsuarioFerramenta tipoFerramenta = umTipoUsuarioFerramenta().build();
        tipoFerramenta.getId();
        tipoFerramenta.getDescricao();
        tipoFerramenta.getNome();
        tipoFerramenta.getSigla();
        
        List<TipoUsuarioServico> tipos = Arrays.asList(umTipoUsuarioServico().build());
        tipos.get(0).getId();
        tipos.get(0).getDescricao();
        tipos.get(0).getNome();
        tipos.get(0).getSigla();
        
        //Mock
        when(servicoNlcDao.findById(idServico)).thenReturn(servicoNlc);
        when(tipoUsuarioFerramentaDao.findBySigla(TipoUsuarioFerramenta.SIGLA_PUBLICO)).thenReturn(tipoFerramenta);
        when(tipoUsuarioServicoDao.findAll()).thenReturn(tipos);
        
        //Ação
        assertThatThrownBy(() -> {
            permissaoUsuarioManager.importar(idServico, isXls);
      }).isInstanceOf(NegocioException.class).hasMessageContaining("Erro ao carregar arquivo");
        
        //Verificação
        verify(servicoNlcDao, times(1)).findById(idServico);
        verify(tipoUsuarioFerramentaDao, times(1)).findBySigla(TipoUsuarioFerramenta.SIGLA_PUBLICO);
        verify(tipoUsuarioServicoDao, times(1)).findAll();
    }
    
    @Ignore
    public void testImportar() {
        //Cenário
        
        Integer idServico = 1;
        InputStream isXls = null;
        
//        InputStream isXls = Mockito.mock(InputStream.class);
        
        ServicoNlc servicoNlc = umServicoNlc().build();
        TipoUsuarioFerramenta tipoFerramenta = umTipoUsuarioFerramenta().build();
        tipoFerramenta.getId();
        tipoFerramenta.getDescricao();
        tipoFerramenta.getNome();
        tipoFerramenta.getSigla();
        
        List<TipoUsuarioServico> tipos = Arrays.asList(umTipoUsuarioServico().build());
        
        //Mock
        when(servicoNlcDao.findById(idServico)).thenReturn(servicoNlc);
        when(tipoUsuarioFerramentaDao.findBySigla(TipoUsuarioFerramenta.SIGLA_PUBLICO)).thenReturn(tipoFerramenta);
        when(tipoUsuarioServicoDao.findAll()).thenReturn(tipos);
        //when(WorkbookFactory.create(Mockito.any()))
        
        //Ação
        permissaoUsuarioManager.importar(idServico, isXls);
        
        //Verificação
    }
    
}
