package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.AgruparEntidadeSinonimosBuilder.umAgruparEntidadeSinonimos;
import static br.com.bb.databuilder.FluxoBuilder.umFluxo;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.MigrarIntencaoVOBuilder.umMigrarIntencaoVO;
import static br.com.bb.databuilder.PerguntaBuilder.umPergunta;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import br.com.bb.databuilder.ClassificadorBuilder;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.model.AgruparEntidadeSinonimos;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.vo.MigrarIntencaoVO;
import br.com.bb.sos.infra.exceptions.NegocioException;

public class IntencaoManagerTest {

    @InjectMocks
    private IntencaoManager intencaoManager;
    
    @Mock
    private FluxoManager fluxoManager;

    @Mock
    private IntencaoDao intencaoDao;

    @Mock
    private ClassificadorDao classificadorDao;

    @Mock
    private PerguntaDao perguntaDao;

    @Mock
    private FluxoDao fluxoDao;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSalvarComSucesso() {
        // Cenario
        Intencao intencao = umIntencao().comDescricao("Descrição da intenção").build();
        int idClassificador = 140;

        // Mocks
        when(classificadorDao.findById(idClassificador)).thenReturn(new Classificador());
        when(intencaoDao.persist(intencao)).thenReturn(intencao);

        // Acao
        intencaoManager.salvar(idClassificador, intencao);
        ArgumentCaptor<Intencao> intencaoCapturada = ArgumentCaptor.forClass(Intencao.class);

        // Verificao
        verify(intencaoDao, times(2)).persist(intencaoCapturada.capture());
        verify(intencaoDao, times(1)).flush();
    }
    
    @Test
    public void testFalharAoMigrarIntencaoComClassificadorQueTenhaPerguntasIguais() {
        // Cenario
        Classificador classificador = ClassificadorBuilder.umClassificador().build();
        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comClassificador(classificador).build();
        List<Intencao> intencoes = Arrays.asList(
                umIntencao().comId(0).comNome("Intencao 1").build(),
                umIntencao().comId(1).comNome("NomeIgual").build(),
                umIntencao().comId(2).comNome("NomeIgual").build(),
                umIntencao().comId(3).comNome("Intencao 4").build());
        
        List<Pergunta> perguntas = Arrays.asList(
                umPergunta().build(),
                umPergunta().build(),
                umPergunta().build(),
                umPergunta().build());
        
        List<Fluxo> fluxos = Arrays.asList(
                umFluxo().comId(0).comIntencao(intencoes.get(0)).build(),
                umFluxo().comId(1).comIntencao(intencoes.get(1)).build(),
                umFluxo().comId(2).comIntencao(intencoes.get(2)).build(),
                umFluxo().comId(3).comIntencao(intencoes.get(3)).build());
        
        // Mocks
        when(perguntaDao.findIdClassificador(migrarIntencaoVO.getClassificador().getId())).thenReturn(perguntas);
        when(perguntaDao.findByIntencao(intencoes.get(1).getId())).thenReturn(Arrays.asList(perguntas.get(1)));
        migrarIntencaoVO.setListaIntencao(intencoes);
        
        // Acao
        assertThatThrownBy(() -> {
            intencaoManager.migrar(migrarIntencaoVO);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("No Classificador selecionado já existem as mesmas perguntas das seguintes intenções:");
    }

    @Test
    public void testFalharAoMigrarIntencaoComFluxoFilhoComAgrupador() {
        // Cenario
        Classificador classificador = ClassificadorBuilder.umClassificador().build();
        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comClassificador(classificador).build();
        List<Intencao> intencoes = Arrays.asList(
                umIntencao().comId(0).comNome("Intencao 1").build(),
                umIntencao().comId(1).comNome("Intencao 2").build(),
                umIntencao().comId(2).comNome("Intencao 3").build(),
                umIntencao().comId(3).comNome("Intencao 4").build());

        List<Pergunta> perguntas = Arrays.asList(
                umPergunta().build(), 
                umPergunta().build(), 
                umPergunta().build(),
                umPergunta().build());

        AgruparEntidadeSinonimos agrupadorA = umAgruparEntidadeSinonimos().build();
        Fluxo fluxoA = umFluxo().build();
        List<Fluxo> fluxos = Arrays.asList(
                umFluxo().comId(0).comIntencao(intencoes.get(0))
                .comAgrupador(agrupadorA)
                .comFluxoPai(fluxoA).build(),
                umFluxo().comId(1).comIntencao(intencoes.get(1)).build(),
                umFluxo().comId(2).comIntencao(intencoes.get(2)).build(),
                umFluxo().comId(3).comIntencao(intencoes.get(3)).build());

        List<Fluxo> fluxoFilhoComAgrupadores1 = Arrays.asList(
                umFluxo().comAgrupador(new AgruparEntidadeSinonimos()).comFluxoPai(fluxos.get(1)).build());

        List<Fluxo> fluxoFilhoComAgrupadores2 = Arrays.asList(
                umFluxo().comAgrupador(new AgruparEntidadeSinonimos()).comFluxoPai(fluxos.get(2)).build());

        // Mocks
        when(fluxoManager.listarPorIntencao(intencoes.get(0).getId())).thenReturn(fluxos);
        when(perguntaDao.findIdClassificador(migrarIntencaoVO.getClassificador().getId())).thenReturn(perguntas);
        when(fluxoDao.findByFluxo(intencoes.get(0).getId())).thenReturn(fluxoFilhoComAgrupadores1);
        when(fluxoDao.findByFluxo(intencoes.get(1).getId())).thenReturn(fluxoFilhoComAgrupadores2);
        
        when(fluxoManager.listarPorIntencao(Mockito.anyInt())).thenReturn(Arrays.asList(fluxos.get(0)));
        migrarIntencaoVO.setListaIntencao(intencoes);

        // Acao

        assertThatThrownBy(() -> {
            intencaoManager.migrar(migrarIntencaoVO);
        }).isInstanceOf(NegocioException.class)
                .hasMessageContaining("Não é permitida a migração da(s) intenção(ões): Intencao 1")
                .hasMessageContaining("Não é permitida a migração da(s) intenção(ões): Intencao 2");
    }

    @Test
    public void testFalharAoMigrarIntencaoSemClassificador() {
        // Cenario
        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comClassificador(null).build();

        // Acao
        assertThatThrownBy(() -> {
            intencaoManager.migrar(migrarIntencaoVO);
        }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione um Classificador.");
    }

    @Test
    public void testFalharAoMigrarIntencaoComListaVazia() {
        // Cenario
        Classificador classificador = ClassificadorBuilder.umClassificador().build();
        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comClassificador(classificador).build();
        List<Intencao> listaVazia = Arrays.asList();
        migrarIntencaoVO.setListaIntencao(listaVazia);

        // Acao
        assertThatThrownBy(() -> {
            intencaoManager.migrar(migrarIntencaoVO);
        }).isInstanceOf(NegocioException.class).hasMessageContaining("Selecione uma ou mais intenções.");
    }
    
    @Test
    public void testFalharAoMigrarIntencaoComDesambiguacao() {
        // Cenario
        Classificador classificador = ClassificadorBuilder.umClassificador().build();
        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comClassificador(classificador).build();
        List<Intencao> intencoes = Arrays.asList(
                umIntencao().comId(0).comNome("Intencao 1").comNecessitaDesambiguacao(true).build(),
                umIntencao().comId(1).comNome("Intencao 2").comNecessitaDesambiguacao(true).build(),
                umIntencao().comId(2).comNome("Intencao 3").build(),
                umIntencao().comId(3).comNome("Intencao 4").build());

        List<Pergunta> perguntas = Arrays.asList(
                umPergunta().build(), 
                umPergunta().build(), 
                umPergunta().build(),
                umPergunta().build());

        List<Fluxo> fluxos = Arrays.asList(
                umFluxo().comId(0).comIntencao(intencoes.get(0)).build(),
                umFluxo().comId(1).comIntencao(intencoes.get(1)).build(),
                umFluxo().comId(2).comIntencao(intencoes.get(2)).build(),
                umFluxo().comId(3).comIntencao(intencoes.get(3)).build());

        List<Fluxo> fluxoFilhoComAgrupadores1 = Arrays.asList(
                umFluxo().comAgrupador(new AgruparEntidadeSinonimos()).comFluxoPai(fluxos.get(1)).build());

        List<Fluxo> fluxoFilhoComAgrupadores2 = Arrays.asList(
                umFluxo().comAgrupador(new AgruparEntidadeSinonimos()).comFluxoPai(fluxos.get(2)).build());

        // Mocks
        when(perguntaDao.findIdClassificador(migrarIntencaoVO.getClassificador().getId())).thenReturn(perguntas);
        when(fluxoDao.findByFluxo(intencoes.get(0).getId())).thenReturn(fluxoFilhoComAgrupadores1);
        when(fluxoDao.findByFluxo(intencoes.get(1).getId())).thenReturn(fluxoFilhoComAgrupadores2);
        migrarIntencaoVO.setListaIntencao(intencoes);

        // Acao
        assertThatThrownBy(() -> {
            intencaoManager.migrar(migrarIntencaoVO);
        }).isInstanceOf(NegocioException.class).hasMessageContaining("Não foi possível migrar ");
    }
    
    @Test
    public void testMigrarComSucesso() {
        // Cenario
        int idClassificador = 140;
        Intencao intencao = umIntencao().comDescricao("Descrição da intenção").build();
        
        Classificador classificador = ClassificadorBuilder.umClassificador().comId(140).build();
        List<Intencao> intencoes = Arrays.asList(
                umIntencao().comId(0).comNome("Intencao 1").build(),
                umIntencao().comId(1).comNome("Intencao 2").build(),
                umIntencao().comId(2).comNome("Intencao 3").build(),
                umIntencao().comId(3).comNome("Intencao 4").build());
        
        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comClassificador(classificador).build();
        migrarIntencaoVO.setListaIntencao(intencoes);

        List<Pergunta> perguntas = Arrays.asList(
                umPergunta().build(),
                umPergunta().build(),
                umPergunta().build(),
                umPergunta().build());

        // Mocks
        when(classificadorDao.findById(idClassificador)).thenReturn(classificador);
        when(intencaoDao.persist(intencao)).thenReturn(intencao);
        when(perguntaDao.findByIntencao(intencoes.get(0).getId())).thenReturn(Arrays.asList(perguntas.get(0)));
        when(perguntaDao.findByIntencao(intencoes.get(1).getId())).thenReturn(Arrays.asList(perguntas.get(1)));
        when(perguntaDao.findByIntencao(intencoes.get(2).getId())).thenReturn(Arrays.asList(perguntas.get(2)));
        when(perguntaDao.findByIntencao(intencoes.get(3).getId())).thenReturn(Arrays.asList(perguntas.get(3)));
        
        // Acao
        intencaoManager.migrar(migrarIntencaoVO);
        ArgumentCaptor<Intencao> intencaoCapturada = ArgumentCaptor.forClass(Intencao.class);

        // Verificao
        verify(intencaoDao, times(4)).persist(intencaoCapturada.capture());
        verify(intencaoDao, times(1)).flush();
    }
    
    @Test
    public void testFalharAoMigrarIntencaoComClassificadorComNomesIguais() {
        // Cenario
        Classificador classificador = ClassificadorBuilder.umClassificador().comId(140).build();
        
        List<Intencao> intencoes = Arrays.asList(
                umIntencao().comId(0).comNome("Intencao 1").build(),
                umIntencao().comId(1).comNome("Intencao 2").build(),
                umIntencao().comId(2).comNome("Intencao 3").build(),
                umIntencao().comId(3).comNome("Intencao 4").build());

        MigrarIntencaoVO migrarIntencaoVO = umMigrarIntencaoVO().comListaListaIntencao(intencoes.get(0)).comClassificador(classificador).build();
        List<Pergunta> perguntas = Arrays.asList(
                umPergunta().comId(0).build(), 
                umPergunta().comId(1).build(), 
                umPergunta().comId(2).build(), 
                umPergunta().comId(3).build());

        Fluxo fluxoPai = umFluxo().comId(4).build();
        AgruparEntidadeSinonimos agrupar = umAgruparEntidadeSinonimos().build();
        agrupar.getNomeAgrupadorEntidade();
        agrupar.setNomeAgrupadorEntidade(null);
        agrupar.getTipo();
        
        List<Fluxo> fluxos = Arrays.asList(
                umFluxo().comId(0).comIntencao(intencoes.get(0)).comAgrupador(agrupar).comFluxoPai(fluxoPai).build(),
                umFluxo().comId(1).comIntencao(intencoes.get(1)).build(),
                umFluxo().comId(2).comIntencao(intencoes.get(2)).build(),
                umFluxo().comId(3).comIntencao(intencoes.get(3)).build());

        List<Fluxo> fluxoFilhoComAgrupadores1 = Arrays.asList(
                umFluxo().comAgrupador(new AgruparEntidadeSinonimos()).comFluxoPai(fluxos.get(1)).build());

        List<Fluxo> fluxoFilhoComAgrupadores2 = Arrays.asList(
                umFluxo().comAgrupador(new AgruparEntidadeSinonimos()).comFluxoPai(fluxos.get(2)).build());

        // Mocks
        when(perguntaDao.findIdClassificador(migrarIntencaoVO.getClassificador().getId())).thenReturn(perguntas);
        when(intencaoDao.findByClassificador(migrarIntencaoVO.getClassificador().getId())).thenReturn(intencoes);
        when(fluxoDao.findByFluxo(intencoes.get(0).getId())).thenReturn(fluxoFilhoComAgrupadores1);
        when(fluxoDao.findByFluxo(intencoes.get(1).getId())).thenReturn(fluxoFilhoComAgrupadores2);
                                                                                                                        
        
        when(fluxoManager.listarPorIntencao(Mockito.anyInt())).thenReturn(Arrays.asList(fluxos.get(0)));
        when(perguntaDao.findByIntencao(Mockito.anyInt())).thenReturn(perguntas);
//        when(fluxoManager.listarPorIntencao(intencoes.get(1).getId())).thenReturn((List<Fluxo>) fluxos.get(1));
//        when(fluxoManager.listarPorIntencao(intencoes.get(2).getId())).thenReturn((List<Fluxo>) fluxos.get(2));
//        when(fluxoManager.listarPorIntencao(intencoes.get(3).getId())).thenReturn((List<Fluxo>) fluxos.get(3));
//        ArgumentCaptor<Locacao> argumentCaptor = ArgumentCaptor.forClass(.class);
        
        
        migrarIntencaoVO.setListaIntencao(intencoes);

        // Acao
        assertThatThrownBy(() -> {
            intencaoManager.migrar(migrarIntencaoVO);
        }).isInstanceOf(NegocioException.class)
        .hasMessageContaining("Já existem no corpus as intenções:")
        .hasMessageContaining("Intencao 1")
        .hasMessageContaining("Intencao 2")
        .hasMessageContaining("Intencao 3")
        .hasMessageContaining("Intencao 4");
    }
}

