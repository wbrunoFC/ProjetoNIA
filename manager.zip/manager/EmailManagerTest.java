package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.ClassificadorBuilder.umClassificador;
import static br.com.bb.databuilder.FluxoBuilder.umFluxo;
import static br.com.bb.databuilder.IntencaoBuilder.umIntencao;
import static br.com.bb.databuilder.PerguntaRevisaoBuilder.umPerguntaRevisao;
import static br.com.bb.databuilder.PerguntaRevisaoIntencaoBuilder.umPerguntaRevisaoIntencao;
import static br.com.bb.databuilder.PerguntaRevisaoUsuarioBuilder.umPerguntaRevisaoUsuario;
import static br.com.bb.databuilder.ServicoNlcBuilder.umServicoNlc;
import static br.com.bb.databuilder.TipoRespostaBuilder.umTipoResposta;
import static br.com.bb.databuilder.TipoRespostaIntencaoBuilder.umTipoRespostaIntencao;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoIntencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;

public class EmailManagerTest {
    @InjectMocks
    private EmailManager emailManager;
    
    @Mock
    private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;
    
    @Mock
    private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
    
    @Mock
    private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
    
    @Mock
    private FluxoDao fluxoDao;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testEnviar() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(true).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = umServicoNlc().comId(10).comDiretoria("DITORIA").build();
        Classificador classificador = umClassificador().comId(12).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        pergunta.getDataCriacao();
        pergunta.getEntidadeAgrupador();
        pergunta.getIntencao();
        pergunta.getVinculada();
        pergunta.getPerguntasRevisaoUsuarios();
        pergunta.getQtdPositivo();
        pergunta.getQtdNegativo();
        pergunta.getDataCuradoria();
        pergunta.getSerialversionuid();
        pergunta.getAssuntoServico();
        pergunta.getPerguntaOriginal();
        pergunta.getIndAltPergunta();
        pergunta.getNomeIntencao();
        
        
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().comUsuario("F1234567").build());
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON(TipoResposta.TX_PADRAO).build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao().comTipoResposta(tipoResposta).build());
        
        List<Fluxo> lista = Arrays.asList(umFluxo().comFluxoPai(null).comPerguntaDesambiguacao("Pergunta_Desambiguação").build());
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        when(tipoRespostaIntencaoDao.findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null)).thenReturn(respostas);
        when(fluxoDao.findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId())).thenReturn(lista);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        verify(tipoRespostaIntencaoDao, times(1)).findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null);
        verify(fluxoDao, times(1)).findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId());
        
    }
    
    @Test
    public void testEnviarComDiretoriaNull() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(true).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = umServicoNlc().comId(10).comDiretoria(null).build();
        Classificador classificador = umClassificador().comId(63).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().comUsuario("F1234567").build());
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON(TipoResposta.TX_PADRAO).build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao().comTipoResposta(tipoResposta).build());
        
        List<Fluxo> lista = new ArrayList<>();
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        when(tipoRespostaIntencaoDao.findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null)).thenReturn(respostas);
        when(fluxoDao.findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId())).thenReturn(lista);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        verify(tipoRespostaIntencaoDao, times(1)).findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null);
        verify(fluxoDao, times(1)).findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId());
        
    }
    
    @Test
    public void testEnviarComListaFluxoNull() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(true).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = umServicoNlc().comId(10).comDiretoria(null).build();
        Classificador classificador = umClassificador().comId(21).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().comUsuario("F1234567").build());
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON(TipoResposta.TX_PADRAO).build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao().comTipoResposta(tipoResposta).build());
        
        List<Fluxo> lista = null;
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        when(tipoRespostaIntencaoDao.findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null)).thenReturn(respostas);
        when(fluxoDao.findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId())).thenReturn(lista);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        verify(tipoRespostaIntencaoDao, times(1)).findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null);
        verify(fluxoDao, times(1)).findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId());
    }
    
    @Test
    public void testEnviarComServicoNull() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(true).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = null;
        Classificador classificador = umClassificador().comId(63).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().comUsuario("F1234567").build(),
                                                              umPerguntaRevisaoUsuario().comUsuario("USUARIO_EXTERNO").build(),
                                                              umPerguntaRevisaoUsuario().comUsuario(null).build());
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON(TipoResposta.TX_PADRAO).build();
        TipoResposta tipoResposta2 = umTipoResposta().comNomeJSON("Nome Json").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao().comTipoResposta(tipoResposta).build(),
                                                             umTipoRespostaIntencao().comTipoResposta(tipoResposta2).build());
        
        Fluxo fluxo = umFluxo().build();
        List<Fluxo> lista = Arrays.asList(umFluxo().comFluxoPai(fluxo).comPerguntaDesambiguacao("Pergunta_Desambiguação").build(),
                                          umFluxo().comFluxoPai(null).comPerguntaDesambiguacao("Pergunta_Desambiguação").build());
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        when(tipoRespostaIntencaoDao.findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null)).thenReturn(respostas);
        when(fluxoDao.findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId())).thenReturn(lista);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        verify(tipoRespostaIntencaoDao, times(1)).findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null);
        verify(fluxoDao, times(1)).findByFluxo(pergunta.getIntencaoRevisao().getIntencao().getId());
        
    }
    
    @Test
    public void testEnviarComPerguntaSemDesambiguacao() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(false).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = null;
        Classificador classificador = umClassificador().comId(12).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().comUsuario("F1234567").build(),
                                                              umPerguntaRevisaoUsuario().comUsuario("USUARIO_EXTERNO").build(),
                                                              umPerguntaRevisaoUsuario().comUsuario(null).build());
        
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON(TipoResposta.TX_PADRAO).build();
        TipoResposta tipoResposta2 = umTipoResposta().comNomeJSON("Nome Json").build();
        List<TipoRespostaIntencao> respostas = Arrays.asList(umTipoRespostaIntencao().comTipoResposta(tipoResposta).build(),
                                                             umTipoRespostaIntencao().comTipoResposta(tipoResposta2).build());
        
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        when(tipoRespostaIntencaoDao.findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null)).thenReturn(respostas);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        verify(tipoRespostaIntencaoDao, times(1)).findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null);
        
    }
    
    @Test
    public void testEnviarSemResposta() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(false).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = null;
        Classificador classificador = umClassificador().comId(12).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = Arrays.asList(umPerguntaRevisaoUsuario().comUsuario("F1234567").build(),
                                                              umPerguntaRevisaoUsuario().comUsuario("USUARIO_EXTERNO").build(),
                                                              umPerguntaRevisaoUsuario().comUsuario(null).build());
        
        List<TipoRespostaIntencao> respostas = null;
        
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        when(tipoRespostaIntencaoDao.findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null)).thenReturn(respostas);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        verify(tipoRespostaIntencaoDao, times(1)).findAll(pergunta.getIntencaoRevisao().getIntencao().getId(), null);
        
    }
    
    @Test
    public void testEnviarComUsuarioIgualA0() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(false).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = null;
        Classificador classificador = umClassificador().comId(12).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = new ArrayList<>();
        
        List<TipoRespostaIntencao> respostas = new ArrayList<>();
        
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
    }
    
    @Test
    public void testEnviarComUsuariosNull() {
        //Cenário
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(false).build();
        PerguntaRevisaoIntencao perguntaRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        ServicoNlc servico = umServicoNlc().comId(10).comDiretoria(null).build();
        Classificador classificador = umClassificador().comId(12).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        
        List<PerguntaRevisaoUsuario> usuarios = null;
        
        //Mock
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        
    }
    
    
    @Test
    public void testEnviarComIntencaoRevisaoNull() {
        //Cenário
        PerguntaRevisaoIntencao perguntaRevisao = null;
        ServicoNlc servico = umServicoNlc().comId(10).comDiretoria("DITORIA").build();
        Classificador classificador = umClassificador().comId(12).comServicoNlc(servico).comNome("Nome do Classificador").build();
        PerguntaRevisao pergunta = umPerguntaRevisao().comId(1)
                                                      .comIntencaoRevisao(perguntaRevisao)
                                                      .comClassificador(classificador)
                                                      .comIdIntencaoRevisao(2)
                                                      .build();
        
        Intencao intencao = umIntencao().comId(3).comNecessitaDesambiguacao(true).build();
        PerguntaRevisaoIntencao intencaoRevisao = umPerguntaRevisaoIntencao().comIntencao(intencao).build();
        
        List<PerguntaRevisaoUsuario> usuarios = null;
        
        //Mock
        when(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao())).thenReturn(intencaoRevisao);
        when(perguntaRevisaoUsuarioDao.findEmail(true, pergunta.getId())).thenReturn(usuarios);
        
        //Ação
        emailManager.enviar(pergunta);
        
        //Verificação
        verify(perguntaRevisaoIntencaoDao, times(1)).findById(pergunta.getIdIntencaoRevisao());
        verify(perguntaRevisaoUsuarioDao, times(1)).findEmail(true, pergunta.getId());
        
    }
    
   
}
