package br.com.bb.gearq.c4coleta.manager;

import static br.com.bb.databuilder.DialogoBuilder.umDialogo;
import static br.com.bb.databuilder.RespostaDialogoBuilder.umRespostaDialogo;
import static br.com.bb.databuilder.RespostaDialogoPKBuilder.umRespostaDialogoPK;
import static br.com.bb.databuilder.RespostaDialogoSlotBuilder.umRespostaDialogoSlot;
import static br.com.bb.databuilder.RespostaDialogoSlotPKBuilder.umRespostaDialogoSlotPK;
import static br.com.bb.databuilder.SlotsBuilder.umSlots;
import static br.com.bb.databuilder.TagBuilder.umTag;
import static br.com.bb.databuilder.TipoRespostaBuilder.umTipoResposta;
import static br.com.bb.databuilder.VariavelContextoBuilder.umVariavelContexto;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.DialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.dao.SlotsDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoPK;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlot;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlotPK;
import br.com.bb.gearq.c4coleta.model.Slots;
import br.com.bb.gearq.c4coleta.model.Tag;
import br.com.bb.gearq.c4coleta.model.TipoCondicaoDialogo;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.VariavelContexto;

public class SlotManagerTest {
    @InjectMocks
    private SlotManager slotManager;

    @Mock
    private RespostaDialogoSlotDao respostaDialogoSlotDao;
    
    @Mock
    private SlotsDao slotsDao;
    
    @Mock
    private RespostaDialogoSlotManager respostaDialogoSlotManager;
    
    @Mock
    private DialogoDao dialogoDao;
    
    @Mock
    private DialogoManager dialogoManager;
    
    @Mock
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;
    
    @Mock
    private TipoComponenteVisualDao tipoComponenteVisualDao;
    
    @Mock
    private CacheProgresso cacheProgresso;
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testListaRespostaDialogoSlot() {
        //Cenário
        Integer idSlot = 1;
        
        List<RespostaDialogoSlot> lista = Arrays.asList(umRespostaDialogoSlot().build());
        
        //Mock
        when(respostaDialogoSlotDao.findByDialogoSlot(idSlot)).thenReturn(lista);
        
        //Ação
        slotManager.listaRespostaDialogoSlot(idSlot);
        
        //Verificação
        verify(respostaDialogoSlotDao, times(1)).findByDialogoSlot(idSlot);
        
        
    }
    
    @Test
    public void testSalvar() {
        //Cenário
        List<RespostaDialogoSlot> respostas = Arrays.asList(umRespostaDialogoSlot()
                                                           .comTextoResposta("Resposta 1")
                                                           .build());
        
        List<Dialogo> dialogoFilho = Arrays.asList(umDialogo().build());
        
        Dialogo dialogo = umDialogo().comIdClassificador(1).build();
        
        Slots slot = umSlots()
                    .comId(1)
                    .comListaRespostas(respostas)
                    .comFilhos(dialogoFilho)
                    .comDialogo(dialogo)
                    .comSlotNaoPreenchidoHash(null)
                    .build();
        
        RespostaDialogoSlot resposta = umRespostaDialogoSlot().build();
        
        
        //Mock
        when(slotManager.obter(1)).thenReturn(slot);
        when(slotsDao.persist(slot)).thenReturn(slot);
        when(respostaDialogoSlotManager.salvar(Mockito.any(RespostaDialogoSlot.class), Mockito.any(Integer.class))).thenReturn(resposta);
        when(dialogoManager.salvar(Mockito.any(Dialogo.class))).thenReturn(dialogo);
        
        //Ação
        slotManager.salvar(slot);
        
        //Verificação
        verify(slotsDao, times(1)).persist(slot);
        
    }
    
    @Test
    public void testExluirId() {
        //Cenário
        Integer id = 1;
        Slots slots = umSlots().build();

        //Mock
        when(slotsDao.findById(id)).thenReturn(slots);
        
        //Ação
        slotManager.excluir(id);
        
        //Verificação
        verify(slotsDao, times(1)).findById(id);
    }
    
    @Test
    public void testExluirIdComSlotsNull() {
        //Cenário
        Integer id = 1;
        Slots slots = null;

        //Mock
        when(slotsDao.findById(id)).thenReturn(slots);
        
        //Ação
        slotManager.excluir(id);
        
        //Verificação
        verify(slotsDao, times(1)).findById(id);
    }
    
    @Test
    public void testExluirSlots() {
        //Cenário
        Slots slot = umSlots().comId(1).build();
        List<Dialogo> dialogo = Arrays.asList(umDialogo().build());
        
        List<RespostaDialogoSlot> listaResposta = Arrays.asList(umRespostaDialogoSlot().build());
        
        //Mock
        when(dialogoDao.carregarMultiplaRespotaSlot(slot.getId())).thenReturn(dialogo);
//        dialogoManager.excluir(Mockito.any(Dialogo.class), true);
        when(respostaDialogoSlotDao.findByDialogoSlot(slot.getId())).thenReturn(listaResposta);
        respostaDialogoSlotDao.remove(listaResposta.get(0));
        
        //Ação
        slotManager.excluir(slot);
        
        //Verificação
        verify(dialogoDao, times(1)).carregarMultiplaRespotaSlot(slot.getId());
        // verify(dialogoManager, times(2)).excluir(Mockito.any(Dialogo.class), false);
        verify(respostaDialogoSlotDao, times(1)).findByDialogoSlot(slot.getId());
        verify(respostaDialogoSlotDao, times(2)).remove(listaResposta.get(0));
    }
    
    @Test
    public void testGetPrimeiraResposta() {
        //Cenário
        Dialogo dialogo = umDialogo().comId(1).comIdClassificador(2).build();
        List<RespostaDialogoSlot> respostas = Arrays.asList(umRespostaDialogoSlot().comTextoResposta("Padrão").build());
        
        Slots slot = umSlots().comId(1).comDialogo(dialogo).comListaRespostas(respostas).comSlotNaoPreenchidoHash(null).comHashDadoValido(null).comHashDadoInvalido(null).build();
        
        //Ação
        slotManager.getPrimeiraResposta(slot);
        
    }
    
    @Test
    public void testGetPrimeiraRespostaComTextoNull() {
        //Cenário
        Dialogo dialogo = umDialogo().comId(1).comIdClassificador(2).build();
        List<RespostaDialogoSlot> respostas = Arrays.asList(umRespostaDialogoSlot().comTextoResposta(null).build());
        
        Slots slot = umSlots().comId(1).comDialogo(dialogo).comListaRespostas(respostas).comSlotNaoPreenchidoHash(null).comHashDadoValido(null).comHashDadoInvalido(null).build();
        
        //Ação
        slotManager.getPrimeiraResposta(slot);
    }
    
    @Test
    public void testListarVersao() {
        //Cenário
        Integer idClassificador = 140;
        
        VariavelContexto variavel = umVariavelContexto().comUuid("").build();
        
        Tag tag = umTag().comId(1).build();
        List<Tag> tags = Arrays.asList(tag);
        
        RespostaDialogoSlotPK id = umRespostaDialogoSlotPK().comIdResposta(1).build();
        TipoResposta tipo = umTipoResposta().comNomeJSON("Json").build();
        List<RespostaDialogoSlot> respostas = Arrays.asList(umRespostaDialogoSlot().comId(id).comTipoResposta(tipo).build());
        
        //slots.comFilhos(filhos)
        Dialogo dialogo = umDialogo().comId(10).comUuid("123456").comNome("Dialogo").build();
        Dialogo pai = umDialogo().comUuid("4689789").build();
        Dialogo enviar = umDialogo().comUuid("7894561").build();
        Slots slotPai = umSlots().comUuid("456123").build();
        RespostaDialogoPK idRespostaDialogo = umRespostaDialogoPK().comIdDialogo(1).comIdResposta(1).comSequenciaBloco(1).comSequenciaItem(1).build();
        TipoResposta tipoResposta = umTipoResposta().comNomeJSON("Nome Json").build();
        RespostaDialogo respostaDialogo = umRespostaDialogo().comId(idRespostaDialogo).comTipoResposta(tipoResposta).build();
        List <Dialogo> filhos = Arrays.asList(umDialogo().comId(2).comIdPai(1).comPai(pai).comEnviarPara(enviar).comIdSlotsPai(3).comListaRespostas(respostaDialogo).comSlotsPai(slotPai).build());
        
        List<Slots> slots = Arrays.asList(umSlots()
                                         .comCodTipoLocalizador(TipoCondicaoDialogo.INTENCAO)
                                         .comCondicao("Condicao")
                                         .comCondicaoSlots("Condição do Slot")
                                         .comDialogo(dialogo)
                                         .comFilhos(filhos)
                                         .comHashDadoInvalido(null)
                                         .comHashDadoValido(null)
                                         .comId(1)
                                         .comIdDialogo(2)
                                         .comIdentificador("Identificador")
                                         .comIdVariavelContexto(null)
                                         .comIndicadorLimparContexto(true)
                                         .comIndicadorObrigatorio(false)
                                         .comIndicadorRespostaMultipla(false)
                                         .comJson("Json")
                                         .comListaRespostas(respostas)
                                         .comSlotDadoInvalido(null)
                                         .comSlotDadoValido(null)
                                         .comSlotNaoPreenchido(null)
                                         .comSlotNaoPreenchidoHash(null)
                                         .comTags(tags)
                                         .comUuid("123456")
                                         .comVariavelContexto(variavel)
                                         .build());
        
        int ordinal = 2;
        List<Slots> slots2 = Arrays.asList(umSlots().comCodTipoLocalizador(TipoCondicaoDialogo.getValor(ordinal)).build());

        
        //Mock
        when(slotsDao.listarVersao(idClassificador)).thenReturn(slots);
        
        //Ação
        slotManager.listarVersao(idClassificador);
        
        //Verificação
        verify(slotsDao, times(1)).listarVersao(idClassificador);
    }
    
    @Test
    public void testLimparPorClassificador() {
        //Cenário
        Integer idClassificador = 140;
        
        List<Slots> slots = Arrays.asList(umSlots()
                                         .comId(1)
                                         .build());
        
        //Mock
        when(slotsDao.listarVersao(idClassificador)).thenReturn(slots);
        cacheProgresso.atualizar("RECOVERY_" + idClassificador + "_PROGRESSO", 3, "Removendo slot 1/1");
        
        //Ação
        slotManager.limparPorClassificador(idClassificador);
        
        //Verificação
        verify(slotsDao, times(1)).listarVersao(idClassificador);
    }
    
}
