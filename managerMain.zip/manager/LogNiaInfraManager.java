package br.com.bb.gearq.c4coleta.manager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.json.JSONArray;
import org.json.JSONObject;

import br.com.bb.gearq.c4coleta.dao.CuradoriaLogDao;
import br.com.bb.gearq.c4coleta.dao.LogNiaInfraSlaveDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoFormulario;
import br.com.bb.gearq.c4coleta.model.CuradoriaLog;
import br.com.bb.gearq.c4coleta.model.LogNiaInfra;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.PerguntaLogVO;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("logNiaInfraManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class LogNiaInfraManager {

    @In(create = true)
    private LogNiaInfraSlaveDao logNiaInfraSlaveDao;
    
    @In(create = true)
    private CuradoriaLogDao curadoriaLogDao;
    
    @In(create = true)
    private NuvemWatsonDao nuvemWatsonDao;
    
	public Paginacao<LogNiaInfra> findPorPeriodoEServicoETipo(Paginacao<LogNiaInfra> paginacao, 
			String dataInicial, String dataFinal, String tipoConsulta, int idClassificador, String filtroServico)
            throws NegocioException {
		
		List<String> listaSiglaNuvem = buscarListaNuvem(idClassificador, filtroServico);
		if(!listaSiglaNuvem.isEmpty()) {
			paginacao = logNiaInfraSlaveDao.findPorPeriodoEServicoETipo(paginacao, dataInicial, dataFinal, tipoConsulta, listaSiglaNuvem);
			formatarDados(paginacao);
		} else {
			Paginacao<LogNiaInfra> novaPaginacao = new Paginacao<LogNiaInfra>();
			novaPaginacao.setPaginaAtual(1);
			novaPaginacao.setRegistrosPagina(paginacao.getRegistrosPagina());
			paginacao = novaPaginacao;
		}
        return paginacao;
    }

	private List<String> buscarListaNuvem(int idClassificador, String filtroServico) {
		List<String> listaSiglaNuvem = new ArrayList<String>();
		List<NuvemWatson> listaNuvemWatson = nuvemWatsonDao.findByClassificador(idClassificador);
		for (NuvemWatson nuvemWatson : listaNuvemWatson) {
			if(filtroServico == null || nuvemWatson.getNome().toUpperCase().contains(filtroServico.toUpperCase())) {
				listaSiglaNuvem.add(nuvemWatson.getSiglaNuvem());
			}
		}
		return listaSiglaNuvem;
	}
	
	private void formatarDados(Paginacao<LogNiaInfra> paginacao) {
		for(LogNiaInfra log: paginacao.getListaPaginada()) {
			preencherResposta(log);
			buscarCuradoriaLog(log);
			buscarServicoCognitivo(log);
		}
	}

	private void preencherResposta(LogNiaInfra log) {
        if(log.getRespostas() == null || log.getRespostas().isEmpty()) {
            log.setRespostas(new ArrayList<String>());
            if(log.getJson() != null) {
                String valor = log.getJson();
                JSONObject json = new JSONObject(valor);
                JSONObject output = json.getJSONObject("output");
                if(output != null) {
                    JSONArray jsonArray = output.getJSONArray("text");
                    for (int i = 0; i < jsonArray.length(); i++) {
                    	log.getRespostas().add(new String((String)jsonArray.get(i)));
                    }
                }
            }
        }
	}
	
	private void buscarCuradoriaLog(LogNiaInfra log) {
		CuradoriaLog curadoriaLog = curadoriaLogDao.buscarPorLogNiaInfra(log.getId());
		if(curadoriaLog == null) {
			curadoriaLog = new CuradoriaLog();
			curadoriaLog.setIdLogNiaInfra(log.getId());
		}
		log.setCuradoriaLog(curadoriaLog);
	}

	private void buscarServicoCognitivo(LogNiaInfra log) {
		if(log.getServico() != null) {
			List<NuvemWatson> listaNuvem = nuvemWatsonDao.findBySigla(log.getServico());
			if(!listaNuvem.isEmpty()) {
				log.setNomeServicoCognitivo(listaNuvem.get(0).getNome());
			}
		}
	}
	
    public Paginacao<LogNiaInfra> findByLogNiaInfraDialogos(Paginacao<LogNiaInfra> paginacao, String dataInicial,
            String dataFinal, String chave, String idConversa, String servico, Integer idClassificador) {
 
        Date dataIni = FormatarData.tratarDataPeriodo(dataInicial, true);
        Date dataFim = FormatarData.tratarDataPeriodo(dataFinal, false);
        
        if (idConversa != null && idConversa.trim().equals("") ) {
            idConversa = null;
        }
        
        if (chave != null && chave.trim().equals("") ) {
            chave = null;
        }
        
        List<String> siglas = getSiglas(servico, idClassificador);
        
        Paginacao<LogNiaInfra> paginacaoLogs = logNiaInfraSlaveDao.findByLogNiaInfraDialogos(paginacao, dataIni, dataFim, chave, idConversa, siglas);
     
        List<LogNiaInfra> listaRetorno = new ArrayList<LogNiaInfra>();

        for (Object o : paginacaoLogs.getListaPaginada()) {
            Object[] obs = (Object[]) o;
            LogNiaInfra l = new LogNiaInfra();

            l.setChave((String) obs[0]);

            if (obs[1] != null) {
                l.setDataHora((Date) obs[1]);
            }

            if (obs[2] != null) {
                l.setIdConversa((String) obs[2]);
            }

            if (obs[3] != null) {
                l.setServico((String) obs[3]);
            }

            if (obs[3] != null) {
                l.setNomeServicoCognitivo(logNiaInfraSlaveDao.buscarServicoCognitivo((String) obs[3]));
            }

            listaRetorno.add(l);
        }

        paginacaoLogs.setListaPaginada(listaRetorno);
        return paginacaoLogs;
    }

    private List<String> getSiglas(String servico, Integer idClassificador) {
        List<String> siglas = new ArrayList<String>();
        if (servico != null && !servico.isEmpty()) {
            siglas.add(servico);            
        } else if(idClassificador != null) {
            for (NuvemWatson nuvemWatson : nuvemWatsonDao.findByClassificador(idClassificador)) {
                siglas.add(nuvemWatson.getSiglaNuvem());                                
            }
        }
        return siglas;
    }

    public Paginacao<LogNiaInfra> findByLogNiaInfra(Paginacao<LogNiaInfra> paginacao, String dataInicial,
            String dataFinal, String tipoServicoInfra, String pergunta, String tipoOrdem, String hash, String chave,
            String idConversa, String tipoConsulta, Integer idClassificador) {
        
        Date dataIni = FormatarData.tratarDataPeriodo(dataInicial, true);
        Date dataFim = FormatarData.tratarDataPeriodo(dataFinal, false);
        
        List<String> siglas = getSiglas(tipoServicoInfra, idClassificador);
        
        return logNiaInfraSlaveDao.findByLogNiaInfra(paginacao, dataIni, dataFim, siglas, pergunta, tipoOrdem, hash, idConversa, tipoConsulta, chave);
    }

    public List<PerguntaLogVO> findLogPerguntas(int idInicio, int idFim) {
        List<PerguntaLogVO> logs = new ArrayList<PerguntaLogVO>();
        for (Object[] object : logNiaInfraSlaveDao.findLogPerguntas(idInicio, idFim)) {
            logs.add(new PerguntaLogVO((Object[]) object));
        }
        return logs;
    }
    
    public int ultimoIdLogNiaInfra() {
        return logNiaInfraSlaveDao.ultimoIdLogNiaInfra();
    }
    
    public LogNiaInfra getMaxAndMinDate() {
        return logNiaInfraSlaveDao.getMaxAndMinDate();
    }
    
    public Map<String,Long> mapLogNiaInfraQuantidadeIteracaoPorChave(String dataInicial, String dataFinal, String servico, AvaliacaoFormulario avaliacaoFormulario, String origem) throws ParseException {
        return logNiaInfraSlaveDao.mapLogNiaInfraQuantidadeIteracaoPorChave(dataInicial, dataFinal, servico, avaliacaoFormulario, origem);
    }
    
    public List<String> listaLogNiaInfraQuantidadeIteracaoPorChave(String dataInicial, String dataFinal, String servico, AvaliacaoFormulario avaliacaoFormulario, String origem) throws ParseException {
        return logNiaInfraSlaveDao.listaLogNiaInfraQuantidadeIteracaoPorChave(dataInicial, dataFinal, servico, avaliacaoFormulario, origem);
    }
    
    
	
}
