package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoServicoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.util.PermissaoUsuario;
import br.com.bb.gearq.c4coleta.vo.PermissaoUsuarioVO;

@Name("gerarVersaoPermissaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class GerarVersaoPermissaoManager {

    @In(create = true)
    private PermissaoUsuarioManager permissaoUsuarioManager;

    @In(create = true)
    private PermissaoUsuario permissaoUsuario;

    @In(create = true)
    private NivelAcessoClassificadorDao nivelAcessoClassificadorDao;

    @In(create = true)
    private NivelAcessoServicoDao nivelAcessoServicoDao;

    @In(create = true)
    private ClassificadorDao classificadorDao;

    /**
     * verifica o nivel de permissão do usuario logado apenas usuarios com nivel de
     * curador master pode gerar versão e sincronizar os corpus.
     * 
     * @return
     */
    public boolean nivelPermissaoGerarVersao(Integer idClassificador) {

        Classificador classificador = classificadorDao.findById(idClassificador);

        if (permissaoUsuario.isAuditor() || permissaoUsuario.isMaster()) {
            return true;
        }
        // serviço
        PermissaoUsuarioVO permissaoServico = permissaoUsuarioManager
                .recuperarPermissao(classificador.getServicoNlc().getId(), false);

        // classificador
        PermissaoUsuarioVO permissaoClassificador = permissaoUsuarioManager.recuperarPermissao(idClassificador, true);

        return permissaoClassificador.isCuradorMaster() || permissaoServico.isCuradorMaster();
    }

}
