package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import com.vdurmont.emoji.EmojiParser;

import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.enums.TipoFormatacao;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoPK;
import br.com.bb.gearq.c4coleta.vo.DialogoRespostaBlocoVo;
import br.com.bb.gearq.c4coleta.vo.DialogoRespostaVo;

@Name("respostaDialogoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class RespostaDialogoManager {

    @In(create = true)
    private RespostaDialogoDao respostaDialogoDao;

    @In(create = true)
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @In(create = true)
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;

    public RespostaDialogo salvar(RespostaDialogo resposta) {
        if (resposta.getTextoResposta() != null) {
            if (resposta.getTipoResposta() != null
                    && TipoFormatacao.WHATSAPP.equals(resposta.getTipoResposta().getTipoFormatacao())) {
                String textoWhatsappFormatado = formattingHTMLToTextWhatsapp(resposta.getTextoResposta());
                resposta.setTextoResposta(textoWhatsappFormatado);
            }
            resposta.setTextoResposta(EmojiParser.parseToAliases(resposta.getTextoResposta()));
        }
        return respostaDialogoDao.persist(resposta);
    }

    public RespostaDialogo criar(Dialogo node) {
        RespostaDialogo resposta = new RespostaDialogo();
        resposta.setId(new RespostaDialogoPK());
        resposta.getId().setIdDialogo(node.getId());
        resposta.getId().setSequenciaBloco(1);
        resposta.getId().setSequenciaItem(1);
        resposta.getId().setIdResposta(1);
        return resposta;
    }

    public void excluir(RespostaDialogo resposta) {
        respostaDialogoDao.remove(resposta);
    }

    public void limparPorClassificador(Integer idClassificador) {
        for (RespostaDialogo resposta : respostaDialogoDao.listarVersao(idClassificador)) {
            excluir(resposta);
        }
    }

    public List<DialogoRespostaVo> obterRespostasPadrao(Integer idDialogo) {
        DialogoRespostaVo respostaVO = new DialogoRespostaVo();
        respostaVO.setBlocos(new ArrayList<DialogoRespostaBlocoVo>());

        for (RespostaDialogo resp : respostaDialogoDao.findByDialogoETipoResposta(idDialogo, 1)) {
            DialogoRespostaBlocoVo bloco = null;

            // recuperar se existe uma sequencia no bloco
            for (DialogoRespostaBlocoVo blocoSeq : respostaVO.getBlocos()) {
                if (blocoSeq.getSequenciaBloco().equals(resp.getId().getSequenciaBloco())) {
                    bloco = blocoSeq;
                    break;
                }
            }

            if (bloco == null) {
                bloco = new DialogoRespostaBlocoVo();
                bloco.setSequenciaBloco(resp.getId().getSequenciaBloco());
                bloco.setIdTipoComponente(resp.getIdTipoComponenteVisual());
                Integer idTipoComponente = resp.getIdTipoComponenteVisual();
                if (idTipoComponente == null) {
                    idTipoComponente = 1;
                }
                bloco.setTipoComponente(tipoComponenteVisualDao.findById(idTipoComponente));
                bloco.setTempoResposta(resp.getTempoResposta());
                bloco.setRespostas(new ArrayList<>());
                respostaVO.getBlocos().add(bloco);
            }

            bloco.getRespostas().add(resp);
        }
        List<DialogoRespostaVo> dialogoRespostas = new ArrayList<>();
        dialogoRespostas.add(respostaVO);
        return dialogoRespostas;
    }

    public void salvar(DialogoRespostaVo respostaVo, Integer idDialogo) {
        for (RespostaDialogo resp : respostaVo.getRespostas()) {
            resp.getId().setIdDialogo(idDialogo);
            respostaDialogoDao.persist(resp);
        }
    }

    public String formattingTextWhatsappToHTML(String texto) {
        texto = texto.replaceAll("\\ \\*(.*)\\*\\ ", "\\ <strong>$1</strong>\\ ");
        texto = texto.replaceAll("\\ \\_(.*)\\_\\ ", "\\ <em>$1</em>\\ ");
        return texto;
    }

    private String formattingHTMLToTextWhatsapp(String texto) {
        texto = texto.replaceAll("\\</?strong>", "*");
        texto = texto.replaceAll("\\</?em>", "_");
        texto = texto.replaceAll("\\<.*?\\>", "");
        return texto;
    }

}
