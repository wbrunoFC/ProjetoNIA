package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AgrupadorSinonimosDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeVODao;
import br.com.bb.gearq.c4coleta.dao.SinonimoDao;
import br.com.bb.gearq.c4coleta.model.AgruparEntidadeSinonimos;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Sinonimo;
import br.com.bb.gearq.c4coleta.versionamento.v1.EntidadeVersaoV1;
import br.com.bb.gearq.c4coleta.vo.BuscaAvancadaEntidadeVO;
import br.com.bb.gearq.c4coleta.vo.EntidadeVO;
import br.com.bb.gearq.c4coleta.vo.MigrarEntidadeVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.MensagemNegocio;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("entidadeManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class EntidadeManager {

	@In(create = true)
	private EntidadeDao entidadeDao;
	
	@In(create=true)
	private ClassificadorDao classificadorDao;
	
	@In(create = true)
	private AgrupadorSinonimosDao agrupadorSinonimosDao;
	
	@In(create = true)
	private SinonimoDao sinonimoDao;

	@In(create = true)
	private FluxoManager fluxoManager;
	
	@In(create = true)
    private EntidadeVODao entidadeVODao;
	
	@In(create = true)
	private CacheProgresso cacheProgresso;
	
	public Paginacao<Entidade> listarEntidades(int idClassificador, String entidade,Paginacao<Entidade> paginacao, int colunaOrdenacao, boolean asc, boolean showsys) throws NegocioException{
	    return entidadeDao.findEntidade(paginacao, idClassificador, entidade, colunaOrdenacao, asc, showsys);
	}
	
	public Paginacao<EntidadeVO> listarEntidadesVO(int idClassificador, String entidade,Paginacao<EntidadeVO> paginacao, int colunaOrdenacao, boolean asc, boolean showsys) throws NegocioException{
        return entidadeVODao.findEntidadeVO(paginacao, idClassificador, entidade, colunaOrdenacao, asc, showsys);
    }
	
	public Paginacao<Entidade> listarEntidades(int idClassificador, String entidade,Paginacao<Entidade> paginacao, int colunaOrdenacao, boolean asc) throws NegocioException{
        return entidadeDao.findEntidade(paginacao, idClassificador, entidade, colunaOrdenacao, asc, false);
    }
	
	public List<Entidade> listarEntidadesClassiFluxo(int idClassificador, String entidade) throws NegocioException{
		return findByClassificadorFluxo(idClassificador,entidade); 	
	}
	
	public List<Entidade> listarEntidadesSistema(int idClassificador) throws NegocioException{
		List<Entidade> entidades = new ArrayList<Entidade>();
		entidades.addAll(findByClassificadorFluxo(idClassificador,"sys-currency"));
		entidades.addAll(findByClassificadorFluxo(idClassificador,"sys-date"));
		entidades.addAll(findByClassificadorFluxo(idClassificador,"sys-number"));
		entidades.addAll(findByClassificadorFluxo(idClassificador,"sys-percentage"));
		entidades.addAll(findByClassificadorFluxo(idClassificador,"sys-time"));
		return entidades;
	}
	
	public List<Entidade> findByClassificadorFluxo(int idClassificador, String nome) {
	    
	    if(nome.length() > 2) {
	        return entidadeDao.findByClassificadorFluxo(idClassificador, nome);
	    
	    }else{
	        return new ArrayList<Entidade>();
	    }
    }
	

	
	public List<Entidade> buscarEntidadePorNomeExato(String nome, int idClassificador) {
	    return entidadeDao.findByNomeExato(idClassificador, nome);
	}
	
	public Entidade salvar(int idClassificador, Entidade entidade) {
		boolean entidadeAlterada = false;
		String nomeEntidadeFormulario = entidade.getNome();
		if(entidade.getId()==null || entidade.getId() == 0){
			if (!existeEntidadeCadastrada(idClassificador, entidade)) {
				entidade.setDataCriacao(new Date());
				entidade.setDataModificacao(entidade.getDataCriacao());
				entidade.setIdClassificador(idClassificador);
				entidade.setFuzzyMatch(entidade.getFuzzyMatch());
				entidade = entidadeDao.persist(entidade);
			}
		}else{
			Entidade entidadeConsulta = buscarEntidade(entidade.getId());
			
			if(entidadeConsulta.getFuzzyMatch() != entidade.getFuzzyMatch()){
				entidadeAlterada = true;
				entidade.setFuzzyMatch(entidade.getFuzzyMatch());
				entidadeDao.persist(entidade);
			}
			
			if (!nomeEntidadeFormulario.equals(entidadeConsulta.getNome())) {
				if(!existeEntidadeCadastrada(idClassificador, entidade)){
					entidade.setDataModificacao(new Date());
					entidade = entidadeDao.persist(entidade);
				}
			}
		}
		
		if(entidade.getAgrupadores() != null && !entidade.getAgrupadores().isEmpty() && entidade.getAgrupadores().size() > 0){
			
			for(AgruparEntidadeSinonimos agr :entidade.getAgrupadores()){
				if(agr.getNome() != ""){
					String nomeAgrupadorFormulario = agr.getNome();
					if (agr.getId() == null || agr.getId() == 0) {
						if (!existeAgrupadorCadastrado(agr, entidade.getId())) {
							entidadeAlterada = true;
							agr.setIdEntidade(entidade.getId());
							agr.setEntidade(entidade);
							//cadastra o agrupador
							agr = salvarEditarAgrupador(agr);
						}
					}
					if (agr.getId() != null || agr.getId() > 0) {
						AgruparEntidadeSinonimos agrupadorConsulta = new AgruparEntidadeSinonimos();
						agrupadorConsulta = buscarAgruparEntidadeSinonimos(agr.getId());
						if (!nomeAgrupadorFormulario.equals(agrupadorConsulta.getNome()) || !agr.getTipo().equals(agrupadorConsulta.getTipo())) {
							if (!existeAgrupadorCadastrado(agr, entidade.getId())) {
								entidadeAlterada = true;
								//edita o agrupador
								agr = salvarEditarAgrupador(agr);
							}
						}
					}
					
					
					//cadastrar sinonimos caso tenho. 
					if (!agr.getSinonimos().isEmpty() && agr.getSinonimos().size() > 0) {
						
						for(Sinonimo sin : agr.getSinonimos()){
							if (agr.getId() != null || agr.getId() > 0) {
								if(sin.getNome() != ""){
									String nomeSinonimoFormulario = sin.getNome();
									if (sin.getId() == null || sin.getId() == 0) {
										if (!existeSinonimoCadastrado(sin.getNome(), entidade.getId())) {									
											entidadeAlterada = true;
											sin.setAgruparSinonimo(agr);
											// grava novo sinonimo
											salvarEditarSinonimo(sin);
										}
									}else{
										Sinonimo sinonimoConsulta = new Sinonimo();
										sinonimoConsulta = buscarSinonimo(sin.getId());
										if (!nomeSinonimoFormulario.toUpperCase().equals(sinonimoConsulta.getNome().toUpperCase())) {
											if (!existeSinonimoCadastrado(nomeSinonimoFormulario, entidade.getId())) {
												entidadeAlterada = true;
												// edita o sinonimo
												salvarEditarSinonimo(sin);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		if(entidadeAlterada) {
			atualizarDataModificacaoEntidade(entidade.getId());
		}
		entidadeDao.flush();
		return entidade;
	}
	
	private Sinonimo buscarSinonimo(Integer idSinonimo) {
		return sinonimoDao.findIdSinonimo(idSinonimo);
	}

	/**
	 * Verifica se existe o sinonimo na Entidade, (true=Sim, false=Não)
	 * @param nomeSinonimo
	 * @param idEntidade
	 * @return (true=Sim, false=Não)
	 * @throws NegocioException
	 */
	private boolean existeSinonimoCadastrado(String nomeSinonimo, Integer idEntidade) throws NegocioException {
		String nomeSinonimoFormulario = nomeSinonimo;
		List<Sinonimo> sinoList = new ArrayList<Sinonimo>();
		sinoList = sinonimoDao.findEntidadeId(idEntidade);
		for (Sinonimo sinonimo : sinoList) {
			if (nomeSinonimoFormulario.toUpperCase().equals(sinonimo.getNome().toUpperCase())) {
				throw new NegocioException("Sinônimo: "
						+ nomeSinonimoFormulario + " já existe na Entidade");
			}
		}

		return false;
	}

	private AgruparEntidadeSinonimos buscarAgruparEntidadeSinonimos(Integer idAgruparEntidadeSinonimos) {
		AgruparEntidadeSinonimos agruparEntidadeSinonimos = agrupadorSinonimosDao.findByIdAgrupador(idAgruparEntidadeSinonimos);
		return agruparEntidadeSinonimos;
	}
	
	/**
	 * Verifica se existe o Agrupamento na Entidade, (true=Sim, false=Não)
	 * @param agr
	 * @param idEntidade
	 * @return (true=Sim, false=Não)
	 * @throws NegocioException
	 */
	private boolean existeAgrupadorCadastrado(AgruparEntidadeSinonimos agr, Integer idEntidade) throws NegocioException {
		String nomeAgrupadorFormulario = agr.getNome();
		List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = new ArrayList<AgruparEntidadeSinonimos>();
		listaAgruparEntidadeSinonimos = agrupadorSinonimosDao.findAgrupadorIdEntidade(idEntidade, agr.getId());
		for (AgruparEntidadeSinonimos agruparEntidadeSinonimos : listaAgruparEntidadeSinonimos) {
			if (nomeAgrupadorFormulario.toUpperCase().equals(agruparEntidadeSinonimos.getNome().toUpperCase())) {
				throw new NegocioException("Agrupador: "+ nomeAgrupadorFormulario+" já existe!");
			}
		}
		return false;
	}

	/**
	 * Verifica se existe a Entidade no Classificador, (true=Sim, false=Não)
	 * @param idClassificador
	 * @param entidade
	 * @return (true=Sim, false=Não)
	 * @throws NegocioException
	 */
	private boolean existeEntidadeCadastrada(int idClassificador, Entidade entidade) throws NegocioException {
		String nomeEntidadeFormulario = entidade.getNome();
		List<Entidade> listaEntidade = new ArrayList<Entidade>();
		listaEntidade = entidadeDao.findByClassificador(idClassificador);
		for (Entidade entidadeAux : listaEntidade) {
			if (!entidadeAux.getId().equals(entidade.getId()) && nomeEntidadeFormulario.toUpperCase().equals(entidadeAux.getNome().toUpperCase())) {
				throw new NegocioException("Entidade: "+ nomeEntidadeFormulario+" já existe!");
			}
		}
		return false;
	}

	public Entidade buscarEntidade(int idEntidade ) {		
		return entidadeDao.findIdEntidade(idEntidade);
	}
	
	public List<AgruparEntidadeSinonimos> listarAgrupador(Entidade entidade ) throws NegocioException{	
		return agrupadorSinonimosDao.findAgrupadorIdEntidade(entidade.getId(), null);
	 }

	public AgruparEntidadeSinonimos salvarEditarAgrupador(AgruparEntidadeSinonimos agrupador ) throws NegocioException{	
		return agrupadorSinonimosDao.persist(agrupador);
		
	}

	public void salvarEditarSinonimo(Sinonimo sinonimo) throws NegocioException{
		if (sinonimo != null){
			sinonimoDao.persist(sinonimo);
		}
	}

	
	public List<Sinonimo> listarSinonimos(AgruparEntidadeSinonimos agrupador) throws NegocioException{
		return sinonimoDao.findAgrupadorId(agrupador.getId());
	}

	public void removerSinonimo(Sinonimo sinonimo) throws NegocioException{
		Sinonimo sinonimoRemover = sinonimoDao.findIdSinonimo(sinonimo.getId());
		if (sinonimoRemover != null ){ 
		    atualizarDataModificacaoEntidade(sinonimoRemover.getAgruparSinonimo().getEntidade().getId());
			sinonimoDao.removeAndFlush(sinonimoRemover);
		}
	}

	
	public void removerAgrupador(AgruparEntidadeSinonimos agrupador) throws NegocioException{
		if(agrupador.getId() != null && agrupador.getId() > 0){
			
			//remover sinonimos
			if(agrupador.getSinonimos() != null){
				
				for(Sinonimo si : agrupador.getSinonimos()){
					removerSinonimo(si);
				}
				
			}
			//remover agrupador
			AgruparEntidadeSinonimos agrupadorRemover = agrupadorSinonimosDao.findByIdAgrupador(agrupador.getId());
			atualizarDataModificacaoEntidade(agrupadorRemover.getEntidade().getId());
			agrupadorSinonimosDao.removeAndFlush(agrupadorRemover);
		}
	}
	
	public void excluir(Integer idEntidade) {
	    Entidade entidade = this.buscarEntidade(idEntidade);
	    excluir(entidade);
	}
	
	public void excluir(Entidade entidade) {
		List<Fluxo> listaFluxo = new ArrayList<>();
		for (AgruparEntidadeSinonimos agrupador : entidade.getAgrupadores()) {
		    listaFluxo.addAll(fluxoManager.listarPorAgrupador(agrupador.getId()));
		}
		
		if(!listaFluxo.isEmpty()) {
			throw new NegocioException(criarMensagemErroFluxo(entidade, listaFluxo));
		}
		
		for (AgruparEntidadeSinonimos agrupador : entidade.getAgrupadores()) {
		    for (Sinonimo sinonimo : agrupador.getSinonimos()) {
		        sinonimoDao.remove(sinonimo);
            }
		    agrupadorSinonimosDao.remove(agrupador);
        }
		entidadeDao.remove(entidade);
	}
	
	private void atualizarDataModificacaoEntidade(int idEntidade) {
		Entidade e = entidadeDao.findById(idEntidade);
		e.setDataModificacao(new Date());
		entidadeDao.persist(e);
	}
	
	private List<MensagemNegocio> criarMensagemErroFluxo(Entidade e, List<Fluxo> fluxos) {
		List<MensagemNegocio> mensagens = new ArrayList<>();
		MensagemNegocio msg = new MensagemNegocio();
		msg.setTextoMensagem("Não é permitida a exclusão da entidade "
				+ e.getNome() +", pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
		mensagens.add(msg);
		Set<String> entidades = removerNomesRepetidosFluxo(fluxos);
		for(String nomeEnt: entidades){
			msg = new MensagemNegocio();
			msg.setTextoMensagem("- " + nomeEnt);
			mensagens.add(msg);
		}
		return mensagens;
	}

	private Set<String> removerNomesRepetidosFluxo(List<Fluxo> fluxos) {
		Set<String> nomes = new HashSet<String>();
		for(Fluxo f: fluxos){
			if(f.getFluxoPai() != null && f.getFluxoPai().getIntencao() != null){
				nomes.add(f.getFluxoPai().getIntencao().getNome());
			}
		}
		return nomes;
	}

	public Paginacao<AgruparEntidadeSinonimos> agrupadorEntidadeFluxo(Paginacao<AgruparEntidadeSinonimos> paginacao,int idClassificador,String cpNome) throws NegocioException{
		
			paginacao =	agrupadorSinonimosDao.findByAgrupadorEntidade(paginacao, idClassificador, cpNome);
		
		return paginacao; 
	
	}
	
	public void migrar(MigrarEntidadeVO mi  ) throws NegocioException {
		
		
		if (mi.getClassificador() == null){
			throw new NegocioException("Selecione um Classificador.");
		}
		
		if (mi.getListaEntidade().isEmpty()){
			throw new NegocioException("Selecione uma ou mais entidades.");
		}
		
		List<Entidade> listaEntidadeClassificador = entidadeDao.findByClassificador(mi.getClassificador().getId());
		List<String> nomeIguaisErro = new ArrayList<String>();
		List<String> listaFluxos = new ArrayList<String>();
		List<ApresentarErroEntidadeFluxo> listaEntidadeFluxoErro = new ArrayList<EntidadeManager.ApresentarErroEntidadeFluxo>();
		List<AgruparEntidadeSinonimos> listaAgrupador =  new ArrayList<AgruparEntidadeSinonimos>();
		
		for (Entidade i :mi.getListaEntidade()){
			listaAgrupador.addAll(listarAgrupador(i));
			
			List<Fluxo> listaFluxo = new ArrayList<Fluxo>();
			
			for (AgruparEntidadeSinonimos a : listaAgrupador) {
				listaFluxo.addAll(fluxoManager.listarPorAgrupador(a.getId()));
			}
			
			ApresentarErroEntidadeFluxo apresentarErroEntidadeFluxo = new ApresentarErroEntidadeFluxo(i, new ArrayList<Fluxo>());
			
			for(Fluxo f: listaFluxo){
				apresentarErroEntidadeFluxo.getListaFluxos().add(f);
			}
			
			if (!apresentarErroEntidadeFluxo.getListaFluxos().isEmpty()){
				listaEntidadeFluxoErro.add(apresentarErroEntidadeFluxo);
			}
			
		
			if(!listaFluxo.isEmpty()){
				listaFluxos.add(i.getNome()); 
			}
		
			for (Entidade iC: listaEntidadeClassificador){
				if (iC.getNome().equals(i.getNome())){ 
					nomeIguaisErro.add(iC.getNome());
				}
			};
			
		};
		
		
		if (!nomeIguaisErro.isEmpty()){
			throw new NegocioException(criarMensagemErro("Não é permitido migrar a(s) entidade(s) listada(s) abaixo, pois a(s) mesma(s) já existe(m) no corpus selecionado:" ,nomeIguaisErro));
		}
		
		if (!listaEntidadeFluxoErro.isEmpty()){
			throw new NegocioException(criarMensagemErroIntencaoFluxo(listaEntidadeFluxoErro, "Não é permitida a migração da(s) entidade(s):"));
		}	
		
		for (Entidade i :mi.getListaEntidade()){
			i.setClassificador(mi.getClassificador());
			entidadeDao.persist(i);
		};
		
		entidadeDao.flush();

	}
	
	protected class ApresentarErroEntidadeFluxo{
		private Entidade entidade;
		private List<Fluxo> listaFluxos= new ArrayList<Fluxo>();
		
		public ApresentarErroEntidadeFluxo(Entidade entidade,
				List<Fluxo> listaFluxos) {
			super();
			this.entidade = entidade;
			this.listaFluxos = listaFluxos;
		}
		
		public Entidade getEntidade() {
			return entidade;
		}
		public void setEntidade(Entidade entidade) {
			this.entidade = entidade;
		}
		public List<Fluxo> getListaFluxos() {
			return listaFluxos;
		}
		public void setListaFluxos(List<Fluxo> listaFluxos) {
			this.listaFluxos = listaFluxos;
		}
	}
	
	private List<MensagemNegocio> criarMensagemErroIntencaoFluxo(List<ApresentarErroEntidadeFluxo> listaInEntidadeFluxoErro, String msgErro) {
		
		List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
		
		
		for (ApresentarErroEntidadeFluxo erro :listaInEntidadeFluxoErro){
			MensagemNegocio msg = new MensagemNegocio();
			msg.setTextoMensagem(msgErro +erro.getEntidade().getNome()+", pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
			mensagens.add(msg);
			Set<String> entidades = removerNomesRepetidosIntencaoFluxos(erro.getListaFluxos());
			for(String e: entidades){
				msg = new MensagemNegocio();
				msg.setTextoMensagem("- " + e );
				mensagens.add(msg);
			}
		}
		return mensagens;
	}

	private Set<String> removerNomesRepetidosIntencaoFluxos(List<Fluxo> fluxos) {
		Set<String> nomes = new HashSet<String>();
		
		for(Fluxo f: fluxos){
			if(f.getFluxoPai() != null && f.getFluxoPai().getIntencao() != null){				
				nomes.add(f.getFluxoPai().getIntencao().getNome());
			}
		}
		return nomes;
	}

	private List<MensagemNegocio> criarMensagemErro(String mensagemErro, List<String> listaErro) {
		List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
		MensagemNegocio msg = new MensagemNegocio();
		msg.setTextoMensagem(mensagemErro);
		mensagens.add(msg);
		
		Set<String> nomes = removerNomesRepetidos(listaErro);
		for(String i: nomes){
			msg = new MensagemNegocio();
		    msg.setTextoMensagem("- " + i );
		    mensagens.add(msg);
		}
		
		return mensagens;
	}
	
	private Set<String> removerNomesRepetidos(List<String> listaErro) {
		Set<String> nomes = new HashSet<String>();
		for(String l: listaErro){
			nomes.add(l);
		}
		return nomes;
	}
	
	public  void salvarEntidadeCondicao(int idClassificador, String textoConsulta, String operador) {
            String cpNomeEnti  = "" ;
            String cpNomeAgrup = "" ;
            Entidade entidade = new Entidade();
            
            if(operador != null && textoConsulta.indexOf(operador) != -1){
                cpNomeEnti = textoConsulta.substring(0, textoConsulta.indexOf(operador)).trim();
                cpNomeAgrup = textoConsulta.substring(textoConsulta.indexOf(operador)+operador.length(), textoConsulta.length()).trim();
            }else {
                cpNomeEnti = textoConsulta.trim();
            }
            
            List<Entidade> listaEntidade = entidadeDao.findByNomeIgual(cpNomeEnti,idClassificador);
            
            if(!listaEntidade.isEmpty()) {
                entidade = listaEntidade.get(0);
            }else {
                entidade.setNome(cpNomeEnti);
                entidade.setClassificador(classificadorDao.findById(idClassificador));
            }
            
            if (!cpNomeAgrup.isEmpty()){
                AgruparEntidadeSinonimos agrupador = new AgruparEntidadeSinonimos();
                agrupador.setNome(cpNomeAgrup);
                entidade.setAgrupadores(new ArrayList<AgruparEntidadeSinonimos>());
                entidade.getAgrupadores().add(agrupador);
            }
                
            salvar(idClassificador, entidade);
    }

	public Paginacao<Entidade> findBuscaAvancada(BuscaAvancadaEntidadeVO buscaAvancadaEntidade,
			Paginacao<Entidade> paginacao) {
		
		List<Entidade> listaEntidade = null;
		List<AgruparEntidadeSinonimos> listaAgruparEntidadeSinonimos = null;
		List<Sinonimo> listaSinonimos = null; 
		List<Integer> listaIdsEntidade = new ArrayList<Integer>();
		List<Integer> listaIdsAgrupadoresByListaEntidade = new ArrayList<Integer>();
		List<Integer> idsEntidadeConsultaLikeAgrupador = new ArrayList<Integer>();
		List<Integer> listaIdsEntidadeConsultaLikeSinonimo = new ArrayList<Integer>();
		
		
		if (buscaAvancadaEntidade.getCheckValores()) {
			
			listaEntidade = entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador());
			for (Entidade entidade : listaEntidade) {
				listaIdsEntidade.add(entidade.getId());
			}
			
			//AgruparEntidadeSinonimos.findIdListaEntidadeLikeNomeAgrupador
			listaAgruparEntidadeSinonimos = agrupadorSinonimosDao.findIdListaEntidadeLikeNomeAgrupador(buscaAvancadaEntidade, listaIdsEntidade);
			
			for (AgruparEntidadeSinonimos agruparEntidadeSinonimos : listaAgruparEntidadeSinonimos) {
				Entidade entidade = agruparEntidadeSinonimos.getEntidade();
				if (!idsEntidadeConsultaLikeAgrupador.contains(entidade.getId())) {
					idsEntidadeConsultaLikeAgrupador.add(entidade.getId());
				}
			}
		}
		
		if (buscaAvancadaEntidade.getCheckSinonimos()) {
			// Carraga lista de Entidade caso esteja vazia, se nao, aprovieta a lista resultante da busca de Agrupadores (getCheckValores)
			if (listaIdsEntidade.isEmpty()) {
				listaEntidade = entidadeDao.findByClassificador(buscaAvancadaEntidade.getIdClassificador());
				for (Entidade entidade : listaEntidade) {
					listaIdsEntidade.add(entidade.getId());
				}
			}
			
			// se a lista de ids de Entidade não estiver vazia, serão listados os Agrupadores que pertencem a algum id da listaIdsEntidade
			if (!listaIdsEntidade.isEmpty()) {
				//AgruparEntidadeSinonimos.findIdListaEntidade
				listaAgruparEntidadeSinonimos = agrupadorSinonimosDao.listaIdsAgrupadoresByListaEntidade(listaIdsEntidade);
			}
			
			// se a lista de Agrupadores não estiver vazia, serão listados os ids de Agrupadores na lista listaIdsAgrupadoresByListaEntidade
			for (AgruparEntidadeSinonimos agrupador : listaAgruparEntidadeSinonimos) {
				if(!listaIdsAgrupadoresByListaEntidade.contains(agrupador.getId())) {
					listaIdsAgrupadoresByListaEntidade.add(agrupador.getId());
				}
			}
			
			// se a lista dos ids do Agrupadores listaIdsAgrupadores ByListaEntidade não estiver vazia
			// sistema fará consulta de sinônimos que pertecem a algum Agrupador e contêm parte do nome igual ao campo informado na pesquisa
			if(!listaIdsAgrupadoresByListaEntidade.isEmpty()) {
				listaSinonimos = sinonimoDao.findByListaIdsAgrupadoresLikeNome(buscaAvancadaEntidade,listaIdsAgrupadoresByListaEntidade);
			}
			
			for (Sinonimo sinonimo : listaSinonimos) {
				Integer idEntidadeLykeSinonimo = sinonimo.getAgruparSinonimo().getEntidade().getId();
				if (!listaIdsEntidadeConsultaLikeSinonimo.contains(idEntidadeLykeSinonimo)) {
					listaIdsEntidadeConsultaLikeSinonimo.add(idEntidadeLykeSinonimo);
				}
			}
		
		}
		
		paginacao = entidadeDao.findBuscaAvancada(buscaAvancadaEntidade,paginacao,idsEntidadeConsultaLikeAgrupador,listaIdsEntidadeConsultaLikeSinonimo);
		
		List<Entidade> listaAux = new ArrayList<Entidade>(); 
		if(paginacao.getListaPaginada().size() > 0){
			
			listaAux.addAll(paginacao.getListaPaginada());
			
			for( Entidade ent : paginacao.getListaPaginada() ){
				List<AgruparEntidadeSinonimos> agru =  listarAgrupador(ent);
				if( agru != null ){
					for( AgruparEntidadeSinonimos agrupador : agru ){
						agrupador.setEntidade(new Entidade());
						agrupador.getEntidade().setId(ent.getId());
					}
				}
				ent.setAgrupadores(agru);
			}
		}

		return paginacao;
	}
	
	/**
	 * 
	 * @param idClassificador
	 * @return Lista as Entidades pelo idClassificador
	 * @throws NegocioException
	 */
		
	public List<Entidade> listarEntidadeIdClassificador(int idClassificador) {
		return entidadeDao.findByClassificador(idClassificador); 	
	}
	
	public List<EntidadeVersaoV1> listarVersao(Integer idClassificador) {
		List<Entidade> entidades = entidadeDao.listarVersao(idClassificador);
	    return EntidadeVersaoV1.parseToVersao(entidades);
	}

	public void limparPorClassificador(Integer idClassificador) {
        int i = 0;
        List<Entidade> entidades = entidadeDao.listarVersao(idClassificador);
        int size = entidades.size();
		for (Entidade entidade : entidades) {
		    String msg = "Removendo entidade " + ++i + "/" + size; 
		    cacheProgresso.atualizar("RECOVERY_" + idClassificador + "_PROGRESSO", 2, msg);
			excluir(entidade);
		}
	}
	
}
