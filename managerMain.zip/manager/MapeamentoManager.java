package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.model.Usuario;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("mapeamentoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class MapeamentoManager {

	@In(create=true)
	private PerguntaDao perguntaDao;
	
	@In(create=true)
	private IntencaoDao intencaoDao;
	
	@In(create=true)
	private PerguntaRevisaoDao perguntaRevisaoDao;
	
	@In(create=true)
	private EmailManager emailManager;
	
	@In(create=true)
	private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
	
	@In(create=true)
	private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;
	
	@In(create = true)
	private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
	
	@In(create = true)
	private UsuarioDao usuarioDao;
	
	@In(create=true, required = false)
	private UsuarioVO funci;

	
	public void coletar(PerguntaRevisao perguntaRevisao) throws NegocioException{
		
		List<Pergunta> perguntasCorpus = perguntaDao.findIgual(perguntaRevisao.getClassificador().getId(),perguntaRevisao.getPergunta());
		if( perguntasCorpus == null || perguntasCorpus.size() == 0 ){
			List<PerguntaRevisao> perguntas = perguntaRevisaoDao.findPergunta(perguntaRevisao.getPergunta(),perguntaRevisao.getClassificador().getId(), PerguntaRevisaoStatus.REVISAO);
			if (perguntas != null && perguntas.size() > 0) {
				perguntaRevisao = perguntas.get(0);
				perguntaRevisao.setQuantidade(perguntaRevisao.getQuantidade()+1);
			}else{
				perguntaRevisao.setDataCriacao(new Date());
				perguntaRevisao.setQuantidade(1);
				perguntaRevisao.setVinculada(false);
				perguntaRevisao.setQtdNegativo(0);
				perguntaRevisao.setQtdPositivo(0);
				perguntaRevisao.setStatus(PerguntaRevisaoStatus.REVISAO);
			}
			if( perguntaRevisao != null ){
				perguntaRevisao = perguntaRevisaoDao.persist(perguntaRevisao);
				PerguntaRevisaoUsuario perguntaRevisaoUsuario = new PerguntaRevisaoUsuario();
				perguntaRevisaoUsuario.setEmail(false);
				perguntaRevisaoUsuario.setPerguntaRevisao(perguntaRevisao);				
				Usuario usuario = usuarioDao.findByChave(funci.getChave());
				perguntaRevisaoUsuario.setUsuario(usuario.getChave());
				perguntaRevisaoUsuarioDao.persist(perguntaRevisaoUsuario);
			}
		}
		
		
	}
	
	public void migrar( List<Pergunta> perguntas, Integer idItencaoDestino ) throws NegocioException{
		
		if( perguntas == null || perguntas.size() == 0 ){
			throw new NegocioException("Selecione ao menos uma pergunta");
		}
		
		if( idItencaoDestino == null || idItencaoDestino == 0 ){
			throw new NegocioException("Selecione uma intenção");
		}
		
		Intencao intencao = intencaoDao.findById(idItencaoDestino);
		
		if( intencao != null ){
			for( Pergunta pergunta : perguntas ){
				pergunta.setIntencao(intencao);
				perguntaDao.persist(pergunta);
			}
			perguntaDao.flush();
		}
		
		
	}
	
}
