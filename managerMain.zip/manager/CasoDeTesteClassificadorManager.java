package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.json.JSONArray;
import org.json.JSONObject;

import br.com.bb.gearq.c4coleta.dao.CasoDeTesteClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.CenarioEsperadoDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.model.CasoDeTesteClassificador;
import br.com.bb.gearq.c4coleta.model.CenarioEsperado;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.SecaoCasoDeTeste;
import br.com.bb.gearq.c4coleta.model.StatusNuvem;
import br.com.bb.gearq.c4coleta.model.TipoElemento;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.util.JSONUtils;
import br.com.bb.gearq.c4coleta.versionamento.v1.CasoDeTesteVersaoV1;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("casoDeTesteClassificadorManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class CasoDeTesteClassificadorManager {

    @In(create = true)
    private SecaoCasoDeTesteManager secaoCasoDeTesteManager;

    @In(create = true)
    private CasoDeTesteClassificadorDao casoDeTesteClassificadorDao;

    @In(create = true)
    private CenarioEsperadoDao cenarioEsperadoDao;

    @In(create = true)
    private ClassificadorDao classificadorDao;

    @In(create = true)
    private NuvemWatsonDao nuvemWatsonDao;

    @In(create = true)
    private VersaoCorpusManager versaoCorpusManager;

    public CasoDeTesteClassificador obter(Integer idCasoDeTeste) {
        return casoDeTesteClassificadorDao.findById(idCasoDeTeste);
    }

    public void salvar(int idClassificador, CasoDeTesteClassificador caso) {
        caso.setIdClassificador(idClassificador);
        this.salvar(caso);
    }

    public CasoDeTesteClassificador salvar(CasoDeTesteClassificador caso) {
        atualizarSequencia(caso.getSecoes());
        caso = casoDeTesteClassificadorDao.persist(caso);
        salvarSecoes(caso);
        return caso;
    }

    public void excluir(CasoDeTesteClassificador caso) {
        excluir(caso.getId());
    }

    public void excluir(Integer idCaso) {
        CasoDeTesteClassificador caso = casoDeTesteClassificadorDao.findById(idCaso);
        for (SecaoCasoDeTeste secao : caso.getSecoes()) {
            secaoCasoDeTesteManager.excluir(secao);
        }
        casoDeTesteClassificadorDao.remove(caso);
    }

    public JSONObject criarEntradaExecucao(int idCasoDeTesteClassificador, int idClassificador) {
        JSONObject retorno = new JSONObject();
        formatarEntradaExecucao(retorno, idClassificador);
        JSONArray testCases = new JSONArray();
        retorno.put("testCases", testCases);
        criarListaTestCases(idClassificador, idCasoDeTesteClassificador, testCases);
        return retorno;
    }

    public JSONObject criarListaEntradaExecucao(int idClassificador) {
        JSONObject retorno = new JSONObject();
        formatarEntradaExecucao(retorno, idClassificador);
        JSONArray testCases = new JSONArray();
        retorno.put("testCases", testCases);
        List<CasoDeTesteClassificador> listaCaso = casoDeTesteClassificadorDao
                .buscarTodosPorIdClassificador(idClassificador);
        for (CasoDeTesteClassificador c : listaCaso) {
            criarListaTestCases(idClassificador, c.getId(), testCases);
        }
        return retorno;
    }

    private void formatarEntradaExecucao(JSONObject retorno, int idClassificador) {
        criarCorpus(retorno, idClassificador);
        criarWatsonData(idClassificador, retorno);
    }

    private void criarCorpus(JSONObject retorno, int idClassificador) {
        NuvemWatson nuvem = nuvemWatsonDao.findByClassificadorStatus(idClassificador, StatusNuvem.TESTE);
        if (nuvem == null) {
            throw new NegocioException("Esse Corpus não possui um ambiente de teste configurado");
        }
        retorno.put("corpus", nuvem.getSiglaNuvem());
        // Classificador classificador = classificadorDao.findById(idClassificador);
        // retorno.put("corpus", classificador.getSiglaWorkspace());
    }

    private void criarListaTestCases(int idClassificador, int idCasoDeTesteClassificador, JSONArray testCases) {
        CasoDeTesteClassificador caso = this.obter(idCasoDeTesteClassificador);
        if (caso != null) {
            JSONObject json = new JSONObject();
            json.put("name", caso.getNomeCasoDeTeste());
            JSONArray steps = new JSONArray();
            json.put("steps", steps);
            for (SecaoCasoDeTeste secao : caso.getSecoes()) {
                JSONObject cenario = formatarCenario(secao);
                steps.put(cenario);
            }
            testCases.put(json);
        }
    }

    private void criarWatsonData(int idClassificador, JSONObject retorno) {
        VersaoCorpus versaoCorpus = versaoCorpusManager.listarUltimoPorClassificador(idClassificador);
        if (versaoCorpus != null) {
            retorno.put("watsonData", JSONUtils.getJson(versaoCorpus.getJsonWatson()));
        }
    }

    private JSONObject formatarCenario(SecaoCasoDeTeste secao) {
        JSONObject cenario = new JSONObject();
        cenario.put("input", secao.getTextoEntrada());
        JSONObject expected = new JSONObject();
        cenario.put("expected", expected);
        for (CenarioEsperado cenarioEsperado : secao.getCenarios()) {
            String elemento = cenarioEsperado.getTipoElemento().getNome();
            if (elemento.equals("Intenção") && !JSONUtils.isJSONObject(expected, "intents")) {
                expected.put("intents", buscarListaTipoCondicao(secao, cenarioEsperado.getTipoElemento()));
            } else if (elemento.equals("Entidade")) {
                expected.put("entities", buscarListaTipoCondicao(secao, cenarioEsperado.getTipoElemento()));
            } else if (elemento.equals("Nó de diálogo") && !JSONUtils.isJSONObject(expected, "dialog_nodes")) {
                expected.put("dialog_nodes", buscarListaTipoCondicao(secao, cenarioEsperado.getTipoElemento()));
            } else if (elemento.equals("Contexto")) {
                expected.put("context", buscarListaTipoCondicao(secao, cenarioEsperado.getTipoElemento()));
            }
        }
        return cenario;
    }

    private JSONObject buscarListaTipoCondicao(SecaoCasoDeTeste secao, TipoElemento tipoElementoSelecionado) {
        JSONObject retorno = new JSONObject();
        for (CenarioEsperado cenarioEsperado : secao.getCenarios()) {
            if (cenarioEsperado.getTipoCondicao() != null
                    && cenarioEsperado.getTipoElemento().equals(tipoElementoSelecionado)) {
                String tipoCondicao = cenarioEsperado.getTipoCondicao().getNome();
                if (tipoCondicao.equals("Igual")) {
                    if (cenarioEsperado.getTextoElementoValor() != null && JSONUtils.isJSONObject(retorno, "equals")) {
                        JSONObject equals = JSONUtils.getJson(retorno, "equals");
                        if (equals == null) {
                            equals = new JSONObject();
                            retorno.put("equals", equals);
                        }
                        equals.put(cenarioEsperado.getTextoElemento(), cenarioEsperado.getTextoElementoValor());
                    } else {
                        retorno.put("equals", cenarioEsperado.getTextoElemento());
                    }
                } else if (tipoCondicao.equals("Diferente")) {
                    if (cenarioEsperado.getTextoElementoValor() != null
                            && JSONUtils.isJSONObject(retorno, "not_equals")) {
                        JSONObject not_equals = JSONUtils.getJson(retorno, "not_equals");
                        if (not_equals == null) {
                            not_equals = new JSONObject();
                            retorno.put("not_equals", not_equals);
                        }
                        not_equals.put(cenarioEsperado.getTextoElemento(), cenarioEsperado.getTextoElementoValor());
                    } else {
                        retorno.put("not_equals", cenarioEsperado.getTextoElemento());
                    }
                } else if (tipoCondicao.equals("Contém")) {
                    retorno.append("includes", cenarioEsperado.getTextoElemento());
                } else if (tipoCondicao.equals("Não contém")) {
                    retorno.append("excludes", cenarioEsperado.getTextoElemento());
                }
            }
        }
        return retorno;
    }

    public Paginacao<CasoDeTesteClassificador> findByIdClassificador(Integer idClassificador,
            Paginacao<CasoDeTesteClassificador> paginacao) {
        return casoDeTesteClassificadorDao.findByIdClassificador(idClassificador, paginacao);
    }

    public void moverSecao(SecaoCasoDeTeste secao, Integer posicao) {
        Integer idCasoDeTeste = secao.getIdCasoDeTesteClassificador();
        CasoDeTesteClassificador caso = this.obter(idCasoDeTeste);
        List<SecaoCasoDeTeste> secoes = caso.getSecoes();
        secoes.remove(secao);
        secoes.add(posicao, secao);
        atualizarSequencia(secoes);
        salvarSecoes(caso);
    }

    public void atualizarSequenciaSalvar(Integer idCasoDeTeste) {
        CasoDeTesteClassificador caso = this.obter(idCasoDeTeste);
        atualizarSequencia(caso.getSecoes());
        salvarSecoes(caso);
    }

    private void atualizarSequencia(List<SecaoCasoDeTeste> secoes) {
        for (int i = 0; i < secoes.size(); i++) {
            secoes.get(i).setNumeroSequencial(i);
        }
    }

    private void salvarSecoes(CasoDeTesteClassificador caso) {
        for (SecaoCasoDeTeste secao : caso.getSecoes()) {
            secao.setCasoDeTeste(caso);
            secao.setIdCasoDeTesteClassificador(caso.getId());
            secaoCasoDeTesteManager.salvar(secao);
        }
    }

    public List<CasoDeTesteVersaoV1> listarVersao(Integer idClassificador) {
        List<CasoDeTesteVersaoV1> casosDeTesteVersao = new ArrayList<>();

        List<CasoDeTesteClassificador> casos = casoDeTesteClassificadorDao.listarVersao(idClassificador);
        for (CasoDeTesteClassificador caso : casos) {
            casosDeTesteVersao.add(new CasoDeTesteVersaoV1(caso));
        }

        return casosDeTesteVersao;

    }

    public void limparPorClassificador(Integer idClassificador) {
        for (CasoDeTesteClassificador caso : casoDeTesteClassificadorDao.listarVersao(idClassificador)) {
            excluir(caso);
        }
    }

}
