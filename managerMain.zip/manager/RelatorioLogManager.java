package br.com.bb.gearq.c4coleta.manager;

import java.util.Calendar;
import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.RelatorioLogDao;
import br.com.bb.gearq.c4coleta.model.RelatorioLog;
import br.com.bb.gearq.c4coleta.vo.InteracaoBotVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("relatorioLogManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class RelatorioLogManager {
	
	@In(create = true)
	private ClassificadorDao classificadorDao;
	
	@In(create = true)
	private RelatorioLogDao relatorioLogDao;
	
	public Paginacao<RelatorioLog> listarPorBot(InteracaoBotVO interacaoBotVO){
		if( interacaoBotVO.getValorPeriodo() == null ){
			return null;
		}
		PeriodoVO periodo = getPeriodo(interacaoBotVO.getValorPeriodo());
		
		if( periodo.getInicio() == null ){
			periodo.setInicio(getData(interacaoBotVO.getDataInicial(),true).getTime());
			periodo.setFim(getData(interacaoBotVO.getDataFinal(),false).getTime());
		} else {
			interacaoBotVO.setDataInicial(periodo.getInicio());
			interacaoBotVO.setDataFinal(periodo.getFim());
		}
		
		if( interacaoBotVO.getListaBot() != null && interacaoBotVO.getListaBot().size() > 0 && periodo.getInicio() != null && periodo.getFim() != null){
			if(periodo.getInicio().after(periodo.getFim())) {
				throw new NegocioException("A data inícial deve ser anterior a data final");
			}
			
			return relatorioLogDao.buscarPorListaIdInteracaoBot(interacaoBotVO);
		}
		return null;
	}
	
	private PeriodoVO getPeriodo(String intervalo){
		
	    PeriodoVO periodoVO = new PeriodoVO();
		if( intervalo.equals("HOJE") ){
			
			Calendar cal = getData(null,true);
			periodoVO.setInicio(cal.getTime());
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			
		}else if( intervalo.equals("ONTEM") ){
			
			Calendar cal = getData(null,true);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			periodoVO.setInicio(cal.getTime());
			
		}else if( intervalo.equals("ULTIMOS_7_DIAS") ){
			
			Calendar cal = getData(null,true);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			cal.add(Calendar.DAY_OF_MONTH, -7);
			periodoVO.setInicio(cal.getTime());
		
		}else if( intervalo.equals("SEMANA_ATUAL") ){
			
			Calendar cal = getData(null,true);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
			periodoVO.setInicio(cal.getTime());
			
		}else if( intervalo.equals("SEMANA_PASSADA") ){
			
			Calendar cal = getData(null,true);
			int i = cal.get(Calendar.DAY_OF_WEEK) - cal.getFirstDayOfWeek();
			cal.add(Calendar.DATE, -i - 7);
			periodoVO.setInicio(cal.getTime());
			cal.add(Calendar.DATE, 6);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			
		}else if( intervalo.equals("MES_ATUAL") ){
			Calendar cal = getData(null,true);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
			periodoVO.setInicio(cal.getTime());
			
		}else if( intervalo.equals("MES_PASSADO") ){
			Calendar cal = getData(null,true);
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
			periodoVO.setInicio(cal.getTime());
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
		}
		
		return periodoVO;
}

	private Calendar getData(Date data, boolean inicio){
		Calendar calendar = Calendar.getInstance();
		if( data != null )
			calendar.setTime(data);
		
		if( inicio ){
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
		}else{
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MINUTE, 59);
			calendar.set(Calendar.SECOND, 59);
		}
		
		return calendar;
	}
	
	private static class PeriodoVO{
		private Date inicio;
		private Date fim;
		public Date getInicio() {
			return inicio;
		}
		public void setInicio(Date inicio) {
			this.inicio = inicio;
		}
		public Date getFim() {
			return fim;
		}
		public void setFim(Date fim) {
			this.fim = fim;
		}
	}
	

}
