package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.AvaliacaoFormularioDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacaoMotivoDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacaoMotivoNotaDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacaoNotaDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacoesDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoFormulario;
import br.com.bb.gearq.c4coleta.model.AvaliacaoMotivo;
import br.com.bb.gearq.c4coleta.model.AvaliacaoNota;
import br.com.bb.gearq.c4coleta.model.Avaliacoes;
import br.com.bb.gearq.c4coleta.vo.FiltroAvaliacoesVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.avaliacao.AvaliacaoFormularioVO;

@Name("avaliacaoFormularioManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class AvaliacaoFormularioManager {
	
	@In(create = true)
	private AvaliacaoMotivoManager avaliacaoMotivoManager;
	
	@In(create = true)
	private AvaliacaoFormularioDao avaliacaoFormularioDao;

    @In(create = true)
    private AvaliacaoMotivoDao avaliacaoMotivoDao;
    
    @In(create = true)
    private AvaliacaoMotivoNotaDao avaliacaoMotivoNotaDao;
    
    @In(create = true)
    private AvaliacaoNotaDao avaliacaoNotaDao;

	@In(create=true)
	private AvaliacoesDao avaliacoesDao;
	
	@In(create=true)
	private NuvemWatsonDao nuvemWatsonDao;
	
	public AvaliacaoFormulario obter(Integer id) {
	    return avaliacaoFormularioDao.findById(id); 
	}
	
	public AvaliacaoFormulario salvar(AvaliacaoFormulario avaliacaoFormulario) {
		AvaliacaoFormulario formRetorno = avaliacaoFormularioDao.persistAndFlush(avaliacaoFormulario);
		List<AvaliacaoMotivo> listaAvaliacaoMotivo = avaliacaoFormulario.getListaAvaliacaoMotivo();
		if(listaAvaliacaoMotivo != null) {
			for (AvaliacaoMotivo avaliacaoMotivo : listaAvaliacaoMotivo) {
				avaliacaoMotivo.setIdAvaliacaoFormulario(formRetorno.getId());
				if(avaliacaoMotivo.getId() == null) {
					List<AvaliacaoNota> notas = avaliacaoMotivo.getNotas();
					avaliacaoMotivo.setNotas(null);
					avaliacaoMotivo = avaliacaoMotivoDao.persistAndFlush(avaliacaoMotivo);
					avaliacaoMotivo.setNotas(notas);
					avaliacaoMotivo = avaliacaoMotivoDao.persistAndFlush(avaliacaoMotivo);
				} else {
					avaliacaoMotivo = avaliacaoMotivoDao.persistAndFlush(avaliacaoMotivo);
				}
			}
		}
		avaliacaoFormulario = formRetorno;
		return avaliacaoFormulario;
	}
	
	public List<AvaliacaoFormulario> listarFormularioEMotivo() {
		List<AvaliacaoFormulario> listaAvaliacaoFormulario = avaliacaoFormularioDao.listar("");
		for (AvaliacaoFormulario avaliacaoFormulario: listaAvaliacaoFormulario) {
			List<AvaliacaoMotivo> listaMotivo = avaliacaoMotivoManager.listar(avaliacaoFormulario.getId());
			avaliacaoFormulario.setListaAvaliacaoMotivo(listaMotivo);
			List<AvaliacaoNota> listaNota = avaliacaoNotaDao.findAll();
			avaliacaoFormulario.setListaAvaliacaoNota(listaNota);
		}
		return listaAvaliacaoFormulario;
	}
	
	public AvaliacaoFormulario buscarFormularioEMotivoPorId(int id) {
		AvaliacaoFormulario avaliacaoFormulario = avaliacaoFormularioDao.findById(id);
		if(avaliacaoFormulario != null) {
			List<AvaliacaoMotivo> listaMotivo = avaliacaoMotivoManager.listar(avaliacaoFormulario.getId());
			avaliacaoFormulario.setListaAvaliacaoMotivo(listaMotivo);
			List<AvaliacaoNota> listaNota = avaliacaoNotaDao.findAll();
			avaliacaoFormulario.setListaAvaliacaoNota(listaNota);
		}
		return avaliacaoFormulario;
	}
	
	public AvaliacaoFormulario buscarAvaliacaoFormulario(String titulo) {      
        return avaliacaoFormularioDao.listarPorTitulo(titulo);
    }
	
	public boolean verificarFormularioComAvaliacoes(int idFormulario) {
		boolean existeAvaliacoes = false;
		for (AvaliacaoMotivo avaliacaoMotivo : avaliacaoMotivoManager.listar(idFormulario)) {
			FiltroAvaliacoesVO filtroAvaliacoesVO = new FiltroAvaliacoesVO();
			filtroAvaliacoesVO.setIdMotivo(avaliacaoMotivo.getId());
			Paginacao<Avaliacoes> listaAvaliacoes = avaliacoesDao.pesquisar(filtroAvaliacoesVO);
			if(listaAvaliacoes.getTotalRegistros() > 0) {
				existeAvaliacoes = true;
				break;
			}
		}
		return existeAvaliacoes;
	}
	
	public boolean verificarFormularioComNuvemCredencial(int idFormulario) {
		boolean existeNuvem = false;
		if(!nuvemWatsonDao.findByFormulario(idFormulario).isEmpty()) {
			existeNuvem = true;
		}
		return existeNuvem;
	}
	
	public void excluir(AvaliacaoFormulario avaliacaoFormulario) {
		avaliacaoFormulario = avaliacaoFormularioDao.findById(avaliacaoFormulario.getId());
		for (AvaliacaoMotivo avaliacaoMotivo : avaliacaoMotivoManager.listar(avaliacaoFormulario.getId())) {
			avaliacaoMotivoManager.excluir(avaliacaoMotivo);
		}
		avaliacaoFormularioDao.remove(avaliacaoFormulario);
	}

    public AvaliacaoFormularioVO getFormularioComMotivos(Integer idFormulario) {
        AvaliacaoFormulario avaliacaoFormulario = avaliacaoFormularioDao.findById(idFormulario);
        if(avaliacaoFormulario != null) {
            List<AvaliacaoNota> notas = avaliacaoNotaDao.findAll();
            List<AvaliacaoMotivo> motivos = avaliacaoMotivoManager.listar(avaliacaoFormulario.getId());
            
            return new AvaliacaoFormularioVO(avaliacaoFormulario, notas, motivos);
        }
        return null;
    }
    public List<AvaliacaoFormulario> lista(){
        return avaliacaoFormularioDao.findAll();
    }
}
