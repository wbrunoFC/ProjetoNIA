package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.VersaoCorpusExcluidosDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.VersaoCorpusExcluidos;

@Name("versaoCorpusExcluidosManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class VersaoCorpusExcluidosManager {
    
    @In(create = true)
    private VersaoCorpusExcluidosDao versaoCorpusExcluidosDao;
    
    @In(create = true)
    private UsuarioManager usuarioManager;
    
    public VersaoCorpusExcluidos criar(int idClassificador, String descricao, int versao, Classificador classificador, String jsonNia, 
            UsuarioVO funci, String siglaNuvem) {
        VersaoCorpusExcluidos versaoCorpusExcluidos = new VersaoCorpusExcluidos();
        versaoCorpusExcluidos.setIdClassificador(idClassificador);
        versaoCorpusExcluidos.setNomeClassificador(classificador.getNome());
        versaoCorpusExcluidos.setDataCriacao(new Date());
        versaoCorpusExcluidos.setDescricao(descricao);
        versaoCorpusExcluidos.setVersao(versao);
        versaoCorpusExcluidos.setJsonNia(jsonNia);
        versaoCorpusExcluidos.setIdUsuario(usuarioManager.obterIdUsuarioLogado(funci));
        versaoCorpusExcluidos.setSiglaNuvem(siglaNuvem);
        
        versaoCorpusExcluidosDao.persist(versaoCorpusExcluidos);
        return versaoCorpusExcluidos;
    }

}
