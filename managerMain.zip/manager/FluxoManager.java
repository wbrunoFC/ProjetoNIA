package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;

@Name("fluxoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class FluxoManager {

    @In(create = true)
    private FluxoDao fluxoDao;

    @In(create = true)
    private CacheProgresso cacheProgresso;

    public Fluxo obter(Integer idFluxo) {
        return fluxoDao.findById(idFluxo);
    }

    public void excluir(int idFluxo) {
        Fluxo fluxo = this.obter(idFluxo);
        this.excluir(fluxo);
    }

    public void excluir(Fluxo fluxo) {
        for (Fluxo fluxoFilho : fluxoDao.findByidFluxoPai(fluxo.getId())) {
            excluir(fluxoFilho);
        }
        fluxoDao.remove(fluxo);
    }

    public Fluxo salvar(Fluxo fluxo) {
        return fluxoDao.persist(fluxo);
    }

    public List<Fluxo> listarPorIntencao(Integer idIntencao) {
        return fluxoDao.findByFluxo(idIntencao);
    }

    public List<Fluxo> listarPorAgrupador(Integer id) {
        return fluxoDao.findByidAgrupador(id);
    }

    public FluxoVO fluxo(Integer idIntencao) {
        return fluxoDao.fluxo(idIntencao);
    }

    public void limparPorClassificador(Integer idClassificador) {
        for (Fluxo fluxo : fluxoDao.listarVersao(idClassificador)) {
            excluir(fluxo);
        }
    }

}