package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.AcionamentoIntencaoDiaDao;
import br.com.bb.gearq.c4coleta.model.AcionamentoIntencaoDia;

@Name("acionamentoIntencaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class AcionamentoIntencaoManager {

	
	
	@In(create = true)
	private AcionamentoIntencaoDiaDao acionamentoIntencaoDiaDao;
	
	public void processarQtd (){
		List<AcionamentoIntencaoDia> lista = new ArrayList<AcionamentoIntencaoDia>();	
		
		
		
		lista = acionamentoIntencaoDiaDao.findByDadosDia();
	
		
		for(AcionamentoIntencaoDia ac:lista){
		
			// criar consulta para verificar se já existe registro com o mesmo dia, classificador e intencao.			
			List<AcionamentoIntencaoDia> validarAc = acionamentoIntencaoDiaDao.findConsultaDia(ac);
			
			// só inserir o registro se ele não existir. 
			if(validarAc.isEmpty()){

				acionamentoIntencaoDiaDao.persist(ac);
				
			}
		
		
		}
		
		
	}
}
