package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ChangeLogAgrupadorDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogDialogoDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogDialogoTagDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogEntidadeDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogExemploDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogPerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogRespostaDao;
import br.com.bb.gearq.c4coleta.dao.ChangeLogSinonimoDao;
import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDialogoAUDDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotAUDDao;
import br.com.bb.gearq.c4coleta.dao.SlotsAUDDao;
import br.com.bb.gearq.c4coleta.dao.SlotsTagsAUDDao;
import br.com.bb.gearq.c4coleta.model.ChangeLogAgrupador;
import br.com.bb.gearq.c4coleta.model.ChangeLogDialogo;
import br.com.bb.gearq.c4coleta.model.ChangeLogDialogoTag;
import br.com.bb.gearq.c4coleta.model.ChangeLogResposta;
import br.com.bb.gearq.c4coleta.model.ChangeLogSinonimo;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativaDialogoAUD;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlotAUD;
import br.com.bb.gearq.c4coleta.model.SlotsAUD;
import br.com.bb.gearq.c4coleta.model.SlotsTagsAUD;
import br.com.bb.gearq.c4coleta.vo.ChangeLogEntidade;
import br.com.bb.gearq.c4coleta.vo.ChangeLogExemplo;
import br.com.bb.gearq.c4coleta.vo.ChangeLogIntencao;
import br.com.bb.gearq.c4coleta.vo.ChangeLogParametrosEntradaVO;
import br.com.bb.gearq.c4coleta.vo.ChangeLogPerguntaRevisao;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("changeLogManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ChangeLogManager {
	
	@In(create = true)
	private ChangeLogIntencaoDao changeLogIntencaoDao;
	
	@In(create = true)
	private ChangeLogEntidadeDao changeLogEntidadeDao;
	
	@In(create = true)
	private ChangeLogExemploDao changeLogExemploDao;
	
	@In(create = true)
	private ChangeLogSinonimoDao changeLogSinonimoDao;

	@In(create = true)
	private ChangeLogAgrupadorDao changeLogAgrupadorDao;

	@In(create = true)
	private ChangeLogPerguntaRevisaoDao changeLogPerguntaRevisaoDao;
	
	@In(create = true)
	private ChangeLogRespostaDao changeLogRespostaDao;
	
	@In(create = true)
	private ChangeLogDialogoDao changeLogDialogoDao;
	
	@In(create = true)
    private ChangeLogDialogoTagDao changeLogDialogoTagDao;
	
	@In(create = true)
	private InstrucaoNormativaDialogoAUDDao instrucaoNormativaDialogoAUDDao;
	
	@In(create = true)
    private RespostaDialogoSlotAUDDao respostaDialogoSlotAUDDao;
	
	@In(create = true)
	private SlotsAUDDao slotsAUDDao;
	
	@In(create = true)
	private SlotsTagsAUDDao slotsTagsAUDDao;
	
	public Paginacao<ChangeLogIntencao> listarChangeLogIntencao(
			ChangeLogParametrosEntradaVO entradaChangeLog, Paginacao<ChangeLogIntencao> paginacao) throws NegocioException{
		entradaChangeLog = validarDatas(entradaChangeLog);
		paginacao = changeLogIntencaoDao.listarChangeLogIntencao(entradaChangeLog, paginacao);
		return paginacao;
	}
	
	public Paginacao<ChangeLogExemplo> listarChangeLogExemplo(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, Paginacao<ChangeLogExemplo> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogExemploDao.listarChangeLogExemplo(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}
	
	public Paginacao<ChangeLogPerguntaRevisao> listarChangeLogPerguntaRevisao(
			ChangeLogParametrosEntradaVO entradaParametrosChangeLog, Paginacao<ChangeLogPerguntaRevisao> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogPerguntaRevisaoDao.listarChangeLogPerguntaRevisao(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}
	
	public Paginacao<ChangeLogEntidade> listarChangeLogEntidade(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, Paginacao<ChangeLogEntidade> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogEntidadeDao.listarChangeLogEntidade(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}
	
	public Paginacao<ChangeLogSinonimo> listarChangeLogSinonimo(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, Paginacao<ChangeLogSinonimo> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogSinonimoDao.listarChangeLogSinonimo(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}

	public Paginacao<ChangeLogAgrupador> listarChangeLogAgrupador(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, Paginacao<ChangeLogAgrupador> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogAgrupadorDao.listarChangeLogAgrupador(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}

	
	public Paginacao<ChangeLogResposta> listarChangeLogResposta(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
			Paginacao<ChangeLogResposta> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogRespostaDao.listarChangeLogResposta(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}

	public Paginacao<ChangeLogDialogo> listarChangeLogNos(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
			Paginacao<ChangeLogDialogo> paginacao) {
		entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
		paginacao = changeLogDialogoDao.listarChangeLogNos(entradaParametrosChangeLog, paginacao);
		return paginacao;
	}
	
	public Paginacao<ChangeLogDialogoTag> listarChangeLogTagNos(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
            Paginacao<ChangeLogDialogoTag> paginacao) {
        entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
        paginacao = changeLogDialogoTagDao.listarChangeLogTagNos(entradaParametrosChangeLog, paginacao);
        return paginacao;
    }
	
	public Paginacao<InstrucaoNormativaDialogoAUD> listarChangeLogIns(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
            Paginacao<InstrucaoNormativaDialogoAUD> paginacao) {
        entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
        paginacao = instrucaoNormativaDialogoAUDDao.listarChangeLogIns(entradaParametrosChangeLog, paginacao);
        return paginacao;
    }
	
	public Paginacao<SlotsAUD> listarChangeLogSlots(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
            Paginacao<SlotsAUD> paginacao) {
        entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
        paginacao = slotsAUDDao.listarChangeLogSlots(entradaParametrosChangeLog, paginacao);
        return paginacao;
    }
	
	public Paginacao<SlotsTagsAUD> listarChangeLogSlotsTags(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
            Paginacao<SlotsTagsAUD> paginacao) {
        entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
        paginacao = slotsTagsAUDDao.listarChangeLogSlotsTags(entradaParametrosChangeLog, paginacao);
        return paginacao;
    }
	
	public Paginacao<RespostaDialogoSlotAUD> listarChangeLogRespostaSlots(ChangeLogParametrosEntradaVO entradaParametrosChangeLog,
            Paginacao<RespostaDialogoSlotAUD> paginacao) {
        entradaParametrosChangeLog = validarDatas(entradaParametrosChangeLog);
        paginacao = respostaDialogoSlotAUDDao.listarChangeLogRespostaSlots(entradaParametrosChangeLog, paginacao);
        return paginacao;
    }
	
	public List<ChangeLogIntencao> listarChangeLogIntencao(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, int idClassificador) {
		
		entradaParametrosChangeLog  = validarDatas(entradaParametrosChangeLog);
		
		List<ChangeLogIntencao> listaChangeLogIntencao = new ArrayList<ChangeLogIntencao>();
		listaChangeLogIntencao = changeLogIntencaoDao.listarChangeLogIntencao(entradaParametrosChangeLog, idClassificador);
		return listaChangeLogIntencao;
	}
	
	public List<ChangeLogExemplo> listarChangeLogExemplo(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, int idClassificador) {
		entradaParametrosChangeLog  = validarDatas(entradaParametrosChangeLog);
		List<ChangeLogExemplo> listaChangeLogExemplo = new ArrayList<ChangeLogExemplo>();
		listaChangeLogExemplo = changeLogExemploDao.listarChangeLogExemplo(entradaParametrosChangeLog, idClassificador);
		return listaChangeLogExemplo;
	}
	
	public List<ChangeLogEntidade> listarChangeLogEntidade(ChangeLogParametrosEntradaVO entradaParametrosChangeLog, Integer idClassificador) throws NegocioException{
		
		entradaParametrosChangeLog  = validarDatas(entradaParametrosChangeLog);
		
		List<ChangeLogEntidade> listaChangeLogEntidade = new ArrayList<ChangeLogEntidade>();
		listaChangeLogEntidade = changeLogEntidadeDao.listarChangeLogEntidade(entradaParametrosChangeLog, idClassificador);
		return listaChangeLogEntidade;
	}

	public ChangeLogParametrosEntradaVO validarDatas(ChangeLogParametrosEntradaVO entradaChangeLog) {
		
		// quando datas nulas, calcular os ultimos 30 dias a partir da data atual
		if(entradaChangeLog.getDataInicial() == null && entradaChangeLog.getDataFinal() == null) {
			entradaChangeLog = periodoTrintaDias(entradaChangeLog);
			return entradaChangeLog;
		}
		
		// valida quando somente a data final for nula
		if(entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() == null) {
			entradaChangeLog.setDataFinal(entradaChangeLog.getDataInicial());
			return entradaChangeLog;
		}
		
		// valida quando somente a data inicial for nula
		if(isDataInicialNullAndDataFinalPreenchida(entradaChangeLog)) {
			entradaChangeLog.setDataInicial(entradaChangeLog.getDataFinal());
			return entradaChangeLog;
		}
		// valida data inicial maior que data final
		if(isDataInicialPreenchidaAndDataFinalNull(entradaChangeLog)) {
			if(entradaChangeLog.getDataInicial().getTime() > entradaChangeLog.getDataFinal().getTime()) {
				throw new NegocioException("Data inicial maior que a data final");
			}
		}
				
		return entradaChangeLog;
	}

    private boolean isDataInicialPreenchidaAndDataFinalNull(ChangeLogParametrosEntradaVO entradaChangeLog) {
        return entradaChangeLog.getDataInicial() != null && entradaChangeLog.getDataFinal() != null;
    }

    private boolean isDataInicialNullAndDataFinalPreenchida(ChangeLogParametrosEntradaVO entradaChangeLog) {
        return entradaChangeLog.getDataInicial() == null && entradaChangeLog.getDataFinal() != null;
    }
	
	// atribuir trinta dias a menos na data inicial
	private ChangeLogParametrosEntradaVO periodoTrintaDias(ChangeLogParametrosEntradaVO entradaChangeLog) {
		Calendar calendar = Calendar.getInstance();
		entradaChangeLog.setDataFinal(calendar.getTime()); // atribuir data atual na data final
		calendar.add(Calendar.DAY_OF_MONTH, -30); // atribuir trinta dias a menos na data inicial
		entradaChangeLog.setDataInicial(calendar.getTime()); // atribuir trinta dias a menos na data inicial
		return entradaChangeLog;
	}


}
