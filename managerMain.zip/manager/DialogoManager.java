package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AgrupadorSinonimosDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DialogoDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.dao.SlotsDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.enums.DialogoTipoJump;
import br.com.bb.gearq.c4coleta.enums.TipoFormatacao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativaDialogo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.RespostaDialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoPK;
import br.com.bb.gearq.c4coleta.model.Slots;
import br.com.bb.gearq.c4coleta.model.StatusDialogo;
import br.com.bb.gearq.c4coleta.model.TipoCondicaoDialogo;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.TipoRespostaClassificador;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.util.NiaTextoUtils;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.vo.CriarNodeVo;
import br.com.bb.gearq.c4coleta.vo.DialogoListagemVO;
import br.com.bb.gearq.c4coleta.vo.DialogoNoVo;
import br.com.bb.gearq.c4coleta.vo.DialogoRespostaBlocoVo;
import br.com.bb.gearq.c4coleta.vo.DialogoRespostaVo;
import br.com.bb.gearq.c4coleta.vo.DialogoSimplesVo;
import br.com.bb.gearq.c4coleta.vo.DialogoVO;
import br.com.bb.gearq.c4coleta.vo.FiltroDialogoVO;
import br.com.bb.gearq.c4coleta.vo.FluxoItemVO;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;
import br.com.bb.gearq.c4coleta.vo.MoverNodeVo;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("dialogoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class DialogoManager {

    @In(create = true)
    private IntencaoDao intencaoDao;

    @In(create = true)
    private EntidadeDao entidadeDao;

    @In(create = true)
    private AgrupadorSinonimosDao agrupadorSinonimosDao;

    @In(create = true)
    private ClassificadorDao classificadorDao;

    @In(create = true)
    private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;

    @In(create = true)
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @In(create = true)
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;

    @In(create = true)
    private IntencaoManager intencaoManager;

    @In(create = true)
    private DialogoDao dialogoDao;

    @In(create = true)
    private RespostaDialogoDao respostaDialogoDao;

    @In(create = true)
    private RespostaDialogoSlotDao respostaDialogoSlotDao;

    @In(create = true)
    private SlotsDao slotsDao;

    @In(create = true)
    private SlotManager slotManager;

    @In(create = true)
    private InstrucaoNormativaDialogoManager instrucaoNormativaDialogoManager;

    @In(create = true)
    private EntidadeManager entidadeManager;

    @In(create = true)
    private TipoRespostaDao tipoRespostaDao;

    @In(create = true)
    private RespostaDialogoManager respostaDialogoManager;

    @In(create = true)
    private CacheProgresso cacheProgresso;

    private static String NO_SAUDACAO = "NIAC4_SAUDACAO";
    private static String NO_SAUDACAO_VALOR = "welcome";
    private static String NO_NAO_ATENDIA = "NIAC4_NAO_ATENDIA";
    private static String NO_NAO_ATENDIA_VALOR = "anything_else";

    public DialogoListagemVO pesquisar(FiltroDialogoVO filtroVO) {
        DialogoListagemVO dialogoVO = new DialogoListagemVO();

        DialogoSimplesVo saudacao = recuperarDialogo(filtroVO.getIdClassificador(), NO_SAUDACAO);
        if (saudacao != null) {
            dialogoVO.setSaudacao(saudacao);
            filtroVO.setIdSaudacao(saudacao.getId());
        }

        DialogoSimplesVo naoAtendido = recuperarDialogo(filtroVO.getIdClassificador(), NO_NAO_ATENDIA);
        if (naoAtendido != null) {
            dialogoVO.setNaoAtendida(naoAtendido);
            filtroVO.setIdNaoAtendida(naoAtendido.getId());
        }

        Paginacao<Dialogo> paginacao = dialogoDao.pesquisar(filtroVO.getPaginacao(), filtroVO.getId(),
                filtroVO.getIdClassificador(), filtroVO.getIdSaudacao(), filtroVO.getIdNaoAtendida(),
                filtroVO.getStatus(), filtroVO.getNome(), filtroVO.getResposta(), filtroVO.getCondicao(),
                filtroVO.getUuid(), filtroVO.getInstrucaoNormativa());
        dialogoVO.setPaginacao(paginacao);

        List<Dialogo> dialogos = paginacao.getListaPaginada();
        paginacao.setListaPaginada(null);

        if (!dialogos.isEmpty()) {
            dialogoVO.setDialogos(montarArvore(dialogos));
        }
        return dialogoVO;
    }

    private List<DialogoSimplesVo> montarArvore(List<Dialogo> dialogos) {
        List<DialogoSimplesVo> dialogosVOretorno = new ArrayList<>();
        List<DialogoSimplesVo> dialogosVOtodos = new ArrayList<>();

        for (Dialogo dialogo : dialogos) {
            montarArvoreNode(dialogo, dialogosVOretorno, dialogosVOtodos);
        }
        return dialogosVOretorno;
    }

    private DialogoSimplesVo montarArvoreNode(Dialogo dialogo, List<DialogoSimplesVo> dialogosVOretorno,
            List<DialogoSimplesVo> dialogosVOtodos) {
        DialogoSimplesVo vo = new DialogoSimplesVo(dialogo);

        int posicao = dialogosVOtodos.indexOf(vo);
        if (posicao == -1) {
            montarArvorePai(vo, dialogosVOretorno, dialogosVOtodos);
            if (dialogo.getCdTipoNo() == 0 || dialogo.getCdTipoNo() == 3) {
                dialogosVOtodos.add(vo);
            }
        } else {
            vo = dialogosVOtodos.get(posicao);
        }
        return vo;
    }

    private void montarArvorePai(DialogoSimplesVo noVo, List<DialogoSimplesVo> dialogosVOretorno,
            List<DialogoSimplesVo> dialogosVOtodos) {
        Dialogo pai = noVo.getDialogo().getPai();
        if (pai == null) {
            dialogosVOretorno.add(noVo);
        } else {
            DialogoSimplesVo paivo = montarArvoreNode(pai, dialogosVOretorno, dialogosVOtodos);
            if (noVo.getDialogo().getCdTipoNo() == 0 || noVo.getDialogo().getCdTipoNo() == 3) {
                paivo.getFilhos().add(noVo);
            }
        }
    }

    public DialogoSimplesVo obterDialogoSimples(Integer id, Boolean comFilhos) {
        DialogoSimplesVo node = new DialogoSimplesVo(obterDialogo(id));
        if (Boolean.TRUE.equals(comFilhos)) {
            List<DialogoSimplesVo> filhos = carregarFilhosDialogoSimples(id);
            node.setFilhos(filhos);
        }
        return node;
    }

    /**
     * recuparar os dialogos pelo nome
     * 
     * @param idClassificador
     * @param nome
     * @return
     */
    private DialogoSimplesVo recuperarDialogo(Integer idClassificador, String nome) {
        List<Dialogo> dialogos = dialogoDao.findByNome(idClassificador, nome, 0, 0, false);
        if (!dialogos.isEmpty()) {
            return new DialogoSimplesVo(dialogos.get(0));
        }
        return null;
    }

    /**
     * recuparar os dialogos pelo nome
     * 
     * @param idClassificador
     * @param nome
     * @return
     */
    public List<Dialogo> pesquisarDialogo(Integer idClassificador, String nome, Integer idSaudacao,
            Integer idNaoAtendida) {
        return dialogoDao.findByNome(idClassificador, nome, idSaudacao, idNaoAtendida, true);
    }

    /**
     * obter um dialogo pelo id
     * 
     * @param id
     * @param nomeElementoComparado
     * @return
     */
    public Dialogo obterDialogo(Integer id) {
        Dialogo dialogo = dialogoDao.findById(id);
        for (RespostaDialogo resposta : dialogo.getRespostas()) {
            if (resposta.getTipoResposta() != null && TipoFormatacao.WHATSAPP.equals(resposta.getTipoResposta().getTipoFormatacao())) {
                String textoWhatsappFormatado = respostaDialogoManager.formattingTextWhatsappToHTML(resposta.getTextoResposta());
                resposta.setTextoResposta(textoWhatsappFormatado);
            }
        }
        return dialogo;
    }

    public void carregarRespostasPadrao(DialogoNoVo dialogoNoVo) {
        Integer idDialogo = dialogoNoVo.getDialogo().getId();
        List<DialogoRespostaVo> respostasPadrao = respostaDialogoManager.obterRespostasPadrao(idDialogo);
        dialogoNoVo.setRespostas(respostasPadrao);
    }

    public void excluir(Integer id) {
        Dialogo dialogo = dialogoDao.findById(id);
        if (dialogo == null) {
            throw new NegocioException("O nó com id " + id + " não foi encontrado");
        }
        excluir(dialogo, true);
    }

    public void excluir(Dialogo dialogo) {
        excluir(dialogo, true);
    }

    public void excluir(Dialogo dialogo, boolean atualizarPai) {
        Integer id = dialogo.getId();

        for (Dialogo filho : dialogo.getFilhos()) {
            excluir(filho, false);
        }

        for (RespostaDialogo resposta : dialogo.getRespostas()) {
            respostaDialogoDao.remove(resposta);
        }

        for (InstrucaoNormativaDialogo instrucaoNormativaDialogo : dialogo.getiNs()) {
            instrucaoNormativaDialogoManager.excluir(instrucaoNormativaDialogo);
        }

        for (Slots slot : dialogo.getSlots()) {
            slotManager.excluir(slot);
        }

        // Remover jumps para esse nó
        for (Dialogo diagJump : dialogoDao.findByEnviarPara(id)) {
            diagJump.setIdEnviarPara(null);
            diagJump.setTipoResp(DialogoTipoJump.DIRETA);
            diagJump.setJumpSelector(null);
            dialogoDao.persist(diagJump);
        }

        Dialogo pai = dialogo.getPai();

        dialogoDao.remove(dialogo);

        if (atualizarPai) {
            // Se pai nao tem mais filhos, deixa de ser ambiguo
            if (pai != null) {
                atualizarDesambiguacao(pai);
                dialogoDao.persist(pai);
            }

            // Atualizar sequencia dos irmaos
            atualizarSequencia(dialogo.getPai(), dialogo.getIdClassificador(), null, 0, null);
        }

    }

    private void atualizarDesambiguacao(Dialogo node) {
        if (node == null)
            return;
        List<Dialogo> filhos = dialogoDao.listarFilhosDialogoPadrao(node.getId());
        if (filhos.isEmpty()) {
            node.setPossuiDesambiguacao(false);
            if (DialogoTipoJump.PULAR_ENTRADA.equals(node.getTipoResp())) {
                node.setTipoResp(DialogoTipoJump.DIRETA);
            }
        } else {
            node.setPossuiDesambiguacao(true);
        }
    }

    public List<DialogoSimplesVo> carregarFilhosDialogoSimples(Integer id) {
        List<DialogoSimplesVo> dialogosSimples = new ArrayList<>();
        for (Dialogo filho : dialogoDao.listarFilhosDialogoPadrao(id)) {
            DialogoSimplesVo vo = new DialogoSimplesVo(filho);
            dialogosSimples.add(vo);
        }
        return dialogosSimples;
    }

    // ######################### MIGRAÇÂO DE INTENCAO E FLUXO
    // #########################
    /**
     * Criar fluxo de dialogo de acordo com a intenções exitentes no corpus,
     * inclusive com o fluxo de desambiguação
     * 
     * @param idClassificador
     * @return
     */
    public DialogoVO migrarDialogo(Integer idClassificador) {
        DialogoVO retorno = new DialogoVO();

        List<Intencao> intencoes = intencaoDao.findByClassificador(idClassificador);

        Classificador classificador = classificadorDao.findById(idClassificador);

        List<TipoRespostaClassificador> tipoRespostas = tipoRespostaClassificadorDao
                .findByClassificador(classificador.getId());

        retorno.setSaudacao(getDialogo(NO_SAUDACAO, NO_SAUDACAO_VALOR, TipoCondicaoDialogo.VARIAVEL_FIXA, null,
                "Olá em que posso ajudar?", tipoRespostas, classificador, false, StatusDialogo.ATIVO));
        retorno.setNaoAtendida(getDialogo(NO_NAO_ATENDIA, NO_NAO_ATENDIA_VALOR, TipoCondicaoDialogo.VARIAVEL_FIXA, null,
                "Desculpe... ainda estou aprendendo e não sei essa resposta.", tipoRespostas, classificador, false,
                StatusDialogo.ATIVO));

        retorno.setDialogos(new ArrayList<DialogoNoVo>());

        if (intencoes != null && intencoes.size() > 0) {

            // cria primeiros nós com a intenção
            for (Intencao intencao : intencoes) {

                List<TipoRespostaIntencao> respostas = tipoRespostaIntencaoDao.findAll(intencao.getId(), null);
                StatusDialogo status = StatusDialogo.INATIVO;
                for (StatusDialogo stt : StatusDialogo.values()) {
                    if (stt.name().equalsIgnoreCase(intencao.getStatus().name())) {
                        status = stt;
                        break;
                    }
                }
                DialogoNoVo no = getDialogo(intencao.getNome(), intencao.getId(), TipoCondicaoDialogo.INTENCAO,
                        respostas, null, tipoRespostas, classificador, intencao.getNecessitaDesambiguacao(), status);
                retorno.getDialogos().add(no);

            }

            // desambiguação
            for (Intencao intencao : intencoes) {

                if (intencao.getNecessitaDesambiguacao()) {

                    FluxoVO fluxo = intencaoManager.buscaFluxo(intencao.getId());

                    DialogoNoVo noAmbigua = getNoAmbigua(intencao, fluxo.getPergunta(), retorno);

                    if (fluxo.getFluxos() != null && fluxo.getFluxos().size() > 0) {
                        noAmbigua.setFilhos(new ArrayList<DialogoNoVo>());
                        for (FluxoItemVO filho : fluxo.getFluxos()) {
                            noAmbigua.getFilhos().add(getNosFilhos(filho, filho.getRespostaDireta(), tipoRespostas,
                                    retorno, noAmbigua.getDialogo(), classificador));
                        }
                    }
                }
            }
        }

        return retorno;
    }

    private DialogoNoVo getNosFilhos(FluxoItemVO filho, String pergunta, List<TipoRespostaClassificador> tipoRespostas,
            DialogoVO retorno, Dialogo pai, Classificador classificador) {
        Object condicao = null;
        TipoCondicaoDialogo tipoCondicao = null;
        String nome = null;

        // Monta condição
        if (filho.getAgrupador().getId() != null && filho.getAgrupador().getId() > 0) {
            condicao = filho.getAgrupador().getId();
            nome = filho.getAgrupador().getEntidade().getNome() + ":" + filho.getAgrupador().getNome();
            tipoCondicao = TipoCondicaoDialogo.AGRUPADOR;
        } else if (filho.getAgrupador().getEntidade() != null && filho.getAgrupador().getEntidade().getId() > 0) {
            condicao = filho.getAgrupador().getEntidade().getId();
            nome = filho.getAgrupador().getEntidade().getNome();
            tipoCondicao = TipoCondicaoDialogo.ENTIDADE;
        }

        boolean possuiDesambiguacao = filho.getBlocoFluxos() != null && filho.getBlocoFluxos().size() > 0;
        DialogoNoVo filhoVo = getDialogo(nome, condicao, tipoCondicao, null, pergunta, tipoRespostas, classificador,
                possuiDesambiguacao, pai.getStatus());
        filhoVo.getDialogo().setPai(pai);

        // jump TO
        if (filho.getIntencaoAcionada() != null && filho.getIntencaoAcionada().getId() != null
                && filho.getIntencaoAcionada().getId() > 0) {
            DialogoNoVo jumpTo = null;
            for (DialogoNoVo no : retorno.getDialogos()) {
                if (no.getDialogo().getCondicao().equals("#" + filho.getIntencaoAcionada().getNome())) {
                    jumpTo = no;
                    break;
                }
            }

            filhoVo.getDialogo().setIdEnviarPara(jumpTo != null ? jumpTo.getDialogo().getId() : null);
            if (filhoVo.getDialogo().getIdEnviarPara() != null) {
                filhoVo.getDialogo().setJumpSelector("body");
                filhoVo.getDialogo().setTipoResp(DialogoTipoJump.ENVAR_PARA);
                dialogoDao.persist(filhoVo.getDialogo());
            }

        }

        // monta nós filhos
        if (filho.getBlocoFluxos() != null && filho.getBlocoFluxos().size() > 0) {
            if (filhoVo.getFilhos() == null) {
                filhoVo.setFilhos(new ArrayList<DialogoNoVo>());
            }
            for (FluxoItemVO item : filho.getBlocoFluxos()) {
                filhoVo.getFilhos().add(getNosFilhos(item, item.getRespostaDireta(), tipoRespostas, retorno,
                        filhoVo.getDialogo(), classificador));
            }
        }

        return filhoVo;
    }

    /**
     * recuperar diálogo ambiguo
     * 
     * @param intencao
     * @param resposta
     * @param retorno
     * @return
     */
    private DialogoNoVo getNoAmbigua(Intencao intencao, String resposta, DialogoVO retorno) {
        DialogoNoVo noAtual = null;
        if (retorno.getDialogos() != null) {
            for (DialogoNoVo no : retorno.getDialogos()) {
                if (no.getDialogo().getCondicao().equals("#" + intencao.getNome())) {
                    noAtual = no;
                    break;
                }
            }
        }

        if (noAtual != null) {
            if (noAtual.getRespostas() != null) {
                for (DialogoRespostaVo respVO : noAtual.getRespostas()) {
                    if (respVO.getRespostas() != null) {
                        for (RespostaDialogo resp : respVO.getRespostas()) {
                            resp.setTextoResposta(resposta);
                            respostaDialogoDao.persist(resp);
                        }
                    }
                }
            }
        }

        return noAtual;
    }

    private DialogoNoVo getDialogo(String nome, Object condicao, TipoCondicaoDialogo tipoCondicao,
            List<TipoRespostaIntencao> respostas, String resposta, List<TipoRespostaClassificador> tipoRespostas,
            Classificador classificador, Boolean possuiDesambiguacao, StatusDialogo status) {
        DialogoNoVo vo = new DialogoNoVo();

        // Dialogo
        Dialogo dialogo = new Dialogo();
        dialogo.setNome(nome);
        dialogo.setClassificador(classificador);
        dialogo.setHashNuvem(UUID.randomUUID().toString());
        dialogo.setPossuiDesambiguacao(possuiDesambiguacao);
        dialogo.setStatus(status);

        String newcondicao = "";

        if (tipoCondicao == TipoCondicaoDialogo.INTENCAO) {
            newcondicao = "#" + nome;
        } else if (tipoCondicao == TipoCondicaoDialogo.ENTIDADE || tipoCondicao == TipoCondicaoDialogo.AGRUPADOR) {
            newcondicao = "@" + nome;
        } else if (tipoCondicao == TipoCondicaoDialogo.VARIAVEL_FIXA) {
            newcondicao = "" + condicao;
        }
        dialogo.setCondicao(newcondicao);

        vo.setDialogo(dialogo);

        // persiste Dialogo
        dialogoDao.persist(dialogo);
        // respostas do dialogo
        vo.setRespostas(new ArrayList<DialogoRespostaVo>());
        for (TipoRespostaClassificador tipoResp : tipoRespostas) {

            DialogoRespostaVo respDialogoVO = new DialogoRespostaVo();
            respDialogoVO.setTipo(tipoResp.getTipoResposta());
            respDialogoVO.setBlocos(new ArrayList<DialogoRespostaBlocoVo>());
            respDialogoVO.setAtivo(tipoResp.getAtivo());

            DialogoRespostaBlocoVo bloco = new DialogoRespostaBlocoVo();
            bloco.setSequenciaBloco(1);
            bloco.setRespostas(new ArrayList<RespostaDialogo>());

            RespostaDialogo respDialogo = new RespostaDialogo();
            respDialogo.setId(new RespostaDialogoPK());
            respDialogo.getId().setIdResposta(tipoResp.getTipoResposta().getId());
            if (tipoResp.getTipoResposta().getNomeJSON().equals(TipoResposta.TX_PADRAO) && resposta != null
                    && resposta.trim().length() > 0) {
                respDialogo.setTextoResposta(resposta);
            } else if (respostas != null) {
                for (TipoRespostaIntencao resp : respostas) {
                    if (resp.getTipoResposta().equals(tipoResp.getTipoResposta())) {
                        respDialogo.setTextoResposta(resp.getTextoResposta());
                    }
                }
            }
            respDialogo.getId().setIdDialogo(dialogo.getId());
            respDialogo.getId().setSequenciaBloco(1);
            respDialogo.getId().setSequenciaItem(1);
            respDialogo.setTipoResposta(tipoResp.getTipoResposta());
            respostaDialogoDao.persist(respDialogo);
            bloco.getRespostas().add(respDialogo);

            respDialogoVO.getBlocos().add(bloco);
            vo.getRespostas().add(respDialogoVO);
        }

        // persiste condicao
        // condicaoDialogoDao.persist(conDialogo);

        dialogoDao.flush();

        return vo;
    }

    public List<Map<String, String>> validarCondicoes(Integer idClassificador) {
        List<Map<String, String>> erros = new ArrayList<Map<String, String>>();
        for (Dialogo dialogo : dialogoDao.findByClassificador(idClassificador)) {
            if (!validarCondicao(dialogo.getCondicao(), idClassificador)) {
                Map<String, String> map = new HashMap<String, String>();
                map.put("iddialogo", dialogo.getId() + "");
                map.put("nome", dialogo.getNome());
                map.put("condicao", dialogo.getCondicao());
                erros.add(map);
            }
        }
        return erros;
    }

    public boolean validarCondicao(String condicao, Integer idClassificador) {
        if (!NiaTextoUtils.isEmpty(condicao)) {
            condicao = condicao.replaceAll("[(]", "").replaceAll("[)]", "");
            for (String part : condicao.split("&&|\\|\\|")) {
                part = part.trim();
                if (part.startsWith("!")) {
                    part = part.substring(1);
                }
                if (part.startsWith("#") && !validarCondicaoIntencao(part, idClassificador)) {
                    return false;
                } else if (part.startsWith("@") && !validarCondicaoEntidade(part, idClassificador)) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean validarCondicaoIntencao(String condicao, Integer idClassificador) {
        condicao = condicao.replace("#", "");
        List<Intencao> list = intencaoManager.buscarPorNomeExato(condicao, idClassificador);
        return !list.isEmpty();
    }

    private boolean validarCondicaoEntidade(String condicao, int idClassificador) {
        condicao = condicao.replace("@", "");
        int operador = obterOperador(condicao);
        String entidadeNome = condicao;
        if (operador != -1) {
            entidadeNome = condicao.substring(0, operador);
        }
        int pos = entidadeNome.indexOf(".");
        if (pos != -1) {
            entidadeNome = entidadeNome.substring(0, pos);
        }
        List<Entidade> entidades = entidadeManager.buscarEntidadePorNomeExato(entidadeNome.trim(), idClassificador);
        if (entidades.isEmpty()) {
            return false;
        }
        return true;
//        if (operador == -1) {
//            return true;
//        } else {
//            if (entidadeNome.equals("sys-currency") || entidadeNome.equals("sys-date")
//                    || entidadeNome.equals("sys-number") || entidadeNome.equals("sys-percentage")
//                    || entidadeNome.equals("sys-time")) {
//
//                return true;
//            }
//            String valorEntidade = condicao.substring(operador + 1);
//            valorEntidade = valorEntidade.replaceAll("\'", "").replaceAll("[(]", "").replaceAll("[)]", "")
//                    .replaceAll("\"", "").replaceAll("=", "");
//            valorEntidade = valorEntidade.trim();
//            for (Entidade entidade : entidades) {
//                for (AgruparEntidadeSinonimos agrupador : entidade.getAgrupadores()) {
//                    if (valorEntidade.toUpperCase().equals(agrupador.getNome().toUpperCase())) {
//                        return true;                                                                        
//                    }
//                }
//            }
//        }
//        return false;
    }

    private int obterOperador(String condicao) {
        String[] operadores = new String[] { ":", ">", "<", "!=", "==" };
        for (String operador : operadores) {
            int pos = condicao.indexOf(operador);
            if (pos != -1) {
                return pos;
            }
        }
        return -1;
    }

    public List<DialogoVersaoV1> listarVersao(Integer idClassificador) {
        List<DialogoVersaoV1> dialogosVersao = new ArrayList<>();

        List<Dialogo> dialogos = dialogoDao.listarVersao(idClassificador);
        for (Dialogo dialogo : dialogos) {
            dialogosVersao.add(new DialogoVersaoV1(dialogo));
        }

        return dialogosVersao;
    }

    public void limparPorClassificador(Integer idClassificador) {
        List<Dialogo> nos = dialogoDao.listarVersao(idClassificador);
        int size = nos.size();
        int i = 0;
        for (Dialogo dialogo : nos) {
            String msg = "Removendo Nós " + ++i + "/" + size;
            cacheProgresso.atualizar("RECOVERY_" + idClassificador + "_PROGRESSO", 3, msg);
            if (dialogo.getIdPai() == null) {
                excluir(dialogo, false);
            }
        }
    }

    public Dialogo salvar(Dialogo dialogo) {
        if (dialogo.getId() == null) {
            dialogo = dialogoDao.persist(dialogo);
        } else {
            Dialogo dialogoAnterior = this.obterDialogo(dialogo.getId());
            limparSlots(dialogo, dialogoAnterior);
            limparMultiplasRespostas(dialogo, dialogoAnterior);
            limparHandlers(dialogo, dialogoAnterior);
            limparRespostas(dialogo, dialogoAnterior);
            limparINs(dialogo, dialogoAnterior);
        }

        validarJump(dialogo);
        for (RespostaDialogo resposta : dialogo.getRespostas()) {
            resposta.getId().setIdDialogo(dialogo.getId());
            respostaDialogoManager.salvar(resposta);
        }

        for (InstrucaoNormativaDialogo instrucao : dialogo.getiNs()) {
            instrucao.setDialogo(dialogo);
            instrucaoNormativaDialogoManager.salvar(instrucao);
        }
        salvarSlots(dialogo);
        salvarMultiplasRespostas(dialogo);
        salvarHandlers(dialogo);
        for (Dialogo filho : dialogo.getFilhos()) {
            filho.setPai(dialogo);
            filho.setIdClassificador(dialogo.getIdClassificador());
            salvar(filho);
        }
        atualizarDesambiguacao(dialogo);
        return dialogoDao.persist(dialogo);
    }

    private void validarJump(Dialogo dialogo) {
        // Se nao for ENVIAR_PARA nao tem idEnviarPara
        if (!DialogoTipoJump.ENVAR_PARA.equals(dialogo.getTipoResp())) {
            dialogo.setIdEnviarPara(null);
            dialogo.setEnviarPara(null);
        }
    }

    private void limparSlots(Dialogo dialogo, Dialogo dialogoAnterior) {
        List<Slots> excluidas = new ArrayList<>();

        // Limpar slots com condicao nula ou vazia
        for (Slots slot : dialogo.getSlots()) {
            if (NiaTextoUtils.isEmpty(slot.getCondicao())) {
                excluidas.add(slot);
            }
        }
        dialogo.getSlots().removeAll(excluidas);

        // Verificar se um slot que existia foi excluido
        for (Slots slot : dialogoAnterior.getSlots()) {
            if (dialogo.getSlots().indexOf(slot) == -1) {
                this.slotManager.excluir(slot);
            }
        }

    }

    private void limparMultiplasRespostas(Dialogo dialogo, Dialogo dialogoAnterior) {
        // Verificar se uma multipla resposta que existia foi excluida
        for (Dialogo node : dialogoAnterior.getMultiplasRespostas()) {
            if (dialogo.getMultiplasRespostas().indexOf(node) == -1) {
                this.excluir(node, false);
            }
        }

    }

    private void limparHandlers(Dialogo dialogo, Dialogo dialogoAnterior) {
        // Verificar se um handler que existia foi excluido
        for (Dialogo node : dialogoAnterior.getHandlers()) {
            if (dialogo.getHandlers().indexOf(node) == -1) {
                this.excluir(node, false);
            }
        }

    }

    private void limparRespostas(Dialogo dialogo, Dialogo dialogoAnterior) {
        List<RespostaDialogo> excluidas = new ArrayList<>();
        // Limpar respostas nulas ou vazias
        for (RespostaDialogo resposta : dialogo.getRespostas()) {
            if (NiaTextoUtils.isEmpty(resposta.getTextoResposta())) {
                excluidas.add(resposta);
            }
        }
        dialogo.getRespostas().removeAll(excluidas);

        // Verificar respostas excluidas
        for (RespostaDialogo resposta : dialogoAnterior.getRespostas()) {
            if (dialogo.getRespostas().indexOf(resposta) == -1) {
                this.respostaDialogoManager.excluir(resposta);
            }
        }
    }

    private void limparINs(Dialogo dialogo, Dialogo dialogoAnterior) {
        // Limpar INs vazias ou nulas
        List<InstrucaoNormativaDialogo> excluidas = new ArrayList<>();
        for (InstrucaoNormativaDialogo in : dialogo.getiNs()) {
            if (NiaTextoUtils.isEmpty(in.getNumeroIN())) {
                excluidas.add(in);
            }
        }
        dialogo.getiNs().removeAll(excluidas);

        // Verificar se IN foi excluida
        for (InstrucaoNormativaDialogo in : dialogoAnterior.getiNs()) {
            if (dialogo.getiNs().indexOf(in) == -1) {
                this.instrucaoNormativaDialogoManager.excluir(in);
            }
        }
    }

    private void salvarSlots(Dialogo dialogo) {
        int sequencia = 0;
        for (Slots slot : dialogo.getSlots()) {
            slot.setDialogo(dialogo);
            slot.setSequencia(sequencia++);
            slotManager.salvar(slot);
        }
    }

    private void salvarMultiplasRespostas(Dialogo dialogo) {
        int sequencia = 0;
        for (Dialogo filho : dialogo.getMultiplasRespostas()) {
            filho.setPai(dialogo);
            filho.setIdClassificador(dialogo.getIdClassificador());
            filho.setCdTipoNo(1);
            filho.setIdSequencia(sequencia++);
            salvar(filho);
        }
    }

    private void salvarHandlers(Dialogo dialogo) {
        int sequencia = 0;
        for (Dialogo filho : dialogo.getHandlers()) {
            filho.setPai(dialogo);
            filho.setIdClassificador(dialogo.getIdClassificador());
            filho.setCdTipoNo(2);
            filho.setIdSequencia(sequencia++);
            salvar(filho);
        }
    }

    public Dialogo obterPorUuid(int idClassificador, String uuid) {
        List<Dialogo> dialogos = dialogoDao.findByUuid(idClassificador, uuid);
        if (!dialogos.isEmpty()) {
            return dialogos.get(0);
        }
        return null;
    }

    public Dialogo criar(CriarNodeVo nodeVo) {
        Integer idClassificador = nodeVo.getIdClassificador();
        Dialogo pai = null;

        Dialogo node = new Dialogo();
        node.setFolder(nodeVo.getFolder());

        String uuid = UUID.randomUUID().toString();
        node.setHashNuvem(uuid);
        node.setUuid(uuid);

        // Obter pai
        Integer idDialogoAlvo = nodeVo.getIdDialogoAlvo();
        if (nodeVo.getIdDialogoAlvo() != null) {
            Dialogo dialogoAlvo = obterDialogo(idDialogoAlvo);
            idClassificador = dialogoAlvo.getIdClassificador();
            pai = nodeVo.getPosicao() == 0 ? dialogoAlvo : dialogoAlvo.getPai();
        }

        if (pai != null) {
            pai.setPossuiDesambiguacao(true);
            dialogoDao.persist(pai);
            node.setPai(pai);
        }
        node.setIdClassificador(idClassificador);

        int sequencia = 0;

        Integer posicao = nodeVo.getPosicao();
        if (posicao == 0) {
            // Se for filho
            sequencia = this.getProximaSequencia(idClassificador, idDialogoAlvo);
        } else {
            // Anterior/Posterior
            sequencia = atualizarSequencia(pai, idClassificador, idDialogoAlvo, posicao, null);
        }
        node.setIdSequencia(sequencia);

        dialogoDao.persist(node);

        RespostaDialogo resposta = respostaDialogoManager.criar(node);
        node.getRespostas().add(resposta);
        respostaDialogoManager.salvar(resposta);

        return node;
    }

    public Dialogo mover(MoverNodeVo nodeVo) {
        Dialogo node = obterDialogo(nodeVo.getIdDialogo());
        Integer idDialogoAlvo = nodeVo.getIdDialogoAlvo();
        Integer idClassificador = node.getIdClassificador();

        Dialogo paiAntigo = node.getPai();

        // Obter pai
        Dialogo pai = null;
        if (nodeVo.getIdDialogoAlvo() != null) {
            Dialogo dialogoAlvo = obterDialogo(idDialogoAlvo);
            pai = nodeVo.getPosicao() == 0 ? dialogoAlvo : dialogoAlvo.getPai();
        }

        int sequencia = 0;
        if (nodeVo.getPosicao() == 0) {
            // Se for filho
            sequencia = this.getProximaSequencia(idClassificador, idDialogoAlvo);
        } else {
            // Anterior/Posterior
            sequencia = atualizarSequencia(pai, idClassificador, idDialogoAlvo, nodeVo.getPosicao(), node.getId());
        }

        node.setPai(pai);
        node.setIdSequencia(sequencia);

        dialogoDao.persist(node);

        atualizarDesambiguacao(pai);
        dialogoDao.persist(pai);

        if (paiAntigo != null && pai != paiAntigo) {
            atualizarDesambiguacao(paiAntigo);
            dialogoDao.persist(paiAntigo);
            atualizarSequencia(paiAntigo, idClassificador, null, null, null);
        }

        return node;
    }

    private int atualizarSequencia(Dialogo pai, Integer idClassificador, Integer idDialogoAlvo, Integer posicao,
            Integer idDialogoIgnorar) {
        int nodeSequencia = 0;
        int sequencia = 0;
        for (Dialogo irmao : listarDialogosPadrao(pai, idClassificador)) {
            if (NO_SAUDACAO.equals(irmao.getNome()) || NO_NAO_ATENDIA.equals(irmao.getNome())
                    || irmao.getId().equals(idDialogoIgnorar)) {
                continue;
            }
            if (irmao.getId().equals(idDialogoAlvo) && posicao == -1) {
                nodeSequencia = sequencia++;
            }
            irmao.setIdSequencia(sequencia++);
            dialogoDao.persist(irmao);
            if (irmao.getId().equals(idDialogoAlvo) && posicao == 1) {
                nodeSequencia = sequencia++;
            }
        }
        return nodeSequencia;
    }

    private List<Dialogo> listarDialogosPadrao(Dialogo dialogo, Integer idClassificador) {
        if (dialogo != null) {
            return dialogoDao.listarFilhosDialogoPadrao(dialogo.getId());
        } else {
            return dialogoDao.listarDialogosRaiz(idClassificador);
        }
    }

    private int getProximaSequencia(Integer idClassificador, Integer idPai) {
        return dialogoDao.contaFilhosDialogoPadrao(idClassificador, idPai).intValue();
    }

}
