package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.CredencialWatsonDao;
import br.com.bb.gearq.c4coleta.dao.SincronizacaoDao;
import br.com.bb.gearq.c4coleta.model.CredencialWatson;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.Sincronizacao;
import br.com.bb.gearq.c4coleta.vo.AtivarSincronizacaoVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.SincronizacaoListagemVO;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("sincronizacaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class SincronizacaoManager {

    @In(create = true)
    private ClassificadorDao classificadorDao;

    @In(create = true)
    private SincronizacaoDao sincronizacaoDao;

    @In(create = true)
    private CredencialWatsonDao credencialWatsonDao;

    public Sincronizacao consultarUltimaSincronizacao(int idClassificador) {
        // verificar a melhor forma de retornar apenas 1 item
        return sincronizacaoDao.findByClassificador(idClassificador);
    }

    public SincronizacaoListagemVO listaSincronizacaoClassificador(Paginacao<Sincronizacao> paginacao,
            int idClassificador) {
        paginacao = sincronizacaoDao.findByListaSincronizacao(paginacao, idClassificador);
        return new SincronizacaoListagemVO(paginacao);
    }

    public void ativarSincronizacao(AtivarSincronizacaoVO ativarSincronizacaoVO) {

        Boolean itemSelecionada = false;

        for (NuvemWatson nuvem : ativarSincronizacaoVO.getListaNuvemWatson()) {
            if (nuvem.getSelecionado() != null && nuvem.getSelecionado()) {
                itemSelecionada = true;
                List<CredencialWatson> credenciais = credencialWatsonDao.findByIdNuvemIdParametro(nuvem.getId(), 3);
                for (CredencialWatson c : credenciais) {

                    String workspaceQueDeveSerInativado = c.getNome();

                    // novo workspace ID
                    c.setNome(ativarSincronizacaoVO.getWorkspaceId());
                    credencialWatsonDao.persist(c);

                    // inativar sincronização anterior
                    Sincronizacao inativarSincronizacao = new Sincronizacao();
                    List<Sincronizacao> listaAux = sincronizacaoDao
                            .findBySincronizacaoCdWorkspace(workspaceQueDeveSerInativado);
                    for (int i = 0; i < listaAux.size(); i++) {
                        inativarSincronizacao = listaAux.get(i);
                        if (inativarSincronizacao != null && i < listaAux.size()) {
                            inativarSincronizacao.setIndicadorAtivo(false);
                            sincronizacaoDao.persist(inativarSincronizacao);
                        }
                        if (i == listaAux.size() - 1) {
                            Sincronizacao ativoS = new Sincronizacao();
                            ativoS = listaAux.get(listaAux.size() - 1);
                            ativoS.setIndicadorAtivo(true);
                            sincronizacaoDao.persist(ativoS);
                        }

                    }

                }

            }

        }
        if (!itemSelecionada) {
            throw new NegocioException("Selecione uma ou mais Credenciais");
        }

    }

    public Date getUltimaDataSincronizacaoByNuvem(Integer idNuvem) {
        return sincronizacaoDao.getUltimaDataSincronizacaoByNuvem(idNuvem);
    }

}
