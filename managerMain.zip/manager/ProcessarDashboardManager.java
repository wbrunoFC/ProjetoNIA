package br.com.bb.gearq.c4coleta.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.audit.dto.IntecoesMaisSugeridas;
import br.com.bb.gearq.c4coleta.audit.dto.UsuarioDashboardVO;
import br.com.bb.gearq.c4coleta.audit.dto.UsuariosAtivos;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DashboardGeralDao;
import br.com.bb.gearq.c4coleta.dao.IdentificadorIntencaoDashboardDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.SecaoConversaBotDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDashboardDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.ControleJobStatusEnum;
import br.com.bb.gearq.c4coleta.model.Dashboard;
import br.com.bb.gearq.c4coleta.model.IdentificadorIntencaoDashboard;
import br.com.bb.gearq.c4coleta.model.UsuarioDashboard;

@Name("processarDashboardManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ProcessarDashboardManager {

	
	@In(create = true)
	private ClassificadorDao classificadorDao;
	
	@In(create = true)
	private PerguntaRevisaoDao perguntaRevisaoDao;	
	
	@In(create = true)
	private IntencaoDao intencaoDao;	
	
	@In(create = true)
	private RelatoriosGeralManager relatoriosGeralManager;
	
	@In(create = true)
	private DashboardGeralDao dashboardGeralDao;
	
	@In(create = true)
	private IdentificadorIntencaoDashboardDao identificadorIntencaoDashboardDao;
	
	@In(create = true)
	private UsuarioDao usuarioDao;

	@In(create = true)
	private UsuarioDashboardDao usuarioDashboardDao;
	
	@In(create = true)
	private PerguntaDao perguntaDao;
	
	@In(create = true)
    private SecaoConversaBotDao secaoConversaBotDao;
	
	
	
	public void processarDashboard (Integer idClassificador, Date dataDia){
	
    System.out.println("INICIO DA EXECUCAO DO DASHBOARD");
    boolean jobLivre = dashboardGeralDao.isJobLivre("JOB_DIARIO");
    System.out.println("Job Livre? "+ jobLivre);
    
    if(jobLivre) {
        dashboardGeralDao.registrarExecucaoJob("JOB_DIARIO");
        List<Classificador> listaClass = new ArrayList<Classificador>();
        
        if( idClassificador != null && idClassificador > 0 ){
            Classificador classificador = new Classificador();
            classificador.setId(idClassificador);
            listaClass.add(classificador);
        }else{
            listaClass = classificadorDao.findAll();
        }
        
        System.out.println("INICIADO:  "+listaClass.size()+new Date());
        
        for(Classificador c:listaClass){
            
            try {
                Dashboard dashboard = new Dashboard();
                dashboard.setDataConsulta(dataDia);
                
                // id classificador
                dashboard.setIdClassificador(c.getId());			
                
                
                // Qt_qst_curadas: quantidade total de perguntas curadas no dia
                dashboard.setQtPerguntasCuradasCurador(perguntaRevisaoDao.totalPerguntasCuradasPorIntervaloData(c.getId(), dataDia,dataDia).intValue());
                
                // qtd_qst_excd: quantidade total de perguntas excluidas 
                dashboard.setQtdPerguntasCuradasExcluida(perguntaRevisaoDao.totalPerguntasCuradasPorExcluida(c.getId(), dataDia,dataDia).intValue());
                
                //TODO qt_qst_curada_regua: quantidade total de perguntas curadas pela régua
                dashboard.setQtPerguntasCuradasRegua(perguntaRevisaoDao.totalPerguntasCuradasReguaPorIntervaloData(c.getId(), dataDia,dataDia).intValue());
                
                // Qt_qst_n_curadas: quantidade total de perguntas não curadas no dia;
                dashboard.setQtPerguntasNaocuradas(perguntaRevisaoDao.findAllQuantidadePerguntasNaoCuradasIntervaloData(c.getId(), dataDia,dataDia));
                
                //Qt_qst_env: quantidade total de perguntas enviadas ao gestor no dia;
                dashboard.setQtTotalPerguntasEnvGestor(perguntaRevisaoDao.perguntasEnviadasGestor(c.getId(), dataDia, dataDia).intValue()); 
                
                //Qt_itn: quantidade total de intenções existentes no dia;
                dashboard.setQtTotalIntencoes(intencaoDao.findByQuantidadeIntencaoByClassificador(c.getId()).intValue()); 
                
                //qt_qst_vcld_vldd: quantidades de perguntas validadas até a data ;
                dashboard.setQtPerguntasCorpoValidada(perguntaDao.qtdPerguntasCorpus(c.getId(), true));
                
                //qt_qst_vcld_n_vldd: quantidades de perguntas não validadas até a data
                dashboard.setQtPerguntasCorpoNaoValidada(perguntaDao.qtdPerguntasCorpus(c.getId(), false)); 
                
                //grau_medi_cnh_diar  'Grau médio de conhecimento diário'
                dashboard.setMediaGrauConhecimento(perguntaRevisaoDao.grauMedioCorpoDiario(c.getId(), dataDia,dataDia));
                
                // 
                dashboard.setQtTotalSecao(secaoConversaBotDao.totalSecoesPorIntervaloData(c.getId(), dataDia, dataDia).intValue());
                
                dashboard =	dashboardGeralDao.persist(dashboard);
                
                processarItnDashboard(dashboard);
                
                processarUsuDashboard(dashboard);
                
                dashboardGeralDao.flush();
                System.out.println("FINALIZADO:  "+c.getId()+" - "+new Date());
                throw new Exception(); 
            } catch (Exception e) {
                dashboardGeralDao.updateJob("JOB_DIARIO", ControleJobStatusEnum.ERRO.name());
                e.printStackTrace();
            }
        }
        
        dashboardGeralDao.updateJob("JOB_DIARIO", ControleJobStatusEnum.SUCESSO.name());
    }else {
        System.out.println("Job ja esta em execucao...");
    }
		
	}
	
	public void processarItnDashboard(Dashboard dashboard){
		SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");    
		String d = fmt.format(dashboard.getDataConsulta());  
		List<IntecoesMaisSugeridas> intencoesSugeridas = perguntaRevisaoDao.findIntecoesMaisSugeridasPeriodoData(d, d, dashboard.getIdClassificador());
		
		if(intencoesSugeridas.size()>0){
		
			for (IntecoesMaisSugeridas o : intencoesSugeridas) {
				
				IdentificadorIntencaoDashboard itn = new IdentificadorIntencaoDashboard();
	
				itn.setNomeIntencao(o.getNome());
				itn.setIdentificadorIntencao(o.getIntencao()!= null?o.getIntencao().intValue():0);
				itn.setQtTotalAcionamentos(o.getQuantidade()!= null?o.getQuantidade().intValue():0);
				itn.setQtFeedbackPositIntencao(o.getPosistivo()!= null?o.getPosistivo().intValue():0);
				itn.setQtFeedbackNegatIntencao(o.getNegativo()!= null?o.getNegativo().intValue():0);
				itn.setDashboard(dashboard);
				
				if(itn.getQtFeedbackPositIntencao() > 0){
					dashboard.setQtFeedbackPosit(dashboard.getQtFeedbackPosit()+itn.getQtFeedbackPositIntencao());
				}

				if(itn.getQtFeedbackNegatIntencao() > 0){
					dashboard.setQtFeedbackNegat(dashboard.getQtFeedbackNegat()+itn.getQtFeedbackNegatIntencao());
				}							

				
				identificadorIntencaoDashboardDao.persist(itn);
				
			}

		}
		
	}
	
	public void processarUsuDashboard (Dashboard dashboard){
		SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");    
		String d = fmt.format(dashboard.getDataConsulta());  
		 UsuariosAtivos usuariosAtivos = usuarioDao.findAllUsuariosAtivosDashboard(dashboard.getIdClassificador(),d);
			
		 for(UsuarioDashboardVO usuAti : usuariosAtivos.getUsuariosColetores()){
			 UsuarioDashboard usu = new UsuarioDashboard();
			 usu.setChaveUsuario(usuAti.getChave());
			 usu.setNomeUsuario(usuAti.getUsuario());
			 usu.setQtAcionamentos(usuAti.getQtColetadas());
			 usu.setQtCuradas(0);
			 usu.setQtDesconsideradas(0);
			 usu.setDashboard(dashboard);
			 usu.setTipoUsuario(0);// usuario coletor
			 dashboard.setQtTotalPerguntas(dashboard.getQtTotalPerguntas() + usuAti.getQtColetadas());
			 usuarioDashboardDao.persist(usu);
		 }
	
		 for(UsuarioDashboardVO usuAti : usuariosAtivos.getUsuariosCuradores()){
			 UsuarioDashboard usu = new UsuarioDashboard();
			 usu.setChaveUsuario(usuAti.getChave());
			 usu.setNomeUsuario(usuAti.getUsuario());
			 usu.setQtAcionamentos(0);
			 usu.setQtCuradas(usuAti.getQtCuradas());
			 usu.setQtDesconsideradas(usuAti.getQtDesconsideradas());
			 usu.setDashboard(dashboard);
			 usu.setTipoUsuario(1);// usuario curador
			 usuarioDashboardDao.persist(usu);
		 }
		
	}
	
}
