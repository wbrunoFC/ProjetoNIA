package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.AvaliacaoMotivoDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacaoMotivoNotaDao;
import br.com.bb.gearq.c4coleta.dao.AvaliacoesDao;
import br.com.bb.gearq.c4coleta.model.AvaliacaoMotivo;
import br.com.bb.gearq.c4coleta.model.Avaliacoes;
import br.com.bb.gearq.c4coleta.vo.FiltroAvaliacoesVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("avaliacaoMotivoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class AvaliacaoMotivoManager {

    @In(create = true)
    private AvaliacaoMotivoDao avaliacaoMotivoDao;
    
    @In(create = true)
    private AvaliacaoMotivoNotaDao avaliacaoMotivoNotaDao;
    
    @In(create = true)
    private AvaliacoesDao avaliacoesDao;

	public List<AvaliacaoMotivo> listar(int idFormulario) {
		List<AvaliacaoMotivo> lista = avaliacaoMotivoDao.findByIdFormulario(idFormulario);
		if(lista!=null) {
			for(AvaliacaoMotivo m: lista) {
				m.getNotas();
			}
		}
		return lista;
	}

	public boolean verificarMotivoComAvaliacoes(int idMotivo) {
		boolean existeMotivo = false;
		FiltroAvaliacoesVO filtroAvaliacoesVO = new FiltroAvaliacoesVO();
		filtroAvaliacoesVO.setIdMotivo(idMotivo);
		Paginacao<Avaliacoes> listaAvaliacoes = avaliacoesDao.pesquisar(filtroAvaliacoesVO);
		if(listaAvaliacoes.getTotalRegistros() > 0) {
			existeMotivo = true;
		}
		return existeMotivo;
	}

	public void excluir(AvaliacaoMotivo avaliacaoMotivo) throws NegocioException {
	    
		if(verificarMotivoComAvaliacoes(avaliacaoMotivo.getId())) {
	        avaliacaoMotivo = avaliacaoMotivoDao.persist(avaliacaoMotivo);
        }else {
            avaliacaoMotivo = avaliacaoMotivoDao.findById(avaliacaoMotivo.getId());
            avaliacaoMotivo.getNotas().clear();
            avaliacaoMotivoDao.remove(avaliacaoMotivo);
        }
	}
	
	public void desabilitar(AvaliacaoMotivo avaliacaoMotivo) throws NegocioException {
        avaliacaoMotivo = avaliacaoMotivoDao.persist(avaliacaoMotivo);
    }
}
