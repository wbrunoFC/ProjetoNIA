package br.com.bb.gearq.c4coleta.manager;

import java.io.InputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.NivelAcessoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoServicoDao;
import br.com.bb.gearq.c4coleta.dao.ServicoNlcDao;
import br.com.bb.gearq.c4coleta.dao.TipoUsuarioFerramentaDao;
import br.com.bb.gearq.c4coleta.dao.TipoUsuarioServicoDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioHasServicoDao;
import br.com.bb.gearq.c4coleta.model.NivelAcessoClassificador;
import br.com.bb.gearq.c4coleta.model.NivelAcessoServico;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.TipoNivelAcesso;
import br.com.bb.gearq.c4coleta.model.TipoUsuarioFerramenta;
import br.com.bb.gearq.c4coleta.model.TipoUsuarioServico;
import br.com.bb.gearq.c4coleta.model.Usuario;
import br.com.bb.gearq.c4coleta.model.UsuarioHasServico;
import br.com.bb.gearq.c4coleta.model.UsuarioHasServicoPK;
import br.com.bb.gearq.c4coleta.util.PermissaoUsuario;
import br.com.bb.gearq.c4coleta.vo.PermissaoUsuarioVO;
import br.com.bb.sos.infra.exceptions.MensagemException;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("permissaoUsuarioManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class PermissaoUsuarioManager {

	@In(create = true)
	private UsuarioHasServicoDao usuarioHasServicoDao;

	@In(create = true)
	private UsuarioDao usuarioDao;

	@In(create = true)
	private ServicoNlcDao servicoNlcDao;

	@In(create = true)
	private TipoUsuarioFerramentaDao tipoUsuarioFerramentaDao;

	@In(create = true)
	private TipoUsuarioServicoDao tipoUsuarioServicoDao;

	@In(create = true)
	private PermissaoUsuario permissaoUsuario;
	
	@In(create = true)
	private NivelAcessoServicoDao nivelAcessoServicoDao;
	
	@In(create = true)
    private NivelAcessoClassificadorDao nivelAcessoClassificadorDao;

	/**
	 * recuperar nivel de permissao para um determinado serviço Herarqui do
	 * perfil 1 - Master 1.1 - Administrador 1.1.1 - Curador 1.1.1.1 - Coletor
	 * 
	 * tipoPesquisa = true buscar perfil dos classificadores
	 * tipoPesquisa = false buscar perfil dos serviços
	 * 	 * 
	 * @param id
	 * @return
	 * @throws NegocioException
	 */
	public PermissaoUsuarioVO recuperarPermissao(Integer id, boolean tipoPesquisa)
			throws NegocioException {
		PermissaoUsuarioVO permissao = new PermissaoUsuarioVO();

		permissao.setMaster(permissaoUsuario.isMaster());
		permissao.setAuditor(permissaoUsuario.isAuditor());
		permissao.setAdministrador(permissao.isMaster() || permissao.isAuditor());
		permissao.setColetor(permissao.isMaster() || permissao.isAuditor());
		permissao.setCurador(permissao.isMaster()  || permissao.isAuditor());
		permissao.setCuradorMaster(permissao.isMaster() || permissao.isAuditor());
		
		
		permissaoCentralAcesso(permissao, id, tipoPesquisa);
		
		if (permissao.isAdministrador()) {
			permissao.setCuradorMaster(true);
		}
		
		if (permissao.isCuradorMaster()) {
			permissao.setCurador(true);
		}
		
		if (permissao.isCurador()) {
			permissao.setColetor(true);
		}
		
		return permissao;

	}
	/**
	 * tipoPesquisa = true buscar perfil dos classificadores
     * tipoPesquisa = false buscar perfil dos serviços
	 * 
	 * @param permissao
	 * @param id
	 * @param tipoPesquisa
	 */
	private void permissaoCentralAcesso(PermissaoUsuarioVO permissao, Integer id, boolean tipoPesquisa){
	    
	    if(!tipoPesquisa) {	
	        // permissão serviços/diretoria
	        if (!permissao.isMaster() && id != null && id > 0) {
	            List<NivelAcessoServico> permissoes = nivelAcessoServicoDao.findByServico(id);
	            if (permissoes != null) {
	                for (NivelAcessoServico nivel : permissoes) {
	                    if (!permissao.isCuradorMaster() && nivel.getTipo().equals(TipoNivelAcesso.CURADOR_MASTER)) {
	                        permissao.setCuradorMaster(permissaoUsuario.hasRole(nivel.getSiglaAcesso()));
	                    }
	                    
	                    if (!permissao.isCurador() && nivel.getTipo().equals(TipoNivelAcesso.CURADOR)) {
	                        permissao.setCurador(permissaoUsuario.hasRole(nivel.getSiglaAcesso()));
	                    }
	                    
	                    if (!permissao.isColetor() && nivel.getTipo().equals(TipoNivelAcesso.COLETOR)) {
	                        permissao.setColetor(permissaoUsuario.hasRole(nivel.getSiglaAcesso()));
	                    }
	                    
	                }
	            }
	            
	        }
	    }else {
	        // permissão classificador/corpus  
	        if (!permissao.isMaster() && id != null && id > 0) {
                List<NivelAcessoClassificador> permissoes = nivelAcessoClassificadorDao.findByClassificador(id);
                if (permissoes != null) {
                    for (NivelAcessoClassificador nivel : permissoes) {
                        if (!permissao.isCuradorMaster() && nivel.getTipo().equals(TipoNivelAcesso.CURADOR_MASTER)) {
                            permissao.setCuradorMaster(permissaoUsuario.hasRole(nivel.getSiglaAcesso()));
                        }
                        
                        if (!permissao.isCurador() && nivel.getTipo().equals(TipoNivelAcesso.CURADOR)) {
                            permissao.setCurador(permissaoUsuario.hasRole(nivel.getSiglaAcesso()));
                        }
                        
                        if (!permissao.isColetor() && nivel.getTipo().equals(TipoNivelAcesso.COLETOR)) {
                            permissao.setColetor(permissaoUsuario.hasRole(nivel.getSiglaAcesso()));
                        }
                        
                    }
                }
                
            }
	        
	    }
	    
	}
	
	public boolean importar(Integer idServico, InputStream isXls)
			throws MensagemException {

		ServicoNlc servicoNlc = servicoNlcDao.findById(idServico);
		TipoUsuarioFerramenta tipoFerramenta = tipoUsuarioFerramentaDao
				.findBySigla(TipoUsuarioFerramenta.SIGLA_PUBLICO);
		List<TipoUsuarioServico> tipos = tipoUsuarioServicoDao.findAll();

		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(isXls);
		} catch (Exception e1) {
			throw new MensagemException("Erro ao carregar arquivo");
		}

		Sheet sheet = workbook.getSheetAt(0);
		//Iterator<Row> rowIterator = sheet.iterator();

		for (int i=1;i<sheet.getLastRowNum();i++) {
			
			Row row = sheet.getRow(i);
			String chave = row.getCell(0).getStringCellValue();
			String nome = row.getCell(1).getStringCellValue();
			String perfil = row.getCell(2).getStringCellValue();

			try {

				if (chave != null && chave.trim().length() > 0 && 
						nome != null && nome.trim().length() > 0 && 
						perfil != null && perfil.trim().length() > 0) {
					
					UsuarioHasServico usuServi = usuarioHasServicoDao
							.findUsuarioServico(idServico, chave);

					if (usuServi == null) {
						usuServi = new UsuarioHasServico();
						usuServi.setUsuario(getUsuario(chave, nome,
								tipoFerramenta));
						usuServi.setServicoNlc(servicoNlc);
						usuServi.setId(new UsuarioHasServicoPK());
						usuServi.getId().setServico_nlc_idservico_nlc(servicoNlc.getId());
						usuServi.getId().setUsuario_idUsuario(usuServi.getUsuario().getId());
					}

					usuServi.setTipoUsuarioServico(getTipoUsuarioServico(
							perfil, tipos));
					usuarioHasServicoDao.persist(usuServi);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		usuarioHasServicoDao.flush();

		return true;
	}

	private Usuario getUsuario(String chave, String nome,
			TipoUsuarioFerramenta tipoFerramenta) throws NegocioException {
		Usuario usuario = usuarioDao.findByChave(chave);
		if (usuario == null) {
			usuario = new Usuario();
			usuario.setChave(chave);
			usuario.setNome(nome);
			usuario.setTipousuarioferramenta(tipoFerramenta);
			usuario = usuarioDao.persist(usuario);
			usuario = usuarioDao.findByChave(chave);
		}
		return usuario;
	}

	private TipoUsuarioServico getTipoUsuarioServico(String sigla,
			List<TipoUsuarioServico> tipos) {
		for (TipoUsuarioServico tipo : tipos) {
			if (tipo.getNome().equalsIgnoreCase(sigla)) {
				return tipo;
			}
		}
		return null;
	}
}