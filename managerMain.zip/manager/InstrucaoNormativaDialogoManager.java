package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDialogoDao;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativaDialogo;
import br.com.bb.gearq.c4coleta.vo.InstrucaoNormativaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

@Name("instrucaoNormativaDialogoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class InstrucaoNormativaDialogoManager {

    @In(create = true)
    private InstrucaoNormativaDialogoDao instrucaoNormativaDialogoDao;

    public InstrucaoNormativaDialogo obter(Integer id) {
        return instrucaoNormativaDialogoDao.findById(id);
    }

    public void salvar(InstrucaoNormativaDialogo instrucaoNormativaDialogo) {
        instrucaoNormativaDialogoDao.persist(instrucaoNormativaDialogo);
    }

    public void excluir(Integer id) {
        excluir(this.obter(id));
    }

    public void excluir(InstrucaoNormativaDialogo instrucaoNormativaDialogo) {
        instrucaoNormativaDialogoDao.remove(instrucaoNormativaDialogo);
    }

	public InstrucaoNormativaDialogo criarIN(InstrucaoNormativaVO vo) {
		InstrucaoNormativaDialogo in = new InstrucaoNormativaDialogo();
		in.setId(vo.getId());
		in.setIdCxDialogo(vo.getIdCxDialogo());
		in.setNumeroIN(vo.getNumeroIN());
		in.setVrsAuxiliar(vo.getVrsAuxiliar());
		in.setVrsNormativa(vo.getVrsNormativa());
		in.setVrsProcedimento(vo.getVrsProcedimento());
		in.setStatus(vo.getStatus());
		in.setEditarCampo(vo.isEditarCampo());
		return in;
	}
	
	public InstrucaoNormativaVO criarINVO(InstrucaoNormativaDialogo in) {
		InstrucaoNormativaVO vo = new InstrucaoNormativaVO();
		vo.setId(in.getId());
		vo.setIdIntencao(0);
		vo.setIdCxDialogo(in.getIdCxDialogo());
		vo.setIntencao(null);
		vo.setNumeroIN(in.getNumeroIN());
		vo.setVrsAuxiliar(in.getVrsAuxiliar());
		vo.setVrsNormativa(in.getVrsNormativa());
		vo.setVrsProcedimento(in.getVrsProcedimento());
		vo.setStatus(in.getStatus());
		vo.setEditarCampo(in.isEditarCampo());
		vo.setInIntencao(false);
		return vo;
	}
	
	public Paginacao<InstrucaoNormativaDialogo> listarPorClassificador(int idClassificador, String filtroNomeDialogo,
			Paginacao<InstrucaoNormativaDialogo> paginacao) {
		return instrucaoNormativaDialogoDao.findByClassificadorNativo(idClassificador, filtroNomeDialogo, paginacao);
	}
}
