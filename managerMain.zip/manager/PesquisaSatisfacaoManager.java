package br.com.bb.gearq.c4coleta.manager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List; 

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
 
import br.com.bb.gearq.c4coleta.dao.PesquisaSatisfacaoDao; 
import br.com.bb.gearq.c4coleta.model.AvaliacaoFormulario;
import br.com.bb.gearq.c4coleta.model.PesquisaSatisfacao;
import br.com.bb.gearq.c4coleta.model.PesquisaSatisfacaoEnvio;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("pesquisaSatisfacaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class PesquisaSatisfacaoManager { 
    
    @In(create = true)
    private PesquisaSatisfacaoDao pesquisaSatisfacaoDao; 
    
    @In(create = true)
    private PesquisaSatisfacaoEnvioManager pesquisaSatisfacaoEnvioManager;
     
    @In(create = true)
    private LogNiaInfraManager logNiaInfraManager; 
    
    public List<String> listaLogNiaInfraQuantidadeIteracaoPorChave(String origem, String servico, String dataInicioCadastro, String dataFimCadastro, AvaliacaoFormulario avaliacaoFormulario) throws NegocioException, Exception{
        List<String> listaLog = new ArrayList<String>(); 
        
        listaLog = logNiaInfraManager.listaLogNiaInfraQuantidadeIteracaoPorChave(dataInicioCadastro, dataFimCadastro, servico, avaliacaoFormulario, origem);
        
        Iterator<String> it = listaLog.iterator();
        int i = 0;
         
        Date dataCadastro = new Date();
        
        while (it.hasNext()) { 
            
            try {  
                
                String chave = it.next().split("_")[0].replace("wa", ""); 
                
                PesquisaSatisfacao pesquisaSatisfacao = new PesquisaSatisfacao(); 
                pesquisaSatisfacao.setChave(chave);           
                pesquisaSatisfacao.setDataHoraCadastro(dataCadastro);
                
                PesquisaSatisfacaoEnvio pesquisaSatisfacaoEnvio = new PesquisaSatisfacaoEnvio(); 
                pesquisaSatisfacaoEnvio.setDataHoraEnvio(dataCadastro);
                pesquisaSatisfacaoEnvio.setAvaliacaoFormulario(avaliacaoFormulario); 
                pesquisaSatisfacaoEnvio.setServico(servico);
                pesquisaSatisfacaoEnvio.setOrigem(origem); 
                
                pesquisaSatisfacao = pesquisaSatisfacaoDao.persist(pesquisaSatisfacao); //Persiste na tabela PESQUISA_SATISFACAO
                pesquisaSatisfacaoEnvio.setPesquisaSatisfacao(pesquisaSatisfacao);
                
                pesquisaSatisfacaoEnvioManager.salvar(pesquisaSatisfacaoEnvio); //Persiste na tabela PESQUISA_SATISFACAO_ENVIO 
                
                listaLog.set(i, chave);
                
                i++;
            } catch (Exception e) { 
                System.out.println(e.getMessage());
                throw new Exception(e.getMessage());
            }
             
        }
         
        return listaLog;
    }
     
    
    public List<PesquisaSatisfacao> listarPesquisaSatisfacao(String origem, String servico, String dataInicioCadastro, String dataFimCadastro, AvaliacaoFormulario avaliacaoFormulario ) throws ParseException { 
        return pesquisaSatisfacaoDao.listar(origem, servico, dataInicioCadastro, dataFimCadastro, avaliacaoFormulario);
    } 
     
}
