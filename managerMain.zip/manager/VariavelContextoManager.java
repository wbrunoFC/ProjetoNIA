package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.VariavelContextoDao;
import br.com.bb.gearq.c4coleta.model.VariavelContexto;
import br.com.bb.gearq.c4coleta.util.NiaTextoUtils;
import br.com.bb.gearq.c4coleta.versionamento.v1.VariavelContextoVersaoV1;
import br.com.bb.gearq.c4coleta.vo.FiltrarCondicaoVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("variavelContextoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class VariavelContextoManager {

    @In(create = true)
    private VariavelContextoDao variavelContextoDao;

    public VariavelContexto obterOuCriar(Integer idClassificador, String valor) {
        valor = valor.replaceAll("\\$", "");
        List<VariavelContexto> variaveis = this.findByNomeExato(idClassificador, valor);
        if (!variaveis.isEmpty()) {
            return variaveis.get(0);
        }
        return this.criar(idClassificador, valor);
    }

    public VariavelContexto criar(int idClassificador, String valor) {
        VariavelContexto variavelContexto = new VariavelContexto(idClassificador, valor);
        return variavelContextoDao.persist(variavelContexto);
    }

    public List<VariavelContexto> buscar(FiltrarCondicaoVO filtro) {
        Paginacao<VariavelContexto> paginacao = new Paginacao<>();
        paginacao.setRegistrosPagina(20);
        if (filtro.getTextoConsulta() != null) {
            filtro.setTextoConsulta(filtro.getTextoConsulta().replace("$", ""));
        }
        paginacao = variavelContextoDao.findVariavelContexto(paginacao, filtro.getIdClassificador(),
                filtro.getTextoConsulta());

        List<VariavelContexto> variaveis = paginacao.getListaPaginada();

        // Se for novo
        if (variaveis.isEmpty() && !NiaTextoUtils.isEmpty(filtro.getTextoConsulta())) {
            VariavelContexto variavel = new VariavelContexto();
            variavel.setVariavelContexto(filtro.getTextoConsulta());
            variaveis.add(variavel);
        }

        return variaveis;
    }

    public VariavelContexto salvar(int idClassificador, VariavelContexto entity) {
        entity.setIdClassificador(idClassificador);
        return variavelContextoDao.persist(entity);
    }

    public void salvar(int idClassificador, String variavel) {
        List<VariavelContexto> variaveis = variavelContextoDao.findByNomeExato(idClassificador, variavel);

        if (!variaveis.isEmpty()) {
            throw new NegocioException("Falha na criação da Variável de Contexto! $" + variavel + " já cadastrada.");
        }
        this.criar(idClassificador, variavel);
    }

    public List<VariavelContexto> findByNomeExato(Integer idClassificador, String valor) {
        return variavelContextoDao.findByNomeExato(idClassificador, valor);
    }

    public List<VariavelContextoVersaoV1> listarVersao(Integer idClassificador) {
        List<VariavelContextoVersaoV1> variaveisVersao = new ArrayList<>();
        for (VariavelContexto variavel : variavelContextoDao.findByIdClassificador(idClassificador)) {
            variaveisVersao.add(new VariavelContextoVersaoV1(variavel));
        }
        return variaveisVersao;
    }

    public void limparPorClassificador(Integer idClassificador) {
        for (VariavelContexto vc : variavelContextoDao.findByIdClassificador(idClassificador)) {
            excluir(vc.getId());
        }
    }

    private void excluir(Integer id) {
        VariavelContexto vc = variavelContextoDao.findById(id);
        variavelContextoDao.remove(vc);
    }

}
