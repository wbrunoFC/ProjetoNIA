package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.CredencialWatsonDao;
import br.com.bb.gearq.c4coleta.model.CredencialWatson;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.vo.CredencialAcessoWatsonVO;

@Name("credencialAcessoWatsonManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class CredencialAcessoWatsonManager {

    private static final String WATSON_HASH_INSTANCIA = "watson_hash_instancia";
    private static final String WATSON_SENHA = "watson_senha";
    private static final String WATSON_USUARIO = "watson_usuario";

    @In(create = true)
    private CredencialWatsonDao credencialWatsonDao;

    public CredencialAcessoWatsonVO credenciaisAcesso(NuvemWatson nuvemWatson) {
        CredencialAcessoWatsonVO credencialAcesso = new CredencialAcessoWatsonVO();

        if (nuvemWatson != null) {
            credencialAcesso.setUsuario(getValorparametro(nuvemWatson, WATSON_USUARIO));
            credencialAcesso.setSenha(getValorparametro(nuvemWatson, WATSON_SENHA));
            credencialAcesso.setHashInstancia(getValorparametro(nuvemWatson, WATSON_HASH_INSTANCIA));
        }
        return credencialAcesso;

    }

    private String getValorparametro(NuvemWatson nuvem, String parametro) {
        List<CredencialWatson> credenciais = credencialWatsonDao.findByIdNuvemIdParametro(nuvem.getId(), null);
        for (CredencialWatson credencial : credenciais) {
            if (credencial.getParametroWatson().getTextoTratamentoAcesso().equalsIgnoreCase(parametro)) {
                return credencial.getNome();
            }
        }

        return null;
    }
}
