package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.CuradoriaLogDao;
import br.com.bb.gearq.c4coleta.model.CuradoriaLog;

@Name("curadoriaLogManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class CuradoriaLogManager {

	@In(create=true)
	private CuradoriaLogDao curadoriaLogDao;
	
	public void salvar(CuradoriaLog curadoriaLog) {
		CuradoriaLog log = curadoriaLogDao.buscarPorLogNiaInfra(curadoriaLog.getIdLogNiaInfra());
		UsuarioVO usuario = ((UsuarioVO) Component.getInstance("funci"));
		if(log != null) {
			log.setChave(usuario.getChave());
			log.setDataHora(new Date());
			log.setValidacao(curadoriaLog.isValidacao());
			curadoriaLogDao.persist(log);
		} else {
			curadoriaLog.setChave(usuario.getChave());
			curadoriaLog.setDataHora(new Date());
			curadoriaLog.setValidacao(curadoriaLog.isValidacao());
			curadoriaLogDao.persist(curadoriaLog);
		}
	}
}
