package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.audit.dto.MediaQtdPalavrasRespostas;
import br.com.bb.gearq.c4coleta.audit.dto.PerguntaPorColetor;
import br.com.bb.gearq.c4coleta.audit.dto.QualidadeCorpus;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.DashboardGeralDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDashboardDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Dashboard;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.gearq.c4coleta.vo.DashboardAndamentoCuradoriaVO;
import br.com.bb.gearq.c4coleta.vo.DashboardAtividadeUsuarioVO;
import br.com.bb.gearq.c4coleta.vo.DashboardHistoricoConfiancaVO;
import br.com.bb.gearq.c4coleta.vo.DashboardHistoricoFeedbackVO;
import br.com.bb.gearq.c4coleta.vo.DashboardVO;
import br.com.bb.gearq.c4coleta.vo.DashboardValorGraficoVO;

@Name("dashboardManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class DashboardManager {

	
	@In(create = true)
	private ClassificadorDao classificadorDao;
	
	@In(create = true)
	private DashboardGeralDao dashboardGeralDao;
	
	@In(create = true)
	private UsuarioDashboardDao usuarioDashboardDao;
	
	@In(create = true)
	private RelatoriosGeralManager relatoriosGeralManager;
	
	public DashboardVO recuperarDadosDashBoard(List<Classificador> listaClassificadores, String valorPeriodo, String dataInicial, String dataFinal){
		
		if( valorPeriodo == null ){
			return null;
		}
		PeriodoVO periodo = getPeriodo(valorPeriodo);
		
		if( periodo.getInicio() == null ){
			Date dtInicio = FormatarData.formatarStringParaData(dataInicial);
			periodo.setInicio(getData(dtInicio,true).getTime());
			
			Date dtFim = FormatarData.formatarStringParaData(dataFinal);
			periodo.setFim(getData(dtFim,false).getTime());
			
		}
		
		if(isListaClassificadoresAndPeriodoFimValid(listaClassificadores, periodo)){
			List<Dashboard> listaDashboards = dashboardGeralDao.findIdDashboard(listaClassificadores, periodo.getInicio(), periodo.getFim());
			
			if( listaDashboards != null && listaDashboards.size() > 0){
				
				DashboardVO db = new DashboardVO();
				
				//  recuperar valores para andamento da curadoria 
				db.setAndamentoCuradoria(recuperarAndamentoCuradoria(listaDashboards));
				
				// Atualizar totais
				db.setQtTotalPerguntas(0);
				db.setQtSecoes(0);
				db.setQtPerguntasCuradas(0);
				db.setQtPerguntasDescosideradas(0);
				db.setQtPerguntasNaoCuradas(0);
				db.setQtTotalPerguntasEnvGestor(0);
				db.setQtPerguntasCuradasRegua(0);
				db.setQtFeedbackPosit(0);
				db.setQtFeedbackNegat(0);
				
				for( Dashboard dashboard : listaDashboards ){				    				    
				    db.setQtSecoes(db.getQtSecoes()+dashboard.getQtTotalSecao());
					db.setQtTotalPerguntas(db.getQtTotalPerguntas()+dashboard.getQtTotalPerguntas());
					db.setQtPerguntasCuradas(db.getQtPerguntasCuradas()+dashboard.getQtPerguntasCuradasCurador());
					db.setQtPerguntasDescosideradas(db.getQtPerguntasDescosideradas()+dashboard.getQtdPerguntasCuradasExcluida());
					db.setQtPerguntasNaoCuradas(db.getQtPerguntasNaoCuradas()+dashboard.getQtPerguntasNaocuradas());
					db.setQtTotalPerguntasEnvGestor(db.getQtTotalPerguntasEnvGestor()+dashboard.getQtTotalPerguntasEnvGestor());
					db.setQtPerguntasCuradasRegua(db.getQtPerguntasCuradasRegua()+dashboard.getQtPerguntasCuradasRegua());
					db.setQtFeedbackPosit(db.getQtFeedbackPosit()+dashboard.getQtFeedbackPosit());
					db.setQtFeedbackNegat(db.getQtFeedbackNegat()+dashboard.getQtFeedbackNegat());
				}
				
				//valores para o grafico de atividades de curador
				db.setAtividadeCurador(recuperarAtividades(listaClassificadores, periodo.getInicio(), periodo.getFim(), true));
				
				//valores para o grafico de atividades de coletor
				db.setAtividadeColetor(recuperarAtividades(listaClassificadores, periodo.getInicio(), periodo.getFim(), false));
				
				//valor para montar grafico e media de confiança
				db.setMediaConfianca(recuperarMediaConfianca(listaDashboards));
				
				//valores de intenções mais sugeridas
				db.setIntencoesMaisSugeridas(dashboardGeralDao.findIntecoesMaisSugeridasClassificador(listaClassificadores, periodo.getInicio(), periodo.getFim()));
				
				// consular media de perguntas por inteção sugeridas
				if( db.getIntencoesMaisSugeridas() != null && db.getIntencoesMaisSugeridas().size() > 0 && db.getQtTotalPerguntas() > 0 ){
					db.setMediaPerguntasIntencao(db.getQtTotalPerguntas()/db.getIntencoesMaisSugeridas().size());
				}
				
				// valor para montar grafico do histórico de feedback
				db.setHistoricoFeedback(recuperarHistoricoFeedback(listaDashboards));
				return db;
			}
		}
		return null;
	}

    private boolean isListaClassificadoresAndPeriodoFimValid(List<Classificador> listaClassificadores,
            PeriodoVO periodo) {
        return listaClassificadores != null && listaClassificadores.size() > 0 && periodo.getFim() != null;
    }

	/**
	 * montar resposta media confiança
	 * @param listaDashboards
	 * @return
	 */
	private DashboardHistoricoConfiancaVO recuperarMediaConfianca(
			List<Dashboard> listaDashboards) {
		
		if( listaDashboards != null && listaDashboards.size() > 0 ){
			
			DashboardHistoricoConfiancaVO confiancaVO = new DashboardHistoricoConfiancaVO();
			confiancaVO.setListaConfiancaDia(new ArrayList<DashboardValorGraficoVO>());
			confiancaVO.setDatas(new ArrayList<String>());
			
			int qtdConfianca = 0;
			int valorConfianca = 0;
			
			for( Dashboard dashboard: listaDashboards ){
				
				// soma valores de confiança para calcular a média do período
				if( dashboard.getMediaGrauConhecimento() > 0 ){
					valorConfianca += dashboard.getMediaGrauConhecimento().intValue();
					qtdConfianca++;
				}
				
				// grau medio de confianca por dia
				DashboardValorGraficoVO coletada = new DashboardValorGraficoVO();
				coletada.setValor(dashboard.getMediaGrauConhecimento());
				coletada.setData(FormatarData.formatarString(dashboard.getDataConsulta()));
				confiancaVO.getListaConfiancaDia().add(coletada);
				
				// datas apresentadas
				confiancaVO.getDatas().add(FormatarData.formatarString(dashboard.getDataConsulta()));
			}
			
			// media de confianca do periodo
			if( qtdConfianca > 0 ){
				confiancaVO.setMediaConfianca((valorConfianca/qtdConfianca));
			}
			
			Collections.sort(confiancaVO.getDatas(), new DataComparator());
			Collections.sort(confiancaVO.getListaConfiancaDia(), new DataComparator());
			
			return confiancaVO;
		}
		
		return null;
	}

	/**
	 * recuperar atividades de usuários cletories ou curadores
	 * @param listaDashboards
	 * @param b
	 * @return
	 */
	private DashboardAtividadeUsuarioVO recuperarAtividades(List<Classificador>listaClassificadores, Date dataInicial, Date dataFinal, Boolean curador) {
		List<PerguntaPorColetor> atividades = dashboardGeralDao.findPerguntasPorUsuario(listaClassificadores, dataInicial, dataFinal, curador);
		
		if( atividades != null && atividades.size() > 0){
			DashboardAtividadeUsuarioVO atividade = new DashboardAtividadeUsuarioVO();
			atividade.setNomeUsuario(new ArrayList<String>());
			atividade.setColetadas(new ArrayList<Integer>());
			atividade.setCuradas(new ArrayList<Integer>());
			atividade.setDesconsideradas(new ArrayList<Integer>());
			for( PerguntaPorColetor pergunta : atividades ){
				atividade.getNomeUsuario().add(pergunta.getNome());
				atividade.getColetadas().add(pergunta.getColetadas());
				atividade.getCuradas().add(pergunta.getCuradas());
				atividade.getDesconsideradas().add(pergunta.getDesconsideradas());
			}
			return atividade;
		}
		
		return null;
	}


	/**
	 * criar objeto para montar o grafico de andamento da curadoria
	 * @param listaDashboards
	 * @return
	 */
	private DashboardAndamentoCuradoriaVO recuperarAndamentoCuradoria(
			List<Dashboard> listaDashboards) {
		
		DashboardAndamentoCuradoriaVO andamentoCuradoria = new DashboardAndamentoCuradoriaVO();
		andamentoCuradoria.setPerguntasNaoCuradas(new ArrayList<DashboardValorGraficoVO>());
		andamentoCuradoria.setPerguntasCuradas(new ArrayList<DashboardValorGraficoVO>());
		andamentoCuradoria.setPerguntasDesconsideradas(new ArrayList<DashboardValorGraficoVO>());
		andamentoCuradoria.setPerguntasCuradasRegua(new ArrayList<DashboardValorGraficoVO>());
		andamentoCuradoria.setPerguntasData(new ArrayList<String>());
		
		for( Dashboard dashboard : listaDashboards ){
			
			// perguntas curadas
			DashboardValorGraficoVO curadas = new DashboardValorGraficoVO();
			curadas.setValor(dashboard.getQtPerguntasCuradasCurador());
			curadas.setData(FormatarData.formatarString(dashboard.getDataConsulta()));
			andamentoCuradoria.getPerguntasCuradas().add(curadas);

			// perguntas nao curadas
			DashboardValorGraficoVO naoCuradas = new DashboardValorGraficoVO();
			naoCuradas.setValor(dashboard.getQtPerguntasNaocuradas());
			naoCuradas.setData(FormatarData.formatarString(dashboard.getDataConsulta()));
			andamentoCuradoria.getPerguntasNaoCuradas().add(naoCuradas);
			
			// perguntas desconsideradas
			DashboardValorGraficoVO desconsideradas = new DashboardValorGraficoVO();
			desconsideradas.setValor(dashboard.getQtdPerguntasCuradasExcluida());
			desconsideradas.setData(FormatarData.formatarString(dashboard.getDataConsulta()));
			andamentoCuradoria.getPerguntasDesconsideradas().add(desconsideradas);
			
			// perguntas curadas pela regua
			DashboardValorGraficoVO curadasRegua = new DashboardValorGraficoVO();
			curadasRegua.setValor(dashboard.getQtPerguntasCuradasRegua());
			curadasRegua.setData(FormatarData.formatarString(dashboard.getDataConsulta()));
			andamentoCuradoria.getPerguntasCuradasRegua().add(curadasRegua);
			
			// datas apresentadas
			andamentoCuradoria.getPerguntasData().add(FormatarData.formatarString(dashboard.getDataConsulta()));
			
		}
		
		Collections.sort(andamentoCuradoria.getPerguntasNaoCuradas(), new DataComparator());
		Collections.sort(andamentoCuradoria.getPerguntasCuradas(), new DataComparator());
		Collections.sort(andamentoCuradoria.getPerguntasCuradasRegua(), new DataComparator());
		Collections.sort(andamentoCuradoria.getPerguntasData(), new DataComparator());
		
		return andamentoCuradoria;
	}
	
	/**
	 * criar objeto para montar o grafico de histórico de feedback
	 * @param listaHistoricoFeedback
	 * @return
	 */
	private DashboardHistoricoFeedbackVO recuperarHistoricoFeedback(
			List<Dashboard> listaDashboards) {
		DashboardHistoricoFeedbackVO historicoFeedback = new DashboardHistoricoFeedbackVO();
		historicoFeedback.setFeedbackPositivo(new ArrayList<DashboardValorGraficoVO>());
		historicoFeedback.setFeedbackNegativo(new ArrayList<DashboardValorGraficoVO>());
		historicoFeedback.setSemFeedback(new ArrayList<DashboardValorGraficoVO>());
		historicoFeedback.setDataDia(new ArrayList<String>());
		
		for( Dashboard d : listaDashboards){
			// feedback positivo
			DashboardValorGraficoVO positivo = new DashboardValorGraficoVO();
			positivo.setValor(d.getQtFeedbackPosit());
			positivo.setData(FormatarData.formatarString(d.getDataConsulta()));
			historicoFeedback.getFeedbackPositivo().add(positivo);
			
			// feedback negativo
			DashboardValorGraficoVO negativo = new DashboardValorGraficoVO();
			negativo.setValor(d.getQtFeedbackNegat());
			negativo.setData(FormatarData.formatarString(d.getDataConsulta()));
			historicoFeedback.getFeedbackNegativo().add(negativo);
			
			// sem feedback
			DashboardValorGraficoVO semFeedback = new DashboardValorGraficoVO();
			semFeedback.setValor(calcularQntSemFeedback(d));
			semFeedback.setData(FormatarData.formatarString(d.getDataConsulta()));
			historicoFeedback.getSemFeedback().add(semFeedback);
			
			// datas apresentadas
			historicoFeedback.getDataDia().add(FormatarData.formatarString(d.getDataConsulta()));
		}
		
		Collections.sort(historicoFeedback.getFeedbackPositivo(), new DataComparator());
		Collections.sort(historicoFeedback.getFeedbackNegativo(), new DataComparator());
		Collections.sort(historicoFeedback.getSemFeedback(), new DataComparator());
		Collections.sort(historicoFeedback.getDataDia(), new DataComparator());
		
		return historicoFeedback;
	}
	
	private int calcularQntSemFeedback(Dashboard d) {
		return d.getQtTotalPerguntas() - d.getQtFeedbackPosit() - d.getQtFeedbackNegat();
	}
	private class DataComparator implements Comparator<Object> {

		@Override
		public int compare(Object o1, Object o2) {
			
			Date dt1 = null;
			Date dt2 = null;
			
			if( o1 instanceof DashboardValorGraficoVO ){
				dt1 = FormatarData.formatarStringParaData(""+((DashboardValorGraficoVO)o1).getData());
				dt2 = FormatarData.formatarStringParaData(""+((DashboardValorGraficoVO)o2).getData());
			}else if( o1 instanceof String ){
				dt1 = FormatarData.formatarStringParaData(""+o1);
				dt2 = FormatarData.formatarStringParaData(""+o2);
			}
			if(dt1 != null && dt2 != null){
				return dt1.compareTo(dt2);
			}
			return 0;
		}

		
	}
	
	private PeriodoVO getPeriodo(String intervalo){
		
        PeriodoVO periodoVO = new PeriodoVO();
		if( intervalo.equals("HOJE") ){
			
			Calendar cal = getData(null,true);
			periodoVO.setInicio(cal.getTime());
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			
		}else if( intervalo.equals("ONTEM") ){
			
			Calendar cal = getData(null,true);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			periodoVO.setInicio(cal.getTime());
			
		}else if( intervalo.equals("ULTIMOS_7_DIAS") ){
			
			Calendar cal = getData(null,true);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			cal.add(Calendar.DAY_OF_MONTH, -7);
			periodoVO.setInicio(cal.getTime());
		
		}else if( intervalo.equals("SEMANA_ATUAL") ){
			
			Calendar cal = getData(null,true);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
			periodoVO.setInicio(cal.getTime());
			
		}else if( intervalo.equals("SEMANA_PASSADA") ){
			
			Calendar cal = getData(null,true);
			int i = cal.get(Calendar.DAY_OF_WEEK) - cal.getFirstDayOfWeek();
			cal.add(Calendar.DATE, -i - 7);
			periodoVO.setInicio(cal.getTime());
			cal.add(Calendar.DATE, 6);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			
		}else if( intervalo.equals("MES_ATUAL") ){
			Calendar cal = getData(null,true);
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
			periodoVO.setInicio(cal.getTime());
			
		}else if( intervalo.equals("MES_PASSADO") ){
			Calendar cal = getData(null,true);
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
			periodoVO.setInicio(cal.getTime());
			cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			periodoVO.setFim(getData(cal.getTime(),false).getTime());
		}
		
		return periodoVO;
	}
	
	private Calendar getData(Date data, boolean inicio){
		Calendar calendar = Calendar.getInstance();
		if( data != null )
			calendar.setTime(data);
		
		if( inicio ){
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
		}else{
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MINUTE, 59);
			calendar.set(Calendar.SECOND, 59);
		}
		
		return calendar;
	}
	
	private static class PeriodoVO{
		private Date inicio;
		private Date fim;
		public Date getInicio() {
			return inicio;
		}
		public void setInicio(Date inicio) {
			this.inicio = inicio;
		}
		public Date getFim() {
			return fim;
		}
		public void setFim(Date fim) {
			this.fim = fim;
		}
	}
	
	public QualidadeCorpus recuperarQualidadeCorpus(List<Classificador> classificadores){
		QualidadeCorpus qualidade = dashboardGeralDao.findQtdPerguntasPorIntencao(classificadores);
		if( qualidade == null ){
			qualidade = new QualidadeCorpus();
		}
		qualidade.setMediaPalavras(relatoriosGeralManager.mediaTamanhoRespostas(classificadores.get(0).getId()));
		return qualidade;
	}

}
