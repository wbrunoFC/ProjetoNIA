package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.json.JSONArray;
import org.json.JSONObject;

import br.com.bb.gearq.c4coleta.dao.RespostaDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaVersaoHistoricoDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.Resposta;
import br.com.bb.gearq.c4coleta.model.RespostaVersaoHistorico;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.versionamento.v1.CorpusVersaoVoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.RespostaBaseVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.SlotVersaoV1;

@Name("respostaManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class RespostaManager {

    @In(create = true)
    private RespostaVersaoHistoricoDao respostaVersaoHistoricoDao;

    @In(create = true)
    private RespostaDao respostaDao;

    @In(create = true)
    private RespostaDialogoDao respostaDialogoDao;

    @In(create = true)
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @In(create = true)
    private VersaoCorpusManager versaoCorpusManager;

    public void limparRespostaAmbiente(NuvemWatson nuvem) {
        respostaDao.apagarRespostas(nuvem.getId());
    }

    public void atualizaRespostaAmbiente(NuvemWatson nuvem, VersaoCorpus versaoCorpus) {
        // Apagar respostas anteriores
        limparRespostaAmbiente(nuvem);

        String jsonNia = versaoCorpus.getJsonNia();
        if (jsonNia == null || jsonNia.trim().isEmpty()) {
            atualizaRespostaAmbiente(nuvem, versaoCorpus.getId());
        } else {
            CorpusVersaoVoV1 corpusVersao = versaoCorpusManager.parseJsonToCorpus(jsonNia);
            atualizaRespostaAmbiente(nuvem, corpusVersao);
        }
    }

    private void atualizaRespostaAmbiente(NuvemWatson ambiente, int idVersao) {
        // Obter resposta
        List<RespostaVersaoHistorico> respostas = respostaVersaoHistoricoDao
                .buscarPorVersaoClassificador(ambiente.getClassificador().getId(), idVersao);

        for (RespostaVersaoHistorico respostaHistorico : respostas) {
            Resposta r = new Resposta();
            r.setClassificador(ambiente.getClassificador());
            r.setHash(respostaHistorico.getHash());
            r.setJson(respostaHistorico.getJson());
            r.setNuvemWatson(ambiente);
            r.setSgNuvem(ambiente.getSiglaNuvem());

            respostaDao.persist(r);
        }

    }

    private void atualizaRespostaAmbiente(NuvemWatson ambiente, CorpusVersaoVoV1 corpusVersao) {
        for (Map<String, String> respostaJson : getRespostasCorpusVersao(corpusVersao)) {
            Resposta r = new Resposta();
            r.setClassificador(ambiente.getClassificador());
            r.setHash(respostaJson.get("uuid"));
            r.setJson(respostaJson.get("respostajson"));
            r.setNuvemWatson(ambiente);
            r.setSgNuvem(ambiente.getSiglaNuvem());

            respostaDao.persist(r);
        }
    }

    private List<Map<String, String>> getRespostasCorpusVersao(CorpusVersaoVoV1 corpusVersao) {
        List<Map<String, String>> respostas = new ArrayList<>();
        getRespostasJson(respostas, corpusVersao.getNos());
        return respostas;
    }

    private List<Map<String, String>> getRespostasJson(List<Map<String, String>> respostas, List<DialogoVersaoV1> nos) {
        for (DialogoVersaoV1 node : nos) {
            if (node.isAtivo()) {
                Map<String, String> map = buildRespostaJson(node.getUuid(), parseRespostasToJson(node.getRespostas()));
                respostas.add(map);
                getRespostasJson(respostas, node.getFilhos());
                getRespostasSlot(respostas, node.getSlots());
            }
        }
        return respostas;
    }

    private void getRespostasSlot(List<Map<String, String>> respostas, List<SlotVersaoV1> slots) {
        for (SlotVersaoV1 slot : slots) {
            Map<String, String> map = buildRespostaJson(slot.getUuid(), parseRespostasToJson(slot.getRespostas()));
            respostas.add(map);

            Map<String, String> respostaValido = buildRespostaJson(slot.getHashDadoValido(),
                    getJsonRespostaSimples(slot.getSlotDadoValido()));
            respostas.add(respostaValido);

            Map<String, String> respostaInvalido = buildRespostaJson(slot.getHashDadoInvalido(),
                    getJsonRespostaSimples(slot.getSlotDadoInvalido()));
            respostas.add(respostaInvalido);

            getRespostasJson(respostas, slot.getFilhos());
        }
    }

    private Map<String, String> buildRespostaJson(String uuid, String resposta) {
        Map<String, String> map = new HashMap<>();
        map.put("uuid", uuid);
        map.put("respostajson", resposta);
        return map;
    }

    private String parseRespostasToJson(List<? extends RespostaBaseVersaoV1> respostas) {
        JSONArray jsonArray = new JSONArray();
        for (RespostaBaseVersaoV1 resposta : respostas) {
            jsonArray.put(respostatoJsonObject(resposta));
        }
        return jsonArray.toString();
    }

    private JSONObject respostatoJsonObject(RespostaBaseVersaoV1 resposta) {
        JSONObject jResp = new JSONObject();
        jResp.put("nome", resposta.getTipoRespostaNomeJSON());
        jResp.put("resposta", resposta.getTextoResposta());
        jResp.put("bloco", resposta.getSequenciaBloco());
        jResp.put("sequencia", resposta.getSequenciaItem());
        jResp.put("tempoResposta", resposta.getTempoResposta());
        return jResp;
    }

    private String getJsonRespostaSimples(String textoResposta) {
        JSONArray jsonArray = new JSONArray();
        JSONObject jResp = new JSONObject();
        jResp.put("nome", "TX_PADRAO");
        jResp.put("resposta", textoResposta);
        jResp.put("bloco", 1);
        jResp.put("sequencia", 1);
        jResp.put("tempoResposta", 0);
        jsonArray.put(jResp);
        return jsonArray.toString();
    }
}
