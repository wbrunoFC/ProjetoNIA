package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.Predicate;
import org.apache.commons.lang3.builder.Diff;
import org.apache.commons.lang3.builder.DiffResult;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.common.collect.MapDifference.ValueDifference;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.VersaoCorpusDao;
import br.com.bb.gearq.c4coleta.model.AssuntoClassificador;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.Tag;
import br.com.bb.gearq.c4coleta.model.VariavelContexto;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.util.JSONUtils;
import br.com.bb.gearq.c4coleta.versionamento.v1.AssuntoClassificadorVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.CasoDeTesteVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.CorpusVersaoVoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.DialogoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.EntidadeVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.IntencaoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.VariavelContextoVersaoV1;
import br.com.bb.gearq.c4coleta.versionamento.v1.Versao;
import br.com.bb.gearq.c4coleta.versionamento.v1.VersaoUuid;
import br.com.bb.gearq.c4coleta.vo.DiffVersao;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.RespostaComparacaoVersaoVO;
import br.com.bb.gearq.c4coleta.vo.VersaoCorpusVo;

@Name("versaoCorpusManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class VersaoCorpusManager {

    @In(create = true)
    private VersaoCorpusDao versaoCorpusDao;

    @In(create = true)
    private ClassificadorManager classificadorManager;

    @In(create = true)
    private IntencaoManager intencaoManager;

    @In(create = true)
    private EntidadeManager entidadeManager;

    @In(create = true)
    private DialogoManager dialogoManager;

    @In(create = true)
    private AssuntoClassificadorManager assuntoClassificadorManager;

    @In(create = true)
    private SlotManager slotManager;

    @In(create = true)
    private VariavelContextoManager variavelContextoManager;

    @In(create = true)
    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;

    @In(create = true)
    private UsuarioManager usuarioManager;
    
    @In(create = true)
    private TagManager tagManager;

    @In(create = true)
    private CacheProgresso cacheProgresso;

    public VersaoCorpus criar(int idClassificador, String descricao, String jsonNia, String jsonWatson,
            UsuarioVO funci) {
        VersaoCorpus versaoCorpus = new VersaoCorpus();
        versaoCorpus.setIdClassificador(idClassificador);
        versaoCorpus.setDataCriacao(new Date());
        versaoCorpus.setDescricao(descricao);
        versaoCorpus.setVersao(versaoCorpusDao.getProximaVersao(idClassificador));
        versaoCorpus.setJsonNia(jsonNia);
        versaoCorpus.setJsonWatson(jsonWatson);
        versaoCorpus.setIdUsuario(usuarioManager.obterIdUsuarioLogado(funci));

        versaoCorpusDao.persist(versaoCorpus);

        return versaoCorpus;
    }

    public VersaoCorpus obter(Integer idVersao) {
        return versaoCorpusDao.findById(idVersao);
    }

    public VersaoCorpus obterPorVersao(Integer idClassificador, Integer versao) {
        return versaoCorpusDao.findByVersao(idClassificador, versao);
    }

    public CorpusVersaoVoV1 montarNovaVersao(Integer idClassificador) {
        CorpusVersaoVoV1 corpusVersao = new CorpusVersaoVoV1();
        corpusVersao.setIntencoes(intencaoManager.listarVersao(idClassificador));
        corpusVersao.setEntidades(entidadeManager.listarVersao(idClassificador));
        corpusVersao.setNos(dialogoManager.listarVersao(idClassificador));
        corpusVersao.setAssuntos(assuntoClassificadorManager.listarVersao(idClassificador));
        corpusVersao.setVariaveisContexto(variavelContextoManager.listarVersao(idClassificador));        
        corpusVersao.setCasosDeTeste(casoDeTesteClassificadorManager.listarVersao(idClassificador));
        return corpusVersao;
    }

    public String montarNovaVersaoStr(Integer idClassificador) {
        CorpusVersaoVoV1 corpus = this.montarNovaVersao(idClassificador);
        return this.parseCorpusToJson(corpus);
    }

    private String parseCorpusToJson(CorpusVersaoVoV1 corpus) {
        return JSONUtils.parseToJson(corpus);
    }

    public CorpusVersaoVoV1 parseJsonToCorpus(String json) {
        Object obj = JSONUtils.parseToObject(json, CorpusVersaoVoV1.class);
        return (CorpusVersaoVoV1) obj;
    }

    public VersaoCorpus findById(int idVersao) {
        return versaoCorpusDao.findById(idVersao);
    }

    public List<VersaoCorpusVo> listarPorClassificador(Integer idClassificador) {
        return versaoCorpusDao.listarPorClassificador(idClassificador);
    }

    public VersaoCorpus listarUltimoPorClassificador(Integer idClassificador) {
        return versaoCorpusDao.listarUltimoPorClassificador(idClassificador);
    }

    public Paginacao<VersaoCorpusVo> findVersoesPaginacao(Paginacao<VersaoCorpus> paginacao, int idClassificador,
            int versao) {
        paginacao = versaoCorpusDao.findVersoesPaginacao(paginacao, idClassificador, versao);

        Paginacao<VersaoCorpusVo> novapaginacao = new Paginacao<>();

        List<VersaoCorpusVo> versoesVo = transformarParaVo(paginacao.getListaPaginada());
        novapaginacao.setListaPaginada(versoesVo);

        novapaginacao.setPaginaAtual(paginacao.getPaginaAtual());
        novapaginacao.setPaginasTotal(paginacao.getPaginasTotal());
        novapaginacao.setRegistrosPagina(paginacao.getRegistrosPagina());
        novapaginacao.setTotalRegistros(paginacao.getTotalRegistros());

        return novapaginacao;
    }

    private List<VersaoCorpusVo> transformarParaVo(List<VersaoCorpus> versoes) {
        List<VersaoCorpusVo> versoesVo = new ArrayList<>();
        for (VersaoCorpus vc : versoes) {
            VersaoCorpusVo versaoVo = new VersaoCorpusVo(vc);
            versoesVo.add(versaoVo);
        }
        return versoesVo;
    }

    public void restaurar(int idClassificador, int versao) {
        VersaoCorpus vc = this.obterPorVersao(idClassificador, versao);
        String json = vc.getJsonNia();
        restaurar(idClassificador, json);
    }

    public void restaurar(int idClassificador, String json) {
        CorpusVersaoVoV1 corpus = parseJsonToCorpus(json);
        restaurar(idClassificador, corpus);
    }

    private void restaurar(int idClassificador, CorpusVersaoVoV1 corpus) {
        String nomeItem = "RECOVERY_" + idClassificador + "_PROGRESSO";
        cacheProgresso.atualizar(nomeItem, 1, "Removendo dados do corpus");

        classificadorManager.limpar(idClassificador);

        restaurarV1(idClassificador, corpus);
    }

    private void restaurarV1(int idClassificador, CorpusVersaoVoV1 corpus) {
        String nomeItem = "RECOVERY_" + idClassificador + "_PROGRESSO";

        cacheProgresso.atualizar(nomeItem, 5, "Restaurando assuntos");
        int size = corpus.getAssuntos().size();
        int i = 0;
        List<AssuntoClassificador> assuntos = new ArrayList<>();
        for (AssuntoClassificadorVersaoV1 assuntoVersao : corpus.getAssuntos()) {
            String msg = "Restaurando Assunto " + ++i + "/" + size;
            cacheProgresso.atualizar(nomeItem, 5, msg);
            AssuntoClassificador assunto = assuntoClassificadorManager.salvar(idClassificador, assuntoVersao.getEntity());
            assuntos.add(assunto);
        }

        cacheProgresso.atualizar(nomeItem, 6, "Restaurando intenções");
        size = corpus.getIntencoes().size();
        i = 0;
        for (IntencaoVersaoV1 intencaoVersao : corpus.getIntencoes()) {
            String msg = "Restaurando Intenção " + ++i + "/" + size;
            cacheProgresso.atualizar(nomeItem, 6, msg);
            intencaoManager.salvar(idClassificador, intencaoVersao.getEntity(assuntos));
        }

        cacheProgresso.atualizar(nomeItem, 7, "Restaurando entidades");
        size = corpus.getEntidades().size();
        i = 0;
        for (EntidadeVersaoV1 entidadeVersao : corpus.getEntidades()) {
            String msg = "Restaurando Entidade " + ++i + "/" + size;
            cacheProgresso.atualizar(nomeItem, 7, msg);
            entidadeManager.salvar(idClassificador, entidadeVersao.getEntity());
        }

        cacheProgresso.atualizar(nomeItem, 8, "Restaurando os Nós do Dialogo");
        Map<String, Integer> idsVariaveis = salvarVariaveis(idClassificador, corpus.getVariaveisContexto());
        salvarDialogos(idClassificador, corpus, idsVariaveis, assuntos);

        cacheProgresso.atualizar(nomeItem, 9, "Restaurando Casos de Teste");
        for (CasoDeTesteVersaoV1 casoVersao : corpus.getCasosDeTeste()) {
            casoDeTesteClassificadorManager.salvar(idClassificador, casoVersao.getEntity());
        }
    }

    private Map<String, Integer> salvarVariaveis(int idClassificador, List<VariavelContextoVersaoV1> variaveis) {
        Map<String, Integer> ids = new HashMap<>();
        for (VariavelContextoVersaoV1 vcVersao : variaveis) {
            VariavelContexto vc = variavelContextoManager.salvar(idClassificador, vcVersao.getEntity());
            ids.put(vc.getUuid(), vc.getId());
        }
        return ids;
    }

    private void salvarDialogos(int idClassificador, CorpusVersaoVoV1 corpus, Map<String, Integer> idsVariaveis,
            List<AssuntoClassificador> assuntos) {
        String nomeItem = "RECOVERY_" + idClassificador + "_PROGRESSO";
        Map<String, Tag> tags = tagManager.listarToMap();
        
        int size = corpus.getNos().size();
        int i = 0;
        List<DialogoVersaoV1> nosComJump = new ArrayList<>();
        for (DialogoVersaoV1 dialogoVersaoV1 : corpus.getNos()) {
            String msg = "Restaurando node " + ++i + "/" + size + " (raiz)";
            cacheProgresso.atualizar(nomeItem, 8, msg);
            Dialogo dialogo = dialogoVersaoV1.getEntity(idsVariaveis, assuntos, tags);
            dialogo.setIdClassificador(idClassificador);
            dialogoManager.salvar(dialogo);
            obterNosComJump(nosComJump, dialogoVersaoV1);
        }

        // Atualizar jumps
        for (DialogoVersaoV1 dialogoVersaoV1 : nosComJump) {
            Dialogo dialogo = dialogoManager.obterPorUuid(idClassificador, dialogoVersaoV1.getUuid());
            Dialogo dialogoAlvo = dialogoManager.obterPorUuid(idClassificador, dialogoVersaoV1.getUuidEnviarPara());
            dialogo.setEnviarPara(dialogoAlvo);
            dialogoManager.salvar(dialogo);
        }
    }

    private void obterNosComJump(List<DialogoVersaoV1> nosComJump, DialogoVersaoV1 dialogoVersaoV1) {
        if (dialogoVersaoV1.getUuidEnviarPara() != null) {
            nosComJump.add(dialogoVersaoV1);
        }
        for (DialogoVersaoV1 dialogoVersao : dialogoVersaoV1.getFilhos()) {
            obterNosComJump(nosComJump, dialogoVersao);
        }
    }

    public RespostaComparacaoVersaoVO carregarCorpusOrigemDestino(int corpusOrigemId, int corpusDestinoId) {
        CorpusVersaoVoV1 origem = getCorpusVersaoById(corpusOrigemId);
        CorpusVersaoVoV1 destino = getCorpusVersaoById(corpusDestinoId);

        return new RespostaComparacaoVersaoVO(origem, destino);
    }

    private CorpusVersaoVoV1 getCorpusVersaoById(int idCorpusVersao) {
        String json = findById(idCorpusVersao).getJsonNia();
        return parseJsonToCorpus(json);
    }
}
