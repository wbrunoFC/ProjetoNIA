package br.com.bb.gearq.c4coleta.manager;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.audit.dto.MediaQtdPalavrasRespostas;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.ServicoNlcDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.QtdTamanhoPalavrasRespostasVO;

@Name("relatoriosGeralManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class RelatoriosGeralManager {

	@In(create = true)
	private ClassificadorDao classificadorDao;

	@In(create = true)
	private ServicoNlcDao servicoNlcDao;
	
	@In(create = true)
	private IntencaoDao intencaoDao;

	
	@In(create=true)
	private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
	
	@In(create=true)
	private TipoRespostaDao tipoRespostaDao;
	

	public Paginacao<ServicoNlc> teste(Paginacao<ServicoNlc> p) {
	    p = servicoNlcDao.findByUsuarioAuthenticado(p, null);
	    return p;
	}
	
	public List<Classificador> listaClassificadores (){
		
		Paginacao<ServicoNlc> p =  new Paginacao<ServicoNlc>();
		
		p.setRegistrosPagina(Integer.MAX_VALUE);
		
		p = servicoNlcDao.findByUsuarioAuthenticado(p, null);
		
		List<Classificador> listaRetornoClassf = new ArrayList<Classificador>();
		
		for(ServicoNlc servico :p.getListaPaginada()){
			// ver com o nimai se esta com erro. 
			listaRetornoClassf.addAll(classificadorDao.findByService(servico.getId(), null));
		
		};
		
			return listaRetornoClassf;
	}

	
	
	public MediaQtdPalavrasRespostas mediaTamanhoRespostas (int idClassificador){
		
		
		List<Intencao> i = intencaoDao.findByClassificador(idClassificador);
		
		double contVermelho = 0;
		double contAmarelo = 0;
		double contVerde = 0;
		
		double totalResposta = 0;
		

		MediaQtdPalavrasRespostas media = new MediaQtdPalavrasRespostas(); 
		
		for(Intencao p: i){
			
			List<TipoRespostaIntencao> respostas = tipoRespostaIntencaoDao.findAll(p.getId(), null);
			String texteResposta = "";
			
			if( respostas != null ){
				for( TipoRespostaIntencao resp : respostas ){
					if(resp.getTipoResposta().getNomeJSON().equals(TipoResposta.TX_PADRAO)){
						texteResposta = StringEscapeUtils.unescapeJava(resp.getTextoResposta());
					}
				}
			}
			
			
			
			if(texteResposta!=null && !texteResposta.equalsIgnoreCase("")){
				
				String textoHtml = StringEscapeUtils.unescapeHtml(texteResposta);// retirar o encode
				String textoSemHtml = textoHtml.replaceAll("\\<.*?>","");// retirar html
				String[] palavras = textoSemHtml.split(" "); // contagem de palavras


				// mais de 200 palavras vermelha
				if(palavras.length >= 200){
					
					contVermelho++;
	
				}
				
				// de 100 a 199 palavras amarelo
				if(palavras.length >= 100 && palavras.length <= 199){
					
					contAmarelo++;

				}
				
				// menos de 100 palavras verde
				if(palavras.length < 100){
					
					contVerde++;

				}
				
				totalResposta++;
			}

			 
		}
		
		
		DecimalFormat formato = new DecimalFormat("#.##");      
       
		if(totalResposta > 0){
			
			media.setQtdRespostasVerdePorcen(Double.valueOf(formato.format((contVerde/totalResposta)*100).replace(",", ".")));
			media.setQtdRespostasAmareloPorcen( Double.valueOf(formato.format((contAmarelo/totalResposta)*100).replace(",", ".")));
			media.setQtdRespostasVermelhoPorcen(Double.valueOf(formato.format((contVermelho/totalResposta)*100).replace(",", ".")));
			media.setQtdTotalRespostas(totalResposta);
		}
		
		return media;
	}
	
	public QtdTamanhoPalavrasRespostasVO tamanhoRespostas (int idClassificador){
		
		QtdTamanhoPalavrasRespostasVO  qtdTamanho =  new QtdTamanhoPalavrasRespostasVO();
		
		List<String> respostas = tipoRespostaDao.findRespostasClassificador(idClassificador);
		
		int maisDuzentas = 0;
		int deCemHaDuzentos = 0;
		int menosCem = 0;
		int totalResposta = 0;
		
		if(respostas != null){
			
			for(String resp:respostas){
				String[] palavras = resp.split(" "); // contagem de palavras
				if(palavras != null){
					// mais de 200 palavras vermelha
					if(palavras.length >= 200){
						
						maisDuzentas++;
						
					}
					
					// de 100 a 199 palavras amarelo
					if(palavras.length >= 100 && palavras.length <= 199){
						
						deCemHaDuzentos++;
						
					}
					
					// menos de 100 palavras verde
					if(palavras.length < 100){
						
						menosCem++;
						
					}
					
					totalResposta++;
				}
				}
		}
		if(totalResposta > 0){
		qtdTamanho.setDeCemHaDuzentos(deCemHaDuzentos);
		qtdTamanho.setMaisDuzentas(maisDuzentas);
		qtdTamanho.setMenosCem(menosCem);
		qtdTamanho.setTotalResposta(totalResposta);

	}

		
		return qtdTamanho;

	}
}
