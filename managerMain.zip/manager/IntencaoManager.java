package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.FluxoTagDao;
import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.FluxoTag;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativa;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.Tag;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.versionamento.v1.IntencaoVersaoV1;
import br.com.bb.gearq.c4coleta.vo.BuscaAvancadaIntencaoVO;
import br.com.bb.gearq.c4coleta.vo.FiltroPesquisaIntencaoVO;
import br.com.bb.gearq.c4coleta.vo.FluxoItemVO;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;
import br.com.bb.gearq.c4coleta.vo.InstrucaoNormativaVO;
import br.com.bb.gearq.c4coleta.vo.IntencaoVO;
import br.com.bb.gearq.c4coleta.vo.MigrarIntencaoVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.MensagemNegocio;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("intencaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class IntencaoManager {

	@In(create = true)
	private ClassificadorDao classificadorDao;

	@In(create = true)
	private IntencaoDao intencaoDao;

	@In(create = true)
	private InstrucaoNormativaDao instrucaoNormativaDao;

	@In(create = true)
	private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
	
	@In(create = true)
	private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;
	
	@In(create = true)
	private PerguntaRevisaoDao perguntaRevisaoDao;
	
	@In(create = true)	
	private PerguntaRevisaoManager perguntaRevisaoManager;

	@In(create = true)
	private FluxoManager fluxoManager;
	
	@In(create = true)
	private PerguntaDao perguntaDao;
	
	@In(create = true)
	private PerguntaManager perguntaManager;
	
	@In(create = true)
	private FluxoTagDao fluxoTagDao;
	
	@In(create = true)	
	private EntidadeManager entidadeManager;
	
	@In(create = true)
	private InstrucaoNormativaManager instrucaoNormativaManager;
	
	@In(create = true)
    private CacheProgresso cacheProgresso;
	
	private List<FluxoItemVO> listaItem = new ArrayList<FluxoItemVO>();
	
	public Intencao findById(Integer idIntencao) {
		return intencaoDao.findById(idIntencao);
	}
	
	public Paginacao<IntencaoVO> pesquisar(FiltroPesquisaIntencaoVO filtroPesquisaIntencaoVO) {
		Paginacao<Intencao> paginacaoOriginal = intencaoDao.findIntencaoNomeStatus(filtroPesquisaIntencaoVO);
		return converterParaIntencaoVO(paginacaoOriginal);
	}
	
	public Paginacao<IntencaoVO> pesquisarPorNome(Paginacao<Intencao> paginacao, int idClassificador, String intencao) {
		Paginacao<Intencao> paginacaoOriginal = intencaoDao.findIntencao(paginacao, idClassificador, intencao);
		return converterParaIntencaoVO(paginacaoOriginal);
	}
	
	public Paginacao<Intencao> pesquisarPorNomeCompleto(Paginacao<Intencao> paginacao, int idClassificador, String intencao) {
        return intencaoDao.findIntencao(paginacao, idClassificador, intencao);
    }
	
	public List<Intencao> listarPorClassificador(Integer idClassificador) {
	    return intencaoDao.findByClassificador(idClassificador);
	}
	
	public Intencao salvar(int idClassificador, Intencao intencao) {
		Classificador classificador = classificadorDao.findById(idClassificador);
		intencao.setClassificador(classificador);
		intencao.setIdClassificador(idClassificador);
		
		intencao.setNome(intencao.getNome().trim());
		intencao.setHashNuvem(getHashNuvem(intencao.getHashNuvem()));
		
		//|| verificarSeAlterouAssuntos(intencao)
		if (intencao.getId() == null || intencao.getId() == 0) {
			// Cadastrar
			intencao = intencaoDao.persist(intencao);
		} else if (verificarSeAlterouIntencao(intencao) || verificarSeAlterourINs(intencao) || verificarSeAlterouRespostas(intencao) ) {
			intencao.setDataModificacao(new Date());
		}
		
		// instrucaoNormativa
		if (intencao.getiNs() != null && !intencao.getiNs().isEmpty()) {
			for (InstrucaoNormativa instrucaoN : intencao.getiNs()) {
				instrucaoN.setIntencao(intencao);
				instrucaoNormativaDao.persist(instrucaoN);
			}
		}
		
		// Exemplos
		if(intencao.getPerguntas() != null) {
			for(Pergunta pergunta : intencao.getPerguntas()) {
				pergunta.setIntencao(intencao);
				perguntaDao.persist(pergunta);
			}
		}
		
		if( !classificador.getIndDialogo() ){
			if (intencao.getNecessitaDesambiguacao()) {
				if (intencao.getFluxo() != null ) {
					cadastrarFluxo(intencao,intencao.getFluxo());
				}				
			} else {
				// repostas
				if (intencao.getRespostas() != null) {
					for (TipoRespostaIntencao resp : intencao.getRespostas()) {
						resp.getId().setIdIntencao(intencao.getId());
						tipoRespostaIntencaoDao.persist(resp);
					}
				}
			}
		}
		
		intencao = intencaoDao.persist(intencao);
		intencaoDao.flush();
		return intencao;
	}
	
	private boolean verificarSeAlterouIntencao(Intencao intencao) {
		Intencao intencaoAnterior = intencaoDao.findIdIntencao(intencao.getId());
		if (intencaoAnterior == null) {
			return false;
		}
		return (
				   !validarIgualdade(intencao.getNome(),intencaoAnterior.getNome()) 
				|| !validarIgualdade(intencao.getStatus().getNome(),intencaoAnterior.getStatus().getNome()) 
				|| !validarIgualdade(intencao.getPerguntaCanonica(),intencaoAnterior.getPerguntaCanonica()) 
				|| !validarIgualdade(intencao.getNecessitaDesambiguacao(),intencaoAnterior.getNecessitaDesambiguacao()) 
				|| !validarIgualdade(intencao.getDescricao(),intencaoAnterior.getDescricao())
		);
	}

//	private boolean verificarSeAlterouAssuntos(Intencao intencao) {
//		List<AssuntoClassificador> assuntos = intencao.getAssuntos();
//		if (assuntos == null) {
//			return false;
//		}
//		
//		Intencao intencaoAnterior = intencaoDao.findIdIntencao(intencao.getId());
//		
//		List<AssuntoClassificador> assuntosAnterior = intencaoAnterior.getAssuntos();
//		if (assuntos.size() != assuntosAnterior.size()) {
//			return true;
//		}
//		
//		for (AssuntoClassificador assunto: assuntos){
//			boolean existe = false;
//			for(AssuntoClassificador assuntoAnt: assuntosAnterior){
//				if (assunto.getId().intValue() == assuntoAnt.getId().intValue()){
//					existe = true;
//					break;
//				}
//			}  
//			if(!existe) {
//				return true;
//			}
//		}
//		return false;
//	}

	private boolean verificarSeAlterourINs(Intencao intencao) {
		List<InstrucaoNormativa> instrucoes = intencao.getiNs();
		List<InstrucaoNormativa> intrucoesAntes = instrucaoNormativaDao.findByIntencao(intencao.getId());
		
		if (instrucoes.size() != intrucoesAntes.size()) {
			return true;
		}
		
		for (InstrucaoNormativa instrucao: instrucoes){
			boolean existeIntrucaoNormativa = false;
			if (instrucao.getNumeroIN() != null){
				for(InstrucaoNormativa intrucaoNor: intrucoesAntes){
					if (instrucao.getNumeroIN().equals(intrucaoNor.getNumeroIN())) {
						existeIntrucaoNormativa = true;
						break;
					}
				}  
				if(!existeIntrucaoNormativa) {
					return true;
				}
			}
		}
		return false;
	}

	private boolean verificarSeAlterouRespostas(Intencao intencao) {
		
		if (intencao.getClassificador().getIndDialogo() || intencao.getNecessitaDesambiguacao()) {
			return false;
		}
		
		List<TipoRespostaIntencao> listaRespostaAnterior = tipoRespostaIntencaoDao.findIdIntencao(intencao.getId());
		
		List<TipoRespostaIntencao> listaResposta1 = null;
		List<TipoRespostaIntencao> listaResposta2 = null;
		
		if (listaRespostaAnterior.size() > intencao.getRespostas().size()){
			listaResposta1  = listaRespostaAnterior;
			listaResposta2  = intencao.getRespostas();
		}else {
			listaResposta1  = intencao.getRespostas();
			listaResposta2  = listaRespostaAnterior;
		}
		
		for (TipoRespostaIntencao  tipoRespostaInt: listaResposta1  ){
			boolean existeTipoRespostaIntencao = false;
			if (tipoRespostaInt.getId() != null && tipoRespostaInt.getTextoResposta() != null ){
				for(TipoRespostaIntencao  tipoRespostaI: listaResposta2){
					if(!tipoRespostaInt.getTextoResposta().equals(tipoRespostaI.getTextoResposta())){
						existeTipoRespostaIntencao = true;
					}
				}
				if(!existeTipoRespostaIntencao){
					return true;
				}
			}
		}
		return false;
	}
	
	private Paginacao<IntencaoVO> converterParaIntencaoVO(Paginacao<Intencao> paginacaoOriginal) {
		Paginacao<IntencaoVO> paginacao = new Paginacao<IntencaoVO>();
		
		List<IntencaoVO> intencoesVO = paginacao.getListaPaginada();		
		for (Intencao intencao : paginacaoOriginal.getListaPaginada()) {
			IntencaoVO intencaoVO = new IntencaoVO(intencao);
			intencaoVO.setQuantidadePergunta(perguntaManager.obterQuantidadePorIntencao(intencao.getId()));
			intencoesVO.add(intencaoVO);
		}
		paginacao.setPaginaAtual(paginacaoOriginal.getPaginaAtual());
		paginacao.setPaginasTotal(paginacaoOriginal.getPaginasTotal());
		paginacao.setRegistrosPagina(paginacaoOriginal.getRegistrosPagina());
		paginacao.setTotalRegistros(paginacaoOriginal.getTotalRegistros());
		
		return paginacao;
	}
	
	public List<Intencao> buscarPorNomeExato(String nome, Integer idClassificador){
	    return intencaoDao.findByNomeIntencao(nome, idClassificador);
	}
	
	public Boolean validarIgualdade(Object valor, Object valor2){
		return (valor != null && valor2 != null && valor.equals(valor2)) || (valor == null && valor2 == null);
	}

	public void cadastrarFluxo(Intencao intencao,FluxoVO fluxoVO) throws NegocioException {
		Fluxo fluxoPai = new Fluxo();
		
		// salvar fluxo
		// fluxo pai
		if (fluxoVO.getPergunta() != null && fluxoVO.getPergunta() != "") {
			//if(fluxoVO.getId() == 0){
				fluxoPai.setPerguntaDesambiguacao(fluxoVO.getPergunta());
				fluxoPai.setFluxoPai(null);
				fluxoPai.setHashNuvem(getHashNuvem(fluxoVO.getHashNuvem()));
				if(fluxoVO.getId() == 0){
					fluxoPai.setId(0);
				}else{
					fluxoPai.setId(fluxoVO.getId());
				}
				fluxoPai.setAgrupador(null);
				fluxoPai.setIntencao(intencao);
				fluxoPai.setItemPaiNaoValida("S");
				fluxoPai.setTextoFormatado(fluxoVO.isTextoFormatado());
				fluxoPai = fluxoManager.salvar(fluxoPai);
				verificarERemoverTags(fluxoPai,fluxoVO.getTags());
				persistirFluxoTags(fluxoPai,fluxoVO.getTags());
			
//			}else{
//				fluxoPai.setPerguntaDesambiguacao(fluxoVO.getPergunta());
//				fluxoPai.setFluxoPai(null);
//				fluxoPai.setId(fluxoVO.getId());
//				fluxoPai.setAgrupador(null);
//				fluxoPai.setIntencao(intencao);
//				fluxoPai.setItemPaiNaoValida("S");
//				fluxoPai.setTextoFormatado(fluxoVO.isTextoFormatado());
//				fluxoPai = fluxoDao.persist(fluxoPai);
//				verificarERemoverTags(fluxoPai,fluxoVO.getTags());
//				persistirFluxoTags(fluxoPai,fluxoVO.getTags());
//			
//
//			}

			fluxoRecursivo(fluxoPai, fluxoVO.getFluxos(), intencao.getClassificador().getId());

		} else {
			throw new NegocioException("Erro! Preencha o campo 'Pergunta' aba Fluxo!");
		}

	}

	public void verificarERemoverTags(Fluxo fluxo,List<Tag> listaTags){
		List<FluxoTag> listaFluxoTag =  fluxoTagDao.buscarTagsPorFluxo(fluxo.getId());

		for(FluxoTag f:listaFluxoTag){
			
			
			boolean remover = true;
			
			
			for(Tag t : listaTags){
				
				if(f.getTag().getId().equals(t.getId())){
					remover = false;
				}
			}
			
			if(remover){
				fluxoTagDao.remove(f);
			}
			
			
			
		}
		
		
		
	}
	
	public void persistirFluxoTags(Fluxo fluxo, List<Tag> listaTags){
		
		for(Tag t: listaTags){
			
			// verificar se já existe ligação entre um fluxo e uma entidade. 
			// Caso a lista retorne vazia, será criado um novo registro.
			
			if(fluxoTagDao.registroJaExiste(fluxo.getId(),t.getId()).isEmpty()){
				FluxoTag fluxoTag = new FluxoTag();
				fluxoTag.setFluxo(fluxo);
				fluxoTag.setTag(t);
				
				fluxoTagDao.persist(fluxoTag);
			}
			
		}
	}
	
	
	public void fluxoRecursivo(Fluxo fluxoId, List<FluxoItemVO> listaFluxoVO, Integer idClassificador)
			throws NegocioException {
		
		
		if (listaFluxoVO.size() > 0) {

			for (FluxoItemVO f : listaFluxoVO) {

				Fluxo fluxoFilho = new Fluxo();
				fluxoFilho.setFluxoPai(fluxoId);
				fluxoFilho.setHashNuvem(getHashNuvem(f.getHashNuvem()));
				
				if(f.getAgrupador() == null){
					throw new NegocioException("Erro! Preencha o campo Entidade da aba fluxo.");
				}else{
					if(f.getAgrupador().getId() == null || f.getAgrupador().getId() == 0){
						Integer idEntidade = f.getAgrupador().getIdEntidade();
						if (idEntidade != null) {
							Entidade entidade = entidadeManager.buscarEntidade(idEntidade);
							f.getAgrupador().setEntidade(entidade);
							fluxoFilho.setEntidade(entidade);
						}
					}else{
						fluxoFilho.setAgrupador(f.getAgrupador());
					}
				}
				
				fluxoFilho.setIntencao(f.getIntencaoAcionada());
				fluxoFilho.setTipoResp(f.getTipoResp());
				fluxoFilho.setPerguntaDesambiguacao(f.getRespostaDireta());
				fluxoFilho.setId(f.getId());
				fluxoFilho.setItemPaiNaoValida("N");
				
				/*Não está sendo usado
				 * if(listaItem.size() > 0){
					
					for(FluxoItemVO lr: listaItem){
						
						
						if(f.getAgrupador().getId()!=null && f.getAgrupador().getId()!= 0){
							if(f.getAgrupador().getId() == lr.getAgrupador().getId()){
									
								//System.out.println("fluxos com a mesma entidade: "+lr.getAgrupador().getNomeAgrupadorEntidade()+ " - "+ fluxoId.getIntencao().getNome());
								//throw new NegocioException("Erro! Não pode existir dois fluxos com a mesma entidade");
									
							}
						}else{
							if(f.getAgrupador().getEntidade().getId().equals(lr.getAgrupador().getEntidade().getId())){
								//System.out.println("fluxos com a mesma entidade: "+lr.getAgrupador().getEntidade().getNome()+ " - "+ fluxoId.getIntencao().getNome());
								//throw new NegocioException("Erro! Não pode existir dois fluxos com a mesma entidade");
								
							}
						}
						
						
					}
				}*/
				
				listaItem.add(f);
				
				
				fluxoFilho = fluxoManager.salvar(fluxoFilho);
				
				//criar vinculo entre o fluxo e suas tags
				verificarERemoverTags(fluxoFilho,f.getTags());
				persistirFluxoTags(fluxoFilho,f.getTags());
		
				
				if (f.getBlocoFluxos().size() > 0) {
					fluxoRecursivo(fluxoFilho, f.getBlocoFluxos(), idClassificador);
				}
			}

		}

	}
	
	public void excluir(Integer id) {
	    Intencao intencao = this.findById(id);
	    excluir(intencao, true);
	}
	
	public void excluir(Intencao intencao, boolean limparPerguntaRevisao) {
		List<Fluxo> fluxos = fluxoManager.listarPorIntencao(intencao.getId());
		for(Fluxo f: fluxos) {
			if(f.getAgrupador()!=null && f.getFluxoPai() != null) {
				throw new NegocioException(criarMensagemErroFluxo(intencao, fluxos));
			}
		}
		
		//Intencao na pergunta para revisao
		if (limparPerguntaRevisao) {
		    perguntaRevisaoIntencaoDao.removerVinculoIntencao(intencao.getId());
		    perguntaRevisaoDao.removerVinculoIntencao(intencao.getId());
		}		
		
		//remover cadeia de fluxos.
		for (Fluxo fluxo : fluxos) {
		    fluxoManager.excluir(fluxo);
        }
		
		for (InstrucaoNormativa instrucaoNormativa : intencao.getiNs()) {
		    instrucaoNormativaDao.remove(instrucaoNormativa);
		}
		
		// repostas
		List<TipoRespostaIntencao> respostas = tipoRespostaIntencaoDao.findAll(intencao.getId(), null);
		for (TipoRespostaIntencao resp : respostas) {
			tipoRespostaIntencaoDao.remove(resp);
		}
		
		for (Pergunta pergunta : intencao.getPerguntas()) {
		    perguntaDao.remove(pergunta);
		}
		
		intencaoDao.remove(intencao);
	}

	private List<MensagemNegocio> criarMensagemErroFluxo(Intencao i, List<Fluxo> fluxos) {
		List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
		MensagemNegocio msg = new MensagemNegocio();
		msg.setTextoMensagem("Não é permitida a exclusão da intenção "
				+ i.getNome() +", pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
		mensagens.add(msg);
		Set<String> intencoes = removerNomesRepetidosFluxos(fluxos);
		for(String nomeInt: intencoes){
			msg = new MensagemNegocio();
			msg.setTextoMensagem("- " + nomeInt);
			mensagens.add(msg);
		}
		return mensagens;
	}

	private Set<String> removerNomesRepetidosFluxos(List<Fluxo> fluxos) {
		Set<String> nomes = new HashSet<String>();
		for(Fluxo f: fluxos){
			if(f.getFluxoPai() != null && f.getFluxoPai().getIntencao() != null){
//				System.out.println("NomeI:"+f.getFluxoPai().getIntencao().getNome());
				nomes.add(f.getFluxoPai().getIntencao().getNome());
			}
		}
		return nomes;
	}
	
	public List<InstrucaoNormativa> listarIns(Integer idItencao) {
		return instrucaoNormativaDao.findByIntencao(idItencao);
	}

	public List<InstrucaoNormativaVO> listarInsVO(Intencao intencao) {
		return instrucaoNormativaManager.criarListaINVO(instrucaoNormativaDao.findByIntencao(intencao.getId()));
	}

	public void removerInBase(InstrucaoNormativa instrucao)
			throws NegocioException {
		InstrucaoNormativa instrucaoNormativa = instrucaoNormativaDao
				.findByInstrucaoNormativa(instrucao.getId());
		if(instrucaoNormativa != null) {
			instrucaoNormativaDao.remove(instrucaoNormativa);
		}

	}
	public FluxoVO buscaFluxo(Integer idIntencao){
		return fluxoManager.fluxo(idIntencao);
	}
	
	public Fluxo buscaPerguntaFluxo(Integer idIntencao){
		for(Fluxo f: fluxoManager.listarPorIntencao(idIntencao)){
			if(f.getFluxoPai() == null){
				return f;
			}
		}
		
		return null;
	}
	
	public void removerFluxo(List<FluxoItemVO> itensRemover, int idFluxo){
	    if (idFluxo == 0 && itensRemover != null ) {
	        for(FluxoItemVO f : itensRemover){
	            fluxoManager.excluir(f.getId());
	        }
	    } else {
	        fluxoManager.excluir(idFluxo);
	    }
	}
	
	private String getHashNuvem(String hashNuvem){
		if( hashNuvem == null || hashNuvem.trim().length() == 0 ){
			
			while( true){
				hashNuvem = UUID.randomUUID().toString();
				if(!intencaoDao.possuiHashNuvem(hashNuvem)){
					break;
				}
			}
		}
		return hashNuvem;
	}
	
	public void migrar(MigrarIntencaoVO mi  ) throws NegocioException {
		
		if (mi.getClassificador() == null){
			throw new NegocioException("Selecione um Classificador.");
		}
		
		if (mi.getListaIntencao().isEmpty()){
			throw new NegocioException("Selecione uma ou mais intenções.");
		}
		
		List<Intencao> listaIntencaoClassificador = intencaoDao.findByClassificador(mi.getClassificador().getId());
		List<String> nomeIguaisErro = new ArrayList<String>();
		List<String> perguntaErro = new ArrayList<String>();
		List<String> listaAmbigua = new ArrayList<String>();
		
		List<ApresentarErroIntencaoFluxo> listaIntecaoFluxoErro = new ArrayList<IntencaoManager.ApresentarErroIntencaoFluxo>();
		
		List<Pergunta> listaPerguntas = perguntaDao.findIdClassificador(mi.getClassificador().getId());
		
		for (Intencao i :mi.getListaIntencao()){
			
			List<Fluxo> fluxos = fluxoManager.listarPorIntencao(i.getId());
			
			ApresentarErroIntencaoFluxo apresentarErroIntencaoFluxo = new ApresentarErroIntencaoFluxo(i, new ArrayList<Fluxo>());
			
			for(Fluxo f: fluxos){
				if(f.getAgrupador()!=null && f.getFluxoPai() != null){
					apresentarErroIntencaoFluxo.getListaFluxos().add(f);
				}
			}
			
			if (!apresentarErroIntencaoFluxo.getListaFluxos().isEmpty()){
				listaIntecaoFluxoErro.add(apresentarErroIntencaoFluxo);
			}
			
			if (i.getNecessitaDesambiguacao() != null && i.getNecessitaDesambiguacao()){
				listaAmbigua.add(i.getNome());
			}
			
			for (Intencao iC: listaIntencaoClassificador){
				if (iC.getNome().equals(i.getNome()) ){
					nomeIguaisErro.add(iC.getNome());
				}
			};
			
			List<Pergunta> listaIdIntencao = perguntaDao.findByIntencao(i.getId());
			
			for(Pergunta p: listaIdIntencao){
				for (Pergunta p1 : listaPerguntas){
					if (p.getPergunta().equals(p1.getPergunta())){
						perguntaErro.add(i.getNome());
					}
				}
			}
			
		};
		
		
		if (!listaAmbigua.isEmpty()){
			if (listaAmbigua.size() == 1){
				throw new NegocioException(criarMensagemErro("Não foi possível migrar a intenção abaixo, pois a mesma é ambígua:",listaAmbigua));
			}else {
				throw new NegocioException(criarMensagemErro("Não foi possível migrar as intenções abaixo, pois as mesmas são ambíguas:",listaAmbigua));
			}
		}
		
		if (!nomeIguaisErro.isEmpty()){
			if(nomeIguaisErro.size() == 1){
				throw new NegocioException(criarMensagemErro("Já existe no corpus a intenção:" ,nomeIguaisErro));
			}else {
				throw new NegocioException(criarMensagemErro("Já existem no corpus as intenções:" ,nomeIguaisErro));
			}
		}
		
		if (!perguntaErro.isEmpty()){
			if(perguntaErro.size() == 1){
				throw new NegocioException(criarMensagemErro("No Classificador selecionado já existe a mesma pergunta da seguinte intenção: ", perguntaErro));
			}else {
				throw new NegocioException(criarMensagemErro("No Classificador selecionado já existem as mesmas perguntas das seguintes intenções: ", perguntaErro));
			}
			
		}
		
		if (!listaIntecaoFluxoErro.isEmpty()){
			throw new NegocioException(criarMensagemErroIntencaoFluxo(listaIntecaoFluxoErro ));
		}			
		
		for (Intencao i :mi.getListaIntencao()){
			i.setClassificador(mi.getClassificador());
			intencaoDao.persist(i);
		}
		
		intencaoDao.flush();

	}
	
	protected class ApresentarErroIntencaoFluxo{
		private Intencao intencao;
		private List<Fluxo> listaFluxos= new ArrayList<Fluxo>();
		
		public ApresentarErroIntencaoFluxo(Intencao intencao,
				List<Fluxo> listaFluxos) {
			super();
			this.intencao = intencao;
			this.listaFluxos = listaFluxos;
		}
		
		public Intencao getIntencao() {
			return intencao;
		}
		public void setIntencao(Intencao intencao) {
			this.intencao = intencao;
		}
		public List<Fluxo> getListaFluxos() {
			return listaFluxos;
		}
		public void setListaFluxos(List<Fluxo> listaFluxos) {
			this.listaFluxos = listaFluxos;
		}
	}
	
	private List<MensagemNegocio> criarMensagemErroIntencaoFluxo(List<ApresentarErroIntencaoFluxo> listaIntecaoFluxoErro) {
		List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
		
		for (ApresentarErroIntencaoFluxo erro :listaIntecaoFluxoErro){
			MensagemNegocio msg = new MensagemNegocio();
			msg.setTextoMensagem("Não é permitida a migração da(s) intenção(ões): "+erro.getIntencao().getNome()+", pois a mesma está vinculada à(s) seguinte(s) intenção(ões):");
			mensagens.add(msg);
			Set<String> entidades = removerNomesRepetidosIntencaoFluxos(erro.getListaFluxos());
			for(String e: entidades){
				msg = new MensagemNegocio();
				msg.setTextoMensagem("- " + e );
				mensagens.add(msg);
			}
		}
		return mensagens;
	}

	private Set<String> removerNomesRepetidosIntencaoFluxos(List<Fluxo> fluxos) {
		Set<String> nomes = new HashSet<String>();
		
		for(Fluxo f: fluxos){
			if(f.getFluxoPai() != null && f.getFluxoPai().getIntencao() != null){
				System.out.println("NomeI: "+f.getFluxoPai().getIntencao().getNome());
				nomes.add(f.getFluxoPai().getIntencao().getNome());
			}
		}
		return nomes;
	}
	
	
	private List<MensagemNegocio> criarMensagemErro(String mensagemErro, List<String> listaErro) {
		List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
		MensagemNegocio msg = new MensagemNegocio();
		msg.setTextoMensagem(mensagemErro);
		mensagens.add(msg);
		
		Set<String> nomes = removerNomesRepetidos(listaErro);
		for(String i: nomes){
			msg = new MensagemNegocio();
		    msg.setTextoMensagem("- " + i );
		    mensagens.add(msg);
		}
		
		return mensagens;
	}
	
	private Set<String> removerNomesRepetidos(List<String> listaErro) {
		Set<String> nomes = new HashSet<String>();
		for(String l: listaErro){
			nomes.add(l);
		}
		return nomes;
	}


	public Paginacao<IntencaoVO> findBuscaAvancada(BuscaAvancadaIntencaoVO buscaAvancadaIntencao,
			Paginacao<Intencao> paginacao) {
		List<Integer> idsIntencao = new ArrayList<Integer>();
		if (buscaAvancadaIntencao.getCheckExemplos()) {			
			idsIntencao = listarIdsIntencaoPergunta(buscaAvancadaIntencao);
		}
		Paginacao<Intencao> paginacaoOriginal = intencaoDao.findBuscaAvancada(buscaAvancadaIntencao, paginacao,idsIntencao);
		return converterParaIntencaoVO(paginacaoOriginal);
	}
	
	public List<Integer> listarIdsIntencaoPergunta(BuscaAvancadaIntencaoVO buscaAvancadaIntencao) {
		List<Pergunta> perguntas = new ArrayList<Pergunta>();
		List<Integer> idsIntencao = new ArrayList<Integer>();
		
		perguntas = perguntaDao.findIdClassificadorLikeNome(buscaAvancadaIntencao.getIdClassificador(), buscaAvancadaIntencao.getBusca());
		for (Pergunta pergunta : perguntas) {
			Intencao intencao = pergunta.getIntencao();
			if (!idsIntencao.contains(intencao.getId())) {
				idsIntencao.add(intencao.getId());
			}
			
		}
		
		return idsIntencao;
	}
	
	public List<IntencaoVersaoV1> listarVersao(Integer idClassificador) {
		List<Intencao> intencoes = intencaoDao.listarVersao(idClassificador);
		return IntencaoVersaoV1.parseToVersao(intencoes);
	}
	
	public void limparPorClassificador(Integer idClassificador) {
	    List<Intencao> intencoes = intencaoDao.listarVersao(idClassificador);
	    int size = intencoes.size();
	    int i = 0;
	    // perguntaRevisaoManager.removerVinculoIntencaoPorClassificador(idClassificador);
		for (Intencao intencao : intencoes) {
		    String msg = "Removendo intencao " + ++i + "/" + size; 
		    cacheProgresso.atualizar("RECOVERY_" + idClassificador + "_PROGRESSO", 1, msg);
			excluir(intencao, false);
		}
	}
	
}
