package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.TipoCondicaoDao;
import br.com.bb.gearq.c4coleta.model.TipoCondicao;

@Name("tipoCondicaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class TipoCondicaoManager {
	
	@In(create= true)
	private TipoCondicaoDao tipoCondicaoDao;

	public List<TipoCondicao> listar() {
		return tipoCondicaoDao.findAll();
	}

	

}
