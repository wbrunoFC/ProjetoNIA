package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.TipoRespostaDao;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

@Name("tipoRespostaManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class TipoRespostaManager {

    @In(create = true)
    private TipoRespostaDao tipoRespostaDao;

    public TipoResposta obter(Integer id) {
        return tipoRespostaDao.findById(id);
    }

    public TipoResposta obterPadrao() {
        return tipoRespostaDao.findById(1);
    }

    public TipoResposta salvar(TipoResposta tipoResposta) {
        return tipoRespostaDao.persist(tipoResposta);
    }

    public Paginacao<TipoResposta> pesquisar(Paginacao<TipoResposta> paginacao, String nome) {
        return tipoRespostaDao.findAll(paginacao, nome);
    }

    public void excluir(Integer id) {
        TipoResposta tipoResposta = tipoRespostaDao.findById(id);
        tipoRespostaDao.remove(tipoResposta);
    }

}
