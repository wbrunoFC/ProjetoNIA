package br.com.bb.gearq.c4coleta.manager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.AcionamentoIntencaoDiaDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.ParametroAlertaDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.ParametroAlerta;

@Name("processarCriseManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ProcessarCriseManager {

	@In(create = true)
	private ParametroAlertaDao parametroAlertaDao;	
	
	@In(create = true)
	private ClassificadorDao classificadorDao;

	@In(create = true)
	private AcionamentoIntencaoDiaDao acionamentoIntencaoDiaDao;
	
	public void processarCrise (){
	
		List<Classificador> listaClass = classificadorDao.findAll();
		
		for(Classificador c:listaClass){
			 
			ParametroAlerta pA = parametroAlertaDao.buscaItemEdicao(c.getId());
			
			if(pA.getId() != null && pA.getId() > 0){
				acionamentoIntencaoDiaDao.QtdIntencaoAcionadas(c.getId(), pA.getQtDias());
			}
					
		}
		
		
	}
}
