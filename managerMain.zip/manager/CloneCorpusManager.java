package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.EntidadeDao;
import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.AgruparEntidadeSinonimos;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Entidade;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativa;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.Sinonimo;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.vo.FluxoItemVO;
import br.com.bb.gearq.c4coleta.vo.FluxoVO;
import br.com.bb.gearq.c4coleta.vo.InstrucaoNormativaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

@Name("cloneCorpusManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class CloneCorpusManager {

	@In(create = true)
	private IntencaoDao intencaoDao;
	
	@In(create = true)
	private EntidadeDao entidadeDao;

	@In(create = true)
	private IntencaoManager intencaoManager;
	
	@In(create = true)
	private EntidadeManager entidadeManager;

	@In(create = true)
	private ClassificadorDao classificadorDao;

	@In(create = true)
	private InstrucaoNormativaDao instrucaoNormativaDao;

	@In(create = true)
	private TipoRespostaIntencaoDao tipoRespostaIntencaoDao; 

	@In(create = true)
	private PerguntaDao perguntaDao;

	public void clonarCorpus(Integer idClassificadorOrigem,
			Integer idClassificadorDestino, Integer ordem, Integer pagina) {
		
		// clonar entidade
		if( ordem == 0 ){
			clonarEntidades(idClassificadorOrigem, idClassificadorDestino);
		}
		
		//clonar intencao
		if( ordem == 1 ){
			clonarIntencoes(idClassificadorOrigem, idClassificadorDestino, null, ordem, pagina, false);
		}
		
		//clonar intencao ambigua
		if( ordem == 2 ){
			Paginacao<Entidade> paginacao = new Paginacao<Entidade>();
			paginacao.setRegistrosPagina(Integer.MAX_VALUE);
			paginacao = entidadeManager.listarEntidades(idClassificadorDestino, null, paginacao, 0, true);
			clonarIntencoes(idClassificadorOrigem, idClassificadorDestino, paginacao.getListaPaginada(), ordem, pagina, false);
		}
		
		// cadastrar respostas das intenções
		if( ordem == 3 ){
			clonarIntencoes(idClassificadorOrigem, idClassificadorDestino, null, ordem, pagina, true);
		}
		
		System.out.println("TERMINOU");
	}
	
	private void clonarEntidades(Integer idClassificadorOrigem,
			Integer idClassificadorDestino){
		System.out.println(" ################# CADASTRAR ENTIDADES ");
		Paginacao<Entidade> paginacao = new Paginacao<Entidade>();
		paginacao.setRegistrosPagina(Integer.MAX_VALUE);
		paginacao = entidadeManager.listarEntidades(idClassificadorOrigem, null, paginacao, 0, true);
		if( paginacao.getListaPaginada() != null  ){
			Classificador classificadorDestino = classificadorDao.findById(idClassificadorDestino);
			for( Entidade entidadeOrigem : paginacao.getListaPaginada() ){
				Entidade entDestino = (Entidade) entidadeOrigem.clone();
				entDestino.setId(null);
				entDestino.setClassificador(classificadorDestino);
				
				//agrupadores
				entDestino.setAgrupadores(new ArrayList<AgruparEntidadeSinonimos>());
				if( entidadeOrigem.getAgrupadores() != null ){
					for( AgruparEntidadeSinonimos grupOrigem : entidadeOrigem.getAgrupadores() ){
						
						AgruparEntidadeSinonimos  grupDestino = (AgruparEntidadeSinonimos) grupOrigem.clone();
						grupDestino.setEntidade(entidadeOrigem);
						grupDestino.setId(null);
						
						// sinonimos
						grupDestino.setSinonimos(new ArrayList<Sinonimo>());
						List<Sinonimo> sinonimosOrigem = entidadeManager.listarSinonimos(grupOrigem);
						
						if( sinonimosOrigem != null ){
							for( Sinonimo sinOrigem : sinonimosOrigem ){
								Sinonimo sinDestino = (Sinonimo) sinOrigem.clone();
								sinDestino.setAgruparSinonimo(grupDestino);
								sinDestino.setId(null);
								grupDestino.getSinonimos().add(sinDestino);
							}
						}
						
						entDestino.getAgrupadores().add(grupDestino);
						
					}
				}
				System.out.println(entDestino.getNome());
				entidadeManager.salvar(idClassificadorDestino, entDestino);
			}
		}
		
	}
	
	private void clonarIntencoes(Integer idClassificadorOrigem,
			Integer idClassificadorDestino, List<Entidade> entidadesDestino, Integer ordem, Integer pagina, boolean respostas){

		//List<Intencao> intencoesOrigem = intencaoDao.findByClassificador(idClassificadorOrigem);
		
		Paginacao<Intencao> paginacao = new Paginacao<Intencao>();
		paginacao.setRegistrosPagina(50);
		if( pagina != null && pagina > 1 ) {
			paginacao.setPaginaAtual(pagina);
		}
		paginacao.setTotalRegistros(Long.MAX_VALUE);
		
		//intencoesOrigem = getIntencoesClone(intencoesOrigem);
		Paginacao<Intencao> paginacaoIntencao = intencaoDao.findIntencao(paginacao, idClassificadorOrigem, null);
        List<Intencao> intencoesOrigem = paginacaoIntencao.getListaPaginada();

		//List<Intencao> intencoesDestino = intencaoDao.findByClassificador(idClassificadorDestino);
        Paginacao<Intencao> paginacaoDestino = intencaoDao.findIntencao(paginacao, idClassificadorDestino, null);
		List<Intencao> intencoesDestino = paginacaoDestino.getListaPaginada();

		if (intencoesOrigem != null && paginacaoDestino != null) {
			
			if( ordem == 1 ){
				// CADASTRAR INTENCOES
				System.out.println(" ################# CADASTRAR INTENÇÔES ");
				for (Intencao intOrigem : intencoesOrigem) {
					
					//if( intOrigem.getNome().equalsIgnoreCase("HD_TEC_MDS_ERRO") ){
						Intencao itnDestino = null;
						for (Intencao destino : intencoesDestino) {
							if (intOrigem.getNome().equals(destino.getNome())) {
								itnDestino = destino;
								break;
							}
						}
						
						if( !respostas ) {
							Intencao intAdd = cloneIntencao(intOrigem, itnDestino,
									idClassificadorDestino);
							System.out.println(intAdd.getNome());
							intencaoDao.persist(intAdd);
							intencaoManager.salvar(idClassificadorDestino, intAdd);
						}else {
						    /**
						     * @author Bruno Costa - c1312334
						     * Em conversa com o Starlone, este bloco ELSE está morto, devido o campo boolean estar com o valor falso.
						     * Não será possível testar com Integer ordem = 3, pois não passará na condição do IF da linha 158.
						     */
							List<TipoRespostaIntencao> respostasOrigem = tipoRespostaIntencaoDao.findAll(intOrigem.getId(), null);
							List<TipoRespostaIntencao> respostasDestino = tipoRespostaIntencaoDao.findAll(itnDestino.getId(), null);
								for (TipoRespostaIntencao respOrigem : respostasOrigem) {
									
									boolean possuiResposta = false;
									
									for (TipoRespostaIntencao respDestino : respostasDestino) {
										if (respOrigem.getTipoResposta().getId().equals(respDestino.getTipoResposta().getId())) {
											possuiResposta = true;
											respDestino.setTextoResposta(respOrigem.getTextoResposta());
											tipoRespostaIntencaoDao.persist(respDestino);
										}
									}
									
									if( !possuiResposta  ) {
										
										TipoRespostaIntencao respDestino = (TipoRespostaIntencao) respOrigem.clone();
										respDestino.getId().setIdIntencao(itnDestino.getId());
										tipoRespostaIntencaoDao.persist(respDestino);
										
									}
								}

						}
					
				}
			}

			if( ordem == 2 ){
				// CADASTRAR FLUXO
				System.out.println(" ################# CADASTRAR FLUXO AMBIGUA ");
				for (Intencao origem : intencoesOrigem) {
					if (origem.getNecessitaDesambiguacao()) {
						Intencao destino = recuparIntencao(origem.getNome(),
								idClassificadorDestino);
						if (destino != null) {
							FluxoVO flxDestino = intencaoManager.buscaFluxo(destino
									.getId());
							if (flxDestino == null || flxDestino.getId() == 0){
								System.out.println("#### INTENCAO AMBIGUA: "+ origem.getNome());
								FluxoVO flxOrigem = intencaoManager.buscaFluxo(origem.getId());
								flxOrigem.setId(0);
								flxOrigem.setNode_id(0);
								flxOrigem.setHashNuvem(null);
								if (flxOrigem.getFluxos() != null
										&& flxOrigem.getFluxos().size() > 0) {
									atualizaFluxo(flxOrigem.getFluxos(),
											idClassificadorDestino, entidadesDestino);
								}
								destino.setNecessitaDesambiguacao(true);
								intencaoManager.cadastrarFluxo(destino, flxOrigem);
							}
						}
						
					}
				}
			}
		}
	}
	

	private void atualizaFluxo(List<FluxoItemVO> filhos,
			Integer idClassificadorDestino, List<Entidade> entidadesDestino) {
		for (FluxoItemVO item : filhos) {
			if (item.getIntencaoAcionada() != null) {
				Intencao jump = recuparIntencao(item.getIntencaoAcionada().getNome(), idClassificadorDestino);
				if (jump == null) {
					jump = cloneIntencao(item.getIntencaoAcionada(), null,idClassificadorDestino);
					intencaoDao.persist(jump);
					intencaoManager.salvar(idClassificadorDestino, jump);
				}
				item.setIntencaoAcionada(jump);
			}
			item.setId(0);
			item.setNode_id(0);
			
			
			if( item.getAgrupador() != null ){
				item.getAgrupador().setEntidade(entidadeDao.findById(item.getAgrupador().getEntidade().getId()));
				if( entidadesDestino != null ){
					for( Entidade entidade : entidadesDestino ){
						if( entidade.getNome().equals(item.getAgrupador().getEntidade().getNome()) ){
								if( item.getAgrupador().getNome() != null && 
								        item.getAgrupador()
								        .getNome()
								        .trim()
								        .length() > 0 ){
									for( AgruparEntidadeSinonimos agrupador : entidade.getAgrupadores() ){
										if( item.getAgrupador().getNome()
										        .endsWith(agrupador.getNome()) ){
											item.setAgrupador(agrupador);
										}
									}
							}else{
								AgruparEntidadeSinonimos agrupador = new AgruparEntidadeSinonimos();
								agrupador.setEntidade(entidade);
								item.setAgrupador(agrupador);
							}
						}
					}
				}
			}
			
			if (item.getBlocoFluxos() != null
					&& item.getBlocoFluxos().size() > 0) {
				atualizaFluxo(item.getBlocoFluxos(), idClassificadorDestino, entidadesDestino);
			}
			
			
			
			
		}
	}
	

	private Intencao recuparIntencao(String nome, Integer idClassificadorDestino) {
		List<Intencao> intencoesDestino = intencaoDao.findByNomeIntencao(nome,
				idClassificadorDestino);
		return intencoesDestino != null && intencoesDestino.size() > 0 ? intencoesDestino
				.get(0) : null;
	}

	private Intencao cloneIntencao(Intencao intencao, Intencao clone,
			Integer idCLassificador) {
		if (clone == null ) {
			clone = (Intencao) intencao.clone();
			clone.setId(null);
			clone.setHashNuvem(null);
		}else{
			clone.setDescricao(intencao.getDescricao());
			clone.setNecessitaDesambiguacao(intencao.getNecessitaDesambiguacao());
			clone.setNome(intencao.getNome());
			clone.setPerguntaCanonica(intencao.getPerguntaCanonica());
			clone.setStatus(intencao.getStatus());
		}
		Classificador classificador = classificadorDao
				.findById(idCLassificador);
		clone.setClassificador(classificador);

		// recuperar instruções normativas
		clone.setiNs(new ArrayList<InstrucaoNormativa>());
		List<InstrucaoNormativa> INs = instrucaoNormativaDao
				.findByIntencao(intencao.getId());
		List<InstrucaoNormativa> INsClone = new ArrayList<InstrucaoNormativa>();
		if (clone.getId() != null) {
			INsClone = instrucaoNormativaDao.findByIntencao(clone.getId());
		}
		if (INs != null) {
			for (InstrucaoNormativa in : INs) {
				boolean possui = false;
				for (InstrucaoNormativa inClone : INsClone) {
					if (in.getNumeroIN() != null
							&& in.getNumeroIN().equalsIgnoreCase(
									inClone.getNumeroIN())) {
						possui = true;
						break;
					}
				}
				if (!possui) {
					InstrucaoNormativa inClone = (InstrucaoNormativa) in
							.clone();
					inClone.setId(null);
					inClone.setIntencao(clone);
					clone.getiNs().add(inClone);
				}
			}
		}

		// recuperar respostas
		clone.setRespostas(new ArrayList<TipoRespostaIntencao>());
		List<TipoRespostaIntencao> respostas = tipoRespostaIntencaoDao.findAll(
				intencao.getId(), null);
		List<TipoRespostaIntencao> respostasClone = new ArrayList<TipoRespostaIntencao>();
		if (clone.getId() != null) {
			respostasClone = tipoRespostaIntencaoDao.findAll(clone.getId(), null);
		}
		if (respostas != null) {

			for (TipoRespostaIntencao resp : respostas) {

				boolean possui = false;
				for (TipoRespostaIntencao respClone : respostasClone) {
					if (resp.getTipoResposta().getId().equals(respClone.getTipoResposta().getId())) {
						respClone.setTextoResposta(resp.getTextoResposta());
						clone.getRespostas().add(respClone);
						possui = true;
						break;
					}
				}
				if (!possui) {
					TipoRespostaIntencao objClone = (TipoRespostaIntencao) resp.clone();
					objClone.getId().setIdIntencao(null);
					clone.getRespostas().add(objClone);
				}
			}
		}

		// recuperar respostas
		clone.setPerguntas(new ArrayList<Pergunta>());
		List<Pergunta> perguntas = perguntaDao.findByIntencao(intencao.getId());
		List<Pergunta> perguntasClone = new ArrayList<Pergunta>();
		
		if( clone.getId() != null ){
			perguntasClone = perguntaDao.findByIntencao(clone.getId());
		}
		
		if (perguntas != null) {
			for (Pergunta pergunta : perguntas) {
				
				boolean possui = false;
				
				for (Pergunta perguntaClone : perguntasClone) {
					if( pergunta.getPergunta() != null && pergunta.getPergunta().equalsIgnoreCase(perguntaClone.getPergunta()) ){
						possui = true;
					}
				}
				
				if( !possui ){
					Pergunta objClone = (Pergunta) pergunta.clone();
					objClone.setId(null);
					objClone.setIntencao(clone);
					clone.getPerguntas().add(objClone);
				}
			}
		}
		return clone;
	}

}
