package br.com.bb.gearq.c4coleta.manager;



import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.InstrucaoNormativaDao;
import br.com.bb.gearq.c4coleta.model.InstrucaoNormativa;
import br.com.bb.gearq.c4coleta.vo.InstrucaoNormativaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

@Name("instrucaoNormativaManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class InstrucaoNormativaManager {

	@In(create = true)
	private InstrucaoNormativaDao instrucaoNormativaDao;

	public Paginacao<InstrucaoNormativa> listarPorClassificador(int idClassificador,
			String filtroNomeIntencao, Paginacao<InstrucaoNormativa> paginacao) {
		return instrucaoNormativaDao.findByClassificadorNativo(idClassificador,
				filtroNomeIntencao, paginacao);
	}

	public InstrucaoNormativa criarIN(InstrucaoNormativaVO vo) {
		InstrucaoNormativa in = new InstrucaoNormativa();
		in.setId(vo.getId());
		in.setIdIntencao(vo.getIdIntencao());
		in.setIntencao(vo.getIntencao());
		in.setNumeroIN(vo.getNumeroIN());
		in.setVrsAuxiliar(vo.getVrsAuxiliar());
		in.setVrsNormativa(vo.getVrsNormativa());
		in.setVrsProcedimento(vo.getVrsProcedimento());
		in.setNomeIntencao(vo.getNomeIntencao());
		in.setStatus(vo.getStatus());
		in.setEditarCampo(vo.isEditarCampo());
		return in;
	}
	
	public List<InstrucaoNormativa> criarListaIN(List<InstrucaoNormativaVO> listaVO) {
		List<InstrucaoNormativa> listaIN = new ArrayList<InstrucaoNormativa>();
		for (InstrucaoNormativaVO vo: listaVO) {
			listaIN.add(criarIN(vo));
		}
		return listaIN;
	}

	public InstrucaoNormativaVO criarINVO(InstrucaoNormativa in) {
		InstrucaoNormativaVO vo = new InstrucaoNormativaVO();
		vo.setId(in.getId());
		vo.setIdIntencao(in.getIdIntencao());
		vo.setIntencao(in.getIntencao());
		vo.setNumeroIN(in.getNumeroIN());
		vo.setVrsAuxiliar(in.getVrsAuxiliar());
		vo.setVrsNormativa(in.getVrsNormativa());
		vo.setVrsProcedimento(in.getVrsProcedimento());
		vo.setNomeIntencao(in.getNomeIntencao());
		vo.setStatus(in.getStatus());
		vo.setEditarCampo(in.isEditarCampo());
		vo.setInIntencao(true);
		return vo;
	}
	
	public List<InstrucaoNormativaVO> criarListaINVO(List<InstrucaoNormativa> listaIN) {
		List<InstrucaoNormativaVO> listaVO = new ArrayList<InstrucaoNormativaVO>();
		for (InstrucaoNormativa vo: listaIN) {
			listaVO.add(criarINVO(vo));
		}
		return listaVO;
	}
	
}
