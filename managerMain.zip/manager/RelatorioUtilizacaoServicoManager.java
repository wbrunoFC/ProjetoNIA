package br.com.bb.gearq.c4coleta.manager;
import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.ServicoNlcDao;
import br.com.bb.gearq.c4coleta.dao.ServicosCognitivosDao;
import br.com.bb.gearq.c4coleta.dao.ValoresServicosCognitivosDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.ServicoNlc;
import br.com.bb.gearq.c4coleta.model.ServicosCognitivos;
import br.com.bb.gearq.c4coleta.vo.FiltrosUtilizacaoServicoVO;
import br.com.bb.gearq.c4coleta.vo.UtilizacaoServicosCognitivosVO;

@Name("relatorioUtilizacaoServicoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class RelatorioUtilizacaoServicoManager {

	@In(create = true)
	private ClassificadorDao classificadorDao;

	@In(create = true)
	private ServicoNlcDao servicoNlcDao;
	
	@In(create = true)
	private NuvemWatsonDao nuvemWatsonDao;

	@In(create = true)
	private ServicosCognitivosDao servicosCognitivosDao;

	@In(create = true)
	private ValoresServicosCognitivosDao valoresServicosCognitivosDao;
	
	
	
	public List<ServicoNlc> serviçosNuvem (){		
		List<ServicoNlc> listaServico = servicoNlcDao.findByServicoNuvem();	
		return listaServico;
	}

	public List<Classificador> classificadorNuvem (int idServico){
		List<Classificador> listaServico = new ArrayList<Classificador>();
		if(idServico > 0){
			listaServico = classificadorDao.classificadorNuvemServico(idServico);
		}else{
			listaServico = classificadorDao.classificadorNuvem();
		}
		return listaServico;
	}
	
	public List<NuvemWatson> nuvemCredencial(int idClassificador){
		
		List<NuvemWatson> listaRetorno = new ArrayList<NuvemWatson>();
		if(idClassificador > 0){
			listaRetorno = nuvemWatsonDao.findByClassificador(idClassificador);			
		}else{			
			listaRetorno = nuvemWatsonDao.findCredenciaisNuvem();		
		}
		
		return listaRetorno;
	}
	
	
	public List<ServicosCognitivos> listaServicosCognitivos(){
		return servicosCognitivosDao.findAll();
	}
	
	public UtilizacaoServicosCognitivosVO pesquisa(FiltrosUtilizacaoServicoVO filtro){
		UtilizacaoServicosCognitivosVO uti = new UtilizacaoServicosCognitivosVO();
		uti.setDadosPeriodo(nuvemWatsonDao.findUtilizacaoServicoCognitivoDadosPeriodo(filtro));
		uti.setConsolidadoDemandante(nuvemWatsonDao.findUtilizacaoServicoCognitivoConsolidadoDemandante(filtro));
		uti.setResumoPeriodo(nuvemWatsonDao.findUtilizacaoServicoCognitivoResumoPeriodo(filtro));
		return uti;
	}
	
}
