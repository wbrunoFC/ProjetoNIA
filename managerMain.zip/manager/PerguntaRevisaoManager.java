package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.ControleIdPerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.vo.PerguntaLogVO;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("perguntaRevisaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class PerguntaRevisaoManager {

    private Logger logger = LogManager.getLogger(PerguntaRevisaoManager.class);

    @In(create = true)
    private FeedbackManager feedbackManager;

    @In(create = true)
    private LogNiaInfraManager logNiaInfraManager;

    @In(create = true)
    private ControleIdPerguntaRevisaoManager controleIdPerguntaRevisaoManager;
    
    @In(create = true)
    private ClassificadorManager classificadorManager;
    
    @In(create = true)
    private PerguntaRevisaoDao perguntaRevisaoDao;
    
    @In(create = true)
    private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;

    public void coletarLog() {
        logger.info("Inicio - Processo de coleta de perguntas para revisão iniciado");
        long start = System.currentTimeMillis();

        // buscar a ultima versão do controle.
        ControleIdPerguntaRevisao controle = controleIdPerguntaRevisaoManager.getControlePerguntaRevisao();

        controleIdPerguntaRevisaoManager.incrementar(controle, 4000);

        int idInicio = controle.getIdInicioPerguntaRevisao();
        int idFim = controle.getIdFimPerguntaRevisao();

        logger.info("Executando de " + idInicio + " até " + idFim);

        executar(controle, idInicio, idFim);

        long elapsed = System.currentTimeMillis() - start;
        logger.info("Fim - Processo de coleta de perguntas para revisão finalizado.");
        logger.info("Tempo: ms: " + elapsed + ", em sg: " + elapsed / 1000F + ", em min: " + elapsed / 1000F / 60F);
    }

    private void executar(ControleIdPerguntaRevisao controle, int idInicio, int idFim) {
        int ultimoLog = idInicio;
        int cont = 0;
        Map<Integer, Classificador> classificadores = new HashMap<Integer, Classificador>();
        List<PerguntaLogVO> logs = logNiaInfraManager.findLogPerguntas(idInicio, idFim);
        for (int i = 0; i < logs.size(); i++) {
            PerguntaLogVO log = logs.get(i);
            logger.info(++cont + " - Coletando: " + log.getId() + " input: " + log.getInput() + " quantidade: " + log.getQuantidade());
            String input = log.getInput();
            if (input != null && !input.trim().isEmpty()) {
                Classificador classificador = getClassificador(classificadores, log.getIdClassificador());
                feedbackManager.coletar(input, classificador, log.getChave(), false, log.getJson(), log.getQuantidade().intValue(), log.getHasExemplo(), log.getDataHora());
            }
            ultimoLog = log.getId();
        }
        persistirControle(controle, ultimoLog);
    }
    
    private Classificador getClassificador(Map<Integer, Classificador> classificadores, Integer idClassificador) {
        if (idClassificador != null) {
            Classificador classificador = classificadores.get(idClassificador);
            if (classificador == null) {
                classificador = classificadorManager.obter(idClassificador);
                classificadores.put(idClassificador, classificador);
            }
            return classificador;
            
        }
        return null;
        
    }

    private void persistirControle(ControleIdPerguntaRevisao controle, int ultimoLog) {
        logger.info("Persistindo controle, ultimo_id: " + ultimoLog);
        controleIdPerguntaRevisaoManager.atualizarControle(controle, ultimoLog);
        controleIdPerguntaRevisaoManager.salvar(controle);
    }

    public void removerVinculoIntencaoPorClassificador(Integer idClassificador) {
        perguntaRevisaoIntencaoDao.removerVinculoIntencaoPorClassificador(idClassificador);
        perguntaRevisaoDao.removerVinculoIntencaoPorClassificador(idClassificador);
    }
    

}

