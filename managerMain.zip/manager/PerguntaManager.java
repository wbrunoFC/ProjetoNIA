package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.sos.infra.MensagemNegocio;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("perguntaManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class PerguntaManager {
	
	@In(create = true)
	private ClassificadorDao classificadorDao;

	@In(create = true)
	private IntencaoDao intencaoDao;
	
	@In(create = true)
	private PerguntaDao perguntaDao;
	
	public void migrarExemplos(List<Pergunta> perguntas, int idClassificador) {
		
		if (perguntas.isEmpty()){
			throw new NegocioException("Selecione uma ou mais Perguntas.");
		}
		
		List<String> nomeIguaisErro = new ArrayList<String>();
		List<String> nomeIntencao   = new ArrayList<String>();
		int classificadorIgueal = 0;
		
		for (Pergunta pergunta :perguntas){
			Intencao intencao = pergunta.getIntencao();
			if (intencao == null) {
				intencao = intencaoDao.findById(pergunta.getIdIntencao());				
			}
			if (intencao.getIdClassificador().equals(idClassificador)){
				classificadorIgueal = idClassificador;
				break;
			}
		}
		
		if (classificadorIgueal > 0){
			for (Pergunta p1 :perguntas){
				perguntaDao.persist(p1);
			}
			
			perguntaDao.flush();
			
		}else{ 	
			
			for (Pergunta p :perguntas) {
				Intencao intencao = p.getIntencao();
				if (intencao == null) {
					intencao = intencaoDao.findById(p.getIdIntencao());				
				}
				List<Pergunta> listaIdIPergunta = perguntaDao.findIgual(intencao.getIdClassificador(), p.getPergunta());				
				for (Pergunta p1 : listaIdIPergunta){
					nomeIguaisErro.add(p1.getPergunta());
					nomeIntencao.add(p1.getIntencao().getNome());
				}
			}
		
			if (!nomeIguaisErro.isEmpty()){
				throw new NegocioException(criarMensagemErro("Não é permitido migrar as perguntas listadas abaixo, pois as mesmas já existem no corpus selecionado: " ,nomeIguaisErro));
			}
			
			for (Pergunta p2 :perguntas){
				perguntaDao.persist(p2);
			}
			
			perguntaDao.flush();
		}
	
	}
	
	private List<MensagemNegocio> criarMensagemErro(String mensagemErro, List<String> listaErro) {
		List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
		MensagemNegocio msg = new MensagemNegocio();
		msg.setTextoMensagem(mensagemErro);
		mensagens.add(msg);
		
		Set<String> nomes = removerNomesRepetidos(listaErro);
		for(String i: nomes){
			 msg = new MensagemNegocio();
			 msg.setTextoMensagem("- " + i);
			 mensagens.add(msg);
		}

		return mensagens;
	}
	
	private Set<String> removerNomesRepetidos(List<String> listaErro) {
		Set<String> nomes = new HashSet<String>();
		for(String l: listaErro){
			nomes.add(l);
		}
		return nomes;
	}
	
	public Long obterQuantidadePorIntencao(Integer idIntencao) {
		return perguntaDao.obterQuantidadePorIntencao(idIntencao);
	}

}
