package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.LogNiaInfraDao;
import br.com.bb.gearq.c4coleta.dao.SecaoConversaBotDao;
import br.com.bb.gearq.c4coleta.model.SecaoConversaBot;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.PeriodoDatasVO;
import br.com.bb.gearq.c4coleta.vo.SecaoConversaBotParametrosEntrada;

@Name("secaoConversaBotManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class SecaoConversaBotManager {
	
	@In(create = true)
	private SecaoConversaBotDao secaoConversaBotDao;
	
	@In(create = true)
	private LogNiaInfraDao logNiaInfraDao;
	
	private List<SecaoConversaBot> listaConversasBots = new ArrayList<SecaoConversaBot>();

	public void processarSecaoConversaBot(Date dataConsulta) {
		
		//Consulta na tabela c4gsccaaud.LOG_NIA_INFRA
		listaConversasBots = secaoConversaBotDao.listarSecaoConversaBot(dataConsulta,logNiaInfraDao);
		if (listaConversasBots.size() > 0) {
			// Grava na tabela c4gsccdatabase.SCAO_BOT (id_scao_bot, sg_nuvem, id_conversa, qt_itra, cd_usu, cd_cnl, dt_inc, dt_fim, cd_origem)
			for (SecaoConversaBot secaoConversaBot : listaConversasBots) {
				secaoConversaBotDao.persist(secaoConversaBot);
			}
			
		}
	}
	
	/**
	 * A partir do dia da data informada, sistema gravará as seções na tabela SCAO_BOT, até o último dia do mês informado na data
	 * @param dataConsulta
	 */
	public void processarLegadoSecaoConversaBot(Calendar dataConsulta) {
		iniciarProcessoAtualizarLegado(dataConsulta);
	}
		
	
	private void iniciarProcessoAtualizarLegado(Calendar dataConsulta) {
				
		List<Date> listaDataConsulta = new ArrayList<Date>();
		/*dataConsulta.set(Calendar.YEAR, ano);
		dataConsulta.set(Calendar.MONTH, mes);
		dataConsulta.set(Calendar.DAY_OF_MONTH, dia);*/
		dataConsulta.set(Calendar.HOUR_OF_DAY, 0);
		dataConsulta.set(Calendar.MINUTE, 0);
		dataConsulta.set(Calendar.SECOND, 0);
		listaDataConsulta.add(dataConsulta.getTime());
		
		int b = dataConsulta.get(Calendar.MONTH);
		int mes = dataConsulta.get(Calendar.MONTH); // 0=JAN, 1=FEV, 2=MAR, 3=ABR, 4=MAI, 5=JUN, 6=JUL, 7=AGO, 8=SET, 9=OUT, 10=NOV, 11=DEZ
		int ano = dataConsulta.get(Calendar.YEAR);
		int dia = dataConsulta.get(Calendar.DAY_OF_MONTH);
		
		//int dia = 0;
		while (b == mes) {
			//dia = dataConsulta.get(Calendar.DAY_OF_MONTH);
			if (dataConsulta.get(Calendar.DAY_OF_MONTH) > 1) {
				dataConsulta.add(Calendar.DAY_OF_MONTH, + 1);
			}else {
				dataConsulta.add(Calendar.DAY_OF_MONTH, 1);
			}
			b = dataConsulta.get(Calendar.MONTH);
			if(b == mes) {
				listaDataConsulta.add(dataConsulta.getTime());
			}
		}
		for (Date datasListadas : listaDataConsulta) {
			processarSecaoConversaBot(datasListadas);
		}	
	}

	public List<SecaoConversaBot> getListaConversasBots() {
		return listaConversasBots;
	}

	public void setListaConversasBots(List<SecaoConversaBot> listaConversasBots) {
		this.listaConversasBots = listaConversasBots;
	}

	public Paginacao<SecaoConversaBot> listaSecaoConversaBotParametros(SecaoConversaBotParametrosEntrada entrada, Paginacao<SecaoConversaBot> paginacao) {
		if (!entrada.getIdPeriodo().equalsIgnoreCase("PERSONALIZADO")) {
			PeriodoDatasVO periodoDatasVO = new PeriodoDatasVO(entrada.getIdPeriodo());
			entrada.setDataInicial(periodoDatasVO.getInicio());
			entrada.setDataFinal(periodoDatasVO.getFim());
		}else {
			entrada.setDataInicial(FormatarData.tratarDataPeriodo(entrada.getDataInicial(), true));
			entrada.setDataFinal(FormatarData.tratarDataPeriodo(entrada.getDataFinal(), false));
		}		
		
		paginacao = secaoConversaBotDao.listaSecaoConversaBotParametros(entrada,paginacao);
		return paginacao;
	}

}
