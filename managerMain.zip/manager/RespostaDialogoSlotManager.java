package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import com.vdurmont.emoji.EmojiParser;

import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.enums.TipoFormatacao;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlot;

@Name("respostaDialogoSlotManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class RespostaDialogoSlotManager {

    @In(create = true)
    private RespostaDialogoSlotDao respostaDialogoSlotDao;

    public RespostaDialogoSlot salvar(RespostaDialogoSlot resposta, Integer idSlot) {
        resposta.getId().setIdSlot(idSlot);
        if (resposta.getTextoResposta() != null) {
            if (resposta.getTipoResposta() != null
                    && TipoFormatacao.WHATSAPP.equals(resposta.getTipoResposta().getTipoFormatacao())) {
                String textoWhatsappFormatado = formattingHTMLToTextWhatsapp(resposta.getTextoResposta());
                resposta.setTextoResposta(textoWhatsappFormatado);
            }
            resposta.setTextoResposta(EmojiParser.parseToAliases(resposta.getTextoResposta()));
        }
        return respostaDialogoSlotDao.persist(resposta);
    }

    private String formattingHTMLToTextWhatsapp(String texto) {
        texto = texto.replaceAll("\\</?strong>", "*");
        texto = texto.replaceAll("\\</?em>", "_");
        texto = texto.replaceAll("\\<.*?\\>", "");
        return texto;
    }

    public void excluir(RespostaDialogoSlot resposta) {
        respostaDialogoSlotDao.remove(resposta);
    }

}
