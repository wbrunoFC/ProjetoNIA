package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ControleIdPerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.model.ControleIdPerguntaRevisao;

@Name("controleIdPerguntaRevisaoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ControleIdPerguntaRevisaoManager {

    @In(create = true)
    private ControleIdPerguntaRevisaoDao controleIdPerguntaRevisaoDao;
    
    @In(create = true)
    private LogNiaInfraManager logNiaInfraManager;

    public ControleIdPerguntaRevisao getControlePerguntaRevisao() {
        List<ControleIdPerguntaRevisao> lista = controleIdPerguntaRevisaoDao.findAll();
        if(!lista.isEmpty()) {
            return lista.get(0);
        }
        return novoControle();
    }

    public ControleIdPerguntaRevisao salvar(ControleIdPerguntaRevisao controleIdPerguntaRevisao) {
        controleIdPerguntaRevisao.setDataConsulta(new Date());
        controleIdPerguntaRevisao = controleIdPerguntaRevisaoDao.persist(controleIdPerguntaRevisao);
        controleIdPerguntaRevisaoDao.flush();
        return controleIdPerguntaRevisao;
    }

    public void incrementarParaUltimo(ControleIdPerguntaRevisao controle) {
        // ultimo id da tabela log nia infra
        Integer ultimoIdLog = logNiaInfraManager.ultimoIdLogNiaInfra();
        atualizarControle(controle, ultimoIdLog);
    }
    
    public void incrementar(ControleIdPerguntaRevisao controle, int quantidade) {
        int idFim = controle.getIdFimPerguntaRevisao();
        idFim += quantidade;
        Integer ultimoIdLog = logNiaInfraManager.ultimoIdLogNiaInfra();
        if (idFim > ultimoIdLog) {
            idFim = ultimoIdLog;
        }
        atualizarControle(controle, idFim);
    }
    
    public void atualizarControle(ControleIdPerguntaRevisao controle, int novoIdFim) {
        int idFim = controle.getIdFimPerguntaRevisao();
        controle.setIdInicioPerguntaRevisao(idFim);
        controle.setIdFimPerguntaRevisao(novoIdFim);
    }
    
    public boolean terminou(ControleIdPerguntaRevisao controle) {
        Integer ultimoIdLog = logNiaInfraManager.ultimoIdLogNiaInfra();
        
        int idFim = controle.getIdFimPerguntaRevisao();
        return idFim >= ultimoIdLog; 
    }
    
    private ControleIdPerguntaRevisao novoControle() {
        Integer ultimoIdLog = logNiaInfraManager.ultimoIdLogNiaInfra();
        return new ControleIdPerguntaRevisao(ultimoIdLog, ultimoIdLog);
    }
    
}
