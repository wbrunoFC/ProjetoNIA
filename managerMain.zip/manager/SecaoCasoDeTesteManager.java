package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.SecaoCasoDeTesteDao;
import br.com.bb.gearq.c4coleta.model.CenarioEsperado;
import br.com.bb.gearq.c4coleta.model.SecaoCasoDeTeste;
import br.com.bb.gearq.c4coleta.vo.SecaoCasoDeTesteNoSalvarVo;
import br.com.bb.gearq.c4coleta.vo.SecaoCasoDeTesteNoVo;

@Name("secaoCasoDeTesteManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class SecaoCasoDeTesteManager {

    @In(create = true)
    private SecaoCasoDeTesteDao secaoCasoDeTesteDao;
    
    @In(create = true)
    private CenarioEsperadoManager cenarioEsperadoManager;
    
    @In(create = true)    
    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;
    
    public SecaoCasoDeTeste obter(Integer idSecao) {
        return secaoCasoDeTesteDao.findById(idSecao); 
    }
    
    public List<SecaoCasoDeTeste> listar(Integer idCasoDeTesteClassificador) {
        return secaoCasoDeTesteDao.findByIdCasoDeTesteClassificador(idCasoDeTesteClassificador);
    }
    
    public SecaoCasoDeTeste salvar(SecaoCasoDeTeste secao) {
        secaoCasoDeTesteDao.persist(secao);
        if(secao.getCenarios() != null) {
            for (CenarioEsperado cenarioEsperado: secao.getCenarios()) {
                cenarioEsperado.setIdSecaoCasoDeTeste(secao.getId());
            	cenarioEsperadoManager.salvar(cenarioEsperado);
            }
        }
        
        return secao;
    }
    
    public SecaoCasoDeTeste criar(SecaoCasoDeTesteNoSalvarVo salvaNo) {
        SecaoCasoDeTesteNoVo secaoCasoDeTesteNoVo = new SecaoCasoDeTesteNoVo();
        SecaoCasoDeTeste secaoCasoDeTeste = new SecaoCasoDeTeste();
        secaoCasoDeTesteNoVo.setSecao(secaoCasoDeTeste);
        secaoCasoDeTeste.setIdCasoDeTesteClassificador(salvaNo.getIdCasoDeTesteClassificador());
        secaoCasoDeTeste.setNumeroSequencial(secaoCasoDeTesteDao.getMaxSequencia(salvaNo.getIdCasoDeTesteClassificador()).intValue());
        
        secaoCasoDeTeste = secaoCasoDeTesteDao.persist(secaoCasoDeTeste);
        secaoCasoDeTesteNoVo.setId(secaoCasoDeTeste.getId());
        
	    CenarioEsperado cenarioEsperado = cenarioEsperadoManager.criar(secaoCasoDeTesteNoVo.getId());
	    secaoCasoDeTeste.getCenarios().add(cenarioEsperado);
        secaoCasoDeTesteNoVo.setSecao(secaoCasoDeTeste);
        
        if (salvaNo.getIdSecaoSelecionado() != null && salvaNo.getSequenciaRegistroHierarquia() != null) {
            SecaoCasoDeTeste secaoSelecionado = this.obter(salvaNo.getIdSecaoSelecionado());
            if (secaoSelecionado != null ) {
                int novaposicao = secaoSelecionado.getNumeroSequencial() + salvaNo.getSequenciaRegistroHierarquia();
                casoDeTesteClassificadorManager.moverSecao(secaoCasoDeTeste, novaposicao);
            }
        }
        
        return secaoCasoDeTeste;
	}

    public void excluirAtualizarSequencia(Integer idSecao) {
        SecaoCasoDeTeste secao = secaoCasoDeTesteDao.findById(idSecao);
        Integer idCaso = secao.getIdCasoDeTesteClassificador();
        excluir(secao);
        casoDeTesteClassificadorManager.atualizarSequenciaSalvar(idCaso);
    }
    
    public void excluir(SecaoCasoDeTeste secao) {
        for (CenarioEsperado cenario : secao.getCenarios()) {
            cenarioEsperadoManager.excluir(cenario);
        }
        secaoCasoDeTesteDao.remove(secao);
    }
    
}
