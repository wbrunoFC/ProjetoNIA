package br.com.bb.gearq.c4coleta.manager;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoIntencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.model.TipoResposta;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.operacao.GatewayConsultarDadosBasicosChaveUsuarioOp292018V1;

@Name("emailManager")
@Scope(ScopeType.EVENT)
public class EmailManager {

	@In(create = true)
	private GatewayConsultarDadosBasicosChaveUsuarioOp292018V1 gatewayConsultarDadosBasicosChaveUsuarioOp292018V1;

	@In(create = true)
	private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;

	@In(create = true)
	private FluxoDao fluxoDao;

	@In(create = true)
	private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
	
	@In(create = true)
	private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;

	public void enviar(PerguntaRevisao pergunta) {
		
		if( pergunta.getIntencaoRevisao() == null && pergunta.getIdIntencaoRevisao() != null){
			pergunta.setIntencaoRevisao(perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao()));
		}
		
		if (pergunta != null && pergunta.getIntencaoRevisao() != null) {
			
			if( pergunta.getIntencaoRevisao() != null && pergunta.getIntencaoRevisao().getIntencao() != null ){
				List<PerguntaRevisaoUsuario> usuarios = perguntaRevisaoUsuarioDao
						.findEmail(true, pergunta.getId());
				if (usuarios != null && usuarios.size() > 0) {
					
					List<TipoRespostaIntencao> respostas = tipoRespostaIntencaoDao
							.findAll(pergunta.getIntencaoRevisao().getIntencao()
									.getId(), null);
					String resposta = "";
					
					if (respostas != null) {
						for (TipoRespostaIntencao resp : respostas) {
							if (resp.getTipoResposta().getNomeJSON()
									.equals(TipoResposta.TX_PADRAO)) {
								resposta = resp.getTextoResposta();
							}
						}
					}
					
					if (pergunta.getIntencaoRevisao().getIntencao().getNecessitaDesambiguacao()) {
						List<Fluxo> lista = fluxoDao.findByFluxo(pergunta
								.getIntencaoRevisao().getIntencao().getId());
						if (lista != null) {
							for (Fluxo fluxo : lista) {
								if (fluxo.getFluxoPai() == null) {
									resposta = fluxo.getPerguntaDesambiguacao();
									break;
								}
							}
						}
					}
					
					for (PerguntaRevisaoUsuario usuario : usuarios) {
						
						if (usuario.getUsuario() != null
								&& usuario.getUsuario().trim().length() == 8) {
							EnviarEmail env = new EnviarEmail();
							env.setMatricula(usuario.getUsuario());
							env.setPergunta(pergunta.getPergunta());
							if( pergunta.getClassificador() != null ){
								env.setIdClassificador(pergunta.getClassificador().getId());
							}
							if (pergunta.getClassificador().getServicoNlc() != null
									&& pergunta.getClassificador().getServicoNlc()
									.getDiretoria() != null
									&& pergunta.getClassificador().getServicoNlc()
									.getDiretoria().trim().length() > 0) {
								env.setDiretoria(pergunta.getClassificador()
										.getServicoNlc().getDiretoria()
										.toUpperCase());
							} else {
								env.setDiretoria(pergunta.getClassificador()
										.getNome().toUpperCase());
							}
							env.setResposta(resposta);
							env.setNome("");
							/*
							 * TODO utilizar quando a aplicação em produção puder
							 * utilizar operação try {
							 * DadosRespostaConsultarDadosBasicosChaveUsuario resp =
							 * gatewayConsultarDadosBasicosChaveUsuarioOp292018V1
							 * .executar(pergunta.getChaveSolicitante()); if( resp
							 * != null && resp.getRegRtn() != null &&
							 * resp.getRegRtn().getDadosRtn() != null &&
							 * resp.getRegRtn().getDadosRtn().getNmUsu() != null &&
							 * resp
							 * .getRegRtn().getDadosRtn().getNmUsu().trim().length()
							 * > 0){
							 * env.setNome(resp.getRegRtn().getDadosRtn().getNmUsu
							 * ()); }
							 * 
							 * } catch (Exception e) { e.printStackTrace(); }
							 */
							env.start();
						}
					}
					
				}
			}
		}

	}

	private static class EnviarEmail extends Thread {

		private static int size = 2;
		private static String color = "#000099";

		private String matricula;
		private String nome;
		private String dataHora;
		private String pergunta;
		private String resposta;
		private String diretoria;
		private Integer idClassificador;

		public void run() {

			if (matricula == null || matricula.trim().length() == 0) {
				return;
			}

			if (nome == null)
				nome = "";

			DateFormat df = new SimpleDateFormat("dd/MM/yyyy 'às' HH:mm");

			dataHora = df.format(new Date());

			String to = matricula + "@bb.com.br";

			String from = "naoresponda@nia.bb.com.br";

			String host = "smtp.bb.com.br";

			Properties properties = System.getProperties();
			properties.put("mail.smtp.host", host);
			properties.put("mail.smtp.port", "25");
			properties.put("mail.smtp.starttls.enable", "true");
			properties.put("mail.debug", "true");
			System.out.println("iniciando...." + matricula);
			Session session = Session.getDefaultInstance(properties);

			try {
				MimeMessage message = new MimeMessage(session);

				message.setFrom(new InternetAddress(from,
						"Curadoria - Não responda"));

				message.addRecipient(Message.RecipientType.TO,
						new InternetAddress(to));
				
				if( idClassificador != null && (idClassificador.equals(63) || idClassificador.equals(21))){
					message.setSubject("Resposta da Norminha.");
					message.setContent(getHTMLEmailDisem(), "text/html; charset=utf-8");
				}else{
					message.setSubject("Resposta de sua solicitação.");
					message.setContent(getHTMLEmail(), "text/html; charset=utf-8");
				}


				System.out.println("enviando....");
				Transport.send(message);
				System.out.println("Enviado com sucesso....");
			} catch (Exception mex) {
				mex.printStackTrace();
			}
		}

		public void setResposta(String resposta) {
			this.resposta = resposta;
		}

		public void setMatricula(String matricula) {
			this.matricula = matricula;
		}

		public void setPergunta(String pergunta) {
			this.pergunta = pergunta;
		}

		public void setDiretoria(String diretoria) {
			this.diretoria = diretoria;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}
		
		private String getHTMLEmailDisem() {
			StringBuffer html = new StringBuffer();
			html.append("<div class='s-basicpanel' style='overflow: hidden;'>");

			html.append("<blockquote>");

			if (nome.trim().length() > 0) {
				nome = " " + nome;
			}

			// mensagem não passivel de resposta
			/*String naoPassivel = "Mensagem originada da " + diretoria
					+ " - Curadoria  - NÃO PASSÍVEL DE RESPOSTA";
			html.append("<p>").append(getFont(size, color, naoPassivel))
					.append("<p>");
			html.append("<br>");*/

			// saudação
			String saudacao = "Olá" + nome + ", tudo bem?";
			html.append("<p>").append(getFont(size, color, saudacao))
					.append("<p>");
			html.append("<br>");
			// texto duvida
			String duvida = "Sua dúvida foi respondida pelo nosso time de especialistas em "
					+ dataHora + ".";
			html.append("<p>").append(getFont(size, color, duvida))
					.append("<p>");
			html.append("<br>");
			// pergunta e resposta
			html.append("<blockquote>");

			String perg = "<b>Pergunta:</b> " + pergunta;
			html.append("<p>").append(getFont(size, color, perg)).append("<p>");
			html.append("<br>");

			String rep = "<b>Resposta:</b> " + resposta;
			html.append("<p>").append(getFont(size, color, rep)).append("<p>");

			html.append("</blockquote>");
			html.append("<br>");

			// agradecimento
			String agradecimento = "Em caso de novas dúvidas, a Norminha permanece à disposição."
					+ "<br><br>Continue contribuindo e surpreenda-se com a inteligência artificial no seu dia-a-dia!<br>";
			html.append("<p>").append(getFont(size, color, agradecimento))
					.append("<p>");
			html.append("<br>");
			html.append("<br>");
			
			String sugestao = "__________________________________ <br> Para relatar algum equívoco na resposta ou para dar alguma sugestão envie uma mensagem para disem.curadoria@bb.com.br";
			html.append("<p>").append(getFont(size, color, sugestao)).append("<p>");
			
			
			
			html.append("</blockquote>");
			html.append("<br>");
			html.append("<br>");
			// assinatura

			//html.append(getAssinatura());

			html.append("</div>");

			return html.toString();
		}

		private String getHTMLEmail() {
			StringBuffer html = new StringBuffer();
			html.append("<div class='s-basicpanel' style='overflow: hidden;'>");

			html.append("<blockquote>");

			if (nome.trim().length() > 0) {
				nome = " " + nome;
			}

			// mensagem não passivel de resposta
			String naoPassivel = "Mensagem originada da " + diretoria
					+ " - Curadoria  - NÃO PASSÍVEL DE RESPOSTA";
			html.append("<p>").append(getFont(size, color, naoPassivel))
					.append("<p>");
			html.append("<br>");

			// saudação
			String saudacao = "Olá" + nome + ", tudo bem?";
			html.append("<p>").append(getFont(size, color, saudacao))
					.append("<p>");
			html.append("<br>");
			// texto duvida
			String duvida = "Sua dúvida foi respondida pelo nosso time de especialistas em "
					+ dataHora + ".";
			html.append("<p>").append(getFont(size, color, duvida))
					.append("<p>");
			html.append("<br>");
			// pergunta e resposta
			html.append("<blockquote>");

			String perg = "<b>Pergunta:</b> " + pergunta;
			html.append("<p>").append(getFont(size, color, perg)).append("<p>");
			html.append("<br>");

			String rep = "<b>Resposta:</b> " + resposta;
			html.append("<p>").append(getFont(size, color, rep)).append("<p>");

			html.append("</blockquote>");
			html.append("<br>");

			// agradecimento
			String agradecimento = "Em caso de novas dúvidas, utilize o mesmo canal, pois suas dúvidas "
					+ "podem ser as mesmas de outros colegas. Continue contribuindo e surpreenda-se com a "
					+ "inteligência artificial no seu dia-a-dia! <br><br>Obrigado e conte conosco!<br>";
			html.append("<p>").append(getFont(size, color, agradecimento))
					.append("<p>");

			html.append("</blockquote>");
			html.append("<br>");
			html.append("<br>");
			// assinatura

			html.append(getAssinatura());

			html.append("</div>");

			return html.toString();
		}

		private String getFont(int size, String color, String texto) {
			StringBuffer font = new StringBuffer();

			font.append("<font color='").append(color).append("'");

			font.append(" size='").append(size).append("'");

			font.append("face='Trebuchet MS,Default Sans Serif,Arial,Verdana,Helvetica,sans-serif'>");

			font.append(texto);

			font.append("</font>");

			return font.toString();
		}

		private String getAssinatura() {
			StringBuffer ass = new StringBuffer();

			ass.append("<table style='border: 0px outset #ffffff; font-family: Trebuchet MS, Default Sans Serif, "
					+ "Verdana, Arial, Helvetica, sans-serif; font-size: small; color: #000000;' cellpadding='2' "
					+ "cellspacing='0' width=''>");
			ass.append("<tbody><tr>");

			ass.append("<td style='vertical-align: top;' >");

			// linha
			ass.append(getFont(size, "#000000",
					"<b>__________________________________</b>"));
			ass.append("<br>");
			// nome diretoria
			ass.append(getFont(size, "#000000", "<b>" + diretoria
					+ " - Curadoria</b>"));
			ass.append("</br>");
			// #digitaverde
			ass.append(getFont(1, "#0000ff", "<i><b>#digitaldeverdade</b></i>"));

			ass.append("<td> </tr> </tbody> </table>");

			return ass.toString();
		}

		public Integer getIdClassificador() {
			return idClassificador;
		}

		public void setIdClassificador(Integer idClassificador) {
			this.idClassificador = idClassificador;
		}

	}

}