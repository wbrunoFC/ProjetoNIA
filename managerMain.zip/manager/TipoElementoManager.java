package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.TipoElementoDao;
import br.com.bb.gearq.c4coleta.model.TipoElemento;

@Name("tipoElementoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class TipoElementoManager {
	
	@In(create= true)
	private TipoElementoDao tipoElementoDao;

	public List<TipoElemento> listar() {
		return tipoElementoDao.findAll();
	}

}
