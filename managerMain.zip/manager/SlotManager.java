package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.DialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.dao.SlotsDao;
import br.com.bb.gearq.c4coleta.dao.TipoComponenteVisualDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.model.Dialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlot;
import br.com.bb.gearq.c4coleta.model.Slots;
import br.com.bb.gearq.c4coleta.model.VariavelContexto;
import br.com.bb.gearq.c4coleta.util.NiaTextoUtils;
import br.com.bb.gearq.c4coleta.versionamento.v1.SlotVersaoV1;

@Name("slotManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class SlotManager {

    @In(create = true)
    private TipoComponenteVisualDao tipoComponenteVisualDao;

    @In(create = true)
    private DialogoDao dialogoDao;

    @In(create = true)
    private RespostaDialogoSlotDao respostaDialogoSlotDao;

    @In(create = true)
    private SlotsDao slotsDao;

    @In(create = true)
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;

    @In(create = true)
    private RespostaDialogoSlotManager respostaDialogoSlotManager;

    @In(create = true)
    private DialogoManager dialogoManager;

    @In(create = true)
    private VariavelContextoManager variavelContextoManager;

    @In(create = true)
    private CacheProgresso cacheProgresso;

    public Slots obter(Integer id) {
        return slotsDao.findById(id);
    }

    public List<RespostaDialogoSlot> listaRespostaDialogoSlot(Integer idSlot) {
        return respostaDialogoSlotDao.findByDialogoSlot(idSlot);
    }

    public Slots salvar(Slots slot) {
        if (slot.getVariavelContexto() != null) {
            VariavelContexto variavelContexto = slot.getVariavelContexto();
            if (variavelContexto.getId() == null) {
                Integer idClassificador = slot.getDialogo().getIdClassificador();
                String valorVariavel = variavelContexto.getVariavelContexto();
                variavelContexto = variavelContextoManager.obterOuCriar(idClassificador, valorVariavel);
            }
            slot.setVariavelContexto(variavelContexto);
        }

        preencherUuid(slot);
        slot.setIndicadorObrigatorio(slotIsObrigatorio(slot));

        if (slot.getId() == null) {
            slot = slotsDao.persist(slot);
        } else {
            // Edição
            Slots slotAntes = this.obter(slot.getId());
            if (Boolean.FALSE.equals(slot.getIndicadorRespostaMultipla())) {
                slot.setNodesDadoInvalido(new ArrayList<Dialogo>());
                slot.setNodesDadoValido(new ArrayList<Dialogo>());
            }
            limparRespostas(slot, slotAntes);
            excluirFilhosFaltantes(slot.getNodesDadoInvalido(), slotAntes.getNodesDadoInvalido());
            excluirFilhosFaltantes(slot.getNodesDadoValido(), slotAntes.getNodesDadoValido());
        }

        for (RespostaDialogoSlot resposta : slot.getRespostas()) {
            respostaDialogoSlotManager.salvar(resposta, slot.getId());
        }

        for (Dialogo filho : slot.getNodesDadoInvalido()) {
            filho.setValido(false);
            salvarNodeFilho(slot, filho);
        }
        for (Dialogo filho : slot.getNodesDadoValido()) {
            filho.setValido(true);
            salvarNodeFilho(slot, filho);
        }
        for (Dialogo filho : slot.getFilhos()) {
            salvarNodeFilho(slot, filho);
        }
        return slotsDao.persist(slot);
    }
    
    private void limparRespostas(Slots slot, Slots slotAntes) {
        List<RespostaDialogoSlot> excluidas = new ArrayList<>();
        // Limpar respostas nulas ou vazias
        for (RespostaDialogoSlot resposta : slot.getRespostas()) {
            if (NiaTextoUtils.isEmpty(resposta.getTextoResposta())) {
                excluidas.add(resposta);
            }
        }
        slot.getRespostas().removeAll(excluidas);

        // Verificar respostas excluidas
        for (RespostaDialogoSlot resposta : slotAntes.getRespostas()) {
            if (slot.getRespostas().indexOf(resposta) == -1) {
                this.respostaDialogoSlotManager.excluir(resposta);
            }
        }
    }

    private void excluirFilhosFaltantes(List<Dialogo> nodesNovo, List<Dialogo> nodesVelho) {
        for (Dialogo node : nodesVelho) {
            if (nodesNovo.indexOf(node) == -1) {
                this.dialogoManager.excluir(node, false);
            }
        }
    }

    private void salvarNodeFilho(Slots slot, Dialogo filho) {
        filho.setSlotsPai(slot);
        filho.setCdTipoNo(2);
        filho.setIdClassificador(slot.getDialogo().getIdClassificador());
        dialogoManager.salvar(filho);
    }

    public void excluir(Integer id) {
        Slots slot = slotsDao.findById(id);
        if (slot != null) {
            excluir(slot);
        }
    }

    public void excluir(Slots slot) {
        if (slot != null && slot.getId() != null && slot.getId() > 0) {
            for (Dialogo filho : dialogoDao.carregarMultiplaRespotaSlot(slot.getId())) {
                dialogoManager.excluir(filho, false);
            }
            for (RespostaDialogoSlot respostaDialogoSlot : respostaDialogoSlotDao.findByDialogoSlot(slot.getId())) {
                respostaDialogoSlotDao.remove(respostaDialogoSlot);
            }
            slotsDao.remove(slot);
        }
    }

    private void preencherUuid(Slots slot) {
        if (slot.getSlotNaoPreenchidoHash() == null) {
            slot.setSlotNaoPreenchidoHash(UUID.randomUUID().toString());
        }
        if (slot.getHashDadoValido() == null) {
            slot.setHashDadoValido(UUID.randomUUID().toString());
        }
        if (slot.getHashDadoInvalido() == null) {
            slot.setHashDadoInvalido(UUID.randomUUID().toString());
        }

    }

    private boolean slotIsObrigatorio(Slots slot) {
        for (RespostaDialogoSlot resp : slot.getRespostas()) {
            String texto = resp.getTextoResposta();
            if (texto != null && !texto.trim().equals("")) {
                return true;
            }
        }
        return false;
    }

    public String getPrimeiraResposta(Slots slot) {
        for (RespostaDialogoSlot resp : slot.getRespostas()) {
            String texto = resp.getTextoResposta();
            if (texto != null && !texto.trim().equals("")) {
                return texto;
            }
        }
        return null;
    }

    public List<SlotVersaoV1> listarVersao(Integer idClassificador) {
        List<SlotVersaoV1> slotsVersao = new ArrayList<>();

        List<Slots> slots = slotsDao.listarVersao(idClassificador);
        for (Slots slot : slots) {
            slotsVersao.add(new SlotVersaoV1(slot));
        }

        return slotsVersao;
    }

    public void limparPorClassificador(Integer idClassificador) {
        List<Slots> slots = slotsDao.listarVersao(idClassificador);
        int size = slots.size();
        int i = 0;
        for (Slots slot : slots) {
            String msg = "Removendo slot " + ++i + "/" + size;
            cacheProgresso.atualizar("RECOVERY_" + idClassificador + "_PROGRESSO", 3, msg);
            excluir(slot);
        }
    }

}
