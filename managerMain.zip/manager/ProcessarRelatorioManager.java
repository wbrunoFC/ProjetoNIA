package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.AcionamentoIntencaoDiaDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;

@Name("processarRelatorioManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ProcessarRelatorioManager {

	@In(create = true)
	private IntencaoDao intencaoDao;
	
	@In(create = true)
	private AcionamentoIntencaoDiaDao acionamentoIntencaoDiaDao;
	
	public String processarQtd (){
		
		acionamentoIntencaoDiaDao.findByDadosDia();
	
		System.out.println("processar intencao");
		
		
		return null;
		
	}
}
