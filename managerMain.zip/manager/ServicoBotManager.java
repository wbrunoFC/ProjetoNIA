package br.com.bb.gearq.c4coleta.manager;

import java.text.ParseException;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ParametroServicoBotDao;
import br.com.bb.gearq.c4coleta.dao.ServicoBotDao;
import br.com.bb.gearq.c4coleta.model.ParametroServicoBot;
import br.com.bb.gearq.c4coleta.model.ParametroWatsonTipoCampo;
import br.com.bb.gearq.c4coleta.model.ServicoBot;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.vo.Paginacao;

@Name("servicoBotManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ServicoBotManager {

    @In(create = true)
    private ServicoBotDao servicoBotDao;

    @In(create = true)
    private ParametroServicoBotDao parametroServicoBotDao;

    public Paginacao<ServicoBot> findAll(Paginacao<ServicoBot> paginacao, String nome) {

        return servicoBotDao.findAll(paginacao, nome);

    }
    public Paginacao<ServicoBot> findAllComCampos(Paginacao<ServicoBot> paginacao, String nome) {

        return servicoBotDao.findComCampos(paginacao, nome);

    }
    
    public ServicoBot obterPorNome(String nome) {
        return servicoBotDao.findByName(nome);
    }

    public void salvar(ServicoBot servicoBot) throws ParseException {
        ServicoBot s;
        if (servicoBot.getId() != null && servicoBot.getId() > 0) {
            // editar
            ServicoBot botBanco = buscarServicoBot(servicoBot.getId());
            botBanco.setNome(servicoBot.getNome());
            s = servicoBotDao.persist(botBanco);
        } else {
            // Salvar
            s = servicoBotDao.persist(servicoBot);
        }

        if (servicoBot.getParametrosFilhos() != null && !servicoBot.getParametrosFilhos().isEmpty()) {
            for (ParametroServicoBot p : servicoBot.getParametrosFilhos()) {
                if (s.getId() != null) {
                    salvarEditarParametros(p, s.getId());
                }
            }
        }
    }

    public void salvarEditarParametros(ParametroServicoBot p, Integer idServico) throws ParseException {
        if (p.getId() != null && p.getId() > 0) {
            // editar
            ParametroServicoBot pBanco = parametroServicoBotDao.findById(p.getId());
            pBanco.setCampoObrigatorio(p.isCampoObrigatorio());
            pBanco.setCodigoTipoParametro(p.getCodigoTipoParametro());
            pBanco.setNome(p.getNome());
            pBanco.setTextoPadrao(p.getTextoPadrao());
            pBanco.setTextoTratamentoAcesso(p.getTextoTratamentoAcesso());
            parametroServicoBotDao.persist(pBanco);
        } else {
            // salvar
            p.setTextoPadrao(p.getTextoPadrao().equals("null") ? "" : p.getTextoPadrao());
            formatarData(p);
            p.setIdServicoBot(idServico);
            parametroServicoBotDao.persist(p);
        }

    }
    private void formatarData(ParametroServicoBot parametroWatson) throws ParseException {      
        if(parametroWatson.getCodigoTipoParametro() != null && !parametroWatson.getTextoPadrao().isEmpty()
                && parametroWatson.getCodigoTipoParametro().equals(ParametroWatsonTipoCampo.DATA)) {
            String ano = ((String)parametroWatson.getTextoPadrao()).substring(0,4);
            String mes = ((String)parametroWatson.getTextoPadrao()).substring(5,7);
            String dia = ((String)parametroWatson.getTextoPadrao()).substring(8,10);
            String hora = ((String)parametroWatson.getTextoPadrao()).substring(11,13);
            String min = ((String)parametroWatson.getTextoPadrao()).substring(14,16);
            String seg = ((String)parametroWatson.getTextoPadrao()).substring(17,19);
            parametroWatson.setTextoPadrao(ano+"-"+mes+"-"+dia+" "+hora+":"+min+":"+seg);
        }
    }
    public void buscarRemoverServico(ServicoBot servico) {
        if (servico != null) {
            // remover parametros vinculados ao serviço
            if (servico.getParametrosFilhos() != null && !servico.getParametrosFilhos().isEmpty()) {
                for (ParametroServicoBot p : servico.getParametrosFilhos()) {
                    buscarRemoverParametro(p.getId());
                }
            }
            // remover serviço.
            if (servico.getId() != null) {
                ServicoBot s = servicoBotDao.findById(servico.getId());
                servicoBotDao.remove(s);
            }
        }

    }

    public void buscarRemoverParametro(int idParametro) {
        if (idParametro > 0) {
            ParametroServicoBot p = new ParametroServicoBot();
            p = parametroServicoBotDao.findById(idParametro);
            parametroServicoBotDao.remove(p);
        }
    }

    public ServicoBot buscarServicoBot(int idServicoBot) {
        ServicoBot s = new ServicoBot();
        if (idServicoBot > 0) {
            s = servicoBotDao.findById(idServicoBot);
        }

        return s;
    }

}
