package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.json.JSONObject;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.AcessosChatDao;
import br.com.bb.gearq.c4coleta.dao.CredencialWatsonDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.ParametroServicoBotDao;
import br.com.bb.gearq.c4coleta.dao.SincronizacaoDao;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.model.CredencialWatson;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.ParametroServicoBot;
import br.com.bb.gearq.c4coleta.model.Sincronizacao;
import br.com.bb.gearq.c4coleta.model.StatusNuvem;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.gearq.c4coleta.vo.NuvemWatsonCredenciaisVO;
import br.com.bb.gearq.c4coleta.vo.NuvemWatsonVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("nuvemWatsonManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class NuvemWatsonManager {

    private static final String MODIFICAÇÃO_WORKSPACE_ID = "MODIFICAÇÃO WORKSPACE-ID";

    @In(create = true)
    private NuvemWatsonDao nuvemWatsonDao;

    @In(create = true)
    private CredencialWatsonDao credencialWatsonDao;

    @In(create = true)
    private ParametroServicoBotDao parametroServicoBotDao;

    @In(create = true)
    private SincronizacaoDao sincronizacaoDao;

    @In(create = true)
    private UsuarioDao usuarioDao;

    @In(create = true)
    private AcessosChatDao acessosChatDao;
    
    @In(create = true)
    private SincronizacaoManager sincronizacaoManager;

    public NuvemWatson obter(int idNuvem) {
        return nuvemWatsonDao.findById(idNuvem);
    }

    public NuvemWatson salvar(NuvemWatson nuvemWatson) throws NegocioException {
        int cont = 0;
        if (nuvemWatson.getListaCredencialParametro() != null) {
            for (CredencialWatson credencial : nuvemWatson.getListaCredencialParametro()) {

                // verifidar se a workspaceID foi modificado.
                if (cont == 2 && nuvemWatson.getIdServicoBot() == 1) {
                    String workspaceAtual = nuvemWatson.getWorkspaceId();
                    String novaWorskpaceID = credencial.getNome();
                    gravaModificacaoWorskpace(workspaceAtual, novaWorskpaceID, nuvemWatson);
                }

                credencial.setNuvemWatson(nuvemWatson);
                credencialWatsonDao.preSalvar(credencial);
                cont++;
            }
        }
        if (nuvemWatson.getClassificador() == null) {
            nuvemWatson.setAssunto(null);
        }
        nuvemWatson = nuvemWatsonDao.persistAndFlush(nuvemWatson);
        if (nuvemWatson.getListaCredencialParametro() != null) {
            for (CredencialWatson credencial : nuvemWatson.getListaCredencialParametro()) {
                credencialWatsonDao.persistAndFlush(credencial);
            }
        }
        return nuvemWatson;
    }

    /**
     * caso o campo workspaceID seja modificado, gravar no historico de
     * sincronizações.
     * 
     * @param workspaceAtual
     * @param novaWorskpaceID
     */
    private void gravaModificacaoWorskpace(String workspaceAtual, String novaWorskpaceID, NuvemWatson nuvemWatson) {

        if ((workspaceAtual != null && novaWorskpaceID != null)
                && (!workspaceAtual.equalsIgnoreCase(novaWorskpaceID))) {

            final UsuarioVO funci = (UsuarioVO) Component.getInstance("funci");

            Sincronizacao s = new Sincronizacao();
            s.setCdWorkspace(novaWorskpaceID);
            s.setClassificador(nuvemWatson.getClassificador());
            s.setIndicadorAtivo(true);
            s.setNuvemWatson(nuvemWatson);
            s.setVersaoCorpusResposta(nuvemWatson.getVersaoCorpusResposta());
            s.setDataSincronizacao(new Date());
            s.setIdUsuario(usuarioDao.findByChave(funci.getChave()).getId());
            s.setDescricaoAtividade(MODIFICAÇÃO_WORKSPACE_ID);
            sincronizacaoDao.persist(s);

        }

    }

    public List<CredencialWatson> recuperarCredenciais(Integer idNuvemWatson) {
        List<CredencialWatson> listaCredencial = credencialWatsonDao.findByIdNuvemIdParametro(idNuvemWatson, null);
        List<ParametroServicoBot> parametros = parametroServicoBotDao.findAll();

        if (listaCredencial == null) {
            listaCredencial = new ArrayList<CredencialWatson>();
        }

        for (ParametroServicoBot p : parametros) {
            boolean contem = false;
            for (CredencialWatson credencial : listaCredencial) {
                
                if (credencial.getParametroWatson().getId().equals(p.getId())) {
                    contem = true;
                    break;
                }
                
                
            }
            
            if (!contem) {
                CredencialWatson credencial = new CredencialWatson();
                credencial.setParametroWatson(p);
                credencial.setNome(p.getTextoPadrao());
                listaCredencial.add(credencial);
            }
        }

        return listaCredencial;

    }    

    
    // preciso do id do serviço, me monstrando o conteudo certo. 
    
    public List<CredencialWatson> recuperarCredenciaisPorServicoBot(Integer idNuvemWatson,int idServicoBot) {
        List<CredencialWatson> listaCredencial = credencialWatsonDao.findByIdNuvemIdParametro(idNuvemWatson, null);
        List<ParametroServicoBot> parametros = parametroServicoBotDao.findByServico(idServicoBot);

        if (listaCredencial == null) {
            listaCredencial = new ArrayList<CredencialWatson>();
        }
        List<CredencialWatson> listaCredencialRetorno = new ArrayList<CredencialWatson>();
        for (ParametroServicoBot p : parametros) {
            boolean contem = false;
            for (CredencialWatson credencial : listaCredencial) {
                if (credencial.getParametroWatson().getId().equals(p.getId()) && credencial.getParametroWatson().getIdServicoBot().equals(idServicoBot)) {
                    CredencialWatson credencialRetorno = new CredencialWatson();
                    credencialRetorno.setParametroWatson(p);
                    credencialRetorno.setNome(p.getTextoPadrao());
                    listaCredencialRetorno.add(credencial);
                    contem = true;
                }
            }
            if (!contem) {
                CredencialWatson credencial = new CredencialWatson();
                credencial.setParametroWatson(p);
                credencial.setNome(p.getTextoPadrao());
                listaCredencialRetorno.add(credencial);
                
            }
        }
        
        return listaCredencialRetorno;

    }
    
    public JSONObject obterSimplificadoPorSigla(String sigla) {
        JSONObject json = new JSONObject();
        Object[] nuvem = nuvemWatsonDao.obterSimplificadoPorSigla(sigla);
        
        if (nuvem == null) {
            return null;
        }
        
        Integer id = (Integer) nuvem[0];
        
        json.put("nome", nuvem[1]);
        json.put("tipo_servico", (Integer)nuvem[2] - 1);
        json.put("resposta_nia", nuvem[3]);
        json.put("remover_acento", nuvem[4]);
        json.put("paser_resposta_html", nuvem[5]);
        json.put("usa_quarentena", nuvem[6]);
        json.put("hora_quarentena", nuvem[7]);
        json.put("filtro_numero", nuvem[8]);
        json.put("statusNuvem", nuvem[9]);
        json.put("in_coleta", nuvem[10]);
        json.put("in_converter_emoji", nuvem[11]);
        
        for (Object[] cred : credencialWatsonDao.buscarCredenciaisSimplificado(id)) {
            json.put((String) cred[0], cred[1]);
        }
        
        // for (List<Object[]> credencial : credencialWatsonDao.buscarCredenciaisSimplificado(id)) {
//        for (CredencialWatson credencial : credencialWatsonDao.findByIdNuvemIdParametro(id, null)) {
//            json.put(credencial.getParametroWatson().getTextoTratamentoAcesso(), credencial.getNome());
//
//            if (credencial.getParametroWatson().getTextoTratamentoAcesso() != null
//                    && credencial.getParametroWatson().getTextoTratamentoAcesso().equals("corpus_roteador")
//                    && credencial.getNome() != null && credencial.getNome().equals("true")) {
//                JSONArray corpusRoteaveis = new JSONArray();
//            }            
//        }
//        List<NuvemWatson> corpus = this.findCorpusRoteador(sigla);
//        if (corpus != null) {
//            for (NuvemWatson corpo : corpus) {
//                JSONObject jsonCorpo = new JSONObject();
//                jsonCorpo.accumulate("nome", corpo.getNome());
//                jsonCorpo.accumulate("corpus", corpo.getSiglaNuvem());
//                corpusRoteaveis.put(jsonCorpo);
//            }
//        }
//        json.put("corpus_roteaveis", corpusRoteaveis);
        
        return json;
    }
    
    public List<NuvemWatson> findBySigla(String sigla) {
        return nuvemWatsonDao.findBySigla(sigla);
    }

    public List<NuvemWatson> findCorpusRoteador(String sigla) {
        return nuvemWatsonDao.findCorpusRoteador(sigla);
    }

    public List<NuvemWatsonCredenciaisVO> findListarCredenciaisWatson() {
        List<NuvemWatsonCredenciaisVO> nuvens = new ArrayList<>();
        for (Object[] o : nuvemWatsonDao.findListarCredenciaisWatson()) {
            NuvemWatsonCredenciaisVO nuvem = new NuvemWatsonCredenciaisVO(o);
            nuvens.add(nuvem);
        }
        return nuvens;
    }

    public List<NuvemWatson> findByAssunto(String assunto) {
        return nuvemWatsonDao.findByAssunto(assunto);
    }

    public Paginacao<NuvemWatson> findAll(Paginacao<NuvemWatson> paginacao, String nome, String nomeClassificador,
            String sigla, String workspaceId) {
        return nuvemWatsonDao.findAll(paginacao, nome, nomeClassificador, sigla, workspaceId);
    }

    public NuvemWatson findByClassificadorStatus(Integer idClassificador, StatusNuvem status) {
        return nuvemWatsonDao.findByClassificadorStatus(idClassificador, status);
    }
    
    public List<NuvemWatson> findByClassificadorStatusLista(Integer idClassificador, StatusNuvem status) {
        return nuvemWatsonDao.findByClassificadorStatusLista(idClassificador, status);
    }

    public NuvemWatson atualizarWorkspaceidVersao(NuvemWatson nuvem, VersaoCorpus versaoCorpus, String workspaceid) {
                   nuvem.setWorkspaceId(workspaceid);
        if (workspaceid != null) {
            List<CredencialWatson> credenciais = credencialWatsonDao.findByIdNuvemIdParametro(nuvem.getId(), 3);
            // novo workspace ID
            credenciais.get(0).setNome(workspaceid);
            credencialWatsonDao.persist(credenciais.get(0));
        }
        nuvem.setVersaoCorpusResposta(versaoCorpus);
        return salvar(nuvem);
    }

    public List<NuvemWatsonVO> listarPorClassificadorToVO(Integer idClassificador) {
        List<NuvemWatsonVO> retorno = new ArrayList<>();
        for (NuvemWatson nuvem : nuvemWatsonDao.findByClassificador(idClassificador)) {
            Date ultimaData = sincronizacaoManager.getUltimaDataSincronizacaoByNuvem(nuvem.getId());
            retorno.add(new NuvemWatsonVO(nuvem, ultimaData));
        }
        return retorno;
    }

    public boolean isDialogo(String sigla) {
        return nuvemWatsonDao.isDialogo(sigla);
    }

}
