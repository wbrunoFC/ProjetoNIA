package br.com.bb.gearq.c4coleta.manager;

import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.CenarioEsperadoDao;
import br.com.bb.gearq.c4coleta.model.CenarioEsperado;

@Name("cenarioEsperadoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class CenarioEsperadoManager {

	@In(create = true)
	private CenarioEsperadoDao cenarioEsperadoDao;

	public CenarioEsperado salvar(CenarioEsperado cenarioEsperado) {
        return cenarioEsperadoDao.persist(cenarioEsperado);
	}

	public CenarioEsperado criar(int idSecao) {
		CenarioEsperado cenarioEsperado = new CenarioEsperado();
        cenarioEsperado.setIdSecaoCasoDeTeste(idSecao);
        
        cenarioEsperado.setIdTipoElemento(1); // Intencao
        cenarioEsperado.setIdTipoCondicao(1); // Equals
        
        cenarioEsperado.setTextoElemento("");
        cenarioEsperado = cenarioEsperadoDao.persist(cenarioEsperado);
        return cenarioEsperado;
	}

	public List<CenarioEsperado> findBySecaoCasoDeTeste(Integer idSecao) {
		return cenarioEsperadoDao.findBySecaoCasoDeTeste(idSecao);
	}
	
	public void excluir(CenarioEsperado cenario) {
	    excluir(cenario.getId());        
    }

	public void excluir(Integer id) {
		CenarioEsperado cenarioEsperado = cenarioEsperadoDao.findById(id);
		cenarioEsperadoDao.remove(cenarioEsperado);
	}

	public CenarioEsperado findById(Integer id) {
		return cenarioEsperadoDao.findById(id);
	}

}
