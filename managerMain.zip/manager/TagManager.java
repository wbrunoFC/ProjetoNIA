package br.com.bb.gearq.c4coleta.manager;

import java.util.HashMap;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.TagDao;
import br.com.bb.gearq.c4coleta.model.Tag;

@Name("tagManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class TagManager {

    @In(create = true)
    private TagDao tagDao;

    public Map<String, Tag> listarToMap() {
        Map<String, Tag> map = new HashMap<>();
        for (Tag tag : tagDao.findAll()) {
            map.put(tag.getTag(), tag);
        }
        return map;
    }
    
    public Tag findByUuid(String uuid) {
        return tagDao.findByUuid(uuid);
    }

}
