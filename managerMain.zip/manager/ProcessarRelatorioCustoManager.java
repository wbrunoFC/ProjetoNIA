package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.RelatorioCustoDao;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.RelatorioLog;

@Name("processarRelatorioCustoManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ProcessarRelatorioCustoManager {

	@In(create = true)
	private RelatorioCustoDao relatorioCustoDao;
	
	@In(create = true)
	private NuvemWatsonDao nuvemWatsonDao;
	
	
		
	public void processarCusto(Date data) {
        List<RelatorioLog> listaRelatorioLog = new ArrayList<RelatorioLog>();
		List<NuvemWatson> listaNuvem = nuvemWatsonDao.findAll();
		for(NuvemWatson nw:listaNuvem){
			RelatorioLog item = relatorioCustoDao.consultaDiaria(data, data, nw.getSiglaNuvem());
			if(item != null){
			    
				listaRelatorioLog.add(item);
			}
		}
		for(RelatorioLog log: listaRelatorioLog) {
		    relatorioCustoDao.persist(log);
		}		
		relatorioCustoDao.flush();		
	}
	
}
