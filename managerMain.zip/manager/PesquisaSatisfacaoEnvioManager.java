package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.PesquisaSatisfacaoEnvioDao;
import br.com.bb.gearq.c4coleta.model.PesquisaSatisfacaoEnvio;

@Name("pesquisaSatisfacaoEnvioManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class PesquisaSatisfacaoEnvioManager { 

    @In(create = true)
    private PesquisaSatisfacaoEnvioDao pesquisaSatisfacaoEnvioDao;
  
    public void salvar(PesquisaSatisfacaoEnvio pesquisaSatisfacaoEnvio) { 
        pesquisaSatisfacaoEnvioDao.persist(pesquisaSatisfacaoEnvio);
    }

    public PesquisaSatisfacaoEnvioDao getPesquisaSatisfacaoEnvioDao() {
        return pesquisaSatisfacaoEnvioDao;
    }

    public void setPesquisaSatisfacaoEnvioDao(PesquisaSatisfacaoEnvioDao pesquisaSatisfacaoEnvioDao) {
        this.pesquisaSatisfacaoEnvioDao = pesquisaSatisfacaoEnvioDao;
    }
    
    
    
}
