package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AcessosChatDao;
import br.com.bb.gearq.c4coleta.dao.CanalDao;
import br.com.bb.gearq.c4coleta.dao.ClasseDao;
import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NivelAcessoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.VersaoCorpusDao;
import br.com.bb.gearq.c4coleta.model.AcessosChat;
import br.com.bb.gearq.c4coleta.model.Canal;
import br.com.bb.gearq.c4coleta.model.Classe;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.NivelAcessoClassificador;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.StatusNuvem;
import br.com.bb.gearq.c4coleta.model.TipoRespostaClassificador;
import br.com.bb.gearq.c4coleta.model.VersaoCorpus;
import br.com.bb.sos.infra.MensagemNegocio;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("classificadorManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class ClassificadorManager {

    @In(create = true)
    private NuvemWatsonDao nuvemWatsonDao;
    
    @In(create = true)
    private ClassificadorDao classificadorDao;
    
    @In(create = true)
    private FluxoManager fluxoManager;
    
    @In(create = true)
    private IntencaoManager intencaoManager;
    
    @In(create = true)
    private EntidadeManager entidadeManager;
    
    @In(create = true)
    private DialogoManager dialogoManager;
    
    @In(create = true)
    private SlotManager slotManager;
    
    @In(create = true)
    private RespostaDialogoManager respostaDialogoManager;
    
    @In(create = true)
    private VariavelContextoManager variavelContextoManager;
    
    @In(create = true)
    private CasoDeTesteClassificadorManager casoDeTesteClassificadorManager;
    
    @In(create = true)
    private AssuntoClassificadorManager assuntoClassificadorManager;
    
    @In(create = true)
    private ClasseDao classeDao;
    
    @In(create = true)
    private TipoRespostaClassificadorDao tipoRespostaClassificadorDao;
     
    @In(create = true)
    private VersaoCorpusManager versaoCorpusManager;
    
    @In(create = true)
    private VersaoCorpusExcluidosManager versaoCorpusExcluidosManager;
    
    @In(create = true)
    private VersaoCorpusDao versaoCorpusDao;
    
    @In(create = true)
    private CanalDao canalDao;
    
    @In(create = true)
    private NivelAcessoClassificadorDao nivelAcessoClassificadorDao;
    
    @In(create = true)
    private AcessosChatDao acessosChatDao;
    
    @In(create = true)
    private CacheProgresso cacheProgresso;
    
    public void excluirComBackup(int idClassificador) {
        Classificador classificador = classificadorDao
                .findById(idClassificador);

        if (classificador == null) {
            throw new NegocioException("Classificador não encontrado.");
        }
        
        //Recupera ultima versao do corpus
        VersaoCorpus ultimaVersao = versaoCorpusManager.listarUltimoPorClassificador(idClassificador);
        
        //Recupera versoes dos bots que estao com status de publicado
        List<NuvemWatson> versoesPublicadas = new ArrayList<NuvemWatson>();
        versoesPublicadas = nuvemWatsonDao.findByClassificadorStatusLista(idClassificador, StatusNuvem.PUBLICADO);

        List<VersaoCorpus> listaVersoesPublicadas = new ArrayList<VersaoCorpus>();
        List<String> siglas = new ArrayList<String>();
        if (versoesPublicadas.size() > 0) {
           for (NuvemWatson lista : versoesPublicadas){ 
               listaVersoesPublicadas.add(versaoCorpusManager.findById(lista.getIdVersao()));
               siglas.add(lista.getSiglaNuvem());
           }
        }
        
        //Realiza a exclusao total do corpus
        excluir(idClassificador);
        
        //Grava a ultima versao na tabela de corpus excluidos
        final UsuarioVO funci = (UsuarioVO) Component.getInstance("funci");
        
        if (ultimaVersao.getId() != null) {
            versaoCorpusExcluidosManager.criar(ultimaVersao.getIdClassificador(), ultimaVersao.getDescricao(), ultimaVersao.getVersao(), 
                                               ultimaVersao.getClassificador(), ultimaVersao.getJsonNia(), funci, null);
        }
        
        //Grava versoes publicadas na tabela de corpus excluidos
        if (listaVersoesPublicadas.size() > 0) {
            for (int i = 0; i < listaVersoesPublicadas.size(); i++ ){ 
                versaoCorpusExcluidosManager.criar(listaVersoesPublicadas.get(i).getIdClassificador(), listaVersoesPublicadas.get(i).getDescricao(), listaVersoesPublicadas.get(i).getVersao(), 
                        listaVersoesPublicadas.get(i).getClassificador(), listaVersoesPublicadas.get(i).getJsonNia(), funci, siglas.get(i));
            }
         }
    }
    
    
    public void excluir(int idClassificador) {

        Classificador classificador = classificadorDao
                .findById(idClassificador);

        if (classificador == null) {
            throw new NegocioException("Classificador não encontrado.");
        }
       
        /* List<NuvemWatson> listaNuvem = new ArrayList<NuvemWatson>();
        
        listaNuvem = nuvemWatsonDao.findByClassificador(idClassificador);
        
        if (!listaNuvem.isEmpty()){
            throw new NegocioException(criarMensagemErro(listaNuvem));
        } */
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("ID_CLASSIFICADOR", classificador.getId());
        System.out.println("INICIANDO EXCLUSAO DO CLASSIFICADOR");
        
        apagarDashboard(params);
        apagarFluxo(params);
        apagarDialogo(params);
        apagarHistorico(params);
        apagarCasoDeTeste(params);
        apagarEntidade(params);
        apagarIntencao(params);
        apagarCredenciais(params);
        apagarClassificador(params);
        
        classificadorDao.remove(classificador);
        classificadorDao.flush();
        System.out.println("EXCLUIU CLASSIFICADOR - FIM");

    }

    /**
     * 
     * EXCLUIR RELACIONAMENTO DO DASHBOARD
     * 
     * @param params
     */
    private void apagarDashboard(Map<String, Object> params){
        System.out.println("Excluindo Dashboard");
        
        // excluir intenções dashboard
        String sqlIntDashboard = "DELETE c4gsccdatabase.ITN_DASHBOARD "+
                                 "FROM c4gsccdatabase.ITN_DASHBOARD "+
                                 "JOIN c4gsccdatabase.DASHBOARD on c4gsccdatabase.DASHBOARD.id_dashboard = c4gsccdatabase.ITN_DASHBOARD.id_dashboard "+
                                 "WHERE c4gsccdatabase.DASHBOARD.id_classificador = :ID_CLASSIFICADOR "; 
                                 
        classificadorDao.executeNativeQuery(sqlIntDashboard, params);
        
        
        // excluir usuarios dashboard
        String sqlUsuDashboard = "DELETE c4gsccdatabase.USU_DASHBOARD "+
                                 "FROM c4gsccdatabase.USU_DASHBOARD "+
                                 "JOIN c4gsccdatabase.DASHBOARD on c4gsccdatabase.DASHBOARD.id_dashboard = c4gsccdatabase.USU_DASHBOARD.id_dashboard "+
                                 "WHERE c4gsccdatabase.DASHBOARD.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlUsuDashboard, params);
                                 
        // excluir c4gsccdatabase dashboard
        String sqlDeleteDashboard = "DELETE FROM c4gsccdatabase.DASHBOARD "+
                                    "WHERE c4gsccdatabase.DASHBOARD.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlDeleteDashboard, params);  
        
    }
    
    /**
     * 
     * EXCLUIR RELACIONAMENTO DO FLUXO
     * 
     * @param params
     */
    private void apagarFluxo(Map<String, Object> params){
        System.out.println("Excluindo Fluxo");
        
        // excluir fluxo intenção n tags
        String sqlFluxoIntencaoTags = "DELETE c4gsccdatabase.FLX_ITN_N_TAGS "+
                                      "FROM c4gsccdatabase.FLX_ITN_N_TAGS "+
                                      "JOIN c4gsccdatabase.FLX_ITN on c4gsccdatabase.FLX_ITN.id_flx = c4gsccdatabase.FLX_ITN_N_TAGS.id_flx "+
                                      "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.FLX_ITN.id_itn "+
                                      "WHERE c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlFluxoIntencaoTags, params);
 
        // atualizar fluxo idIntenção
        String sqlFluxoUpdateIdIntencao = "UPDATE c4gsccdatabase.FLX_ITN "+
                                          "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.FLX_ITN.id_itn "+
                                          "AND c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR "+
                                          "SET c4gsccdatabase.FLX_ITN.id_flx_hrq = null ";
                                 
        classificadorDao.executeNativeQuery(sqlFluxoUpdateIdIntencao, params);

        // atualizar fluxo intenção idEntidade
        String sqlFluxoUpdateIdEntidade = "UPDATE c4gsccdatabase.FLX_ITN "+
                                          "JOIN c4gsccdatabase.ENTIDADE on c4gsccdatabase.ENTIDADE.idEntidade = c4gsccdatabase.FLX_ITN.id_entidade "+
                                          "AND c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR "+ 
                                          "SET c4gsccdatabase.FLX_ITN.id_flx_hrq = null ";
                                 
        classificadorDao.executeNativeQuery(sqlFluxoUpdateIdEntidade, params);

        // atualizar fluxo intenção Up Sinonimos
        String sqlFluxoIntencaoUpSinonimos = "UPDATE c4gsccdatabase.FLX_ITN "+
                                             "JOIN c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS on c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idAgruparEntidadeSinonimos = c4gsccdatabase.FLX_ITN.id_agpr_ent "+
                                             "JOIN c4gsccdatabase.ENTIDADE on c4gsccdatabase.ENTIDADE.idEntidade = c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idEntidade "+
                                             "AND c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR "+
                                             "SET c4gsccdatabase.FLX_ITN.id_flx_hrq = null ";
                                 
        classificadorDao.executeNativeQuery(sqlFluxoIntencaoUpSinonimos, params);

        // excluir fluxo intenção Del Sinonimos
        String sqlFluxoIntencaoDelSinonimos = "DELETE c4gsccdatabase.FLX_ITN "+
                                              "FROM c4gsccdatabase.FLX_ITN "+
                                              "JOIN c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS on c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idAgruparEntidadeSinonimos = c4gsccdatabase.FLX_ITN.id_agpr_ent "+
                                              "JOIN c4gsccdatabase.ENTIDADE on c4gsccdatabase.ENTIDADE.idEntidade = c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idEntidade "+
                                              "AND c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR "; 
                                 
        classificadorDao.executeNativeQuery(sqlFluxoIntencaoDelSinonimos, params);

        // excluir fluxo intenção idEntidade
        String sqlFluxoDelIdEntidade = "DELETE c4gsccdatabase.FLX_ITN "+
                                       "FROM c4gsccdatabase.FLX_ITN "+
                                       "JOIN c4gsccdatabase.ENTIDADE on c4gsccdatabase.ENTIDADE.idEntidade = c4gsccdatabase.FLX_ITN.id_entidade "+
                                       "AND c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlFluxoDelIdEntidade, params);

        // excluir fluxo intenção idIntencao
        String sqlFluxoDelIdIntencao = "DELETE c4gsccdatabase.FLX_ITN "+
                                       "FROM c4gsccdatabase.FLX_ITN "+
                                       "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.FLX_ITN.id_itn "+
                                       "AND c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlFluxoDelIdIntencao, params);
        
    }
    
    /**
     * 
     * EXCLUIR RELACIONAMENTO DO DIÁLOGO
     * 
     * @param params
     */
    private void apagarDialogo(Map<String, Object> params){
        System.out.println("Excluindo Dialogo");
        
        // excluir RPST Dialogo
        String sqlRpstDialogo = "DELETE c4gsccdatabase.RPST_DIALOGO "+
                                "FROM c4gsccdatabase.RPST_DIALOGO "+
                                "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.RPST_DIALOGO.id_cx_dialogo = c4gsccdatabase.DIALOGO.id_cx_dialogo "+
                                "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlRpstDialogo, params);

        // excluir Instrução Normativa do Dialogo
        String sqlInDialogo = "DELETE c4gsccdatabase.INSTRUCAO_NORMATIVA_DIALOGO "+
                              "FROM c4gsccdatabase.INSTRUCAO_NORMATIVA_DIALOGO "+
                              "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.DIALOGO.id_cx_dialogo = c4gsccdatabase.INSTRUCAO_NORMATIVA_DIALOGO.id_cx_dialogo "+
                              "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlInDialogo, params);

        // excluir CND do Dialogo
        String sqlCndDialogo = "DELETE c4gsccdatabase.CND_DIALOGO "+
                               "FROM c4gsccdatabase.CND_DIALOGO "+
                               "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.DIALOGO.id_cx_dialogo = c4gsccdatabase.CND_DIALOGO.id_cx_dialogo "+
                               "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlCndDialogo, params);
        
        // excluir Dialogo Tags
        String sqlDialogoTags = "DELETE c4gsccdatabase.DIALOGO_TAGS "+
                                "FROM c4gsccdatabase.DIALOGO_TAGS "+
                                "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.DIALOGO.id_cx_dialogo = c4gsccdatabase.DIALOGO_TAGS.id_dialogo "+
                                "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlDialogoTags, params);

        // excluir Assunto Dialogo 
        String sqlAsntDialogo = "DELETE c4gsccdatabase.ASNT_DIALOGO " +
                                "FROM c4gsccdatabase.ASNT_DIALOGO "+
                                "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.DIALOGO.id_cx_dialogo = c4gsccdatabase.ASNT_DIALOGO.id_cx_dialogo " + 
                                "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlAsntDialogo, params);

        // excluir VRV CTX
        String sqlVrvCtx = "DELETE c4gsccdatabase.VRV_CTX "+
                           "FROM c4gsccdatabase.VRV_CTX "+
                           "WHERE id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlVrvCtx, params);
        
        // excluir RPST Dialogo Slot
        String sqlRpstDialogoSlot = "DELETE c4gsccdatabase.RPST_DIALOGO_SLOT "+
                                    "FROM c4gsccdatabase.RPST_DIALOGO_SLOT "+
                                    "JOIN c4gsccdatabase.SLOTS on c4gsccdatabase.RPST_DIALOGO_SLOT.id_slot = c4gsccdatabase.SLOTS.id_slot "+
                                    "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.SLOTS.id_cx_dialogo = c4gsccdatabase.DIALOGO.id_cx_dialogo "+
                                    "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlRpstDialogoSlot, params);

        // excluir Slot Tags
        String sqlSlotTags = "DELETE c4gsccdatabase.SLOTS_TAGS "+
                             "FROM c4gsccdatabase.SLOTS_TAGS "+
                             "JOIN c4gsccdatabase.SLOTS on c4gsccdatabase.SLOTS_TAGS.id_slots = c4gsccdatabase.SLOTS.id_slot "+
                             "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.SLOTS.id_cx_dialogo = c4gsccdatabase.DIALOGO.id_cx_dialogo "+
                             "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlSlotTags, params);

        // atualizar Dialogo
        String sqlUpdateDialogo = "UPDATE c4gsccdatabase.DIALOGO "+
                                  "SET id_cx_dialogo_hrq = null, id_cx_dialogo_jump = null, id_cx_slot_hrq = null "+
                                  "WHERE id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlUpdateDialogo, params);
        
        // excluir Slots
        String sqlSlots = "DELETE c4gsccdatabase.SLOTS "+
                          "FROM c4gsccdatabase.SLOTS "+
                          "JOIN c4gsccdatabase.DIALOGO on c4gsccdatabase.SLOTS.id_cx_dialogo = c4gsccdatabase.DIALOGO.id_cx_dialogo "+
                          "WHERE c4gsccdatabase.DIALOGO.id_classificador = :ID_CLASSIFICADOR ";
                                 
        classificadorDao.executeNativeQuery(sqlSlots, params);
        
       // excluir Dialogo
        String sqlDelDialogo = "DELETE c4gsccdatabase.DIALOGO "+
                               "FROM c4gsccdatabase.DIALOGO "+
                               "WHERE id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlDelDialogo, params);
    }
   
    
    /**
     * 
     * EXCLUIR RELACIONAMENTO DAS TABELAS DE HISTÓRICO
     * 
     * @param params
     */
    
    private void apagarHistorico(Map<String, Object> params){
        System.out.println("Excluindo Historico");
        
        // excluir Versao corpus 
        String sqlVersaoCorpus = "DELETE c4gsccdatabase.VERSAO_CORPUS "+
                                         "FROM c4gsccdatabase.VERSAO_CORPUS "+
                                         "WHERE c4gsccdatabase.VERSAO_CORPUS.idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlVersaoCorpus, params);
        
        // excluir Resposta Versao Historico
        String sqlRespostaVersaoHistorico = "DELETE c4gsccdatabase.RESPOSTA_VERSAO_HISTORICO "+
                                            "FROM c4gsccdatabase.RESPOSTA_VERSAO_HISTORICO "+
                                            "WHERE c4gsccdatabase.RESPOSTA_VERSAO_HISTORICO.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlRespostaVersaoHistorico, params);
        
    
        // excluir Curadoria Imagem
        String sqlCuradoriaImagem = "DELETE c4gsccdatabase.CURADORIA_IMAGEM "+
                                    "FROM c4gsccdatabase.CURADORIA_IMAGEM "+
                                    "WHERE c4gsccdatabase.CURADORIA_IMAGEM.idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlCuradoriaImagem, params);
  
        // excluir RESP JSON AMBIENTE
        String sqlRespJsonAmbiente = "DELETE c4gsccdatabase.RESP_JSON_AMBIENTE "+
                                     "FROM c4gsccdatabase.RESP_JSON_AMBIENTE "+
                                     "WHERE c4gsccdatabase.RESP_JSON_AMBIENTE.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlRespJsonAmbiente, params);
    }
    
    /**
     * 
     * EXCLUIR RELACIONAMENTO DAS TABELAS DE CASO DE TESTE
     * 
     * @param params
     */
    
    private void apagarCasoDeTeste(Map<String, Object> params){
        System.out.println("Excluindo Caso de Teste");
        
        // excluir Cenario Esperado 
        String sqlCnrEpro = "DELETE c4gsccdatabase.CNR_EPRO " +
                            "FROM c4gsccdatabase.CNR_EPRO " +
                            "JOIN c4gsccdatabase.SCAO_CTST on c4gsccdatabase.SCAO_CTST.id_scao_ctst = c4gsccdatabase.CNR_EPRO.id_scao_ctst " + 
                            "JOIN c4gsccdatabase.CTST_CLASSIFICADOR on c4gsccdatabase.CTST_CLASSIFICADOR.id_ctst_classificador = c4gsccdatabase.SCAO_CTST.id_ctst_classificador " + 
                            "WHERE c4gsccdatabase.CTST_CLASSIFICADOR.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlCnrEpro, params);
    
        // excluir Secao do caso de Teste
        String sqlScaoCtst = "DELETE c4gsccdatabase.SCAO_CTST " +
                             "FROM c4gsccdatabase.SCAO_CTST " +
                             "JOIN c4gsccdatabase.CTST_CLASSIFICADOR on c4gsccdatabase.CTST_CLASSIFICADOR.id_ctst_classificador = c4gsccdatabase.SCAO_CTST.id_ctst_classificador " + 
                             "WHERE c4gsccdatabase.CTST_CLASSIFICADOR.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlScaoCtst, params);
  
        // excluir Caso de Teste
        String sqlCtstClassificador = "DELETE c4gsccdatabase.CTST_CLASSIFICADOR "+
                                      "FROM c4gsccdatabase.CTST_CLASSIFICADOR "+
                                      "WHERE c4gsccdatabase.CTST_CLASSIFICADOR.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlCtstClassificador, params);
    }
        
    /**
     * 
     * EXCLUIR RELACIONAMENTO DE ENTIDADE
     * 
     * @param params
     */
    
    private void apagarEntidade(Map<String, Object> params){
        System.out.println("Excluindo Entidade");
        // excluir Sinonimo
        String sqlSinonimo = "DELETE c4gsccdatabase.SINONIMO "+
                             "FROM c4gsccdatabase.SINONIMO "+
                             "JOIN c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS on c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idAgruparEntidadeSinonimos = c4gsccdatabase.SINONIMO.idAgruparEntidadeSinonimos "+
                             "JOIN c4gsccdatabase.ENTIDADE on c4gsccdatabase.ENTIDADE.idEntidade = c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idEntidade "+
                             "WHERE c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlSinonimo, params);

        // excluir Agrupar Entidade Sinonimo
        String sqlAgruparEntidadeSinonimo = "DELETE c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS "+
                                            "FROM c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS "+
                                            "JOIN c4gsccdatabase.ENTIDADE on c4gsccdatabase.ENTIDADE.idEntidade = c4gsccdatabase.AGRUPAR_ENTIDADE_SINONIMOS.idEntidade "+
                                            "WHERE c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlAgruparEntidadeSinonimo, params);

        // excluir Entidade
        String sqlEntidade = "DELETE c4gsccdatabase.ENTIDADE "+
                             "FROM c4gsccdatabase.ENTIDADE "+
                             "WHERE c4gsccdatabase.ENTIDADE.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlEntidade, params);
    }
    
    /**
     * 
     * EXCLUIR RELACIONAMENTO DE INTENÇÃO
     * 
     * @param params
     */
    
    private void apagarIntencao(Map<String, Object> params){
        System.out.println("Excluindo Intencao");
        
        // excluir Asnt Int
        String sqlAsntInt = "DELETE c4gsccdatabase.ASNT_ITN "+
                            "FROM c4gsccdatabase.ASNT_ITN "+
                            "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.ASNT_ITN.id_itn "+
                            "WHERE c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlAsntInt, params);

        // excluir Instrução Notmativa
        String sqlInstrucaoNormativa = "DELETE c4gsccdatabase.INSTRUCAO_NORMATIVA "+
                                       "FROM c4gsccdatabase.INSTRUCAO_NORMATIVA "+
                                       "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.INSTRUCAO_NORMATIVA.idIntencao "+
                                       "WHERE c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlInstrucaoNormativa, params);

        // excluir Pergunta
        String sqlPergunta = "DELETE c4gsccdatabase.PERGUNTA "+
                             "FROM c4gsccdatabase.PERGUNTA "+
                             "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.PERGUNTA.INTENCAO_idIntencao "+
                             "WHERE c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlPergunta, params);

        // excluir Cla Qst Usu
        String sqlClaQstUsu = "DELETE c4gsccdatabase.CLA_QST_USU "+
                              "FROM c4gsccdatabase.CLA_QST_USU "+
                              "JOIN c4gsccdatabase.PERGUNTA_PARA_REVISAO on c4gsccdatabase.PERGUNTA_PARA_REVISAO.idPerguntaParaRevisao = c4gsccdatabase.CLA_QST_USU.id_qst_itn "+
                              "WHERE c4gsccdatabase.PERGUNTA_PARA_REVISAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlClaQstUsu, params);

        // excluir Qst Rvs Int
        String sqlQstRvsInt = "DELETE c4gsccdatabase.QST_RVS_ITN "+
                              "FROM c4gsccdatabase.QST_RVS_ITN "+
                              "JOIN c4gsccdatabase.PERGUNTA_PARA_REVISAO on c4gsccdatabase.PERGUNTA_PARA_REVISAO.idPerguntaParaRevisao = c4gsccdatabase.QST_RVS_ITN.id_qst_itn "+ 
                              "WHERE c4gsccdatabase.PERGUNTA_PARA_REVISAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlQstRvsInt, params);

        // excluir Qst Ent Agr 
        String sqlQstEntAgr = "DELETE c4gsccdatabase.QST_ENT_AGPR "+
                              "FROM c4gsccdatabase.QST_ENT_AGPR "+
                              "JOIN c4gsccdatabase.PERGUNTA_PARA_REVISAO on c4gsccdatabase.PERGUNTA_PARA_REVISAO.idPerguntaParaRevisao = c4gsccdatabase.QST_ENT_AGPR.id_qst_itn "+
                              "WHERE c4gsccdatabase.PERGUNTA_PARA_REVISAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlQstEntAgr, params);

        // excluir Pergunta para Revisao 
        String sqlPerguntaRevisao = "DELETE "+
                                    "FROM c4gsccdatabase.PERGUNTA_PARA_REVISAO "+
                                    "WHERE CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlPerguntaRevisao, params);

        // excluir Tip Rpst Int
        String sqlTipRpstInt = "DELETE c4gsccdatabase.TIP_RPST_ITN "+
                               "FROM c4gsccdatabase.TIP_RPST_ITN "+
                               "JOIN c4gsccdatabase.INTENCAO on c4gsccdatabase.INTENCAO.idIntencao = c4gsccdatabase.TIP_RPST_ITN.idIntencao "+
                               "WHERE c4gsccdatabase.INTENCAO.CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlTipRpstInt, params);

        // excluir Acmt Itn
        String sqlAcmtItn = "DELETE c4gsccdatabase.ACMT_ITN "+
                            "FROM c4gsccdatabase.ACMT_ITN "+
                            "WHERE id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlAcmtItn, params);

        // excluir Intenção
        String sqlIntencao = "DELETE c4gsccdatabase.INTENCAO "+
                             "FROM c4gsccdatabase.INTENCAO "+
                             "WHERE CLASSIFICADOR_idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlIntencao, params);
    }

    /**
     * 
     * EXCLUIR RELACIONAMENTO DE CREDENCIAIS
     * 
     * @param params
     */
    
    private void apagarCredenciais(Map<String, Object> params){
        System.out.println("Atualizando Credenciais");
        
        // excluir Crdl Watson
        /*String sqlCrdlWatson = "DELETE c4gsccdatabase.CRDL_WATSON "+
                               "FROM c4gsccdatabase.CRDL_WATSON "+
                               "JOIN c4gsccdatabase.NUVEM_WATSON on c4gsccdatabase.CRDL_WATSON.id_nuvem_watson = c4gsccdatabase.NUVEM_WATSON.id_nuvem_watson "+
                               "WHERE c4gsccdatabase.NUVEM_WATSON.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlCrdlWatson, params); */

        // update Nuvem Watson
        String sqlNuvemWatson = "UPDATE c4gsccdatabase.NUVEM_WATSON "+
                                "SET c4gsccdatabase.NUVEM_WATSON.id_classificador = null "+
                                "WHERE id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlNuvemWatson, params);

        // excluir Tip Rpst Classificador
         String sqlTipRpstClassificador = "DELETE c4gsccdatabase.TIP_RPST_CLASSIFICADOR "+
                                         "FROM c4gsccdatabase.TIP_RPST_CLASSIFICADOR "+
                                         "WHERE id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlTipRpstClassificador, params); 
    }

    /**
     * 
     * EXCLUIR RELACIONAMENTO DE CLASSIFICADOR
     * 
     * @param params
     */
    
    private void apagarClassificador(Map<String, Object> params){
        System.out.println("Excluindo relacionamentos com o Classificador");
        
        // excluir Asnt Classificador
        String sqlAsntClassificador = "DELETE c4gsccdatabase.ASNT_CLASSIFICADOR "+
                                      "FROM c4gsccdatabase.ASNT_CLASSIFICADOR "+
                                      "WHERE c4gsccdatabase.ASNT_CLASSIFICADOR.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlAsntClassificador, params);

        // excluir Canal Classificador
        String sqlClassificadorCanal = "DELETE c4gsccdatabase.CLASSIFICADOR_CANAL "+
                                       "FROM c4gsccdatabase.CLASSIFICADOR_CANAL "+
                                       "WHERE c4gsccdatabase.CLASSIFICADOR_CANAL.idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlClassificadorCanal, params);
        
        // excluir Historido Estado Classificador
        String sqlHstEstClassificador = "DELETE c4gsccdatabase.HST_EST_CLASSIFICADOR "+
                                        "FROM c4gsccdatabase.HST_EST_CLASSIFICADOR "+
                                        "WHERE c4gsccdatabase.HST_EST_CLASSIFICADOR.id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlHstEstClassificador, params);
        
        // excluir Mensagem Sentimento
        String sqlMensagemSentimento = "DELETE c4gsccdatabase.MENSAGEM_SENTIMENTO "+
                                       "FROM c4gsccdatabase.MENSAGEM_SENTIMENTO "+
                                       "WHERE c4gsccdatabase.MENSAGEM_SENTIMENTO.idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlMensagemSentimento, params);
        
        // excluir Prm Alerta
        String sqlPrmAlerta = "DELETE c4gsccdatabase.PRM_ALERTA "+
                              "FROM c4gsccdatabase.PRM_ALERTA "+
                              "WHERE id_classificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlPrmAlerta, params);
        
        // excluir Nivel Acesso Classificador
        String sqlNivelAcessoClassificador = "DELETE c4gsccdatabase.NIVEL_ACESSO_CLASSIFICADOR "+
                                             "FROM c4gsccdatabase.NIVEL_ACESSO_CLASSIFICADOR "+
                                             "WHERE c4gsccdatabase.NIVEL_ACESSO_CLASSIFICADOR.idClassificador = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlNivelAcessoClassificador, params);

        // excluir Sncz Base Cnh
        String sqlSnczBaseCnh = "DELETE c4gsccdatabase.SNCZ_BASE_CNH "+
                                "FROM c4gsccdatabase.SNCZ_BASE_CNH "+
                                "WHERE id_base_cnh = :ID_CLASSIFICADOR ";
        
        classificadorDao.executeNativeQuery(sqlSnczBaseCnh, params);
    }
    
    private List<MensagemNegocio> criarMensagemErro(List<NuvemWatson> nuvemWatson) {
        List<MensagemNegocio> mensagens = new ArrayList<MensagemNegocio>();
        MensagemNegocio msg = new MensagemNegocio();
        if (nuvemWatson.size() > 1 ){
            msg.setTextoMensagem("Existem credenciais cadastradas com este Classificador. Para realizar a exclusão do mesmo, é necessário que sejam excluídas as seguintes credenciais:");
        }else if (nuvemWatson.size() ==  1){
            msg.setTextoMensagem("Existe credencial cadastrada com este Classificador. Para realizar a exclusão do mesmo, é necessário que seja excluída a seguinte credencial:");
        }
        mensagens.add(msg);
        for(NuvemWatson lista: nuvemWatson){
            msg = new MensagemNegocio();
            msg.setTextoMensagem("- " + lista.getNome());
            mensagens.add(msg);
        }
        return mensagens;
    }
    
    public Classificador getClassificadorPorServico(String sigla) {
        List<Classificador> lista = classificadorDao.findByServicoInfra(sigla);
        if (!lista.isEmpty()) {
            return lista.get(0);
        }
        return null;
    }

    public Classificador obter(Integer idClassificador) {
        return classificadorDao.findById(idClassificador);
    }


	public void limpar(Integer idClassificador) {
	    String nomeItem = "RECOVERY_" + idClassificador + "_PROGRESSO";
	    
	    cacheProgresso.atualizar(nomeItem, 1, "Removendo Fluxos das Intenções");
        fluxoManager.limparPorClassificador(idClassificador);
        
        cacheProgresso.atualizar(nomeItem, 1, "Removendo Intenções");
		intencaoManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 2, "Removendo Entidades");
		entidadeManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 3, "Removendo Respostas");
		respostaDialogoManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 3, "Removendo Slots");
		slotManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 3, "Removendo Nós do Dialogo");
		dialogoManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 4, "Removendo Variaveis de Contexto");
		variavelContextoManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 4, "Removendo Casos de Teste");
		casoDeTesteClassificadorManager.limparPorClassificador(idClassificador);
		
		cacheProgresso.atualizar(nomeItem, 4, "Removendo Assuntos");
		assuntoClassificadorManager.limparPorClassificador(idClassificador);
	}

    public List<TipoRespostaClassificador> listarTiposResposta(Integer idClassificador) {
        return tipoRespostaClassificadorDao.findByClassificador(idClassificador);
    }

    public Classificador salvar(Classificador classificador) {
        if (classificador.getId() == null) {
            classificadorDao.persist(classificador);
        }
        for(Classe classe : classificador.getClasses()) {
            classe.setClassificador(classificador);
            classeDao.persistAndFlush(classe);
        }
        
        if( classificador.getTipoRespostas() != null ){         
            for( TipoRespostaClassificador resp : classificador.getTipoRespostas() ){
                resp.setClassificador(classificador);
                tipoRespostaClassificadorDao.persistAndFlush(resp);
            }
        }
        if( classificador.getCanais() != null ){
            for( Canal canal : classificador.getCanais() ){
                canalDao.persistAndFlush(canal);
            }
        }
        
        if(classificador.getNivelAcesso() != null) {
            for(NivelAcessoClassificador ni : classificador.getNivelAcesso()) {
                ni.setClassificador(classificador);
                nivelAcessoClassificadorDao.persist(ni);
            }
        }
        if(classificador.getAcessoChat() != null) {
            for(AcessosChat ac : classificador.getAcessoChat()) {
                ac.setClassificador(classificador);
                acessosChatDao.persist(ac);
            }
        }
        classificadorDao.persist(classificador);
        return classificador;
    }
}

 
