package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.json.JSONArray;
import org.json.JSONObject;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.NuvemWatsonDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoEntidadeDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.NuvemWatson;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoEntidade;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoIntencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.util.JSONUtils;

@Name("feedbackManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class FeedbackManager {

	@In(create = true)
	private NuvemWatsonDao nuvemWatsonDao;

	@In(create = true)
	private IntencaoDao intencaoDao;

	@In(create = true)
	private PerguntaRevisaoDao perguntaRevisaoDao;

	@In(create = true)
	private PerguntaDao perguntaDao;

	@In(create = true)
	private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
	
	@In(create = true)
	private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;
	
	@In(create = true)
	private PerguntaRevisaoEntidadeDao perguntaRevisaoEntidadeDao;
	
	@In(create = true)
    private ClassificadorManager classificadorManager;

	public void registrarFeedback(String siglaTipoServico, Boolean feedback,
			Boolean email,String usuario, String json) {

		// verifica se a entrada possui os valores nescessário para realizar o
		// feedback
		if (siglaTipoServico != null && siglaTipoServico.trim().length() > 0
				&& JSONUtils.getJson(json) != null) {

			JSONObject resp = JSONUtils.getJson(json);
			
			// recupera o serviço pela sigla
			Classificador classificador = classificadorManager.getClassificadorPorServico(siglaTipoServico);
			
			if (classificador != null) {
				String input = getInput(resp);

				if (input != null && input.trim().length() > 0) {
					if( feedback == null ){
					    // Verificar se a pergunta já foi usada como exemplo em alguma intenção
						Pergunta exemplo = getPerguntaCorpus(classificador.getId(), input);
						coletar(input, classificador, usuario, email, json, 1, exemplo != null, null);
					}else if( feedback ){
						feedbackPosistivo(input, classificador, usuario, email, resp);
					}else  if( !feedback ){
						feedbackNegativo(input, classificador, usuario, email, resp);
					}
				}
				
			}

		}
	}
	
	/**
	 * Coletar pergunta sem feedback
	 * @param data 
	 * @param perguntaRevisao
	 */
	public void coletar(String input, Classificador corpus, String usuario, Boolean email, String json, Integer quantidade, Boolean temExemplo, Date data){
	    
	    PerguntaRevisaoStatus status = PerguntaRevisaoStatus.REVISAO;
		if( temExemplo ){
		    status = PerguntaRevisaoStatus.AUTOMATICO;
		}
		
		if (corpus == null)
		    return;
		
		PerguntaRevisao perguntaRevisao = recuperarPerguntaRevisao(input, usuario, email, corpus, status, data, json);
		
		perguntaRevisao.setQuantidade(perguntaRevisao.getQuantidade() + quantidade);
        
		if( temExemplo && (perguntaRevisao.getId() == null || perguntaRevisao.getId() == 0) ){
			perguntaRevisao.setStatus(PerguntaRevisaoStatus.AUTOMATICO);
		}
		JSONObject resp = new JSONObject(json);
		persistePerguntaRevisao(perguntaRevisao, resp, usuario, email,null);
	}
	
	/**
	 * Coletar pergunta com feedback positivo
	 * @param perguntaRevisao
	 */
	private void feedbackPosistivo(String input, Classificador corpus, String usuario, Boolean email, JSONObject resp){
		PerguntaRevisao perguntaRevisao = null;
		Pergunta pergunta = getPerguntaCorpus(corpus.getId(),input);
		if(pergunta != null){
			perguntaRevisao =  recuperarPerguntaRevisao(input, usuario, email, corpus, PerguntaRevisaoStatus.AUTOMATICO, null, null);
			if( perguntaRevisao.getId() != null ){
				perguntaRevisao.setQuantidade(perguntaRevisao.getQuantidade() + 1);
			}
			perguntaRevisao.setIntencao(pergunta.getIntencao());
			perguntaRevisao.setVinculada(pergunta.getIntencao() != null);
			perguntaRevisao.setStatus(PerguntaRevisaoStatus.AUTOMATICO);
		}else{
			perguntaRevisao =  recuperarPerguntaRevisao(input, usuario, email, corpus, PerguntaRevisaoStatus.REVISAO, null, null);
		}
		
		if( perguntaRevisao.getQtdPositivo() == null ){
			perguntaRevisao.setQtdPositivo(0);
		}
		
		perguntaRevisao.setQtdPositivo(perguntaRevisao.getQtdPositivo()+1);
		
		persistePerguntaRevisao(perguntaRevisao, resp, usuario, email,true);
	}
	
	/**
	 * Coletar pergunta com feedback negativo
	 * @param perguntaRevisao
	 */
	private void feedbackNegativo(String input, Classificador corpus, String usuario, Boolean email, JSONObject resp){
		PerguntaRevisao perguntaRevisao =  recuperarPerguntaRevisao(input, usuario, email, corpus, PerguntaRevisaoStatus.REVISAO, null, null);
		// enviar email para o usuário
		if( email != null && email && usuario != null && usuario.trim().length() > 0){
			perguntaRevisao.setStatus(PerguntaRevisaoStatus.REVISAO_PRIORITARIA);
		}
		
		if( perguntaRevisao.getQtdNegativo() == null ){
			perguntaRevisao.setQtdNegativo(0);
		}
		if( email == null || !email ){
			perguntaRevisao.setQtdNegativo(perguntaRevisao.getQtdNegativo()+1);
		}
		
		persistePerguntaRevisao(perguntaRevisao, resp, usuario, email,false);
	}
	
	/**
	 * verifica se a pergunta já foi cadastrada no corpus
	 * @param idClassificador
	 * @param pergunta
	 * @return
	 */
	private Pergunta getPerguntaCorpus(Integer idClassificador, String pergunta){
		List<Pergunta> perguntas = perguntaDao.findIgual(idClassificador, pergunta);
		if( perguntas != null && !perguntas.isEmpty() ){
			return perguntas.get(0);
		}else{
			return null;
		}
			
	}

    /**
     * Recuperar ou intencia um novo objeto de pergunta revisão
     * @param feedback
     * @param usuario
     * @param email
     * @param corpus
     * @param data 
     * @param resp
     * @return
     */
	private PerguntaRevisao recuperarPerguntaRevisao(String input,
			String usuario, Boolean email, Classificador corpus, PerguntaRevisaoStatus status, Date data, String jsonResposta) {
	    
		List<PerguntaRevisao> perguntas = perguntaRevisaoDao.findPergunta(input, corpus.getId(), status);
		
		if (perguntas.isEmpty()) {
		    return criarPerguntaRevisao(input, corpus, data);
		}
		
		PerguntaRevisao pergunta = perguntas.get(0);
				
		// verifica se na lista existe alguma pergunta prioritária
		if( email != null && email && usuario != null && usuario.trim().length() > 0 && perguntas.size() > 1){
			for( PerguntaRevisao p : perguntas ){
				if( p.getStatus().equals(PerguntaRevisaoStatus.REVISAO_PRIORITARIA) ){
					pergunta = p;
					break;
				}
			}
		}
		
		// Se já for curada, verifica se a intenção mudou		        
        if( !(pergunta.getStatus().equals(PerguntaRevisaoStatus.REVISAO_PRIORITARIA) || pergunta.getStatus().equals(PerguntaRevisaoStatus.REVISAO)) && jsonResposta!=null ){
            JSONObject resp = new JSONObject(jsonResposta);
            List<PerguntaRevisaoIntencao> intencoesPergunta = getIntencoes(resp, pergunta);
            if((!intencoesPergunta.isEmpty())) {
                if(pergunta.getNomeIntencao() != null && !pergunta.getNomeIntencao().equalsIgnoreCase(intencoesPergunta.get(0).getNome())) {
                    return criarPerguntaRevisao(input, corpus, data);
                }
            }else {
                return criarPerguntaRevisao(input, corpus, data);
            }
        }
		
		if(pergunta.getQuantidade() == null) {
		    pergunta.setQuantidade(0);
        }
		
		return pergunta;
	}

    private PerguntaRevisao criarPerguntaRevisao(String input, Classificador corpus, Date data) {
        PerguntaRevisao pergunta = new PerguntaRevisao();
        Date dataCriacao = data == null ? new Date(): data; 
        pergunta.setDataCriacao(dataCriacao);
        pergunta.setPergunta(input);
        pergunta.setQuantidade(0);
        pergunta.setClassificador(corpus);
        pergunta.setVinculada(false);
        pergunta.setQtdNegativo(0);
        pergunta.setQtdPositivo(0);
        pergunta.setStatus(PerguntaRevisaoStatus.REVISAO);
        return pergunta;
    }
	/**
	 * recupera o servico na base de acordo com a sigla que foi utilizada no watson
	 * @param siglaTipoServico
	 * @param resp
	 * @return
	 */
	private Classificador getClassificadorPorServico(String siglaTipoServico) {
		List<NuvemWatson> nuvens = nuvemWatsonDao.findBySigla(siglaTipoServico);
		if (!nuvens.isEmpty()) {
		    NuvemWatson nuvem = nuvens.get(0);
		    return nuvem.getClassificador();
		}
		return null;
	}
	
	
	/**
	 * grava na base de dados a pergunta para revisão
	 * @param perguntaRevisao
	 * @param resp
	 * @param usuario
	 * @param email
	 */
	private void persistePerguntaRevisao(PerguntaRevisao perguntaRevisao,JSONObject resp, String usuario, Boolean email, Boolean feedback) {
	    
	    boolean isnovo = true;
	    if (perguntaRevisao.getId() != null && perguntaRevisao.getId() != 0) {
	        isnovo = false;	        
	    }
		
		perguntaRevisaoDao.persist(perguntaRevisao);
		
		List<PerguntaRevisaoIntencao> intencoesPergunta = null;
		if (isnovo) {
		    // Intencoes
		    intencoesPergunta = getIntencoes(resp, perguntaRevisao);
		    PerguntaRevisaoIntencao relevante = null;
		    for( PerguntaRevisaoIntencao intencao : intencoesPergunta ){
		        if( relevante == null || (relevante.getConfianca() != null && relevante.getConfianca().compareTo(intencao.getConfianca())<0) ){
		            relevante = intencao;
		        }
		        perguntaRevisaoIntencaoDao.persist(intencao);
		    }
		    
		    if (relevante != null) {
		        perguntaRevisao.setIdIntencaoRevisao(relevante.getId());
		    }
		    
		    List<PerguntaRevisaoEntidade> entidades = getEntidades(resp, perguntaRevisao);
            for( PerguntaRevisaoEntidade entidade : entidades ){
                perguntaRevisaoEntidadeDao.persist(entidade);
            }
		    
		}
		
		//atualiza usuarios
		String conversationId = getConversationId(resp);
		
		PerguntaRevisaoUsuario pru = null;
		if (!isnovo) {
		    List<PerguntaRevisaoUsuario> usuarios = perguntaRevisaoUsuarioDao.findPergunta(usuario, conversationId, perguntaRevisao.getId());
		    if (!usuarios.isEmpty()) {
		        pru = usuarios.get(0);
		        if( email && usuario != null && usuario.trim().length() > 0){
	                pru.setEmail(email);
	            }
	            if( feedback != null){
	                pru.setFeedback(feedback);
	            }
		    }
		    
		}
		
		if (pru == null) {
		    pru = new PerguntaRevisaoUsuario();
		    pru.setEmail(email);
		    pru.setUsuario(usuario);
		    pru.setIdConversa(conversationId);
		    pru.setPerguntaRevisao(perguntaRevisao);
		    pru.setFeedback(feedback);
		}
		
		perguntaRevisaoUsuarioDao.persist(pru);
		
		if( perguntaRevisao.getStatus().equals(PerguntaRevisaoStatus.REVISAO) || 
				perguntaRevisao.getStatus().equals(PerguntaRevisaoStatus.REVISAO_PRIORITARIA) || 
				perguntaRevisao.getStatus().equals(PerguntaRevisaoStatus.CURADA_REDUCAO)){
			
			//Redução da curadoria
			Classificador corpus = perguntaRevisao.getClassificador();
			if( corpus != null && corpus.getReducaoCuradoria() != null && corpus.getReducaoCuradoria()){
				
				//não possui feedback negativo
				if( perguntaRevisao.getQtdNegativo() == 0 ){
					
					//possui feedback positivo
					if( perguntaRevisao.getQtdPositivo() > 0 ){
						
						perguntaRevisao.setStatus(PerguntaRevisaoStatus.CURADA_REDUCAO);
						
					}else if( intencoesPergunta != null && !intencoesPergunta.isEmpty() ){
						PerguntaRevisaoIntencao primeira = intencoesPergunta.get(0);
						PerguntaRevisaoIntencao segunda = intencoesPergunta.size() > 1 ? intencoesPergunta.get(1) : null;
						
						// percentual de confiaça maior ou igual ao percentual do corpus
						if ( 
						      primeira.getConfianca() != null && corpus.getPorcentagemCuradoria() != null 
						   && primeira.getConfianca() >= ((double)corpus.getPorcentagemCuradoria() / 100.0)							
						   && segunda != null && segunda.getConfianca() != null 
						   && (primeira.getConfianca() - segunda.getConfianca()) >= ((double)corpus.getPorcentagemIntencao() / 100.0)
			            ) {
	                            perguntaRevisao.setStatus(PerguntaRevisaoStatus.CURADA_REDUCAO);
						
						} 
						//diferença entre o percentual da intenção 1 com a intenção 2 maior ou igual ao percentual do corpus
						
					}
					
				//muda o status da inteção caso receba um feedback negativo e o status for igual a CURADA_REDUCAO 	
				}else if( perguntaRevisao.getStatus().equals(PerguntaRevisaoStatus.CURADA_REDUCAO) ){
					perguntaRevisao.setStatus(email?PerguntaRevisaoStatus.REVISAO_PRIORITARIA:PerguntaRevisaoStatus.REVISAO);
				}
				
			}
			
			
			//Tratar respostas mini roteador
//			if( !perguntaRevisao.getStatus().equals(PerguntaRevisaoStatus.CURADA_REDUCAO) ){
//				List<PerguntaRevisao> perguntas = perguntaRevisaoDao.findIgual(perguntaRevisao.getPergunta());
//				if( perguntas != null && perguntas.size() > 0 ){
//					PerguntaRevisaoIntencao maior =  getIntencaoMaiorRelevancia(perguntaRevisao, intencoesPergunta);
//					for( PerguntaRevisao pergunta : perguntas ){
//						if( !pergunta.getId().equals(perguntaRevisao.getId()) ){
//							PerguntaRevisaoIntencao atual =  getIntencaoMaiorRelevancia(perguntaRevisao, intencoesPergunta);
//							if( maior != null ){
//								if( atual != null && atual.getConfianca() != null && 
//										maior != null && maior.getConfianca() != null &&
//										atual.getConfianca().compareTo(maior.getConfianca()) == 1 ){
//									maior = atual;
//								}
//							}else{
//								maior = atual;
//							}
//						}
//					}
//					
//					
//					if( maior != null && maior.getPerguntaRevisao() != null ){
//						
//						for( PerguntaRevisao pergunta : perguntas ){
//							if( maior.getPerguntaRevisao() != null && maior.getPerguntaRevisao().getId().equals(pergunta.getId()) ){
//								pergunta.setStatus(email?PerguntaRevisaoStatus.REVISAO_PRIORITARIA:PerguntaRevisaoStatus.REVISAO);
//							}else{
//								pergunta.setStatus(PerguntaRevisaoStatus.AUTOMATICO);
//							}
//						}
//						
//					}
//				}
//			}
		}

		perguntaRevisaoDao.flush();
		
	}
	
	public PerguntaRevisaoIntencao getIntencaoMaiorRelevancia(PerguntaRevisao pergunta,List<PerguntaRevisaoIntencao> intencoes){
		
		if( intencoes != null && intencoes.size() > 0 ){
			return intencoes.get(0);
		}else{
			intencoes = perguntaRevisaoIntencaoDao.findByPerguntaRevisaoIntencoes(pergunta.getId());
			return intencoes != null && intencoes.size() > 0?intencoes.get(0):null;
		}
		
	}
	

	/**
	 * recuperar as intenções relacionadas
	 * 
	 * @param resp
	 * @return
	 */
	private List<PerguntaRevisaoIntencao> getIntencoes(JSONObject resp,PerguntaRevisao perguntaRevisao) {

		List<PerguntaRevisaoIntencao> intencoes = new ArrayList<PerguntaRevisaoIntencao>();
		JSONArray intents = JSONUtils.getJsonArray(resp, "intents");

		if (intents != null && perguntaRevisao != null) {

			List<String> nomeIntencoes = new ArrayList<String>();

			// monta o objeto PerguntaRevisaoIntencao
			for (int i = 0; i < intents.length(); i++) {
				JSONObject intent = intents.getJSONObject(i);
				PerguntaRevisaoIntencao intencao = new PerguntaRevisaoIntencao();
				if(JSONUtils.getValue(intent,"confidence") != null){
					intencao.setConfianca(Double.parseDouble(""+JSONUtils.getValue(intent,"confidence")));
				}else{
					intencao.setConfianca(0.0);
				}
				intencao.setNome((String) JSONUtils.getValue(intent, "intent"));
				intencao.setPerguntaRevisao(perguntaRevisao);
				intencoes.add(intencao);

				// adiciona o nome a lista para pesquisa
				if (intencao.getNome() != null) {
					nomeIntencoes.add(intencao.getNome());
				}
			}

			// Recuperar as intenções do corpus para vincular a
			// PerguntaRevisaoIntencao;
			if( nomeIntencoes != null && nomeIntencoes.size() > 0 ){

				List<Intencao> intencoesCorpus = intencaoDao.findByNomes(
						nomeIntencoes, perguntaRevisao.getClassificador().getId());
				
				if (intencoesCorpus != null) {
					for (Intencao intencao : intencoesCorpus) {
						for (PerguntaRevisaoIntencao intencaoPergunta : intencoes) {
							if (intencao.getNome().equalsIgnoreCase(
									intencaoPergunta.getNome())) {
								intencaoPergunta.setIntencao(intencao);
							}
						}
					}
					
				}
			}

		}

		return intencoes;
	}
	
	/**
	 * recuperar as entidades relacionadas
	 * @param resp
	 * @return
	 */
	private List<PerguntaRevisaoEntidade> getEntidades(JSONObject resp,PerguntaRevisao perguntaRevisao) {

		List<PerguntaRevisaoEntidade> entidades = new ArrayList<PerguntaRevisaoEntidade>();
		JSONArray entities = JSONUtils.getJsonArray(resp, "entities");

		if (entities != null && perguntaRevisao != null) {

			for (int i = 0; i < entities.length(); i++) {
				JSONObject entity = entities.getJSONObject(i);
				PerguntaRevisaoEntidade entidade = new PerguntaRevisaoEntidade();
				entidade.setEntidade((String) JSONUtils.getValue(entity,"entity"));
				entidade.setAgrupador((String) JSONUtils.getValue(entity,"value"));
				entidade.setPerguntaRevisao(perguntaRevisao);
				boolean possui = false;
				for( PerguntaRevisaoEntidade e : entidades ){
					if( e.getEntidade().equals(entidade.getEntidade()) && e.getAgrupador().equals(entidade.getAgrupador()) ){
						possui = true;
						break;
					}
				}
				
				if( !possui ){
					entidades.add(entidade);
				}
			}
		}

		return entidades;
	}
	
	/**
	 * recuperar pergunta feita pelo usuário
	 * 
	 * @return
	 */
	private String getInput(JSONObject resp) {
		JSONObject jInput = JSONUtils.getJson(resp, "input");

		if (jInput != null) {
			String input = (String) JSONUtils.getValue(jInput, "text");
			return input != null?input.trim():null;
		}

		return null;
	}

	private String getConversationId(JSONObject resp) {
		JSONObject context = JSONUtils.getJson(resp, "context");
		if (JSONUtils.isJSONObject(context, "conversation_id")) {
			context = JSONUtils.getJson(context, "conversation_id");
		}
		if (context != null) {
			return (String) JSONUtils.getValue(context, "conversation_id");
		} else {
			return (String) JSONUtils.getValue(resp, "conversation_id");
		}
	}

}
