package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.cache.ItemCacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AvaliacoesDao;
import br.com.bb.gearq.c4coleta.model.Avaliacoes;
import br.com.bb.gearq.c4coleta.vo.FiltroAvaliacoesVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.avaliacao.AvaliacoesVO;

@Name("avaliacoesManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class AvaliacoesManager {

    @In(create = true)
    private AvaliacoesDao avaliacoesDao;
    
    @In(create = true)
    private CacheProgresso cacheProgresso;
    
    public Paginacao<AvaliacoesVO> listar(FiltroAvaliacoesVO filtroAvaliacoesVO) {
        
        Paginacao<Avaliacoes> paginacao = avaliacoesDao.pesquisar(filtroAvaliacoesVO);
        
        Paginacao<AvaliacoesVO> paginacaoVO = new Paginacao<>();
        
        List<AvaliacoesVO> avalicoesVO = transformarParaVo(paginacao.getListaPaginada());
        paginacaoVO.setListaPaginada(avalicoesVO);        
        paginacaoVO.setPaginaAtual(paginacao.getPaginaAtual());
        paginacaoVO.setPaginasTotal(paginacao.getPaginasTotal());
        paginacaoVO.setRegistrosPagina(paginacao.getRegistrosPagina());
        paginacaoVO.setTotalRegistros(paginacao.getTotalRegistros());        

        return paginacaoVO;
    }
    
    
    private List<AvaliacoesVO> transformarParaVo(List<Avaliacoes> avaliacoes) {
        List<AvaliacoesVO> avaliacoesVo = new ArrayList<>();
        for (Avaliacoes av : avaliacoes) {
            AvaliacoesVO avaliacaoVo = new AvaliacoesVO(av);
            avaliacoesVo.add(avaliacaoVo);
        }
        return avaliacoesVo;        
    }



    public void gravarAvaliacao(FiltroAvaliacoesVO filtroAvaliacoesVO){
        avaliacoesDao.gravarAvaliacao(filtroAvaliacoesVO);
    }
    
    public List<Avaliacoes> listarAll(){
        List<Avaliacoes>  lista =   avaliacoesDao.listaAll();
        
    return lista;    
    }
    
    public void getAvaliacoes(){
        
        String nomeItem = "PROGRESSO";
        ItemCacheProgresso item = new ItemCacheProgresso();
        item.setId(nomeItem);
        item.setAndamento(0);
        item.setTotal(4);
        item.setConteudo(null);
        cacheProgresso.atualizar(item);
        
        List<Avaliacoes> avaliacoes =  avaliacoesDao.listaAll();
        
        item.setAndamento(3);
        cacheProgresso.atualizar(item);
        
        StringBuilder string = new StringBuilder();
        
        string.append("\"Id Avaliação Conversa\", \"Chave\",\"Nota\", \"Motivo\",\"Data Hora\",\"ConversationID\",\"Outros\"\r\n");
        
        for(Avaliacoes avaliacao : avaliacoes ){
            string.append("\"");
            string.append(avaliacao.getId());
            string.append("\"");
            string.append(",");
            string.append("\"");
            string.append(avaliacao.getChave());
            string.append("\"");
            string.append(",");
            string.append("\"");
            string.append(avaliacao.getNota());
            string.append("\"");
            string.append(",");
            string.append("\"");
            string.append(avaliacao.getAvaliacaoMotivo().getNome());
            string.append("\"");
            string.append(",");
            string.append("\"");
            string.append(avaliacao.getDataHora());
            string.append("\"");
            string.append(",");
            string.append("\"");
            string.append(avaliacao.getConversationID());
            string.append("\"");
            string.append(",");
            string.append("\"");
            string.append(avaliacao.getOutros());
            string.append("\"");
            string.append("\r\n");
            string.append(avaliacao.getOrigem());
            string.append("\"");
            string.append("\r\n");
        }
        item.setAndamento(4);
        item.setConteudo(string.toString());
        cacheProgresso.atualizar(item);
    }

    public void pesquisar(Avaliacoes capture) {
        // TODO Auto-generated method stub
        
    }

	
}
