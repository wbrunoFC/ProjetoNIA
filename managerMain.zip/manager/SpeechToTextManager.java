package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.SpeechToTextDao;
import br.com.bb.gearq.c4coleta.model.SpeechToText;

@Name("speechToTextManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class SpeechToTextManager {
    
    @In(create = true)
    private SpeechToTextDao speechToTextDao;

    public SpeechToText  salvarArquivoGed(SpeechToText speechToText){
        speechToText = speechToTextDao.persist(speechToText);
        return speechToText;
    }
}
