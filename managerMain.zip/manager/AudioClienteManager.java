package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.AudioClienteDao;
import br.com.bb.gearq.c4coleta.dao.SpeechToTextDao;
import br.com.bb.gearq.c4coleta.model.AudioCliente;
import br.com.bb.gearq.c4coleta.model.SpeechToText;

@Name("audioclienteManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class AudioClienteManager {
    
    @In(create = true)
    private AudioClienteDao audioclienteDao;

    public AudioCliente  salvarArquivoGed(AudioCliente audioCliente){
        audioCliente = audioclienteDao.persist(audioCliente);
        return audioCliente;
    }
}
