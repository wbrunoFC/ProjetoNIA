package br.com.bb.gearq.c4coleta.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import br.com.bb.gearq.c4coleta.cache.CacheProgresso;
import br.com.bb.gearq.c4coleta.dao.AssuntoClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.CasoDeTesteClassificadorDao;
import br.com.bb.gearq.c4coleta.model.AssuntoClassificador;
import br.com.bb.gearq.c4coleta.model.CasoDeTesteClassificador;
import br.com.bb.gearq.c4coleta.versionamento.v1.AssuntoClassificadorVersaoV1;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("assuntoClassificadorManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class AssuntoClassificadorManager {

    @In(create = true)
    private AssuntoClassificadorDao assuntoClassificadorDao;
    
    @In(create = true)
    private CasoDeTesteClassificadorDao casoDeTesteClassificadorDao;
    
    @In(create = true)
    private CacheProgresso cacheProgresso;
    
    public List<AssuntoClassificadorVersaoV1> listarVersao(Integer idClassificador) {
        List<AssuntoClassificadorVersaoV1> assuntosVersao = new ArrayList<>();
        
        List<AssuntoClassificador> assuntos = assuntoClassificadorDao.listarVersao(idClassificador);
        for (AssuntoClassificador assunto : assuntos) {
            assuntosVersao.add(new AssuntoClassificadorVersaoV1(assunto));
        }

        return assuntosVersao;
    }
    
    public AssuntoClassificador salvar(int idClassificador, AssuntoClassificador assuntoClassificador) {
        boolean assuntoAlterado = false;
        String nomeAssuntoFormulario = assuntoClassificador.getNome();
        if(assuntoClassificador.getId()==null || assuntoClassificador.getId() == 0){
            if (!isAssuntoCadastrado(idClassificador, assuntoClassificador)) {
                assuntoClassificador.setDataCriacao(new Date());
                assuntoClassificador.setDataModificacao(assuntoClassificador.getDataCriacao());
                assuntoClassificador.setIdClassificador(idClassificador);
                assuntoClassificador = assuntoClassificadorDao.persist(assuntoClassificador);
            }
        }else{
            AssuntoClassificador assuntoConsultado = buscarAssunto(assuntoClassificador.getId());
            if (!nomeAssuntoFormulario.equals(assuntoConsultado.getNome())) {
                if(!isAssuntoCadastrado(idClassificador, assuntoClassificador)){
                    assuntoClassificador.setDataModificacao(new Date());
                    assuntoClassificador = assuntoClassificadorDao.persist(assuntoClassificador);
                }
            }
        }

        if(assuntoAlterado) {
            atualizarDataModificacaoAssunto(assuntoClassificador.getId());
        }
        assuntoClassificadorDao.flush();
        return assuntoClassificador;
    }

    private void atualizarDataModificacaoAssunto(Integer idClassificador) {
        AssuntoClassificador a = assuntoClassificadorDao.findIdAssunto(idClassificador);
        a.setDataModificacao(new Date());
        assuntoClassificadorDao.persist(a);
    }

    public AssuntoClassificador buscarAssunto(int idAssunto) {       
        return assuntoClassificadorDao.findIdAssunto(idAssunto);
    }
    
    /**
     * Verifica se existe o Assunto no Classificador, (true=Sim, false=Não)
     * @param idClassificador
     * @param assunto
     * @return (true=Sim, false=Não)
     * @throws NegocioException
     */
    private boolean isAssuntoCadastrado(int idClassificador, AssuntoClassificador assunto) throws NegocioException {
        String nomeAssuntoFormulario = assunto.getNome();
        List<AssuntoClassificador> listaAssuntos = assuntoClassificadorDao.findByClassificador(idClassificador);
        for (AssuntoClassificador assuntoAux : listaAssuntos) {
            if (!assuntoAux.getId().equals(assunto.getId()) && nomeAssuntoFormulario.toUpperCase().equals(assuntoAux.getNome().toUpperCase())) {
                throw new NegocioException("Entidade: "+ nomeAssuntoFormulario+" já existe!");
            }
        }

        return false;
    }

    public void limparPorClassificador(Integer idClassificador) {
        
        List<AssuntoClassificador> assuntos = assuntoClassificadorDao.listarVersao(idClassificador);
        int size = assuntos.size();
        int i = 0;
        for (AssuntoClassificador assuntoClassificador : assuntos) {
            String msg = "Removendo assunto " + ++i + "/" + size; 
            cacheProgresso.atualizar("RECOVERY_" + idClassificador + "_PROGRESSO", 1, msg);
            excluir(assuntoClassificador);
        }
    }

    private void excluir(AssuntoClassificador assuntoClassificador) {
        assuntoClassificadorDao.remove(assuntoClassificador);
    }
}
