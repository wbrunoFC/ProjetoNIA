package br.com.bb.gearq.c4coleta.manager;

import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.gearq.c4coleta.dao.ValoresServicosCognitivosDao;
import br.com.bb.gearq.c4coleta.model.ValoresServicosCognitivos;
import br.com.bb.gearq.c4coleta.util.FormatarData;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("valoresServicosCognitivosManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)

public class ValoresServicosCognitivosManager {
	
	@In(create = true)
	private ValoresServicosCognitivosDao valoresServicosCognitivosDao;
	
	public void salvar(ValoresServicosCognitivos valoresServicosCognitivos, String dataIncMinima, double valorSrvcCognitivoAnterior, String dataInicioVigenciaAnterior){
		
		if (valoresServicosCognitivos.getDtIncVgc() != null){
			if  (valoresServicosCognitivos.getDtIncVgc().before(FormatarData.formatarStringParaData(dataIncMinima))){
				throw new NegocioException("Data do início da vigência não pode ser anterior a: "+dataIncMinima);
			}
		}else {
			throw new NegocioException("Erro! O campo Data do início da vigência é obrigatório!");
		}
		
		if (valoresServicosCognitivos.getValorSrvcCognitivo() != null){
			if(valorSrvcCognitivoAnterior == valoresServicosCognitivos.getValorSrvcCognitivo()){
				throw new NegocioException("O valor por chamada não foi alterado.");
			}
		}else {
			throw new NegocioException("Erro! O campo Valor por Chamada é obrigatório!");
		}
		
		
		double novoValor = valoresServicosCognitivos.getValorSrvcCognitivo();
		Date novaData = valoresServicosCognitivos.getDtIncVgc(); 
		
		if(valoresServicosCognitivos.getId() != null){
			valoresServicosCognitivos.setDtFimVgc(valoresServicosCognitivos.getDtIncVgc());
			valoresServicosCognitivos.setDtIncVgc(FormatarData.formatarStringParaData(dataInicioVigenciaAnterior));
			valoresServicosCognitivos.setValorSrvcCognitivo(valorSrvcCognitivoAnterior);
			// atualizar a data fim de vigencia com o inicio da nova data de inicio.
			valoresServicosCognitivosDao.persist(valoresServicosCognitivos);
		}
		
		valoresServicosCognitivos.setId(null);
		valoresServicosCognitivos.setDtFimVgc(null);
		valoresServicosCognitivos.setValorSrvcCognitivo(novoValor);
		valoresServicosCognitivos.setDtIncVgc(novaData);
		// incluir um novo valor do serviços cognitivos.
		valoresServicosCognitivosDao.persist(valoresServicosCognitivos);
	
	}

}
