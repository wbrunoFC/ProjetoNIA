package br.com.bb.gearq.c4coleta.manager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;

import br.com.bb.customizacao.vos.UsuarioVO;
import br.com.bb.gearq.c4coleta.dao.UsuarioDao;
import br.com.bb.gearq.c4coleta.model.Usuario;


@Name("usuarioManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class UsuarioManager {

    @In(create = true)
    private UsuarioDao usuarioDao;

    public Usuario obterUsuarioLogado(UsuarioVO funci) {
        if (funci != null) {
            String chave = funci.getChave();
            return usuarioDao.findByChave(chave);
        }
        return null;
    }

    public Integer obterIdUsuarioLogado(UsuarioVO funci) {
        Usuario usuarioLogado = obterUsuarioLogado(funci);
        if (usuarioLogado != null) {
            return usuarioLogado.getId();
        }
        return null;
    }

}
