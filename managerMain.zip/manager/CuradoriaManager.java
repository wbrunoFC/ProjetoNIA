package br.com.bb.gearq.c4coleta.manager;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.TransactionPropagationType;
import org.jboss.seam.annotations.Transactional;
import org.json.JSONArray;
import org.json.JSONObject;

import br.com.bb.gearq.c4coleta.dao.ClassificadorDao;
import br.com.bb.gearq.c4coleta.dao.FluxoDao;
import br.com.bb.gearq.c4coleta.dao.IntencaoDao;
import br.com.bb.gearq.c4coleta.dao.LogNiaInfraDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoEntidadeDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoIntencaoDao;
import br.com.bb.gearq.c4coleta.dao.PerguntaRevisaoUsuarioDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoDao;
import br.com.bb.gearq.c4coleta.dao.RespostaDialogoSlotDao;
import br.com.bb.gearq.c4coleta.dao.TipoRespostaIntencaoDao;
import br.com.bb.gearq.c4coleta.model.Classificador;
import br.com.bb.gearq.c4coleta.model.Fluxo;
import br.com.bb.gearq.c4coleta.model.Intencao;
import br.com.bb.gearq.c4coleta.model.LogNiaInfra;
import br.com.bb.gearq.c4coleta.model.Pergunta;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoEntidade;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoIntencao;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoStatus;
import br.com.bb.gearq.c4coleta.model.PerguntaRevisaoUsuario;
import br.com.bb.gearq.c4coleta.model.RespostaDialogo;
import br.com.bb.gearq.c4coleta.model.RespostaDialogoSlot;
import br.com.bb.gearq.c4coleta.model.TipoRespostaIntencao;
import br.com.bb.gearq.c4coleta.util.JSONUtils;
import br.com.bb.gearq.c4coleta.vo.ContextoConversaVO;
import br.com.bb.gearq.c4coleta.vo.FiltrosPesquisaVO;
import br.com.bb.gearq.c4coleta.vo.Paginacao;
import br.com.bb.gearq.c4coleta.vo.UsuarioDialogoVO;
import br.com.bb.sos.infra.exceptions.NegocioException;

@Name("curadoriaManager")
@Scope(ScopeType.EVENT)
@Transactional(TransactionPropagationType.REQUIRED)
public class CuradoriaManager {

	private static final String PERGUNTAS_COLUNA_VAZIA = "Não é possível mapear, existem perguntas com a coluna intenção vazio.";

	@In(create = true)
	private PerguntaRevisaoDao perguntaRevisaoDao;
	
	@In(create = true)
	private PerguntaRevisaoIntencaoDao perguntaRevisaoIntencaoDao;

	@In(create = true)
	private PerguntaRevisaoEntidadeDao perguntaRevisaoEntidadeDao;

	@In(create = true)
	private IntencaoDao intencaoDao;
	
	@In(create=true)
	private PerguntaDao perguntaDao;
	
	@In(create=true)
	private TipoRespostaIntencaoDao tipoRespostaIntencaoDao;
	
	@In(create=true)
	private EmailManager emailManager;
	
	@In(create = true)
	private PerguntaRevisaoUsuarioDao perguntaRevisaoUsuarioDao;
	
	@In(create = true)
	private LogNiaInfraDao logNiaInfraDao;
	
	@In(create = true)
    	FluxoDao fluxoDao;
	
	@In(create = true)
    	RespostaDialogoDao respostaDialogoDao;
	
	@In(create = true)
	private ClassificadorManager classificadorManager;
	
	@In(create = true)
    private RespostaDialogoSlotDao respostaDialogoSlotDao;
	
	@In(create = true)
    private EntidadeManager entidadeManager;
	
	
//	public Paginacao<PerguntaRevisao> listarPerguntasRevisao(Paginacao<PerguntaRevisao> paginacao,String pergunta,String intencao,Integer idClassificador,boolean intencaoIsNUll) throws NegocioException{
//			paginacao = perguntaRevisaoDao.findPerguntaRevisao(paginacao, pergunta, intencao,idClassificador,intencaoIsNUll);
//			//entidadeAgrupador
//			if(paginacao.getListaPaginada()!=null){
//				
//				List<PerguntaRevisao> listaAux = new ArrayList<PerguntaRevisao>();
//				for(PerguntaRevisao pr: paginacao.getListaPaginada()){
//					
//					PerguntaRevisao prNovo = new PerguntaRevisao();
//					prNovo.setClassificador(pr.getClassificador());
//					prNovo.setDataCriacao(pr.getDataCriacao());
//					prNovo.setEntidadeAgrupador(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pr.getId()));
//				//	prNovo.setFeedback(pr.getFeedback());
//					prNovo.setId(pr.getId());
//					prNovo.setIntencao(pr.getIntencao());
//					prNovo.setPergunta(pr.getPergunta());
//					prNovo.setQuantidade(pr.getQuantidade());
//					
//					listaAux.add(prNovo);
//					
//				}
//				
//				paginacao.setListaPaginada(listaAux);			
//				
//			}
//			
//			
//			return paginacao;
//	}	
	
	public Paginacao<PerguntaRevisaoIntencao> intencaoRevisao(int idPerguntaRevisao, Integer idClassificador, String intencao, Paginacao<PerguntaRevisaoIntencao> paginacao){
		DecimalFormat df = new DecimalFormat("0.##");
		paginacao = perguntaRevisaoIntencaoDao.findByIntencoesRevisao(idPerguntaRevisao,paginacao);
		List<PerguntaRevisaoIntencao> listaPergunta = new ArrayList<PerguntaRevisaoIntencao>();
		if(paginacao.getListaPaginada()!=null && 
		        paginacao.getListaPaginada().size() > 0 && 
		        intencao.length() == 0){
			
			for(PerguntaRevisaoIntencao ip: paginacao.getListaPaginada()){
				//ip.setNomeConfianca(ip.getConfianca()+"% |"+ip.getIntencao().getNome());
				ip.setNomeConfianca(df.format((ip.getConfianca()*100))+"% | "+ip.getNome());
			}
			return paginacao;
		}else{
			List<Intencao> listaIntecao = intencaoDao.findListaIntencoes(idClassificador, intencao);
			
			if(listaIntecao != null && listaIntecao.size() > 0){
				for(Intencao i :listaIntecao){
					PerguntaRevisaoIntencao pr = new PerguntaRevisaoIntencao();
					pr.setConfianca(0d);
					pr.setId(0);
					pr.setIntencao(i);
					pr.setNome(i.getNome());
					pr.setNomeConfianca(i.getNome());
					pr.setPerguntaRevisao(null);
					listaPergunta.add(pr);
					
				}
			}
			
		}
		
		//paginacao.setListaPaginada(new ArrayList<PerguntaRevisaoIntencao>());
		paginacao.setListaPaginada(listaPergunta);
		return paginacao;
	}
	public List<PerguntaRevisaoEntidade> entidadeAgrupadorRevisao(int idPerguntaRevisao){
		
		List<PerguntaRevisaoEntidade> listaIp= perguntaRevisaoEntidadeDao.findByEntidadesRevisao(idPerguntaRevisao);
		
		return listaIp;
	}
	
	public Paginacao<PerguntaRevisao> filtroPesquisa(FiltrosPesquisaVO filtro){
		
        if(filtro.getAgrupador()!=null && filtro.getAgrupador().getIdEntidade() != null) {
            filtro.getAgrupador().setEntidade(entidadeManager.buscarEntidade(filtro.getAgrupador().getIdEntidade()));            
        }
	    
		Paginacao<PerguntaRevisao> paginacao = perguntaRevisaoDao.findPerguntaRevisao(filtro);
		List<PerguntaRevisao> perguntas = new ArrayList<PerguntaRevisao>();
		if( paginacao.getListaPaginada() != null ){
			for( PerguntaRevisao pr : paginacao.getListaPaginada() ){
				
				PerguntaRevisao pergunta = (PerguntaRevisao) pr.clone();
				
				pergunta.setEntidadeAgrupador(perguntaRevisaoEntidadeDao.findByEntidadesRevisao(pergunta.getId()));
				if(pergunta.getIdIntencaoRevisao() != null && 
				        pergunta.getIdIntencaoRevisao() != 0){
					
					DecimalFormat df = new DecimalFormat("0.##");			
					PerguntaRevisaoIntencao intencaoRevisao = perguntaRevisaoIntencaoDao.findById(pergunta.getIdIntencaoRevisao());
					pergunta.setIntencaoRevisao(intencaoRevisao);
					
					    pergunta.getIntencaoRevisao()
					    .setNomeConfianca(df.format((intencaoRevisao.getConfianca()*100))+"% | "+intencaoRevisao.getNome());
				}
				
				if(filtro.getCurada()!=null && 
				   filtro.getCurada()){
					
					pergunta.setDataCuradoria(perguntaRevisaoDao.findPerguntaRevisaoAudi(pergunta.getId()));
					
				}
				
				perguntas.add(pergunta);
				
			}
		}
		
		paginacao.setListaPaginada(perguntas);
		
		
		return paginacao;
	}
	
	public void mapear( List<PerguntaRevisao> perguntasRevisao,boolean vincular) throws NegocioException{
			
			if( perguntasRevisao == null || perguntasRevisao.size() == 0 ){
				throw new NegocioException("Selecione ao menos uma pergunta");
			}
			// validação 
			for(PerguntaRevisao p: perguntasRevisao){
				if(p.getIntencaoRevisao() == null){
					throw new NegocioException(PERGUNTAS_COLUNA_VAZIA);
				}
				if(p.getIntencaoRevisao().getIntencao() == null){
					throw new NegocioException("Não é possível mapear, existem perguntas com intenção não cadastradas");
				}
				
				
			}// fim do for de validação. 
			
			
			List<PerguntaRevisao> perguntasEmailJaVinculadas = new ArrayList<PerguntaRevisao>(); 
			
			// verificar se a pergunta já existe
	        for( PerguntaRevisao pergunta : perguntasRevisao ){
	            List<Pergunta> perguntas = perguntaDao.findIgual(pergunta.getClassificador().getId(), pergunta.getPergunta());
	            
	            if( perguntas != null && perguntas.size() > 0 ){
	            			
	            	for(Pergunta p: perguntas){
	            		
	            		if(p.getIntencao().getId() != 
	            		        pergunta.getIntencaoRevisao().getIntencao().getId()){
	            			
	            			//atualiza a intenção da pergunta já cadastrada.
	            			p.setIdIntencao(pergunta.getIntencaoRevisao().getIntencao().getId());
	            			perguntaDao.persist(p);	            			
	            		}; 
	            		
	            	}
	            }
	            
	            // REVISAO_PRIORITARIA	            
	            if(pergunta.getStatus() == PerguntaRevisaoStatus.REVISAO_PRIORITARIA){
	            	perguntasEmailJaVinculadas.add(pergunta);
	            }
	            
	            
	        }
	        
			for( PerguntaRevisao pgRev : perguntasRevisao ){
				
				Pergunta perguntaExistente = null;
	            List<Pergunta> perguntas = perguntaDao.findIgual(pgRev.getClassificador().getId(), pgRev.getPergunta());
				
	            if( perguntas != null && perguntas.size() > 0 ){
	            	perguntaExistente = perguntas.get(0);
	            }
	            
				if( !perguntasEmailJaVinculadas.contains(pgRev) && vincular){
					
					if( perguntaExistente == null ){
						Pergunta pergunta = new Pergunta();
						pergunta.setIntencao(pgRev.getIntencaoRevisao().getIntencao());
						pergunta.setDataCriacao(new Date());
						pergunta.setPergunta(pgRev.getPergunta());
						perguntaDao.persist(pergunta);
					}
				
					pgRev.setStatus(PerguntaRevisaoStatus.CURADA);
					pgRev.setIntencao(pgRev.getIntencaoRevisao().getIntencao());
					pgRev.setNomeIntencao(pgRev.getIntencaoRevisao().getIntencao().getNome());
					pgRev.setIdIntencaoRevisao(pgRev.getIntencaoRevisao().getId());
					perguntaRevisaoDao.persist(pgRev);
				
				}else{
				
					PerguntaRevisaoIntencao perguntaRevisaoIntencao = pgRev.getIntencaoRevisao();
					
					
					if(perguntaExistente != null){
						
						// caso a intenção seja diferente, modificar intenção da pergunta. 
						if(perguntaExistente.getIntencao().getId() != perguntaRevisaoIntencao.getIntencao().getId()){
							perguntaExistente.setIntencao(perguntaRevisaoIntencao.getIntencao());
							perguntaDao.persist(perguntaExistente);
							
						}
						
						//atualizando os dados da tabela pergunta_revisao
						//pgRev = perguntaRevisaoDao.findById(pgRev.getId());
						pgRev.setIdIntencaoRevisao(perguntaRevisaoIntencao.getId());
						pgRev.setStatus(PerguntaRevisaoStatus.CURADA);
						pgRev.setIntencao(pgRev.getIntencaoRevisao().getIntencao());
						pgRev.setNomeIntencao(pgRev.getIntencaoRevisao().getIntencao().getNome());
						pgRev.setIdIntencaoRevisao(pgRev.getIntencaoRevisao().getId());
						perguntaRevisaoDao.persist(pgRev);
						
					}else{
						
						// caso a pergunta não exista na tabela PERGUNTA, 
						// sera cadastrada e modificada o status na tabela pergunta_revisao 
						if(vincular){
							Pergunta pergunta = new Pergunta();
							pergunta.setIntencao(pgRev.getIntencaoRevisao().getIntencao());
							pergunta.setDataCriacao(new Date());
							pergunta.setPergunta(pgRev.getPergunta());
							perguntaDao.persist(pergunta);
							
						}
						pgRev.setStatus(PerguntaRevisaoStatus.CURADA);
						pgRev.setIntencao(pgRev.getIntencaoRevisao().getIntencao());
						pgRev.setNomeIntencao(pgRev.getIntencaoRevisao().getIntencao().getNome());
						pgRev.setIdIntencaoRevisao(pgRev.getIntencaoRevisao().getId());
						perguntaRevisaoDao.persist(pgRev);
					}
				}
				
//				if( pgRev.getIntencaoRevisao() == null && 
//				    pgRev.getIdIntencaoRevisao() != null){
//					pgRev.setIntencaoRevisao(perguntaRevisaoIntencaoDao.findById(pgRev.getIdIntencaoRevisao()));
//				}
				
				if( pgRev.getIntencaoRevisao().getIntencao() != null){
					pgRev.setIntencao(pgRev.getIntencaoRevisao().getIntencao());
				}
			
				//envio de email é obrigatorio
				emailManager.enviar(pgRev);
			}
			
			perguntaDao.flush();			
			
			
		}

	
	
	public void mapearTodas(FiltrosPesquisaVO filtro) throws NegocioException{
		
		List<PerguntaRevisao> listaPr =  filtroPesquisa(filtro).getListaPaginada();
		
		try {
		//	mapear(listaPr);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	public Paginacao<PerguntaRevisaoUsuario> perguntaRevisaoUsuario(UsuarioDialogoVO usuariosVO){
	
		return	perguntaRevisaoUsuarioDao.findPergunta(usuariosVO);
	
	}
	
	
	public Paginacao<PerguntaRevisaoUsuario> usuarioPergunta(Paginacao<PerguntaRevisaoUsuario> paginacao, String usuario,Integer idClassificador){
	    
        return  perguntaRevisaoUsuarioDao.findUsuario(paginacao, usuario,  idClassificador);
    
    }
	
	
	/**
	 * recupera texto da conversa de acordo com o identificador do conversation id
	 * @param idConversa
	 * @param siglaServico
	 * @return
	 */
	public List<ContextoConversaVO> recuperarContextoConversa(String idConversa, String siglaServico, int limite){
		

	    
		List<ContextoConversaVO> dialogo = new ArrayList<ContextoConversaVO>();
		
		for( LogNiaInfra log : logNiaInfraDao.findContextoConversa(idConversa, "S", siglaServico)){
			
			if( log.getInput() != null && log.getInput().trim().length() > 0 ){
				ContextoConversaVO usuario = new ContextoConversaVO();
				usuario.setData(log.getDataHora());
				usuario.setTexto(log.getInput());
				usuario.setUsuario(true);
				if (log.getChaveTipoEntrada() != null && !log.getChaveTipoEntrada().trim().isEmpty()) {
				    usuario.setChaveTipoEntrada(Integer.parseInt(log.getChaveTipoEntrada()));
				}
				dialogo.add(usuario);
			}
			
			JSONObject conversa = JSONUtils.getJson(log.getJson());
			JSONObject output = JSONUtils.getJson(conversa, "output");
			JSONArray texts = JSONUtils.getJsonArray(output, "text");
			if( texts != null){ // Verificacao em duplicidade com a linha 435
			    texts.length();
			    for (int i = 0; i < texts.length(); i++) {
			        String resposta = texts.getString(i);
			        JSONObject jsonTitulo = JSONUtils.getJson(resposta);
			        if (jsonTitulo != null && !jsonTitulo.isNull("titulo") && jsonTitulo.get("titulo") instanceof String) {
			        	resposta = jsonTitulo.getString("titulo");
			        }
			        for (String respostaHash : getRespostasHash(resposta, siglaServico)) {
			            
			            // caso o limite seja maior que zero, verificar o tamanho da resposta e querbrar em varios blocos.			                
			                if(respostaHash.length() > limite && limite > 0) {
			                    String[] respostasSeparadasEspaco = respostaHash.split("\\s");	
			                    String textoRepostaFinal = "";
			                    for(String menorParteResposta: respostasSeparadasEspaco) {
			                        
			                        if(limite > (menorParteResposta.length() + textoRepostaFinal.length()) ) {
			                            textoRepostaFinal = textoRepostaFinal+" "+ menorParteResposta;
			                        }else {
			                            dialogo.add(blocoResp(textoRepostaFinal, log));
			                            textoRepostaFinal = menorParteResposta;
			                        }			                        
			                    }
			                    // depois de percorrer  o for, caso reste algum trecho da resposta, cria mais um bloco.
			                    if(!textoRepostaFinal.isEmpty()) {			                        
			                        dialogo.add(blocoResp(textoRepostaFinal, log));
			                    }
			                    
			            }else {
			                dialogo.add(blocoResp(respostaHash, log));                
			                
			            }
			        }
			        
			    }
			}
		}
		
		return dialogo;
	}	 
	
    private ContextoConversaVO blocoResp(String respostaHash, LogNiaInfra log) {
        ContextoConversaVO bot = new ContextoConversaVO();
        bot.setData(log.getDataHora());
        bot.setTexto(respostaHash);
        bot.setUsuario(false);
        return bot;
    }
	
	private static boolean isHash(String texto){
        return texto != null && // Verificacao em duplicidade com a linha 406
               texto.length() == 36 && 
               texto.split("-").length == 5;
    }
	
	private List<String> getRespostasHash(String texto, String siglaServico) {
	    
	    if (!isHash(texto)) {
	        return Arrays.asList(texto);
	    }
	    
	    Boolean isdialogo = false;
	    Classificador classificador = classificadorManager.getClassificadorPorServico(siglaServico);
        if(classificador != null){
            isdialogo = classificador.getIndDialogo();
        }
	    
        if (isdialogo) {
            return getRespostaDialogo(texto, siglaServico);
        } 
        
        return getRespostaIntencao(texto, siglaServico);
    }
	
	private List<String> getRespostaDialogo(String texto, String siglaServico) {
	    List<String> resultado = new ArrayList<String>();
	    
	    // Se node padrao	    
	    int bloco = 0;
	    for (RespostaDialogo resp : respostaDialogoDao.findByNomeHashNuvem(texto, siglaServico)) {
            if (resp.getTipoResposta().getId() == 1 && bloco != resp.getId().getSequenciaBloco()) {
                resultado.add(resp.getTextoResposta());
                bloco = resp.getId().getSequenciaBloco();
            }
        }
	    
	    // Se SLOT nao preenchido	    
	    if (resultado.isEmpty()) {
            bloco = 0;
            for (RespostaDialogoSlot resposta : respostaDialogoSlotDao.findByHash(texto)) {
                if (resposta.getTipoResposta().getId() == 1 && bloco != resposta.getId().getSequenciaBloco()) {
                    resultado.add(resposta.getTextoResposta());
                    bloco = resposta.getId().getSequenciaBloco();
                }
            }
        }
	    
	    return resultado;
	}
	
	private List<String> getRespostaIntencao(String texto, String siglaServico) {
        List<String> resultado = new ArrayList<String>();
        
        // Se intenção
        for (TipoRespostaIntencao resp : tipoRespostaIntencaoDao.findByNomeHashNuvem(texto, siglaServico)) {
            resultado.add(resp.getTextoResposta());
        }
        
        // Se fluxo
        if (resultado.isEmpty()) {
            Fluxo fluxo = fluxoDao.findByHashNuvem(texto);
            if( fluxo != null ){
                resultado.add(fluxo.getPerguntaDesambiguacao());
            } else {
                resultado.add(texto);
            }
        }
        
        return resultado;
    }
	
}
